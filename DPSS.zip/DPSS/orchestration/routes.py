"""LangGraph routing functions.

All conditional edge logic lives here, keeping orchestration/graph.py focused
on node registration and edge wiring only.
"""
from __future__ import annotations

from core.logging_utils import get_logger, setup_logging
from core.schemas import SessionState

setup_logging()
_logger = get_logger(__name__)


def route_after_sufficiency(state: SessionState) -> str:
    """Route after the sufficiency check node."""
    sr = state.sufficiency_report
    if sr is None or not sr.can_solve_now:
        decision = "generate_ask_back"
    elif sr.solve_mode == "degraded" and not state.degraded_solve_confirmed:
        decision = "confirm_degraded"
    else:
        decision = "build_payload"
    _logger.info(
        "[ROUTE] after_sufficiency -> %s | can_solve=%s | mode=%s",
        decision,
        getattr(sr, "can_solve_now", None),
        getattr(sr, "solve_mode", None),
    )
    return decision


def route_after_merge(state: SessionState) -> str:
    """Route after the ask-back merge node."""
    decision = "recheck"
    for msg in reversed(state.user_messages[-5:]):
        if msg.get("type") == "ask_back_merge":
            decision = "remap" if msg.get("requires_remap") else "recheck"
            break
    _logger.info("[ROUTE] after_merge -> %s", decision)
    return decision


def route_after_solve(state: SessionState) -> str:
    """Route after the solver node."""
    status = state.solver_result.solve_status if state.solver_result else "UNKNOWN"
    if state.solver_result and status in ("INFEASIBLE", "UNKNOWN"):
        decision = "explain_infeasible"
    else:
        decision = "validate"
    _logger.info("[ROUTE] after_solve -> %s | solve_status=%s", decision, status)
    return decision
