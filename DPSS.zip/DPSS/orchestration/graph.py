"""LangGraph orchestration — StateGraph[SessionState].

Human-in-the-loop via interrupt_before=["merge_answers", "confirm_degraded"].
Resume with graph.invoke(None, config) after graph.update_state(...).

Node registration and edge wiring only. Routing logic lives in routes.py.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph

from agents.ask_back import (
    confirm_degraded_node,
    generate_ask_back_node,
    merge_answers_node,
)
from agents.constraint_registry import register_constraints_node
from agents.data_sufficiency import check_sufficiency_node
from agents.explanation_qa import explain_infeasible_node, explain_node
from agents.input_understanding import understand_problem_node
from agents.objective_constraint import extract_obj_const_node
from agents.payload_builder import build_payload_node
from agents.post_solve_validation import validate_solution_node
from agents.schema_mapping import map_schema_node
from core.logging_utils import get_logger, log_node_end, log_node_start, setup_logging
from core.schemas import SessionState, SourceInventory
from ingestion.workbook_profiler import profile_csv, profile_prompt, profile_xlsx
from orchestration.routes import route_after_merge, route_after_solve, route_after_sufficiency
from solver.cp_sat_solver import solve_node

setup_logging()
_logger = get_logger(__name__)


# =============================================================================
# Logging wrappers for each node
# =============================================================================

def _wrap(name: str, fn):
    """Wrap a node function with standard-logging entry/exit and timing."""
    def wrapped(state: SessionState) -> dict:
        t0 = log_node_start(_logger, name)
        result = fn(state)
        # Build compact summary from result dict
        kv: dict = {}
        if "current_stage" in result:
            kv["stage"] = result["current_stage"]
        errs = result.get("errors", [])
        if errs:
            kv["errors"] = len(errs)
            for e in errs:
                _logger.warning("[NODE] %s | ERROR: %s", name, e)
        log_node_end(_logger, name, t0, **kv)
        return result
    wrapped.__name__ = name
    return wrapped


# =============================================================================
# Profile input node
# =============================================================================

def _profile_input_node(state: SessionState) -> dict:
    """Deterministic: profile raw file/prompt into SourceInventory."""
    refs = state.raw_input_refs
    if not refs:
        return {"errors": state.errors + ["profile_input: no raw_input_refs"]}

    src = state.source_type
    _logger.info("[NODE] START profile_input | source_type=%s | ref=%s", src, refs[0][:60])
    import time as _t
    t0 = _t.perf_counter()
    try:
        if src == "xlsx":
            inventory = profile_xlsx(refs[0])
        elif src == "csv":
            inventory = profile_csv(refs[0])
        else:  # prompt
            inventory = profile_prompt(refs[0])
        elapsed = (_t.perf_counter() - t0) * 1000
        _logger.info(
            "[NODE] END profile_input | elapsed=%.0fms | tables=%s | rows=%s",
            elapsed, inventory.detected_tables, inventory.row_counts,
        )
    except Exception as e:
        _logger.exception("[NODE] profile_input FAILED: %s", e)
        return {"errors": state.errors + [f"profile_input: {e}"]}

    return {
        "source_inventory": inventory,
        "current_stage": "INPUT_RECEIVED",
    }


profile_input_node = _wrap("profile_input", _profile_input_node)


# =============================================================================
# Graph builder
# =============================================================================

def build_graph():
    """Compile and return the LangGraph StateGraph with MemorySaver checkpointer."""
    _logger.info("[GRAPH] Building graph …")
    g: StateGraph = StateGraph(SessionState)

    # ---- Node registration (all wrapped with logging)
    nodes = [
        ("profile_input",        profile_input_node),
        ("understand_problem",   understand_problem_node),
        ("map_schema",           map_schema_node),
        ("extract_obj_const",    extract_obj_const_node),
        ("register_constraints", register_constraints_node),
        ("check_sufficiency",    check_sufficiency_node),
        ("generate_ask_back",    generate_ask_back_node),
        ("merge_answers",        merge_answers_node),
        ("confirm_degraded",     confirm_degraded_node),
        ("build_payload",        build_payload_node),
        ("solve",                solve_node),
        ("validate_solution",    validate_solution_node),
        ("explain",              explain_node),
        ("explain_infeasible",   explain_infeasible_node),
    ]
    for node_name, fn in nodes:
        # profile_input already wrapped above; wrap all others
        if node_name == "profile_input":
            g.add_node(node_name, fn)
        else:
            g.add_node(node_name, _wrap(node_name, fn))
    _logger.info("[GRAPH] Registered %d nodes", len(nodes))

    # ---- Entry point
    g.set_entry_point("profile_input")

    # ---- Linear pipeline
    g.add_edge("profile_input",        "understand_problem")
    g.add_edge("understand_problem",   "map_schema")
    g.add_edge("map_schema",           "extract_obj_const")
    g.add_edge("extract_obj_const",    "register_constraints")
    g.add_edge("register_constraints", "check_sufficiency")

    # ---- Sufficiency branch: ask-back loop | confirm degraded | build payload
    g.add_conditional_edges(
        "check_sufficiency",
        route_after_sufficiency,
        {
            "generate_ask_back": "generate_ask_back",
            "confirm_degraded":  "confirm_degraded",
            "build_payload":     "build_payload",
        },
    )

    # ---- Ask-back loop
    g.add_edge("generate_ask_back", "merge_answers")
    g.add_conditional_edges(
        "merge_answers",
        route_after_merge,
        {
            "remap":   "map_schema",
            "recheck": "check_sufficiency",
        },
    )

    # ---- Degraded confirmation → build payload
    g.add_edge("confirm_degraded", "build_payload")

    # ---- Solve branch
    g.add_edge("build_payload", "solve")
    g.add_conditional_edges(
        "solve",
        route_after_solve,
        {
            "validate":          "validate_solution",
            "explain_infeasible": "explain_infeasible",
        },
    )

    # ---- Post-solve
    g.add_edge("validate_solution", "explain")
    g.add_edge("explain",            END)
    g.add_edge("explain_infeasible", END)

    compiled = g.compile(
        checkpointer=MemorySaver(),
        interrupt_before=["merge_answers", "confirm_degraded"],
    )
    _logger.info("[GRAPH] Compiled. interrupt_before=['merge_answers', 'confirm_degraded']")
    return compiled


# =============================================================================
# Initial state factory
# =============================================================================

def build_initial_state(
    source_type: str,
    raw_ref: str,
    horizon_start: datetime | None = None,
    time_unit_minutes: int = 1,
) -> dict:
    """Build the initial SessionState dict for a fresh pipeline run."""
    session_id = str(uuid.uuid4())
    h_start = horizon_start or datetime.now(tz=timezone.utc).replace(microsecond=0)
    _logger.info("\n" + "=" * 60)
    _logger.info(
        "[APP] Run requested | source_type=%s | horizon_start=%s | session_id=%s",
        source_type, h_start, session_id,
    )
    _logger.info("[APP] raw_ref=%s", raw_ref[:80])
    return {
        "session_id": session_id,
        "source_type": source_type,
        "raw_input_refs": [raw_ref],
        "user_messages": [],
        "current_stage": "INPUT_RECEIVED",
        "time_unit_minutes": time_unit_minutes,
        "horizon_start": h_start,
        "objectives": [],
        "constraint_candidates": [],
        "ask_back_questions": [],
        "ask_back_answers": {},
        "degraded_solve_confirmed": False,
        "warnings": [],
        "errors": [],
    }
