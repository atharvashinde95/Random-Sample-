"""Checkpoint utilities for the LangGraph pipeline.

Thin wrappers around LangGraph's MemorySaver that standardise how the rest of
the application interacts with thread-keyed state. Keeping this isolated makes
it straightforward to swap MemorySaver for a persistent backend (e.g. Redis or
PostgreSQL) in a future phase without touching app.py or the graph.
"""
from __future__ import annotations

from typing import Any

from langgraph.checkpoint.memory import MemorySaver


def make_config(thread_id: str) -> dict[str, Any]:
    """Return a LangGraph invocation config for the given thread."""
    return {"configurable": {"thread_id": thread_id}}
