"""Profile XLSX, CSV, or prompt inputs into a compact SourceInventory.

Notes:
- Sample rows are truncated to MAX_CELL_LEN characters per cell to limit
  token cost and reduce risk of leaking long PII strings to the local LLM.
- All values are JSON-serializable (datetimes → ISO strings, NaN → None).
- Profilers are pure: same path/text → same SourceInventory.
"""
from __future__ import annotations

import math
from datetime import date, datetime
from pathlib import Path
from typing import Any, Optional

import pandas as pd

from core.constants import MAX_CELL_LEN, MAX_SAMPLE_ROWS
from core.schemas import SourceInventory


def profile_xlsx(path: str) -> SourceInventory:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    xl = pd.ExcelFile(p, engine="openpyxl")
    detected_tables: list[str] = list(xl.sheet_names)
    detected_columns: dict[str, list[str]] = {}
    row_counts: dict[str, int] = {}
    sample_summary: dict[str, list[dict]] = {}
    for sheet in detected_tables:
        df = xl.parse(sheet)
        df.columns = [str(c) for c in df.columns]
        detected_columns[sheet] = list(df.columns)
        row_counts[sheet] = int(len(df))
        sample_summary[sheet] = _df_to_safe_records(df.head(MAX_SAMPLE_ROWS))
    return SourceInventory(
        source_type="xlsx",
        detected_tables=detected_tables,
        detected_columns=detected_columns,
        row_counts=row_counts,
        sample_summary=sample_summary,
        file_metadata={"filename": p.name, "size_bytes": p.stat().st_size, "format": "xlsx"},
    )


def profile_csv(path: str, table_name: Optional[str] = None) -> SourceInventory:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    df = pd.read_csv(p)
    df.columns = [str(c) for c in df.columns]
    name = table_name or p.stem
    return SourceInventory(
        source_type="csv",
        detected_tables=[name],
        detected_columns={name: list(df.columns)},
        row_counts={name: int(len(df))},
        sample_summary={name: _df_to_safe_records(df.head(MAX_SAMPLE_ROWS))},
        file_metadata={"filename": p.name, "size_bytes": p.stat().st_size, "format": "csv"},
    )


def profile_prompt(text: str) -> SourceInventory:
    """Profile a free-text prompt — no tables or columns to extract."""
    return SourceInventory(
        source_type="prompt",
        detected_tables=[],
        detected_columns={},
        row_counts={},
        sample_summary={},
        file_metadata={"prompt_length": len(text), "prompt_preview": text[:512]},
    )


# =============================================================================
# Full data loaders (used by agents/schema_mapping after the LLM proposes a mapping)
# =============================================================================

def load_xlsx_tables(path: str) -> dict[str, pd.DataFrame]:
    xl = pd.ExcelFile(path, engine="openpyxl")
    return {sheet: _normalise_df(xl.parse(sheet)) for sheet in xl.sheet_names}


def load_csv_table(path: str, table_name: Optional[str] = None) -> dict[str, pd.DataFrame]:
    p = Path(path)
    return {(table_name or p.stem): _normalise_df(pd.read_csv(p))}


def _normalise_df(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [str(c) for c in df.columns]
    return df


# =============================================================================
# Internal helpers
# =============================================================================

def _df_to_safe_records(df: pd.DataFrame) -> list[dict]:
    return [{str(col): _safe_value(val) for col, val in row.items()} for _, row in df.iterrows()]


def _safe_value(v: Any) -> Any:
    if v is None:
        return None
    if isinstance(v, float):
        if math.isnan(v) or math.isinf(v):
            return None
        return v
    if isinstance(v, (int, bool)):
        return v
    if isinstance(v, (datetime, date, pd.Timestamp)):
        try:
            return v.isoformat()
        except Exception:
            return str(v)
    s = str(v)
    return s[:MAX_CELL_LEN] + "..." if len(s) > MAX_CELL_LEN else s
