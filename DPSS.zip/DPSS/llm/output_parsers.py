"""Shared output parsing utilities for LLM responses.

Thin helpers used by multiple agents to coerce raw LLM text into typed values.
Heavy field-level coercion lives in agents/schema_mapping.py; this module
covers only generic, reusable primitives.
"""
from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any, Optional

from dateutil import parser as date_parser


def to_int(v: Any) -> Optional[int]:
    """Coerce a raw cell/JSON value to int. Returns None on failure."""
    if v is None:
        return None
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        if math.isnan(v) or math.isinf(v):
            return None
        return int(v)
    s = str(v).strip()
    if not s:
        return None
    try:
        return int(float(s))
    except (TypeError, ValueError):
        return None


def to_float(v: Any) -> Optional[float]:
    """Coerce a raw cell/JSON value to float. Returns None on failure."""
    if v is None:
        return None
    if isinstance(v, bool):
        return float(v)
    if isinstance(v, (int, float)):
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            return None
        return float(v)
    s = str(v).strip()
    if not s:
        return None
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def to_datetime(v: Any) -> Optional[datetime]:
    """Coerce a raw cell/JSON value to a timezone-aware datetime. Returns None on failure."""
    if v is None:
        return None
    if isinstance(v, datetime):
        return v if v.tzinfo else v.replace(tzinfo=timezone.utc)
    s = str(v).strip()
    if not s:
        return None
    try:
        dt = date_parser.parse(s)
    except (ValueError, OverflowError, date_parser.ParserError):
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
