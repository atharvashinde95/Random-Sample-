"""Prompt templates for the four LLM stages.

Strict rules:
- The LLM is told the allow-lists explicitly (no hidden alias maps in code).
- Each system prompt forbids invented fields and requires JSON output (where applicable).
- The explanation prompt forbids inventing facts outside the ExplanationContext.
"""
from __future__ import annotations

import json
from typing import Optional

from core.schemas import (
    CanonicalEntities,
    ExplanationContext,
    ProblemUnderstandingReport,
    SourceInventory,
)

# =============================================================================
# Allow-lists — passed to the LLM at runtime; not used as fallback dictionaries
# =============================================================================

ALLOWED_CANONICAL_ENTITIES: list[str] = [
    "job",
    "operation",
    "resource",
    "operation_eligibility",
    "calendar_window",
    "setup_rule",
    "material",
    "inventory_record",
    "bom_link",
    "cost_parameter",
]

ALLOWED_CANONICAL_FIELDS: dict[str, list[str]] = {
    "job": [
        "job_id", "external_id", "product_id", "quantity",
        "release_time", "due_time", "priority", "customer_deadline_type",
        "late_penalty_per_unit_time",
    ],
    "operation": [
        "operation_id", "job_id", "sequence_index", "operation_name",
        "operation_family", "processing_time_minutes", "batch_capacity_units",
        "setup_family", "requires_skill",
    ],
    "resource": [
        "resource_id", "resource_type", "resource_group", "name",
        "capacity", "hourly_cost",
    ],
    "operation_eligibility": ["operation_id", "resource_id", "eligibility_type"],
    "calendar_window": ["resource_id", "start_time", "end_time", "availability_type"],
    "setup_rule": [
        "from_family", "to_family", "setup_minutes", "setup_cost",
        "cleaning_minutes", "cleaning_cost",
    ],
    "material": ["material_id", "material_name", "unit_cost", "safety_stock"],
    "inventory_record": [
        "inventory_id", "item_type", "item_id", "on_hand_qty", "safety_stock_qty",
    ],
    "bom_link": ["product_id", "material_id", "quantity_per_unit"],
    "cost_parameter": ["name", "value", "unit"],
}

ALLOWED_OBJECTIVE_NAMES: list[str] = [
    "minimize_makespan",
    "minimize_total_tardiness",
    "minimize_total_cost",
    "balance_resource_load",
]

ALLOWED_CONSTRAINT_NAMES: list[str] = [
    "machine_capacity_no_overlap",
    "operation_precedence",
    "machine_eligibility",
    "working_calendar",
    "lunch_break_or_downtime",
    "due_date",
    "setup_changeover",
    "batch_capacity",
    "inventory_availability",
    "material_availability",
]

# =============================================================================
# 1. Input Understanding
# =============================================================================

SYS_UNDERSTAND = (
    "You are a scheduling-domain analyst. "
    "You classify a user's scheduling problem from either a free-text prompt or a "
    "compact source inventory. "
    "Output ONLY a JSON object that matches this exact schema:\n"
    "{\n"
    '  "domain": string,\n'
    '  "problem_type": string,\n'
    '  "candidate_solver": string,\n'
    '  "can_solve_with_cpsat": boolean,\n'
    '  "confidence": number between 0 and 1,\n'
    '  "reasoning_summary": string\n'
    "}\n"
    "Allowed problem_type values include but are not limited to: "
    '"job_shop", "flow_shop", "parallel_machines", "single_machine", '
    '"print_shop", "production_scheduling", "unknown". '
    "Use lower confidence (e.g. <= 0.5) when uncertain. "
    "Do not invent fields. Output JSON only — no prose, no markdown."
)


def prompt_understand(prompt_text: Optional[str], inventory: SourceInventory) -> str:
    inv = {
        "source_type": inventory.source_type,
        "detected_tables": inventory.detected_tables,
        "detected_columns": inventory.detected_columns,
        "row_counts": inventory.row_counts,
        "file_metadata": inventory.file_metadata,
    }
    return (
        f"USER_PROMPT:\n{prompt_text or '(none)'}\n\n"
        f"SOURCE_INVENTORY:\n{json.dumps(inv, default=str)[:3000]}\n\n"
        "Classify the scheduling problem. "
        "Pick a candidate_solver string (e.g. 'cp-sat', 'milp', 'heuristic'). "
        "If CP-SAT is plausibly suitable, set can_solve_with_cpsat=true. "
        "Return JSON only."
    )

# =============================================================================
# 2. Schema Mapping (file inputs)
# =============================================================================

SYS_MAPPING = (
    "You are a strict data mapper for a scheduling system. "
    "You map source columns/sheets onto canonical scheduling entities and fields. "
    "RULES:\n"
    "- You may ONLY use canonical entity names from the provided list.\n"
    "- You may ONLY use canonical field names from the provided list per entity.\n"
    "- If a column has no clear canonical mapping, place it in unmapped_source_fields.\n"
    "- If multiple mappings are plausible, list it under ambiguities.\n"
    "- Do NOT invent canonical entities or fields.\n"
    "- mapping_confidence must reflect overall confidence (0..1).\n"
    "Output ONLY a JSON object that matches the MappingReport schema. "
    "All fields are required. No commentary."
)


def prompt_mapping(inventory: SourceInventory) -> str:
    sample_blob = json.dumps(inventory.sample_summary, default=str)
    if len(sample_blob) > 3000:
        sample_blob = sample_blob[:3000] + "...(truncated)"
    return (
        f"SOURCE_TYPE: {inventory.source_type}\n"
        f"TABLES: {json.dumps(inventory.detected_tables)}\n"
        f"COLUMNS_BY_TABLE: {json.dumps(inventory.detected_columns)}\n"
        f"ROW_COUNTS: {json.dumps(inventory.row_counts)}\n"
        f"SAMPLE_3_ROWS_PER_TABLE: {sample_blob}\n\n"
        f"ALLOWED_CANONICAL_ENTITIES: {json.dumps(ALLOWED_CANONICAL_ENTITIES)}\n"
        f"ALLOWED_CANONICAL_FIELDS: {json.dumps(ALLOWED_CANONICAL_FIELDS)}\n\n"
        "MappingReport schema:\n"
        "{\n"
        '  "source_type": "xlsx"|"csv"|"prompt",\n'
        '  "sheet_mappings": [{\n'
        '     "source_name": string, "canonical_entity": string,\n'
        '     "confidence": number, "mapping_method": "llm_proposed"|"derived"|"explicit_prompt"\n'
        "  }],\n"
        '  "field_mappings": [{\n'
        '     "source_field": string, "canonical_entity": string,\n'
        '     "canonical_field": string, "confidence": number,\n'
        '     "mapping_method": "llm_proposed"|"derived"|"explicit_prompt"\n'
        "  }],\n"
        '  "unmapped_source_fields": [string],\n'
        '  "unmapped_canonical_fields": [string],\n'
        '  "mapping_confidence": number,\n'
        '  "ambiguities": [{\n'
        '     "source_field": string, "candidate_mappings": [string],\n'
        '     "resolution_needed": boolean, "reason": string\n'
        "  }]\n"
        "}\n"
        "field_mappings.source_field MUST use the syntax 'TABLE.COLUMN'.\n"
        "Return JSON only."
    )

# =============================================================================
# 2b. Prompt-only entity extraction (no tables to map)
# =============================================================================

SYS_PROMPT_EXTRACT = (
    "You extract canonical scheduling entities from a user's scheduling problem description.\n"
    "CRITICAL RULES — follow exactly:\n"
    "1. JOBS: For EVERY distinct job mentioned, add EXACTLY ONE object to 'jobs' with a unique job_id string.\n"
    "2. OPERATIONS: For EVERY job, add EXACTLY ONE object to 'operations'.\n"
    "   - 'job_id' in the operation MUST exactly match the job's job_id.\n"
    "   - 'processing_time_minutes' MUST be a positive integer (minutes).\n"
    "   - 'sequence_index' must be 1 for a single-operation job.\n"
    "   - Generate 'operation_id' as 'OP_<job_id>_1'.\n"
    "3. RESOURCES: For EVERY machine/resource mentioned, add ONE object to 'resources' with a unique resource_id.\n"
    "4. ELIGIBILITIES: If a job can run on ANY machine or EITHER machine, add one\n"
    "   'operation_eligibility' entry for EACH (operation_id, resource_id) combination.\n"
    "5. Use ONLY field names from ALLOWED_CANONICAL_FIELDS. Do NOT invent fields.\n"
    "6. Count jobs and operations carefully — the number of operations MUST equal the number of jobs.\n"
    "7. Output JSON only. No prose, no markdown fences."
)


def prompt_prompt_extract(text: str) -> str:
    # Concrete worked example to guide small LLMs
    example = json.dumps({
        "jobs": [
            {"job_id": "J_A", "priority": 1},
            {"job_id": "J_B", "priority": 2},
        ],
        "operations": [
            {"operation_id": "OP_J_A_1", "job_id": "J_A", "sequence_index": 1, "processing_time_minutes": 30},
            {"operation_id": "OP_J_B_1", "job_id": "J_B", "sequence_index": 1, "processing_time_minutes": 45},
        ],
        "resources": [
            {"resource_id": "M1", "resource_type": "machine"},
            {"resource_id": "M2", "resource_type": "machine"},
        ],
        "operation_eligibilities": [
            {"operation_id": "OP_J_A_1", "resource_id": "M1"},
            {"operation_id": "OP_J_A_1", "resource_id": "M2"},
            {"operation_id": "OP_J_B_1", "resource_id": "M1"},
            {"operation_id": "OP_J_B_1", "resource_id": "M2"},
        ],
        "resource_calendars": [], "setup_rules": [], "materials": [],
        "inventories": [], "bom_links": [], "cost_parameters": [],
    }, indent=2)
    return (
        f"USER_PROMPT:\n{text}\n\n"
        f"ALLOWED_CANONICAL_ENTITIES: {json.dumps(ALLOWED_CANONICAL_ENTITIES)}\n"
        f"ALLOWED_CANONICAL_FIELDS: {json.dumps(ALLOWED_CANONICAL_FIELDS)}\n\n"
        "EXAMPLE OUTPUT (2 machines, 2 jobs that can run on either machine):\n"
        f"{example}\n\n"
        "Now extract ALL entities from the USER_PROMPT above using the same structure.\n"
        "Rules:\n"
        "- One entry in 'jobs' per job mentioned.\n"
        "- One entry in 'operations' per job, with matching job_id.\n"
        "- One entry in 'resources' per machine/resource mentioned.\n"
        "- If a job can run on any/either machine, add eligibility rows for every (operation_id, resource_id) pair.\n"
        "Return JSON only."
    )

# =============================================================================
# 3. Objective + Constraint extraction
# =============================================================================

SYS_OBJCON = (
    "You are a scheduling problem analyst. You extract optimization objectives "
    "and constraint candidates from a user prompt and partial canonical entities. "
    "RULES:\n"
    "- Use ONLY objective names from the allow-list.\n"
    "- Use ONLY constraint names from the allow-list.\n"
    "- Provide 'evidence' (short strings citing prompt phrases or entity facts).\n"
    "- If the user did not state an objective, infer one based on data and explain "
    "the inference in stated_preferences.\n"
    "- Do NOT mark required fields as satisfied — that is decided downstream.\n"
    "Output ONLY a JSON object matching the ObjectiveConstraintExtraction schema."
)


def prompt_objcon(
    user_prompt: Optional[str],
    problem_understanding: Optional[ProblemUnderstandingReport],
    partial_entities: Optional[CanonicalEntities],
) -> str:
    pu = problem_understanding.model_dump() if problem_understanding else {}
    summary = _summarize_entities(partial_entities) if partial_entities else {}
    return (
        f"USER_PROMPT:\n{user_prompt or '(none)'}\n\n"
        f"PROBLEM_UNDERSTANDING:\n{json.dumps(pu, default=str)}\n\n"
        f"PARTIAL_ENTITIES_SUMMARY:\n{json.dumps(summary, default=str)}\n\n"
        f"ALLOWED_OBJECTIVE_NAMES: {json.dumps(ALLOWED_OBJECTIVE_NAMES)}\n"
        f"ALLOWED_CONSTRAINT_NAMES: {json.dumps(ALLOWED_CONSTRAINT_NAMES)}\n\n"
        "Schema:\n"
        "{\n"
        '  "objectives": [{"objective_name": <allowed>, "priority_rank": int, "weight": number|null}],\n'
        '  "constraint_candidates": [{\n'
        '     "constraint_name": <allowed>,\n'
        '     "source": "dataset"|"prompt"|"derived",\n'
        '     "evidence": [string],\n'
        '     "required_fields": [string],\n'
        '     "detected": true\n'
        "  }],\n"
        '  "missing_data_hints": [string],\n'
        '  "stated_preferences": [string]\n'
        "}\n"
        "Return JSON only."
    )


def _summarize_entities(e: CanonicalEntities) -> dict:
    return {
        "n_jobs": len(e.jobs),
        "n_operations": len(e.operations),
        "n_resources": len(e.resources),
        "has_due_dates": any(j.due_time for j in e.jobs),
        "has_durations": all(o.processing_time_minutes for o in e.operations) and len(e.operations) > 0,
        "has_eligibility": len(e.operation_eligibilities) > 0,
        "has_calendar": len(e.resource_calendars) > 0,
        "has_setup_rules": len(e.setup_rules) > 0,
        "has_costs": any(r.hourly_cost is not None for r in e.resources) or len(e.cost_parameters) > 0,
        "n_operations_per_job": _ops_per_job(e),
    }


def _ops_per_job(e: CanonicalEntities) -> dict[str, int]:
    out: dict[str, int] = {}
    for op in e.operations:
        out[op.job_id] = out.get(op.job_id, 0) + 1
    return out

# =============================================================================
# 4. Ask-back phrasing (LLM phrasing only; question structure is deterministic)
# =============================================================================

SYS_ASK_BACK_PHRASING = (
    "You rewrite a list of structured ask-back questions into clearer, "
    "user-friendly question text. "
    "You MUST keep the question_id, expected_type, target_field, target_scope, "
    "and target_id fields exactly as given. "
    "You may only change the question_text field. "
    "Output JSON only matching the schema: "
    '{"questions": [{"question_id": string, "question_text": string}]}'
)


def prompt_ask_back_phrasing(questions_json: str) -> str:
    return (
        "Rewrite the following questions to be clear and concise for a "
        "production scheduling user. Do not change ids or types.\n\n"
        f"QUESTIONS:\n{questions_json}\n\n"
        "Return JSON only."
    )

# =============================================================================
# 5. Grounded Explanation / Q&A
# =============================================================================

SYS_EXPLAIN = (
    "You are a scheduling-result explainer. "
    "You will be given an ExplanationContext JSON object. "
    "STRICT RULES:\n"
    "- Cite ONLY facts present in the ExplanationContext (numbers, dates, ids).\n"
    "- Do NOT invent resource ids, job ids, dates, costs, or constraints.\n"
    "- Do NOT label a non-OPTIMAL solve_status as 'optimal'. Use the literal status.\n"
    "- If a question cannot be answered from the context, say "
    '"the available data does not support an answer to this question".\n'
    "- Output PLAIN TEXT (not JSON), 4-8 sentences for an initial explanation, "
    "shorter for follow-up Q&A."
)


def prompt_explanation(context: ExplanationContext, question: Optional[str] = None) -> str:
    ctx_json = context.model_dump_json()
    q_block = f"\n\nUSER_QUESTION: {question}\n" if question else ""
    head = (
        "Write a concise, grounded follow-up answer."
        if question
        else "Write a concise, grounded explanation of the schedule and the trade-offs."
    )
    return (
        f"EXPLANATION_CONTEXT:\n{ctx_json}\n"
        f"{q_block}\n"
        f"{head} "
        "Cite only facts from the context. Plain text only."
    )