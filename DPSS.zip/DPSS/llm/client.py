"""Ollama LLM client with strict JSON output and one-shot repair retry.

Policy:
- temperature 0, format=json, fixed seed for determinism.
- Pydantic validation; on ValidationError, retry once with a repair prompt.
- After two failures raise LLMValidationError so the graph routes to a UI error.
"""
from __future__ import annotations

import json
from typing import Type, TypeVar

import requests
from pydantic import BaseModel, ValidationError

from core.constants import (
    OLLAMA_MODEL,
    OLLAMA_NUM_CTX,
    OLLAMA_SEED,
    OLLAMA_TIMEOUT_SECONDS,
    OLLAMA_URL,
)
from core.logger import log, timer

T = TypeVar("T", bound=BaseModel)


# =============================================================================
# Exceptions
# =============================================================================

class LLMError(RuntimeError):
    """Generic LLM call error (network, HTTP)."""


class LLMValidationError(RuntimeError):
    """Final validation error after the repair retry."""

    def __init__(self, message: str, last_response: str, last_error: ValidationError):
        super().__init__(message)
        self.last_response = last_response
        self.last_error = last_error


# =============================================================================
# Internal HTTP layer
# =============================================================================

def _post(payload: dict) -> str:
    try:
        r = requests.post(OLLAMA_URL, json=payload, timeout=OLLAMA_TIMEOUT_SECONDS)
    except requests.RequestException as e:
        raise LLMError(f"Ollama request failed: {e}") from e
    if not r.ok:
        raise LLMError(f"Ollama HTTP {r.status_code}: {r.text[:500]}")
    try:
        return r.json()["response"]
    except (KeyError, ValueError) as e:
        raise LLMError(f"Ollama returned malformed body: {r.text[:500]}") from e


# =============================================================================
# Public API
# =============================================================================

def call_raw(system: str, prompt: str, *, json_mode: bool = True) -> str:
    """Single Ollama call, returning the raw response string."""
    payload = {
        "model": OLLAMA_MODEL,
        "system": system,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.0,
            "num_ctx": OLLAMA_NUM_CTX,
            "seed": OLLAMA_SEED,
        },
    }
    if json_mode:
        payload["format"] = "json"
    log.llm_call("call_raw", model=OLLAMA_MODEL, json_mode=json_mode)
    with timer() as t:
        response = _post(payload)
    log.llm_ok("call_raw", duration_ms=f"{t.ms:.0f}ms", chars=len(response))
    return response


def call_json(system: str, prompt: str, schema: Type[T]) -> T:
    """Call Ollama and parse the response into the given Pydantic schema.

    On the first ValidationError, the call is retried once with a repair prompt
    that echoes the validation errors and asks for a corrected JSON.
    """
    schema_name = schema.__name__
    log.llm_call("call_json", model=OLLAMA_MODEL, schema=schema_name)

    last_response: str = ""
    last_error: ValidationError | None = None
    current_prompt = prompt

    for attempt in range(2):
        with timer() as t:
            text = call_raw(system, current_prompt, json_mode=True)
        last_response = text
        try:
            result = schema.model_validate_json(text)
            log.llm_ok(
                "call_json",
                schema=schema_name,
                attempt=attempt + 1,
                duration_ms=f"{t.ms:.0f}ms",
            )
            return result
        except ValidationError as e:
            last_error = e
            if attempt == 0:
                log.llm_retry(
                    "call_json",
                    attempt=attempt + 1,
                    schema=schema_name,
                    errors=str(e).splitlines()[0],
                )
            current_prompt = (
                "Your previous response failed JSON Schema validation:\n"
                f"{e}\n\n"
                "Original task prompt:\n"
                f"{prompt}\n\n"
                "Return a corrected JSON object that strictly matches the schema. "
                "Output JSON only, no commentary."
            )

    log.llm_fail(
        "call_json",
        schema=schema_name,
        last_error=str(last_error).splitlines()[0] if last_error else "unknown",
    )
    raise LLMValidationError(
        "LLM JSON validation failed twice.",
        last_response=last_response,
        last_error=last_error,  # type: ignore[arg-type]
    )


def call_text(system: str, prompt: str) -> str:
    """Call Ollama for free-text output (used by the explanation agent)."""
    log.llm_call("call_text", model=OLLAMA_MODEL)
    with timer() as t:
        response = call_raw(system, prompt, json_mode=False)
    log.llm_ok("call_text", duration_ms=f"{t.ms:.0f}ms", chars=len(response))
    return response


def health_check() -> bool:
    """Quick liveness probe for the Ollama daemon."""
    try:
        r = requests.get(OLLAMA_URL.replace("/api/generate", "/api/tags"), timeout=5)
        return r.ok
    except requests.RequestException:
        return False
