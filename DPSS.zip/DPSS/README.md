# Scheduling Copilot

An AI-powered production scheduling assistant that accepts a natural-language
prompt or a structured spreadsheet, runs a CP-SAT optimisation, and explains
the resulting schedule — all inside a Streamlit UI.

---

## Architecture

```
scheduling_copilot/
│
├── app.py                        # Streamlit entry point
├── requirements.txt
│
├── core/                         # Shared foundations (no business logic)
│   ├── schemas.py                # All Pydantic models (single source of truth)
│   ├── time_utils.py             # UTC datetime ↔ solver unit conversions
│   └── constants.py              # Env-overridable system-wide constants
│
├── orchestration/                # LangGraph pipeline wiring
│   ├── graph.py                  # StateGraph build + profile_input node
│   ├── routes.py                 # All conditional edge functions
│   └── checkpoints.py            # Thread config helpers (MemorySaver wrapper)
│
├── agents/                       # One module per pipeline stage
│   ├── input_understanding.py    # Stage 1 — classify problem domain
│   ├── schema_mapping.py         # Stage 2 — map source data → canonical entities
│   ├── objective_constraint.py   # Stage 3 — extract objectives & constraints
│   ├── constraint_registry.py    # Stage 3b — deterministic activation / degrade
│   ├── data_sufficiency.py       # Stage 4 — solve-mode gate + ask-back generation
│   ├── ask_back.py               # Stage 4b — rephrase questions, merge answers
│   ├── payload_builder.py        # Stage 5 — build SolverPayload (deterministic)
│   ├── post_solve_validation.py  # Stage 6 — structural checks + KPI computation
│   └── explanation_qa.py         # Stage 7 — grounded explanation + Q&A
│
├── llm/                          # LLM infrastructure (isolated from business logic)
│   ├── client.py                 # Ollama HTTP client with repair-retry
│   ├── prompts.py                # All system prompts and user prompt builders
│   └── output_parsers.py         # Generic type-coercion helpers for LLM output
│
├── ingestion/                    # Data ingestion (file profiling + loading)
│   └── workbook_profiler.py      # XLSX / CSV / prompt → SourceInventory
│
├── solver/                       # CP-SAT solver (pure deterministic)
│   ├── cp_sat_solver.py          # Model build, solve, infeasibility diagnosis
│   └── __init__.py               # Re-exports: solve, diagnose_infeasibility
│
├── ui/                           # Streamlit UI (reads state, never calls graph)
│   ├── components.py             # One render_*_tab() function per tab
│   ├── tabs.py                   # Re-export registry for app.py
│   └── formatting.py             # Pure display helpers (no st.* calls)
│
└── examples/
    └── sample_prompts.md         # Copy-paste prompts for demos
```

---

## Pipeline Stages

| # | Stage | Module | LLM? |
|---|-------|--------|------|
| 0 | Profile input | `ingestion/workbook_profiler.py` | No |
| 1 | Understand problem | `agents/input_understanding.py` | Yes |
| 2 | Map schema | `agents/schema_mapping.py` | Yes |
| 3 | Extract objectives & constraints | `agents/objective_constraint.py` | Yes |
| 3b | Register constraints | `agents/constraint_registry.py` | No |
| 4 | Check sufficiency | `agents/data_sufficiency.py` | No |
| 4b | Ask-back loop | `agents/ask_back.py` | Yes (phrasing only) |
| 5 | Build solver payload | `agents/payload_builder.py` | No |
| 5b | Solve (CP-SAT) | `solver/cp_sat_solver.py` | No |
| 6 | Validate + KPIs | `agents/post_solve_validation.py` | No |
| 7 | Explain + Q&A | `agents/explanation_qa.py` | Yes |

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Start Ollama with qwen2.5:3b
ollama pull qwen2.5:3b
ollama serve

# 3. Launch the app
streamlit run app.py
```

### Environment variables (all optional)

| Variable | Default | Description |
|----------|---------|-------------|
| `OLLAMA_URL` | `http://localhost:11434/api/generate` | Ollama endpoint |
| `OLLAMA_MODEL` | `qwen2.5:3b` | Model tag |
| `OLLAMA_TIMEOUT_SECONDS` | `180` | Per-request timeout |
| `SOLVER_TIMEOUT_SECONDS` | `30` | CP-SAT wall-clock budget |

---

## Key Design Decisions

- **LLM cannot activate constraints.** Only `agents/constraint_registry.py`
  decides active/degraded/unsupported — from structural evidence alone.
- **Deterministic solver.** `SOLVER_RANDOM_SEED=7`, `num_search_workers=1`.
- **Human-in-the-loop** via LangGraph `interrupt_before` at `merge_answers`
  and `confirm_degraded` nodes.
- **Grounding check** in the explanation agent: any capitalized identifier in
  the LLM's text must appear in the `ExplanationContext` or the response is
  replaced by a deterministic fallback.
