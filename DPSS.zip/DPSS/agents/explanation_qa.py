"""Explanation & Q&A Agent (Stage 7).

Produces grounded natural-language explanations of the schedule. Includes
a post-hoc grounding check: any identifier-like token must appear in the
ExplanationContext. Falls back to a deterministic templated explanation.

The agent receives an ExplanationContext only. The system prompt forbids
inventing facts, and we additionally do a post-hoc grounding check: any token
that looks like a resource_id, job_id, or operation_id must appear in the
context. If it doesn't, we either redact and warn, or fall back to a templated
deterministic explanation.
"""
from __future__ import annotations

import re
from typing import Optional

from llm.client import LLMError, LLMValidationError, call_text
from llm.prompts import SYS_EXPLAIN, prompt_explanation
from core.logging_utils import get_logger, setup_logging
from core.schemas import ExplanationContext, SessionState

setup_logging()
_logger = get_logger(__name__)


ID_PATTERN = re.compile(r"\b[A-Z][A-Za-z0-9_]*\b")  # heuristic: capitalized identifiers


def explain(context: ExplanationContext, question: Optional[str] = None) -> str:
    """Produce a grounded explanation or follow-up answer.

    Falls back to a deterministic templated explanation if the LLM call fails
    or if the produced text references identifiers that are not in the context.
    """
    try:
        text = call_text(SYS_EXPLAIN, prompt_explanation(context, question))
    except (LLMError, LLMValidationError):
        return _deterministic_explanation(context, question)

    if _is_grounded(text, context):
        return text.strip()
    fallback = _deterministic_explanation(context, question)
    return fallback + "\n\n(Note: model output was redacted — it referenced facts outside the schedule context.)"


# =============================================================================
# Grounding check
# =============================================================================

def _is_grounded(text: str, context: ExplanationContext) -> bool:
    """Relaxed grounding check: only reject if the LLM invents specific IDs
    (operation_id, job_id, resource_id) that are NOT in the context.
    We do NOT check constraint names or generic words.
    """
    allowed_ids = set()
    for s in context.solver_result.scheduled_operations:
        allowed_ids.add(s.operation_id)
        allowed_ids.add(s.job_id)
        allowed_ids.add(s.resource_id)

    # Heuristic: look for tokens that look like IDs (uppercase letters + digits + _)
    id_pattern = re.compile(r"\b([A-Z][A-Z0-9_]{1,}|[A-Z]{1,}_[A-Z0-9_]+)\b")
    candidates = id_pattern.findall(text)
    generic = {
        "OPTIMAL", "FEASIBLE", "INFEASIBLE", "UNKNOWN", "TIMEOUT",
        "CP", "SAT", "KPI", "Q", "A",
    }
    for tok in candidates:
        if tok in generic or tok in allowed_ids:
            continue
        return False
    return True


def _allowed_tokens(context: ExplanationContext) -> set[str]:
    out: set[str] = set()
    for s in context.solver_result.scheduled_operations:
        out.add(s.operation_id)
        out.add(s.job_id)
        out.add(s.resource_id)
    for c in context.active_constraints:
        out.add(c.constraint_name)
    for c in context.degraded_constraints:
        out.add(c.constraint_name)
    for c in context.unsupported_constraints:
        out.add(c.constraint_name)
    for o in context.objectives:
        out.add(o.objective_name)
    for k in context.kpi_summary.resource_utilization.keys():
        out.add(k)
    return out


# =============================================================================
# Deterministic fallback
# =============================================================================

def _deterministic_explanation(
    context: ExplanationContext, question: Optional[str]
) -> str:
    sr = context.solver_result
    kpi = context.kpi_summary
    val = context.post_solve_validation

    if sr.solve_status == "INFEASIBLE":
        return (
            "The solver reported INFEASIBLE for the current data. "
            "No schedule is produced. "
            "Use the infeasibility report to relax due dates, calendar windows, "
            "or eligibility constraints."
        )
    if sr.solve_status in ("UNKNOWN", "TIMEOUT"):
        return (
            f"The solver returned status {sr.solve_status}. "
            "It did not find a feasible schedule within the time budget. "
            "Increase the timeout or simplify the model."
        )

    parts: list[str] = []
    parts.append(
        f"Solver status: {sr.solve_status}. "
        f"Makespan: {kpi.makespan_units} time-units."
    )
    if kpi.total_tardiness_units is not None:
        parts.append(
            f"Total tardiness: {kpi.total_tardiness_units} units across "
            f"{kpi.total_late_jobs or 0} late job(s)."
        )
    if context.active_constraints:
        active_names = ", ".join(c.constraint_name for c in context.active_constraints)
        parts.append(f"Active constraints: {active_names}.")
    if context.degraded_constraints:
        deg_names = ", ".join(c.constraint_name for c in context.degraded_constraints)
        parts.append(
            f"Degraded constraints (with documented fallbacks): {deg_names}."
        )
    if context.unsupported_constraints:
        un_names = ", ".join(c.constraint_name for c in context.unsupported_constraints)
        parts.append(
            f"Unsupported constraints (not modeled in Phase 1): {un_names}."
        )
    if not val.validation_passed:
        parts.append(
            "Post-solve validation flagged at least one issue; check the "
            "validation report for details."
        )
    if question:
        parts.append(
            "Note: the available data does not support a richer answer to your "
            "follow-up question."
        )
    return " ".join(parts)


# =============================================================================
# LangGraph nodes
# =============================================================================

def _build_context(state: SessionState) -> Optional[ExplanationContext]:
    if state.solver_result is None:
        return None
    registry = state.constraint_registry
    return ExplanationContext(
        solver_result=state.solver_result,
        kpi_summary=state.kpi_summary or _empty_kpi(),
        post_solve_validation=state.post_solve_validation or _empty_validation(),
        active_constraints=registry.active_constraints if registry else [],
        degraded_constraints=registry.degraded_constraints if registry else [],
        unsupported_constraints=registry.unsupported_constraints if registry else [],
        ask_back_history=state.ask_back_questions,
        ask_back_answers=state.ask_back_answers,
        objectives=state.objectives,
    )


def _empty_kpi():
    from core.schemas import KPISummary
    return KPISummary()


def _empty_validation():
    from core.schemas import PostSolveValidation
    return PostSolveValidation(
        all_operations_scheduled=False,
        no_overlap_violations=False,
        precedence_violations=[],
        eligibility_violations=[],
        calendar_violations=[],
        due_date_violations=[],
        validation_passed=False,
        validation_warnings=[],
    )


def _constraint_footer(ctx: ExplanationContext) -> str:
    """Always-truthful constraint summary appended after any explanation text."""
    parts: list[str] = []
    if ctx.active_constraints:
        names = ", ".join(c.constraint_name for c in ctx.active_constraints)
        parts.append(f"✅ **Active constraints:** {names}.")
    if ctx.degraded_constraints:
        names = ", ".join(
            f"{c.constraint_name} ({c.fallback_behavior})"
            for c in ctx.degraded_constraints
        )
        parts.append(f"⚠️ **Degraded constraints (fallbacks applied):** {names}.")
    if ctx.unsupported_constraints:
        names = ", ".join(c.constraint_name for c in ctx.unsupported_constraints)
        parts.append(f"🚫 **Unsupported (not modeled in Phase 1):** {names}.")
    return "\n\n" + "  \n".join(parts) if parts else ""


def explain_node(state: SessionState) -> dict:
    ctx = _build_context(state)
    if ctx is None:
        return {"errors": state.errors + ["explain: solver_result missing"]}
    _logger.info(
        "[NODE] explain | active=%d | degraded=%d | unsupported=%d | status=%s",
        len(ctx.active_constraints), len(ctx.degraded_constraints),
        len(ctx.unsupported_constraints),
        ctx.solver_result.solve_status,
    )
    text = explain(ctx) + _constraint_footer(ctx)
    return {
        "explanation_context": ctx,
        "explanation_text": text,
        "current_stage": "EXPLAINED",
    }


def explain_infeasible_node(state: SessionState) -> dict:
    ctx = _build_context(state)
    if ctx is None:
        return {"errors": state.errors + ["explain_infeasible: solver_result missing"]}
    _logger.info(
        "[NODE] explain_infeasible | status=%s | conflicts=%d",
        ctx.solver_result.solve_status,
        len(state.infeasibility_report.likely_conflict_areas) if state.infeasibility_report else 0,
    )
    text = _deterministic_explanation(ctx, None)
    if state.infeasibility_report is not None:
        text += (
            "\n\nLikely conflict areas:\n- "
            + "\n- ".join(state.infeasibility_report.likely_conflict_areas)
            + "\n\nSuggested actions:\n- "
            + "\n- ".join(state.infeasibility_report.suggested_user_actions)
        )
    return {
        "explanation_context": ctx,
        "explanation_text": text,
        "current_stage": "EXPLAINED",
    }


def answer_question_node(state: SessionState, question: str) -> str:
    """Used by the UI for free-form Q&A — does not advance the graph."""
    ctx = _build_context(state)
    if ctx is None:
        return "No solver result is available to answer questions about."
    return explain(ctx, question)
