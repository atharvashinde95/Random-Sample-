"""Agent — Objective & Constraint Extraction (Stage 3).

Extracts optimization objectives and constraint candidates from the user
prompt and partial canonical entities. Sanitizes output against allow-lists.

Pure function:
    extract_objectives_and_constraints(prompt, problem_understanding, partial_entities)
        -> ObjectiveConstraintExtraction
"""
from __future__ import annotations

from typing import Optional

from llm.client import LLMValidationError, call_json
from llm.prompts import (
    ALLOWED_CONSTRAINT_NAMES,
    ALLOWED_OBJECTIVE_NAMES,
    SYS_OBJCON,
    prompt_objcon,
)
from core.logging_utils import get_logger, setup_logging
from core.schemas import (
    CanonicalEntities,
    ObjectiveConstraintExtraction,
    ProblemUnderstandingReport,
    SessionState,
)

setup_logging()
_logger = get_logger(__name__)


def extract_objectives_and_constraints(
    prompt_text: Optional[str],
    problem_understanding: Optional[ProblemUnderstandingReport],
    partial_entities: Optional[CanonicalEntities],
) -> ObjectiveConstraintExtraction:
    user = prompt_objcon(prompt_text, problem_understanding, partial_entities)
    raw = call_json(SYS_OBJCON, user, ObjectiveConstraintExtraction)
    return _sanitize_extraction(raw)


def _sanitize_extraction(
    extraction: ObjectiveConstraintExtraction,
) -> ObjectiveConstraintExtraction:
    """Drop any objective/constraint that escaped the allow-list (Pydantic Literal
    catches most cases, but constraint strings may slip through with extra='forbid'
    if the LLM uses an unknown literal — Pydantic will already reject those.)
    """
    objectives = [o for o in extraction.objectives if o.objective_name in ALLOWED_OBJECTIVE_NAMES]
    candidates = [c for c in extraction.constraint_candidates if c.constraint_name in ALLOWED_CONSTRAINT_NAMES]
    return extraction.model_copy(update={
        "objectives": objectives,
        "constraint_candidates": candidates,
    })


# =============================================================================
# LangGraph node
# =============================================================================

def extract_obj_const_node(state: SessionState) -> dict:
    prompt_text: Optional[str] = None
    if state.source_type == "prompt" and state.raw_input_refs:
        prompt_text = state.raw_input_refs[0]

    try:
        result = extract_objectives_and_constraints(
            prompt_text=prompt_text,
            problem_understanding=state.problem_understanding,
            partial_entities=state.canonical_entities,
        )
    except LLMValidationError as e:
        return {
            "errors": state.errors
            + [f"extract_obj_const: LLM validation failed: {e.last_error}"],
            "current_stage": "MAPPED",
        }

    objectives = result.objectives
    if not objectives:
        from core.schemas import Objective
        objectives = [Objective(objective_name="minimize_makespan", priority_rank=1)]

    obj_names = [o.objective_name for o in objectives]
    cand_names = [c.constraint_name for c in result.constraint_candidates]
    _logger.info(
        "[NODE] extract_obj_const | objectives=%s | candidates=%d | hints=%d",
        obj_names, len(cand_names), len(result.missing_data_hints),
    )
    return {
        "objectives": objectives,
        "constraint_candidates": result.constraint_candidates,
        "missing_data_hints": result.missing_data_hints,
        "stated_preferences": result.stated_preferences,
        "current_stage": "OBJECTIVES_EXTRACTED",
    }
