"""Agent — Input Understanding (Stage 1).

Classifies the scheduling problem domain, type, and solver suitability
from a free-text prompt or a SourceInventory produced by the profiler.

Pure function:
    understand_problem(prompt_text, source_inventory) -> ProblemUnderstandingReport

The LangGraph node wrapper lives at the bottom and updates SessionState.
"""
from __future__ import annotations

from typing import Optional

from llm.client import LLMValidationError, call_json
from llm.prompts import SYS_UNDERSTAND, prompt_understand
from core.logging_utils import get_logger, setup_logging
from core.schemas import ProblemUnderstandingReport, SessionState, SourceInventory

setup_logging()
_logger = get_logger(__name__)


def understand_problem(
    prompt_text: Optional[str],
    source_inventory: SourceInventory,
) -> ProblemUnderstandingReport:
    """Run the input-understanding LLM call and return a validated report."""
    user_prompt = prompt_understand(prompt_text, source_inventory)
    return call_json(SYS_UNDERSTAND, user_prompt, ProblemUnderstandingReport)


def understand_problem_node(state: SessionState) -> dict:
    """LangGraph node: read state, call agent, return state delta."""
    if state.source_inventory is None:
        return {
            "errors": state.errors + ["understand_problem: source_inventory missing"],
        }
    user_prompt: Optional[str] = None
    if state.source_type == "prompt" and state.raw_input_refs:
        user_prompt = state.raw_input_refs[0]
    try:
        report = understand_problem(user_prompt, state.source_inventory)
    except LLMValidationError as e:
        return {
            "errors": state.errors
            + [f"understand_problem: LLM validation failed: {e.last_error}"],
            "current_stage": "INPUT_RECEIVED",
        }
    _logger.info(
        "[NODE] understand_problem | domain=%s | problem_type=%s | confidence=%.2f | can_cpsat=%s",
        report.domain, report.problem_type, report.confidence, report.can_solve_with_cpsat,
    )
    return {
        "problem_understanding": report,
        "current_stage": "UNDERSTOOD",
    }
