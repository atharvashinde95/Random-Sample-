"""Payload Builder (Stage 5).

Pure deterministic function. No LLM use. Converts datetimes to integer solver
units, flattens active constraints, and produces a SolverPayload that
solver/cp_sat_solver.py consumes verbatim.

Pure deterministic function. No LLM use. Converts datetimes to integer solver
units, flattens active constraints, and produces a payload that solver.py
consumes verbatim.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional

from core.logging_utils import get_logger, setup_logging
from core.schemas import (
    ActiveConstraint,
    CanonicalEntities,
    ConstraintRegistryState,
    DegradedConstraint,
    Objective,
    SessionState,
    SolverJob,
    SolverObjective,
    SolverOperation,
    SolverPayload,
    SolverResource,
    SolverUnavailabilityWindow,
)
from core.time_utils import compute_horizon_minutes, ensure_utc, to_solver_units
from core.constants import DEFAULT_HORIZON_DAYS, MIN_OPERATION_DURATION_UNITS

setup_logging()
_logger = get_logger(__name__)


# =============================================================================
# Public API
# =============================================================================

def build_solver_payload(
    entities: CanonicalEntities,
    objectives: list[Objective],
    registry: ConstraintRegistryState,
    horizon_start: Optional[datetime],
    time_unit_minutes: int = 1,
) -> SolverPayload:
    """Build a SolverPayload from canonical entities + active/degraded constraints."""
    if time_unit_minutes <= 0:
        raise ValueError("time_unit_minutes must be positive")

    if not entities.jobs:
        raise ValueError("Cannot build payload: no jobs.")
    if not entities.operations:
        raise ValueError("Cannot build payload: no operations.")
    if not entities.resources:
        raise ValueError("Cannot build payload: no resources.")

    horizon_start = horizon_start or _infer_horizon_start(entities)
    horizon_start = ensure_utc(horizon_start)
    horizon_minutes = _compute_horizon(entities, horizon_start, time_unit_minutes)

    active_names = {a.constraint_name for a in registry.active_constraints}
    degraded_names = {d.constraint_name for d in registry.degraded_constraints}

    # ---- Build resources
    solver_resources = [
        SolverResource(resource_id=r.resource_id, capacity=int(r.capacity or 1))
        for r in entities.resources
    ]
    resource_id_set = {r.resource_id for r in solver_resources}

    # ---- Build eligibility map
    eligibility_active = "machine_eligibility" in active_names
    eligibility_degraded = "machine_eligibility" in degraded_names
    eligibility_map = _build_eligibility_map(
        entities, active=eligibility_active, degraded=eligibility_degraded,
        all_resource_ids=list(resource_id_set),
    )

    # ---- Build operations and jobs
    ops_by_job: dict[str, list[SolverOperation]] = {}
    for op in entities.operations:
        eligible_ids = eligibility_map.get(op.operation_id, [])
        # Drop any eligible IDs that aren't in the resource list.
        eligible_ids = [r for r in eligible_ids if r in resource_id_set]
        if not eligible_ids:
            # Degrade: any-machine fallback at the per-op level, since we can't
            # build a payload with an empty eligibility set.
            eligible_ids = list(resource_id_set)
        duration = int(op.processing_time_minutes or 0) // time_unit_minutes
        if duration <= 0:
            duration = MIN_OPERATION_DURATION_UNITS
        sequence_index = op.sequence_index if op.sequence_index is not None else 0
        ops_by_job.setdefault(op.job_id, []).append(
            SolverOperation(
                operation_id=op.operation_id,
                job_id=op.job_id,
                sequence_index=sequence_index,
                duration_units=duration,
                eligible_resource_ids=eligible_ids,
                setup_family=op.setup_family,
            )
        )
    # Sort each job's operations by sequence_index for downstream precedence.
    for job_id in ops_by_job:
        ops_by_job[job_id] = sorted(ops_by_job[job_id], key=lambda o: o.sequence_index)

    solver_jobs: list[SolverJob] = []
    for j in entities.jobs:
        ops = ops_by_job.get(j.job_id, [])
        if not ops:
            continue
        due_units = (
            to_solver_units(j.due_time, horizon_start, time_unit_minutes)
            if j.due_time is not None else None
        )
        release_units = (
            max(0, to_solver_units(j.release_time, horizon_start, time_unit_minutes))
            if j.release_time is not None else None
        )
        solver_jobs.append(SolverJob(
            job_id=j.job_id,
            operations=ops,
            due_time_units=due_units,
            release_time_units=release_units,
            late_penalty_per_unit=j.late_penalty_per_unit_time,
        ))

    if not solver_jobs:
        raise ValueError("Cannot build payload: no solver jobs after assembly.")

    # ---- Unavailability windows from working_calendar / lunch / blocked
    unavailability = _build_unavailability_windows(
        entities, horizon_start, horizon_minutes, time_unit_minutes,
        working_calendar_active="working_calendar" in active_names,
    )

    # ---- Setup matrix
    setup_matrix: dict[str, dict[str, int]] = {}
    if "setup_changeover" in active_names:
        for s in entities.setup_rules:
            if s.setup_minutes is None:
                continue
            setup_matrix.setdefault(s.from_family, {})[s.to_family] = (
                int(s.setup_minutes) // time_unit_minutes
            )

    # ---- Objective
    primary, secondaries = _resolve_objective_priority(objectives)
    objective = SolverObjective(
        primary_type=primary.objective_name,
        weights={o.objective_name: float(o.weight or 1.0) for o in objectives},
        strategy="lexicographic",
        secondary_types=[s.objective_name for s in secondaries],
    )

    hard_constraints = sorted(active_names)
    return SolverPayload(
        time_unit_minutes=time_unit_minutes,
        horizon_minutes=horizon_minutes,
        jobs=solver_jobs,
        resources=solver_resources,
        unavailability_windows=unavailability,
        setup_matrix=setup_matrix,
        objective=objective,
        hard_constraints=hard_constraints,  # type: ignore[arg-type]
        soft_constraints=[],
    )


# =============================================================================
# Helpers
# =============================================================================

def _infer_horizon_start(e: CanonicalEntities) -> datetime:
    candidates: list[datetime] = []
    for j in e.jobs:
        if j.release_time is not None:
            candidates.append(j.release_time)
    for c in e.resource_calendars:
        candidates.append(c.start_time)
    if candidates:
        return ensure_utc(min(candidates))
    return datetime.now(tz=timezone.utc).replace(microsecond=0)


def _compute_horizon(
    e: CanonicalEntities, horizon_start: datetime, time_unit_minutes: int
) -> int:
    end_candidates: list[datetime] = []
    for j in e.jobs:
        if j.due_time is not None:
            end_candidates.append(j.due_time)
    for c in e.resource_calendars:
        end_candidates.append(c.end_time)

    if end_candidates:
        latest = max(end_candidates)
        # Pad with the total processing time so the solver always has slack.
        total_proc = sum(int(o.processing_time_minutes or 0) for o in e.operations)
        latest_with_pad = latest + timedelta(minutes=total_proc)
        h = to_solver_units(latest_with_pad, horizon_start, time_unit_minutes)
        return max(h, 1)
    # Default horizon = total processing * (n_jobs + 1), bounded by 30 days.
    total_proc = sum(int(o.processing_time_minutes or 0) for o in e.operations)
    n_jobs = max(1, len(e.jobs))
    estimate = total_proc * (n_jobs + 1) // time_unit_minutes
    default_cap = compute_horizon_minutes(
        horizon_start, None, time_unit_minutes, default_days=DEFAULT_HORIZON_DAYS
    )
    return max(1, min(estimate or default_cap, default_cap))


def _build_eligibility_map(
    entities: CanonicalEntities,
    active: bool,
    degraded: bool,
    all_resource_ids: list[str],
) -> dict[str, list[str]]:
    eligibility_map: dict[str, list[str]] = {}
    if active:
        for e in entities.operation_eligibilities:
            eligibility_map.setdefault(e.operation_id, []).append(e.resource_id)
    if degraded or not active:
        for op in entities.operations:
            if op.operation_id not in eligibility_map or not eligibility_map[op.operation_id]:
                eligibility_map[op.operation_id] = list(all_resource_ids)
    return eligibility_map


def _build_unavailability_windows(
    entities: CanonicalEntities,
    horizon_start: datetime,
    horizon_minutes: int,
    time_unit_minutes: int,
    working_calendar_active: bool,
) -> list[SolverUnavailabilityWindow]:
    """Convert calendar windows to unavailability intervals.

    If working_calendar is active, we treat 'available' segments as the only
    permitted time; any gap between available segments per resource becomes
    unavailability. Plus any explicitly 'blocked' / 'lunch' / 'maintenance'
    windows always become unavailability.
    """
    windows: list[SolverUnavailabilityWindow] = []
    by_resource: dict[str, list] = {}
    for c in entities.resource_calendars:
        by_resource.setdefault(c.resource_id, []).append(c)

    for resource_id, items in by_resource.items():
        items_sorted = sorted(items, key=lambda x: x.start_time)
        # Always emit explicit blocked/lunch/maintenance windows.
        for c in items_sorted:
            if c.availability_type in ("blocked", "lunch", "maintenance"):
                start_u = max(0, to_solver_units(c.start_time, horizon_start, time_unit_minutes))
                end_u = min(horizon_minutes, to_solver_units(c.end_time, horizon_start, time_unit_minutes))
                if end_u > start_u:
                    windows.append(SolverUnavailabilityWindow(
                        resource_id=resource_id,
                        start_units=start_u,
                        end_units=end_u,
                    ))
        if not working_calendar_active:
            continue
        # Compute gaps between 'available' windows over [0, horizon_minutes]
        available = [c for c in items_sorted if c.availability_type == "available"]
        if not available:
            continue
        cursor = 0
        for c in available:
            s_u = max(0, to_solver_units(c.start_time, horizon_start, time_unit_minutes))
            e_u = min(horizon_minutes, to_solver_units(c.end_time, horizon_start, time_unit_minutes))
            if s_u > cursor:
                windows.append(SolverUnavailabilityWindow(
                    resource_id=resource_id, start_units=cursor, end_units=s_u,
                ))
            cursor = max(cursor, e_u)
        if cursor < horizon_minutes:
            windows.append(SolverUnavailabilityWindow(
                resource_id=resource_id, start_units=cursor, end_units=horizon_minutes,
            ))

    # Coalesce overlapping windows per resource for solver hygiene.
    return _coalesce_windows(windows)


def _coalesce_windows(windows: list[SolverUnavailabilityWindow]) -> list[SolverUnavailabilityWindow]:
    by_res: dict[str, list[SolverUnavailabilityWindow]] = {}
    for w in windows:
        by_res.setdefault(w.resource_id, []).append(w)
    out: list[SolverUnavailabilityWindow] = []
    for res, ws in by_res.items():
        ws_sorted = sorted(ws, key=lambda x: x.start_units)
        cur_start = cur_end = None
        for w in ws_sorted:
            if cur_start is None:
                cur_start, cur_end = w.start_units, w.end_units
                continue
            if w.start_units <= cur_end:
                cur_end = max(cur_end, w.end_units)
            else:
                out.append(SolverUnavailabilityWindow(
                    resource_id=res, start_units=cur_start, end_units=cur_end))
                cur_start, cur_end = w.start_units, w.end_units
        if cur_start is not None:
            out.append(SolverUnavailabilityWindow(
                resource_id=res, start_units=cur_start, end_units=cur_end))
    return out


def _resolve_objective_priority(
    objectives: list[Objective],
) -> tuple[Objective, list[Objective]]:
    if not objectives:
        return Objective(objective_name="minimize_makespan", priority_rank=1), []
    sorted_obj = sorted(objectives, key=lambda o: o.priority_rank)
    return sorted_obj[0], sorted_obj[1:]


# =============================================================================
# LangGraph node
# =============================================================================

def build_payload_node(state: SessionState) -> dict:
    if state.canonical_entities is None or state.constraint_registry is None:
        return {"errors": state.errors + ["build_payload: missing entities or registry"]}
    try:
        payload = build_solver_payload(
            entities=state.canonical_entities,
            objectives=state.objectives,
            registry=state.constraint_registry,
            horizon_start=state.horizon_start,
            time_unit_minutes=state.time_unit_minutes,
        )
    except ValueError as e:
        return {
            "errors": state.errors + [f"build_payload: {e}"],
            "current_stage": "SUFFICIENCY_FAILED",
        }
    horizon_start = state.horizon_start or _infer_horizon_start(state.canonical_entities)
    _logger.info(
        "[NODE] build_payload | jobs=%d | resources=%d | horizon_min=%d | hard_constraints=%s",
        len(payload.jobs), len(payload.resources), payload.horizon_minutes, payload.hard_constraints,
    )
    return {
        "solver_payload": payload,
        "horizon_start": horizon_start,
        "current_stage": "PAYLOAD_BUILT",
    }
