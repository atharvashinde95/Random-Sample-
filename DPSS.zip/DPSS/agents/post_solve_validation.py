"""Post-Solve Validation & KPI Computation (Stage 6).

Re-checks the solver output independently of CP-SAT and computes KPIs
from the schedule (not from solver internals).

Re-checks the solver's output independently of CP-SAT:
- all_operations_scheduled
- no_overlap_violations
- precedence_violations
- eligibility_violations
- calendar_violations
- due_date_violations

Computes KPIs from the schedule (not from solver internals):
- makespan, tardiness totals, late-job count
- per-resource utilization (busy / horizon)
- load balance score (1 - normalized stddev of per-resource busy units)
- estimated total cost (sum of busy_minutes * hourly_cost)
"""
from __future__ import annotations

import math
from typing import Optional

from core.logging_utils import get_logger, setup_logging
from core.schemas import (
    CanonicalEntities,
    KPISummary,
    PostSolveValidation,
    ScheduledOperation,
    SessionState,
    SolverPayload,
    SolverResult,
)

setup_logging()
_logger = get_logger(__name__)


# =============================================================================
# Public API
# =============================================================================

def validate_solution(
    payload: SolverPayload,
    result: SolverResult,
    entities: Optional[CanonicalEntities] = None,
) -> tuple[PostSolveValidation, KPISummary]:
    """Validate the schedule structurally and compute KPIs."""
    if result.solve_status not in ("OPTIMAL", "FEASIBLE"):
        empty_validation = PostSolveValidation(
            all_operations_scheduled=False,
            no_overlap_violations=True,
            precedence_violations=[],
            eligibility_violations=[],
            calendar_violations=[],
            due_date_violations=[],
            validation_passed=False,
            validation_warnings=[
                f"Solver did not produce a feasible result (status={result.solve_status})."
            ],
        )
        return empty_validation, KPISummary()

    expected_op_ids = {op.operation_id for j in payload.jobs for op in j.operations}
    scheduled_op_ids = {s.operation_id for s in result.scheduled_operations}
    all_scheduled = expected_op_ids == scheduled_op_ids

    no_overlap = _check_no_overlap(result.scheduled_operations)
    precedence_violations = _check_precedence(payload, result.scheduled_operations)
    eligibility_violations = _check_eligibility(payload, result.scheduled_operations)
    calendar_violations = _check_calendar(payload, result.scheduled_operations)
    due_date_violations = _check_due_dates(payload, result.scheduled_operations)

    warnings: list[str] = []
    if not all_scheduled:
        warnings.append(
            f"{len(expected_op_ids - scheduled_op_ids)} expected operation(s) not scheduled."
        )
    validation_passed = (
        all_scheduled
        and no_overlap
        and not precedence_violations
        and not eligibility_violations
        and not calendar_violations
    )

    validation = PostSolveValidation(
        all_operations_scheduled=all_scheduled,
        no_overlap_violations=not no_overlap,
        precedence_violations=precedence_violations,
        eligibility_violations=eligibility_violations,
        calendar_violations=calendar_violations,
        due_date_violations=due_date_violations,
        validation_passed=validation_passed,
        validation_warnings=warnings,
    )

    kpis = _compute_kpis(payload, result, entities)
    return validation, kpis


# =============================================================================
# Structural checks
# =============================================================================

def _check_no_overlap(ops: list[ScheduledOperation]) -> bool:
    by_resource: dict[str, list[ScheduledOperation]] = {}
    for o in ops:
        by_resource.setdefault(o.resource_id, []).append(o)
    for res_ops in by_resource.values():
        res_ops_sorted = sorted(res_ops, key=lambda x: x.start_units)
        for a, b in zip(res_ops_sorted, res_ops_sorted[1:]):
            if a.end_units > b.start_units:
                return False
    return True


def _check_precedence(
    payload: SolverPayload, ops: list[ScheduledOperation]
) -> list[str]:
    out: list[str] = []
    by_id = {o.operation_id: o for o in ops}
    for job in payload.jobs:
        ops_sorted = sorted(job.operations, key=lambda o: o.sequence_index)
        for a, b in zip(ops_sorted, ops_sorted[1:]):
            sa, sb = by_id.get(a.operation_id), by_id.get(b.operation_id)
            if sa is None or sb is None:
                continue
            if sb.start_units < sa.end_units:
                out.append(
                    f"job={job.job_id}: '{a.operation_id}' (end={sa.end_units}) "
                    f"precedes '{b.operation_id}' (start={sb.start_units})"
                )
    return out


def _check_eligibility(
    payload: SolverPayload, ops: list[ScheduledOperation]
) -> list[str]:
    eligibility: dict[str, set[str]] = {}
    for job in payload.jobs:
        for op in job.operations:
            eligibility[op.operation_id] = set(op.eligible_resource_ids)
    out: list[str] = []
    for s in ops:
        allowed = eligibility.get(s.operation_id)
        if allowed is None:
            out.append(f"unknown operation '{s.operation_id}' in schedule")
            continue
        if s.resource_id not in allowed:
            out.append(
                f"operation '{s.operation_id}' assigned to '{s.resource_id}' "
                f"which is not in eligible set {sorted(allowed)}"
            )
    return out


def _check_calendar(
    payload: SolverPayload, ops: list[ScheduledOperation]
) -> list[str]:
    """Verify that no scheduled op overlaps any unavailability window."""
    by_resource: dict[str, list[tuple[int, int]]] = {}
    for w in payload.unavailability_windows:
        by_resource.setdefault(w.resource_id, []).append((w.start_units, w.end_units))
    out: list[str] = []
    for s in ops:
        for ws, we in by_resource.get(s.resource_id, []):
            if s.start_units < we and s.end_units > ws:
                out.append(
                    f"operation '{s.operation_id}' on '{s.resource_id}' "
                    f"overlaps unavailability window [{ws},{we}]"
                )
    return out


def _check_due_dates(
    payload: SolverPayload, ops: list[ScheduledOperation]
) -> list[str]:
    out: list[str] = []
    by_id = {o.operation_id: o for o in ops}
    for job in payload.jobs:
        if job.due_time_units is None:
            continue
        last_op = max(job.operations, key=lambda o: o.sequence_index)
        s = by_id.get(last_op.operation_id)
        if s is None:
            continue
        if s.end_units > job.due_time_units:
            tardiness = s.end_units - job.due_time_units
            out.append(
                f"job '{job.job_id}': late by {tardiness} units "
                f"(end={s.end_units} > due={job.due_time_units})"
            )
    return out


# =============================================================================
# KPIs
# =============================================================================

def _compute_kpis(
    payload: SolverPayload,
    result: SolverResult,
    entities: Optional[CanonicalEntities],
) -> KPISummary:
    ops = result.scheduled_operations
    if not ops:
        return KPISummary()

    makespan = max(o.end_units for o in ops)
    horizon = max(makespan, 1)

    # Tardiness
    by_id = {o.operation_id: o for o in ops}
    total_tardiness = 0
    late_jobs = 0
    for job in payload.jobs:
        if job.due_time_units is None:
            continue
        last_op = max(job.operations, key=lambda o: o.sequence_index)
        s = by_id.get(last_op.operation_id)
        if s is None:
            continue
        t = max(0, s.end_units - job.due_time_units)
        total_tardiness += t
        if t > 0:
            late_jobs += 1

    # Resource utilization (over makespan)
    busy_per_res: dict[str, int] = {r.resource_id: 0 for r in payload.resources}
    for s in ops:
        busy_per_res[s.resource_id] = busy_per_res.get(s.resource_id, 0) + (s.end_units - s.start_units)
    utilization = {
        r_id: round(busy / horizon, 4) if horizon > 0 else 0.0
        for r_id, busy in busy_per_res.items()
    }

    # Load balance score: 1 - (stddev / mean) clipped to [0,1].
    busy_values = list(busy_per_res.values())
    load_score: Optional[float] = None
    if busy_values and any(busy_values):
        mean = sum(busy_values) / len(busy_values)
        var = sum((x - mean) ** 2 for x in busy_values) / len(busy_values)
        std = math.sqrt(var)
        if mean > 0:
            load_score = max(0.0, min(1.0, 1.0 - (std / mean)))

    # Estimated total cost
    cost: Optional[float] = None
    if entities is not None:
        cost_by_res = {r.resource_id: r.hourly_cost for r in entities.resources}
        running = 0.0
        any_cost = False
        for r_id, busy_units in busy_per_res.items():
            hourly = cost_by_res.get(r_id)
            if hourly is None:
                continue
            any_cost = True
            running += float(hourly) * (busy_units * payload.time_unit_minutes / 60.0)
        if any_cost:
            cost = round(running, 2)

    return KPISummary(
        makespan_units=int(makespan),
        total_tardiness_units=int(total_tardiness),
        total_late_jobs=int(late_jobs),
        resource_utilization=utilization,
        load_balance_score=round(load_score, 4) if load_score is not None else None,
        estimated_total_cost=cost,
    )


# =============================================================================
# LangGraph node
# =============================================================================

def validate_solution_node(state: SessionState) -> dict:
    if state.solver_payload is None or state.solver_result is None:
        return {"errors": state.errors + ["validate_solution: missing payload or result"]}
    validation, kpis = validate_solution(
        state.solver_payload, state.solver_result, state.canonical_entities
    )
    _logger.info(
        "[NODE] validate_solution | passed=%s | makespan=%s | late_jobs=%s | cost=%s",
        validation.validation_passed, kpis.makespan_units, kpis.total_late_jobs, kpis.estimated_total_cost,
    )
    return {
        "post_solve_validation": validation,
        "kpi_summary": kpis,
    }
