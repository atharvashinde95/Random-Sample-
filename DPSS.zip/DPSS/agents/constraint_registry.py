"""Deterministic Constraint Registry.

Activation, degrade, and unsupported decisions are made *only* from structural
evidence in CanonicalEntities — never from the LLM. classify_constraints() is
the sole writer of registry status.

Activation, degrade, and unsupported decisions are made *only* from structural
evidence in CanonicalEntities — never from the LLM.

The LLM may *propose* constraint candidates but cannot mark any constraint
'active'. classify_constraints() is the only writer of registry status.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from core.logging_utils import get_logger, setup_logging
from core.schemas import (
    ActiveConstraint,
    CanonicalEntities,
    ConstraintCandidate,
    ConstraintName,
    ConstraintRegistryState,
    DegradedConstraint,
    UnsupportedConstraint,
)

setup_logging()
_logger = get_logger(__name__)


# =============================================================================
# Registry data class
# =============================================================================

@dataclass(frozen=True)
class RegistryEntry:
    name: ConstraintName
    required_fields: tuple[tuple[str, str], ...]
    optional_fields: tuple[tuple[str, str], ...]
    supported_in_phase1: bool
    activation_rule: Callable[[CanonicalEntities], tuple[bool, list[str]]]
    degrade_rule: Callable[[CanonicalEntities], tuple[bool, list[str], str]]
    unsupported_rule: Callable[[CanonicalEntities], tuple[bool, str]]


# =============================================================================
# Predicate helpers (structural only)
# =============================================================================

def _has_jobs(e: CanonicalEntities) -> bool:
    return len(e.jobs) > 0


def _has_ops(e: CanonicalEntities) -> bool:
    return len(e.operations) > 0


def _has_durations(e: CanonicalEntities) -> bool:
    return _has_ops(e) and all(
        (o.processing_time_minutes is not None and o.processing_time_minutes >= 0)
        for o in e.operations
    )


def _has_resources(e: CanonicalEntities) -> bool:
    return len(e.resources) > 0


def _has_eligibility(e: CanonicalEntities) -> bool:
    return len(e.operation_eligibilities) > 0


def _has_calendar(e: CanonicalEntities) -> bool:
    return len(e.resource_calendars) > 0


def _has_due_dates(e: CanonicalEntities) -> bool:
    return any(j.due_time is not None for j in e.jobs)


def _has_setup_rules(e: CanonicalEntities) -> bool:
    return len(e.setup_rules) > 0


def _has_setup_families(e: CanonicalEntities) -> bool:
    return any(o.setup_family for o in e.operations)


def _has_blocked_calendar(e: CanonicalEntities) -> bool:
    return any(c.availability_type in ("blocked", "lunch", "maintenance")
               for c in e.resource_calendars)


def _has_batch_capacity(e: CanonicalEntities) -> bool:
    return any(o.batch_capacity_units is not None for o in e.operations)


def _has_inventory(e: CanonicalEntities) -> bool:
    return len(e.inventories) > 0


def _has_materials_or_bom(e: CanonicalEntities) -> bool:
    return len(e.materials) > 0 or len(e.bom_links) > 0


# =============================================================================
# Registry table
# =============================================================================

REGISTRY: dict[ConstraintName, RegistryEntry] = {
    "machine_capacity_no_overlap": RegistryEntry(
        name="machine_capacity_no_overlap",
        required_fields=(
            ("operation", "processing_time_minutes"),
            ("resource", "resource_id"),
        ),
        optional_fields=(),
        supported_in_phase1=True,
        activation_rule=lambda e: (
            _has_ops(e) and _has_durations(e) and _has_resources(e),
            ["operation.processing_time_minutes", "resource.resource_id"],
        ),
        degrade_rule=lambda e: (False, [], ""),
        unsupported_rule=lambda e: (False, ""),
    ),
    "operation_precedence": RegistryEntry(
        name="operation_precedence",
        required_fields=(
            ("operation", "sequence_index"),
            ("operation", "job_id"),
        ),
        optional_fields=(),
        supported_in_phase1=True,
        activation_rule=lambda e: (
            _has_ops(e) and all(o.sequence_index is not None for o in e.operations),
            ["operation.sequence_index", "operation.job_id"],
        ),
        degrade_rule=lambda e: (False, [], ""),
        unsupported_rule=lambda e: (False, ""),
    ),
    "machine_eligibility": RegistryEntry(
        name="machine_eligibility",
        required_fields=(
            ("operation_eligibility", "operation_id"),
            ("operation_eligibility", "resource_id"),
        ),
        optional_fields=(),
        supported_in_phase1=True,
        activation_rule=lambda e: (_has_eligibility(e), ["operation_eligibility.*"]),
        degrade_rule=lambda e: (
            (not _has_eligibility(e)) and _has_resources(e) and _has_ops(e),
            ["operation_eligibility"],
            "Treat all resources as eligible for all operations (any-machine fallback).",
        ),
        unsupported_rule=lambda e: (False, ""),
    ),
    "working_calendar": RegistryEntry(
        name="working_calendar",
        required_fields=(
            ("calendar_window", "resource_id"),
            ("calendar_window", "start_time"),
            ("calendar_window", "end_time"),
            ("calendar_window", "availability_type"),
        ),
        optional_fields=(),
        supported_in_phase1=True,
        activation_rule=lambda e: (
            _has_calendar(e),
            ["calendar_window.resource_id", "calendar_window.start_time",
             "calendar_window.end_time", "calendar_window.availability_type"],
        ),
        degrade_rule=lambda e: (
            not _has_calendar(e),
            ["resource_calendars"],
            "Assume 24/7 availability across the horizon.",
        ),
        unsupported_rule=lambda e: (False, ""),
    ),
    "lunch_break_or_downtime": RegistryEntry(
        name="lunch_break_or_downtime",
        required_fields=(
            ("calendar_window", "availability_type"),
        ),
        optional_fields=(),
        supported_in_phase1=True,
        activation_rule=lambda e: (
            _has_blocked_calendar(e),
            ["calendar_window.availability_type"],
        ),
        degrade_rule=lambda e: (False, [], ""),
        unsupported_rule=lambda e: (False, ""),
    ),
    "due_date": RegistryEntry(
        name="due_date",
        required_fields=(("job", "due_time"),),
        optional_fields=(("job", "late_penalty_per_unit_time"),),
        supported_in_phase1=True,
        activation_rule=lambda e: (_has_due_dates(e), ["job.due_time"]),
        degrade_rule=lambda e: (False, [], ""),
        unsupported_rule=lambda e: (False, ""),
    ),
    "setup_changeover": RegistryEntry(
        name="setup_changeover",
        required_fields=(
            ("operation", "setup_family"),
            ("setup_rule", "from_family"),
            ("setup_rule", "to_family"),
            ("setup_rule", "setup_minutes"),
        ),
        optional_fields=(),
        supported_in_phase1=True,
        activation_rule=lambda e: (
            _has_setup_rules(e) and _has_setup_families(e),
            ["operation.setup_family", "setup_rule.*"],
        ),
        degrade_rule=lambda e: (
            (not _has_setup_rules(e)) and _has_setup_families(e),
            ["setup_rule"],
            "Ignore setup time, schedule without changeover penalties.",
        ),
        unsupported_rule=lambda e: (False, ""),
    ),
    "batch_capacity": RegistryEntry(
        name="batch_capacity",
        required_fields=(("operation", "batch_capacity_units"),),
        optional_fields=(),
        supported_in_phase1=False,
        activation_rule=lambda e: (False, []),
        degrade_rule=lambda e: (False, [], ""),
        unsupported_rule=lambda e: (
            _has_batch_capacity(e),
            "Batch capacity detected but not modeled in Phase 1 CP-SAT formulation.",
        ),
    ),
    "inventory_availability": RegistryEntry(
        name="inventory_availability",
        required_fields=(("inventory_record", "on_hand_qty"),),
        optional_fields=(),
        supported_in_phase1=False,
        activation_rule=lambda e: (False, []),
        degrade_rule=lambda e: (False, [], ""),
        unsupported_rule=lambda e: (
            _has_inventory(e),
            "Inventory time-phasing not modeled in Phase 1.",
        ),
    ),
    "material_availability": RegistryEntry(
        name="material_availability",
        required_fields=(
            ("material", "material_id"),
            ("bom_link", "quantity_per_unit"),
        ),
        optional_fields=(),
        supported_in_phase1=False,
        activation_rule=lambda e: (False, []),
        degrade_rule=lambda e: (False, [], ""),
        unsupported_rule=lambda e: (
            _has_materials_or_bom(e),
            "Material flow / BOM consumption not modeled in Phase 1.",
        ),
    ),
}


# =============================================================================
# Public classification API
# =============================================================================

def classify_constraints(
    candidates: list[ConstraintCandidate],
    entities: CanonicalEntities,
) -> ConstraintRegistryState:
    """Decide active/degraded/unsupported using only structural evidence.

    The LLM-proposed candidates are recorded as 'detected' in the registry
    output, but they cannot directly cause activation.
    """
    active: list[ActiveConstraint] = []
    degraded: list[DegradedConstraint] = []
    unsupported: list[UnsupportedConstraint] = []

    proposed_names = {c.constraint_name for c in candidates}

    for name, entry in REGISTRY.items():
        if not entry.supported_in_phase1:
            ok_unsup, reason = entry.unsupported_rule(entities)
            if ok_unsup or name in proposed_names:
                unsupported.append(UnsupportedConstraint(
                    constraint_name=name,
                    reason=reason or "Not supported in Phase 1.",
                ))
            continue

        ok_active, satisfied = entry.activation_rule(entities)
        if ok_active:
            active.append(ActiveConstraint(
                constraint_name=name,
                activation_reason=f"Required fields present: {satisfied}",
                required_fields_satisfied=satisfied,
            ))
            continue

        ok_deg, missing, behavior = entry.degrade_rule(entities)
        if ok_deg:
            degraded.append(DegradedConstraint(
                constraint_name=name,
                missing_fields=missing,
                fallback_behavior=behavior,
            ))
            continue

        # If the LLM proposed it but we can neither activate nor degrade, mark unsupported.
        if name in proposed_names:
            unsupported.append(UnsupportedConstraint(
                constraint_name=name,
                reason="Required fields missing and no degrade fallback applies.",
            ))

    return ConstraintRegistryState(
        detected_constraints=candidates,
        active_constraints=active,
        degraded_constraints=degraded,
        unsupported_constraints=unsupported,
    )


# =============================================================================
# LangGraph node
# =============================================================================

def register_constraints_node(state) -> dict:
    if state.canonical_entities is None:
        return {"errors": state.errors + ["register_constraints: canonical_entities missing"]}
    registry = classify_constraints(state.constraint_candidates or [], state.canonical_entities)
    _logger.info(
        "[NODE] register_constraints | active=%d | degraded=%d | unsupported=%d",
        len(registry.active_constraints),
        len(registry.degraded_constraints),
        len(registry.unsupported_constraints),
    )
    return {
        "constraint_registry": registry,
        "current_stage": "CONSTRAINTS_REGISTERED",
    }
