from __future__ import annotations

from core.constants import SOLVER_TIMEOUT_SECONDS
from core.schemas import SessionState
from solver.cp_sat_solver import diagnose_infeasibility, solve


def solve_node(state: SessionState) -> dict:
    """LangGraph node wrapper around the deterministic CP-SAT solver."""
    if state.solver_payload is None:
        return {
            "errors": state.errors + ["solve: solver_payload missing"],
        }

    result = solve(state.solver_payload, timeout_seconds=SOLVER_TIMEOUT_SECONDS)

    delta = {
        "solver_result": result,
    }

    if result.solve_status == "INFEASIBLE":
        delta["infeasibility_report"] = diagnose_infeasibility(
            state.solver_payload,
            result,
        )
        delta["current_stage"] = "INFEASIBLE"
    else:
        delta["current_stage"] = "SOLVED"

    return delta