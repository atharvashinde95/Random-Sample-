"""Schema Mapping Agent (Stage 2).

Two paths:
  - file inputs (xlsx/csv): LLM proposes column->canonical_field mappings;
    this module then deterministically materializes CanonicalEntities by
    applying the mappings against full DataFrames.
  - prompt inputs: a single LLM call extracts CanonicalEntities directly
    from the user's text. The MappingReport is reduced to a stub.

Two paths:
  - file inputs (xlsx/csv): LLM proposes column->canonical_field mappings; this
    module then deterministically materializes CanonicalEntities by applying
    the mappings against full DataFrames.
  - prompt inputs: a single LLM call extracts CanonicalEntities directly from
    the user's text. The MappingReport is reduced to a stub (no tables).

No alias dictionaries are used. The LLM is shown allow-lists at runtime; this
module only enforces those allow-lists post-hoc and rejects off-list mappings
into 'unmapped_source_fields' / 'ambiguities'.
"""
from __future__ import annotations

import json
import math
import re
from datetime import datetime, timezone
from typing import Any, Optional

import pandas as pd
from dateutil import parser as date_parser
from pydantic import BaseModel, Field, ValidationError

from llm.client import LLMValidationError, call_json
from llm.prompts import (
    ALLOWED_CANONICAL_ENTITIES,
    ALLOWED_CANONICAL_FIELDS,
    SYS_MAPPING,
    SYS_PROMPT_EXTRACT,
    prompt_mapping,
    prompt_prompt_extract,
)
from core.logging_utils import get_logger, setup_logging
from core.schemas import (
    BOMLink,
    CalendarWindow,
    CanonicalEntities,
    CostParameter,
    FieldMapping,
    InventoryRecord,
    Job,
    MappingAmbiguity,
    MappingReport,
    Material,
    Operation,
    OperationEligibility,
    Resource,
    SessionState,
    SetupRule,
    SheetMapping,
    SourceInventory,
)
from ingestion.workbook_profiler import load_csv_table, load_xlsx_tables

setup_logging()
_logger = get_logger(__name__)


# =============================================================================
# Public API
# =============================================================================

def map_schema(
    source_inventory: SourceInventory,
    raw_path: Optional[str] = None,
    prompt_text: Optional[str] = None,
) -> tuple[MappingReport, CanonicalEntities]:
    """Produce a MappingReport and partial CanonicalEntities for any source type."""
    if source_inventory.source_type in ("xlsx", "csv"):
        if raw_path is None:
            raise ValueError("raw_path required for file-based mapping")
        return _map_file(source_inventory, raw_path)
    if source_inventory.source_type == "prompt":
        if prompt_text is None:
            raise ValueError("prompt_text required for prompt-based mapping")
        return _map_prompt(prompt_text)
    raise ValueError(f"Unknown source_type: {source_inventory.source_type}")


# =============================================================================
# File-based mapping
# =============================================================================

def _map_file(
    inventory: SourceInventory, raw_path: str
) -> tuple[MappingReport, CanonicalEntities]:
    raw = call_json(SYS_MAPPING, prompt_mapping(inventory), MappingReport)

    # Sanitize the LLM mapping against allow-lists.
    sanitized = _sanitize_mapping(raw)

    # Load full data and materialize entities.
    if inventory.source_type == "xlsx":
        tables = load_xlsx_tables(raw_path)
    else:
        tables = load_csv_table(raw_path, inventory.detected_tables[0] if inventory.detected_tables else None)

    entities = _materialize_entities(sanitized, tables)
    return sanitized, entities


def _sanitize_mapping(report: MappingReport) -> MappingReport:
    """Drop sheet/field mappings that don't match the allow-list. Move them to ambiguities/unmapped."""
    valid_sheet_mappings: list[SheetMapping] = []
    for sm in report.sheet_mappings:
        if sm.canonical_entity in ALLOWED_CANONICAL_ENTITIES:
            valid_sheet_mappings.append(sm)
        else:
            report.ambiguities.append(MappingAmbiguity(
                source_field=sm.source_name,
                candidate_mappings=[sm.canonical_entity],
                resolution_needed=True,
                reason=f"LLM proposed canonical_entity '{sm.canonical_entity}' not in allow-list.",
            ))

    valid_field_mappings: list[FieldMapping] = []
    for fm in report.field_mappings:
        allowed = ALLOWED_CANONICAL_FIELDS.get(fm.canonical_entity, [])
        if fm.canonical_field in allowed:
            valid_field_mappings.append(fm)
        else:
            if fm.source_field not in report.unmapped_source_fields:
                report.unmapped_source_fields.append(fm.source_field)
            report.ambiguities.append(MappingAmbiguity(
                source_field=fm.source_field,
                candidate_mappings=[f"{fm.canonical_entity}.{fm.canonical_field}"],
                resolution_needed=True,
                reason=(
                    f"LLM proposed '{fm.canonical_entity}.{fm.canonical_field}' "
                    "which is not in the allow-list for that entity."
                ),
            ))

    return report.model_copy(update={
        "sheet_mappings": valid_sheet_mappings,
        "field_mappings": valid_field_mappings,
    })


def _materialize_entities(
    report: MappingReport, tables: dict[str, pd.DataFrame]
) -> CanonicalEntities:
    """Apply mapping to raw tables and produce typed canonical entities."""
    sheet_to_entity = {sm.source_name: sm.canonical_entity for sm in report.sheet_mappings}

    # Group field mappings: source_field "TABLE.COL" -> (entity, canonical_field)
    field_routes: dict[tuple[str, str], tuple[str, str]] = {}
    for fm in report.field_mappings:
        key = _split_source_field(fm.source_field)
        if key is None:
            continue
        field_routes[key] = (fm.canonical_entity, fm.canonical_field)

    # Bucket rows from each table according to its sheet mapping.
    buckets: dict[str, list[dict[str, Any]]] = {e: [] for e in ALLOWED_CANONICAL_ENTITIES}

    for table_name, df in tables.items():
        target_entity = sheet_to_entity.get(table_name)
        # If the sheet wasn't mapped, we still allow per-column field mappings to claim rows
        # under whichever canonical entity is referenced most in that table.
        if target_entity is None:
            target_entity = _pick_entity_from_columns(table_name, df.columns, field_routes)
            if target_entity is None:
                continue

        for _, row in df.iterrows():
            obj: dict[str, Any] = {}
            for col in df.columns:
                route = field_routes.get((table_name, str(col)))
                if route is None:
                    continue
                ent, c_field = route
                if ent != target_entity:
                    continue
                obj[c_field] = _safe_cell(row[col])
            if obj:
                buckets[target_entity].append(obj)

    return _coerce_buckets_to_entities(buckets)


def _split_source_field(s: str) -> Optional[tuple[str, str]]:
    if "." in s:
        head, tail = s.split(".", 1)
        return head, tail
    return None


def _pick_entity_from_columns(
    table: str, columns, routes: dict[tuple[str, str], tuple[str, str]]
) -> Optional[str]:
    counts: dict[str, int] = {}
    for col in columns:
        r = routes.get((table, str(col)))
        if r is not None:
            counts[r[0]] = counts.get(r[0], 0) + 1
    if not counts:
        return None
    return max(counts.items(), key=lambda kv: kv[1])[0]


def _coerce_buckets_to_entities(buckets: dict[str, list[dict]]) -> CanonicalEntities:
    """Coerce raw dicts into typed Pydantic models, dropping rows that fail validation."""
    jobs = _coerce_list(buckets["job"], Job, _coerce_job_fields)
    operations = _coerce_list(buckets["operation"], Operation, _coerce_operation_fields)
    resources = _coerce_list(buckets["resource"], Resource, _coerce_resource_fields)
    eligibilities = _coerce_list(
        buckets["operation_eligibility"], OperationEligibility, lambda d: _coerce_str_fields(d, ["operation_id", "resource_id", "eligibility_type"])
    )
    calendars = _coerce_list(buckets["calendar_window"], CalendarWindow, _coerce_calendar_fields)
    setups = _coerce_list(buckets["setup_rule"], SetupRule, _coerce_setup_fields)
    materials = _coerce_list(buckets["material"], Material, _coerce_material_fields)
    inventories = _coerce_list(buckets["inventory_record"], InventoryRecord, _coerce_inventory_fields)
    bom_links = _coerce_list(buckets["bom_link"], BOMLink, _coerce_bom_fields)
    cost_params = _coerce_list(buckets["cost_parameter"], CostParameter, _coerce_cost_fields)

    # Auto-fill operation_id / sequence_index when missing.
    operations = _autofill_operation_keys(operations, jobs)
    jobs = _autofill_job_ids(jobs)
    resources = _autofill_resource_ids(resources)

    return CanonicalEntities(
        jobs=jobs,
        operations=operations,
        resources=resources,
        operation_eligibilities=eligibilities,
        resource_calendars=calendars,
        setup_rules=setups,
        materials=materials,
        inventories=inventories,
        bom_links=bom_links,
        cost_parameters=cost_params,
    )


def _coerce_list(rows, model_cls, coerce):
    out: list = []
    for r in rows:
        try:
            out.append(model_cls(**coerce(r)))
        except (ValidationError, ValueError, TypeError):
            continue
    return out


def _coerce_job_fields(d: dict) -> dict:
    r = dict(d)
    if "job_id" in r:
        r["job_id"] = str(r["job_id"])
    if "external_id" in r and r["external_id"] is not None:
        r["external_id"] = str(r["external_id"])
    if "product_id" in r and r["product_id"] is not None:
        r["product_id"] = str(r["product_id"])
    if "quantity" in r:
        r["quantity"] = _to_float(r["quantity"])
    if "release_time" in r:
        r["release_time"] = _to_datetime(r["release_time"])
    if "due_time" in r:
        r["due_time"] = _to_datetime(r["due_time"])
    if "priority" in r:
        r["priority"] = _to_int(r["priority"])
    if "late_penalty_per_unit_time" in r:
        r["late_penalty_per_unit_time"] = _to_float(r["late_penalty_per_unit_time"])
    return {k: v for k, v in r.items() if v is not None or k in ("metadata",)}


def _coerce_operation_fields(d: dict) -> dict:
    r = dict(d)
    for k in ("operation_id", "job_id", "operation_name", "operation_family", "setup_family", "requires_skill"):
        if k in r and r[k] is not None:
            r[k] = str(r[k])
    if "sequence_index" in r:
        r["sequence_index"] = _to_int(r["sequence_index"])
    if "processing_time_minutes" in r:
        r["processing_time_minutes"] = _to_int(r["processing_time_minutes"])
    if "batch_capacity_units" in r:
        r["batch_capacity_units"] = _to_float(r["batch_capacity_units"])
    return {k: v for k, v in r.items() if v is not None}


def _coerce_resource_fields(d: dict) -> dict:
    r = dict(d)
    for k in ("resource_id", "resource_group", "name"):
        if k in r and r[k] is not None:
            r[k] = str(r[k])
    if "resource_type" in r and r["resource_type"] is not None:
        rt = str(r["resource_type"]).lower().strip()
        if rt not in {"machine", "worker", "line", "printer", "generic"}:
            rt = "generic"
        r["resource_type"] = rt
    if "capacity" in r:
        r["capacity"] = _to_int(r["capacity"]) or 1
    if "hourly_cost" in r:
        r["hourly_cost"] = _to_float(r["hourly_cost"])
    return {k: v for k, v in r.items() if v is not None}


def _coerce_calendar_fields(d: dict) -> dict:
    r = dict(d)
    if "resource_id" in r:
        r["resource_id"] = str(r["resource_id"])
    if "start_time" in r:
        r["start_time"] = _to_datetime(r["start_time"])
    if "end_time" in r:
        r["end_time"] = _to_datetime(r["end_time"])
    if "availability_type" in r and r["availability_type"] is not None:
        at = str(r["availability_type"]).lower().strip()
        if at not in {"available", "blocked", "lunch", "maintenance"}:
            at = "available"
        r["availability_type"] = at
    return {k: v for k, v in r.items() if v is not None}


def _coerce_setup_fields(d: dict) -> dict:
    r = dict(d)
    for k in ("from_family", "to_family"):
        if k in r and r[k] is not None:
            r[k] = str(r[k])
    if "setup_minutes" in r:
        r["setup_minutes"] = _to_int(r["setup_minutes"])
    if "cleaning_minutes" in r:
        r["cleaning_minutes"] = _to_int(r["cleaning_minutes"])
    if "setup_cost" in r:
        r["setup_cost"] = _to_float(r["setup_cost"])
    if "cleaning_cost" in r:
        r["cleaning_cost"] = _to_float(r["cleaning_cost"])
    return {k: v for k, v in r.items() if v is not None}


def _coerce_material_fields(d: dict) -> dict:
    r = dict(d)
    for k in ("material_id", "material_name"):
        if k in r and r[k] is not None:
            r[k] = str(r[k])
    if "unit_cost" in r:
        r["unit_cost"] = _to_float(r["unit_cost"])
    if "safety_stock" in r:
        r["safety_stock"] = _to_float(r["safety_stock"])
    return {k: v for k, v in r.items() if v is not None}


def _coerce_inventory_fields(d: dict) -> dict:
    r = dict(d)
    for k in ("inventory_id", "item_id"):
        if k in r and r[k] is not None:
            r[k] = str(r[k])
    if "item_type" in r and r["item_type"] is not None:
        it = str(r["item_type"]).lower().strip()
        if it not in {"raw_material", "finished_good"}:
            it = "raw_material"
        r["item_type"] = it
    if "on_hand_qty" in r:
        r["on_hand_qty"] = _to_float(r["on_hand_qty"]) or 0.0
    if "safety_stock_qty" in r:
        r["safety_stock_qty"] = _to_float(r["safety_stock_qty"])
    return {k: v for k, v in r.items() if v is not None}


def _coerce_bom_fields(d: dict) -> dict:
    r = dict(d)
    for k in ("product_id", "material_id"):
        if k in r and r[k] is not None:
            r[k] = str(r[k])
    if "quantity_per_unit" in r:
        r["quantity_per_unit"] = _to_float(r["quantity_per_unit"]) or 0.0
    return {k: v for k, v in r.items() if v is not None}


def _coerce_cost_fields(d: dict) -> dict:
    r = dict(d)
    if "name" in r and r["name"] is not None:
        r["name"] = str(r["name"])
    if "value" in r:
        r["value"] = _to_float(r["value"]) or 0.0
    if "unit" in r and r["unit"] is not None:
        r["unit"] = str(r["unit"])
    return {k: v for k, v in r.items() if v is not None}


def _coerce_str_fields(d: dict, fields: list[str]) -> dict:
    r = dict(d)
    for k in fields:
        if k in r and r[k] is not None:
            r[k] = str(r[k])
    return {k: v for k, v in r.items() if v is not None}


def _autofill_job_ids(jobs: list[Job]) -> list[Job]:
    out: list[Job] = []
    for i, j in enumerate(jobs):
        if not j.job_id:
            j = j.model_copy(update={"job_id": f"J{i+1}"})
        out.append(j)
    return out


def _autofill_resource_ids(resources: list[Resource]) -> list[Resource]:
    out: list[Resource] = []
    for i, r in enumerate(resources):
        if not r.resource_id:
            r = r.model_copy(update={"resource_id": f"R{i+1}"})
        out.append(r)
    return out


def _autofill_operation_keys(
    operations: list[Operation], jobs: list[Job]
) -> list[Operation]:
    """Fill in operation_id / sequence_index when missing."""
    by_job: dict[str, list[Operation]] = {}
    for op in operations:
        by_job.setdefault(op.job_id, []).append(op)
    out: list[Operation] = []
    for job_id, ops in by_job.items():
        ops_sorted = sorted(ops, key=lambda o: (o.sequence_index if o.sequence_index is not None else 0))
        for idx, op in enumerate(ops_sorted, start=1):
            new = op.model_copy(update={
                "sequence_index": op.sequence_index if op.sequence_index is not None else idx,
                "operation_id": op.operation_id or f"OP_{job_id}_{idx}",
            })
            out.append(new)
    return out


# =============================================================================
# Type coercion helpers
# =============================================================================

def _to_int(v: Any) -> Optional[int]:
    if v is None:
        return None
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, (int,)):
        return v
    if isinstance(v, float):
        if math.isnan(v) or math.isinf(v):
            return None
        return int(v)
    s = str(v).strip()
    if not s:
        return None
    try:
        return int(float(s))
    except (TypeError, ValueError):
        return None


def _to_float(v: Any) -> Optional[float]:
    if v is None:
        return None
    if isinstance(v, bool):
        return float(v)
    if isinstance(v, (int, float)):
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            return None
        return float(v)
    s = str(v).strip()
    if not s:
        return None
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def _to_datetime(v: Any) -> Optional[datetime]:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v if v.tzinfo else v.replace(tzinfo=timezone.utc)
    s = str(v).strip()
    if not s:
        return None
    try:
        dt = date_parser.parse(s)
    except (ValueError, OverflowError, date_parser.ParserError):
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _safe_cell(v: Any) -> Any:
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return None
    if isinstance(v, pd.Timestamp):
        try:
            return v.to_pydatetime()
        except Exception:
            return str(v)
    return v


# =============================================================================
# Prompt-only entity extraction
# =============================================================================

class _PromptEntities(BaseModel):
    """Loose envelope used to validate prompt-extraction output."""
    jobs: list[dict] = Field(default_factory=list)
    operations: list[dict] = Field(default_factory=list)
    resources: list[dict] = Field(default_factory=list)
    operation_eligibilities: list[dict] = Field(default_factory=list)
    resource_calendars: list[dict] = Field(default_factory=list)
    setup_rules: list[dict] = Field(default_factory=list)
    materials: list[dict] = Field(default_factory=list)
    inventories: list[dict] = Field(default_factory=list)
    bom_links: list[dict] = Field(default_factory=list)
    cost_parameters: list[dict] = Field(default_factory=list)


def _map_prompt(prompt_text: str) -> tuple[MappingReport, CanonicalEntities]:
    raw = call_json(SYS_PROMPT_EXTRACT, prompt_prompt_extract(prompt_text), _PromptEntities)
    buckets = {
        "job": raw.jobs,
        "operation": raw.operations,
        "resource": raw.resources,
        "operation_eligibility": raw.operation_eligibilities,
        "calendar_window": raw.resource_calendars,
        "setup_rule": raw.setup_rules,
        "material": raw.materials,
        "inventory_record": raw.inventories,
        "bom_link": raw.bom_links,
        "cost_parameter": raw.cost_parameters,
    }
    entities = _coerce_buckets_to_entities(buckets)
    entities = _normalize_prompt_entities(entities)
    report = MappingReport(
        source_type="prompt",
        sheet_mappings=[],
        field_mappings=[],
        unmapped_source_fields=[],
        unmapped_canonical_fields=[],
        mapping_confidence=0.6 if entities.jobs else 0.3,
        ambiguities=[],
    )
    return report, entities


def _normalize_prompt_entities(entities: CanonicalEntities) -> CanonicalEntities:
    """Fix common LLM extraction errors for prompt-only inputs.

    Repairs:
    1. Operations whose job_id doesn't match any job -> auto-create the missing job.
    2. Jobs that have no operations -> sufficiency checker will ask back.
    3. Eligibilities referencing unknown operation_ids -> drop silently.
    4. If operations exist but eligibilities are empty AND resources exist,
       auto-fill all-eligible (any-machine) so the solver doesn't stall.
    """
    known_job_ids = {j.job_id for j in entities.jobs}
    known_op_ids  = {o.operation_id for o in entities.operations}

    # Create jobs for orphaned operations
    new_jobs = list(entities.jobs)
    for op in entities.operations:
        if op.job_id and op.job_id not in known_job_ids:
            new_jobs.append(Job(job_id=op.job_id))
            known_job_ids.add(op.job_id)

    # Drop eligibilities for unknown operations
    valid_eligibilities = [
        e for e in entities.operation_eligibilities
        if e.operation_id in known_op_ids
    ]

    # If no eligibilities but ops + resources exist, make all eligible (any-machine)
    if not valid_eligibilities and entities.operations and entities.resources:
        resource_ids = [r.resource_id for r in entities.resources]
        for op in entities.operations:
            for r_id in resource_ids:
                valid_eligibilities.append(
                    OperationEligibility(operation_id=op.operation_id, resource_id=r_id)
                )

    return CanonicalEntities(
        jobs=new_jobs,
        operations=entities.operations,
        resources=entities.resources,
        operation_eligibilities=valid_eligibilities,
        resource_calendars=entities.resource_calendars,
        setup_rules=entities.setup_rules,
        materials=entities.materials,
        inventories=entities.inventories,
        bom_links=entities.bom_links,
        cost_parameters=entities.cost_parameters,
    )


# =============================================================================
# LangGraph node
# =============================================================================

def map_schema_node(state: SessionState) -> dict:
    if state.source_inventory is None:
        return {"errors": state.errors + ["map_schema: source_inventory missing"]}
    raw_path: Optional[str] = None
    prompt_text: Optional[str] = None
    if state.source_type in ("xlsx", "csv"):
        if not state.raw_input_refs:
            return {"errors": state.errors + ["map_schema: raw_input_refs missing"]}
        raw_path = state.raw_input_refs[0]
    else:
        prompt_text = state.raw_input_refs[0] if state.raw_input_refs else ""

    try:
        report, entities = map_schema(
            state.source_inventory, raw_path=raw_path, prompt_text=prompt_text
        )
    except LLMValidationError as e:
        return {
            "errors": state.errors + [f"map_schema: LLM validation failed: {e.last_error}"],
            "current_stage": "UNDERSTOOD",
        }
    _logger.info(
        "[NODE] map_schema | jobs=%d | ops=%d | resources=%d | eligibilities=%d | confidence=%.2f",
        len(entities.jobs), len(entities.operations), len(entities.resources),
        len(entities.operation_eligibilities), report.mapping_confidence,
    )
    return {
        "mapping_report": report,
        "canonical_entities": entities,
        "current_stage": "MAPPED",
    }
