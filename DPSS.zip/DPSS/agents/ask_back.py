"""Ask-Back Orchestrator (Stage 4b).

Two responsibilities:
- rephrase_questions: optionally improves question_text via the LLM (phrasing only).
- merge_ask_back_answers: deterministically patches user answers into canonical
  entities, signals whether a remap is required, and advances ask_back_round.

Two responsibilities:
- generate_ask_back_node: optionally rephrase questions via the LLM (phrasing only).
- merge_answers_node: deterministically patch user answers back into canonical entities,
  signal whether a remap is required, and reset/advance ask_back_round.

Patching only mutates allowed fields and uses target_id where the question scope
requires it. Unknown answers are recorded under warnings, never silently used.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Optional

from dateutil import parser as date_parser
from pydantic import BaseModel, Field

from llm.client import LLMError, LLMValidationError, call_json
from llm.prompts import SYS_ASK_BACK_PHRASING, prompt_ask_back_phrasing
from core.logging_utils import get_logger, setup_logging
from core.schemas import (
    AskBackQuestion,
    CanonicalEntities,
    Objective,
    OperationEligibility,
    SessionState,
)

setup_logging()
_logger = get_logger(__name__)


# =============================================================================
# Optional LLM rephrasing (phrasing-only)
# =============================================================================

class _PhrasingItem(BaseModel):
    question_id: str
    question_text: str


class _PhrasingResult(BaseModel):
    questions: list[_PhrasingItem] = Field(default_factory=list)


def rephrase_questions(questions: list[AskBackQuestion]) -> list[AskBackQuestion]:
    """Optionally rephrase question_text only. Other fields are preserved.
    Failures fall back to the original questions.
    """
    if not questions:
        return questions
    minimal = [{"question_id": q.question_id, "question_text": q.question_text}
               for q in questions]
    try:
        result = call_json(
            SYS_ASK_BACK_PHRASING,
            prompt_ask_back_phrasing(json.dumps(minimal)),
            _PhrasingResult,
        )
    except (LLMValidationError, LLMError):
        return questions
    by_id = {item.question_id: item.question_text for item in result.questions}
    out: list[AskBackQuestion] = []
    for q in questions:
        new_text = by_id.get(q.question_id) or q.question_text
        out.append(q.model_copy(update={"question_text": new_text}))
    return out


# =============================================================================
# Answer merging (deterministic)
# =============================================================================

def merge_ask_back_answers(
    state: SessionState, answers: dict[str, Any]
) -> dict:
    """Patch the SessionState canonical entities with user-provided answers.

    Returns a state delta dict (the same shape LangGraph nodes return).
    """
    if state.canonical_entities is None:
        return {"errors": state.errors + ["merge_answers: canonical_entities missing"]}

    questions_by_id: dict[str, AskBackQuestion] = {q.question_id: q for q in state.ask_back_questions}
    entities = state.canonical_entities.model_copy(deep=True)
    objectives = list(state.objectives)
    warnings: list[str] = list(state.warnings)
    requires_remap = False

    for qid, raw_value in answers.items():
        q = questions_by_id.get(qid)
        if q is None:
            warnings.append(f"merge_answers: unknown question_id '{qid}' ignored.")
            continue

        # Skip / fallback handling.
        if raw_value is None or (isinstance(raw_value, str) and raw_value.strip() == ""):
            objectives = _apply_fallback(q, objectives, warnings)
            continue

        try:
            _apply_answer(q, raw_value, entities, objectives, warnings)
        except Exception as e:  # noqa: BLE001
            warnings.append(f"merge_answers: failed to apply answer for {qid}: {e}")

        if q.target_field in {"resources", "jobs", "operations"}:
            requires_remap = True

    new_answers = dict(state.ask_back_answers)
    new_answers.update({qid: v for qid, v in answers.items() if v is not None})

    user_messages = state.user_messages + [
        {"role": "system", "type": "ask_back_merge", "requires_remap": requires_remap}
    ]

    return {
        "canonical_entities": entities,
        "objectives": objectives,
        "ask_back_answers": new_answers,
        "ask_back_round": state.ask_back_round + 1,
        "warnings": warnings,
        "user_messages": user_messages,
        "current_stage": "REMAPPING" if requires_remap else "WAITING_FOR_USER_ANSWER",
    }


def _apply_answer(
    q: AskBackQuestion,
    value: Any,
    entities: CanonicalEntities,
    objectives: list[Objective],
    warnings: list[str],
) -> None:
    scope = q.target_scope
    field = q.target_field

    if scope == "operation" and field == "processing_time_minutes":
        if q.target_id is None:
            warnings.append("merge_answers: operation question missing target_id")
            return
        for op in entities.operations:
            if op.operation_id == q.target_id:
                op.processing_time_minutes = int(float(value))
                return
        warnings.append(f"merge_answers: operation '{q.target_id}' not found")
        return

    if scope == "job" and field == "due_time":
        if q.target_id is None:
            # global table answer: list of {job_id, due_time}
            if isinstance(value, list):
                mp: dict[str, str] = {}
                for row in value:
                    if isinstance(row, dict) and "job_id" in row and "due_time" in row:
                        mp[str(row["job_id"])] = str(row["due_time"])
                for j in entities.jobs:
                    if j.job_id in mp:
                        j.due_time = _parse_dt(mp[j.job_id])
                return
            warnings.append("merge_answers: due_time global expects a list of {job_id, due_time}")
            return
        for j in entities.jobs:
            if j.job_id == q.target_id:
                j.due_time = _parse_dt(value)
                return
        warnings.append(f"merge_answers: job '{q.target_id}' not found")
        return

    if scope == "global" and field == "operation_eligibility_policy":
        if str(value).strip().lower() in {"all_eligible", "any_machine"}:
            entities.operation_eligibilities = [
                OperationEligibility(operation_id=op.operation_id, resource_id=r.resource_id)
                for op in entities.operations
                for r in entities.resources
            ]
        return

    if scope == "global" and field == "cost_basis_policy":
        if str(value).strip().lower() == "drop_cost_objective":
            objectives[:] = [o for o in objectives if o.objective_name != "minimize_total_cost"]
        return

    if scope == "global" and field == "balance_objective_policy":
        if str(value).strip().lower() == "drop_balance_objective":
            objectives[:] = [o for o in objectives if o.objective_name != "balance_resource_load"]
        return

    if scope == "global" and field in {"jobs", "operations", "resources"}:
        # We expect the user to upload a file or table; that flow re-enters
        # map_schema (the requires_remap flag is set by the caller).
        return

    warnings.append(
        f"merge_answers: no handler for scope='{scope}', field='{field}' "
        f"(question_id={q.question_id})"
    )


def _apply_fallback(
    q: AskBackQuestion, objectives: list[Objective], warnings: list[str]
) -> list[Objective]:
    fb = q.fallback_if_skipped
    if fb is None:
        warnings.append(f"merge_answers: question {q.question_id} skipped without fallback")
        return objectives
    if fb == "drop_tardiness_objective":
        return [o for o in objectives if o.objective_name != "minimize_total_tardiness"]
    if fb == "drop_cost_objective":
        return [o for o in objectives if o.objective_name != "minimize_total_cost"]
    if fb == "drop_balance_objective":
        return [o for o in objectives if o.objective_name != "balance_resource_load"]
    if fb == "all_eligible":
        # Will be applied next round via _apply_answer; nothing to do here.
        warnings.append(f"merge_answers: fallback '{fb}' requires explicit answer to apply.")
        return objectives
    warnings.append(f"merge_answers: unknown fallback '{fb}' for question {q.question_id}")
    return objectives


def _parse_dt(value: Any) -> Optional[datetime]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    try:
        return date_parser.parse(str(value))
    except (ValueError, OverflowError, date_parser.ParserError):
        return None


# =============================================================================
# LangGraph nodes
# =============================================================================

def generate_ask_back_node(state: SessionState) -> dict:
    """Phrase the deterministically-generated questions. Failures keep originals."""
    questions = state.ask_back_questions or (
        state.sufficiency_report.ask_back_questions if state.sufficiency_report else []
    )
    if not questions:
        _logger.info("[NODE] generate_ask_back | no questions to send, passing through")
        return {"current_stage": "WAITING_FOR_USER_ANSWER"}
    rephrased = rephrase_questions(questions)
    _logger.info(
        "[NODE] generate_ask_back | questions=%d | round=%d",
        len(rephrased), state.ask_back_round,
    )
    return {
        "ask_back_questions": rephrased,
        "current_stage": "WAITING_FOR_USER_ANSWER",
    }


def merge_answers_node(state: SessionState) -> dict:
    answers = state.ask_back_answers or {}
    if not answers:
        _logger.info("[NODE] merge_answers | no answers yet — staying in WAITING_FOR_USER_ANSWER")
        return {"current_stage": "WAITING_FOR_USER_ANSWER"}
    _logger.info("[NODE] merge_answers | n_answers=%d | round=%d", len(answers), state.ask_back_round)
    return merge_ask_back_answers(state, answers)


def confirm_degraded_node(state: SessionState) -> dict:
    _logger.info("[NODE] confirm_degraded | degraded_solve_confirmed=True")
    return {
        "degraded_solve_confirmed": True,
        "current_stage": "DEGRADED_SOLVE_CONFIRMED",
    }
