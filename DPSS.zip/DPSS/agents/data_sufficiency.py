"""Data Sufficiency Gate (Stage 4, deterministic).

Decides solve_mode (full | degraded | blocked) and generates structured
ask-back questions for any critical missing field. No semantic alias logic —
only structural and dependency checks against the canonical entities.

Decides solve_mode (full | degraded | blocked) and generates structured ask-back
questions for any critical missing field. No semantic alias logic — only
structural and dependency checks against the canonical entities.
"""
from __future__ import annotations

import uuid
from typing import Optional

from core.constants import ASK_BACK_ROUND_LIMIT
from core.logging_utils import get_logger, setup_logging
from core.schemas import (
    AskBackQuestion,
    CanonicalEntities,
    ConstraintRegistryState,
    Objective,
    SessionState,
    SufficiencyReport,
)

setup_logging()
_logger = get_logger(__name__)


OBJECTIVE_REQUIREMENTS: dict[str, list[str]] = {
    "minimize_makespan": [
        "jobs", "operations", "resources", "durations", "eligibility_or_fallback",
    ],
    "minimize_total_tardiness": [
        "jobs", "operations", "resources", "durations", "eligibility_or_fallback",
        "due_times",
    ],
    "minimize_total_cost": [
        "jobs", "operations", "resources", "durations", "eligibility_or_fallback",
        "cost_basis",
    ],
    "balance_resource_load": [
        "jobs", "operations", "resources", "durations", "eligibility_or_fallback",
        "at_least_two_resources",
    ],
}


# =============================================================================
# Core checks
# =============================================================================

def _evaluate_core(e: CanonicalEntities) -> dict[str, bool]:
    return {
        "jobs": len(e.jobs) > 0,
        "operations": len(e.operations) > 0,
        "resources": len(e.resources) > 0,
        "durations": _all_have_durations(e),
        "eligibility_or_fallback": (
            len(e.operation_eligibilities) > 0 or len(e.resources) > 0
        ),
        "due_times": any(j.due_time is not None for j in e.jobs),
        "cost_basis": (
            any(r.hourly_cost is not None for r in e.resources)
            or len(e.cost_parameters) > 0
        ),
        "at_least_two_resources": len(e.resources) >= 2,
    }


def _all_have_durations(e: CanonicalEntities) -> bool:
    if not e.operations:
        return False
    return all(
        (o.processing_time_minutes is not None and o.processing_time_minutes >= 0)
        for o in e.operations
    )


# =============================================================================
# Public sufficiency check
# =============================================================================

def check_sufficiency(
    entities: CanonicalEntities,
    objectives: list[Objective],
    registry: Optional[ConstraintRegistryState],
) -> SufficiencyReport:
    core = _evaluate_core(entities)

    objective_feas: dict[str, bool] = {}
    critical_missing: list[str] = []

    target_objectives = objectives or [
        Objective(objective_name="minimize_makespan", priority_rank=1)
    ]
    for obj in target_objectives:
        reqs = OBJECTIVE_REQUIREMENTS.get(obj.objective_name, [])
        ok = all(core.get(r, False) for r in reqs)
        objective_feas[obj.objective_name] = ok
        if not ok:
            for r in reqs:
                if not core.get(r, False) and r not in critical_missing:
                    critical_missing.append(r)

    constraint_feas: dict[str, str] = {}
    if registry is not None:
        for c in registry.active_constraints:
            constraint_feas[c.constraint_name] = "active"
        for c in registry.degraded_constraints:
            constraint_feas[c.constraint_name] = "degraded"
        for c in registry.unsupported_constraints:
            constraint_feas[c.constraint_name] = "unsupported"

    can_solve_now = len(critical_missing) == 0
    has_degraded = bool(registry and registry.degraded_constraints)

    if not can_solve_now:
        solve_mode = "blocked"
    elif has_degraded:
        solve_mode = "degraded"
    else:
        solve_mode = "full"

    questions = generate_ask_back_questions(critical_missing, entities, objectives)

    return SufficiencyReport(
        can_solve_now=can_solve_now,
        solve_mode=solve_mode,
        critical_missing_fields=critical_missing,
        noncritical_missing_fields=[],
        objective_feasibility=objective_feas,
        constraint_feasibility=constraint_feas,
        ask_back_questions=questions,
    )


# =============================================================================
# Ask-back question generation
# =============================================================================

def generate_ask_back_questions(
    critical_missing: list[str],
    entities: CanonicalEntities,
    objectives: list[Objective],
) -> list[AskBackQuestion]:
    """Emit one AskBackQuestion per concrete missing piece (not per category)."""
    questions: list[AskBackQuestion] = []

    if "jobs" in critical_missing:
        questions.append(AskBackQuestion(
            question_id=_qid(),
            question_text="No jobs were detected. Provide at least one job to schedule.",
            expected_type="table",
            target_field="jobs",
            target_scope="global",
        ))

    if "operations" in critical_missing:
        questions.append(AskBackQuestion(
            question_id=_qid(),
            question_text="No operations were detected. Provide at least one operation per job.",
            expected_type="table",
            target_field="operations",
            target_scope="global",
        ))

    if "resources" in critical_missing:
        questions.append(AskBackQuestion(
            question_id=_qid(),
            question_text="No resources/machines were detected. Provide a list of resources (machines, lines, or printers).",
            expected_type="table",
            target_field="resources",
            target_scope="global",
        ))

    if "durations" in critical_missing:
        # One question per operation lacking a processing time.
        for op in entities.operations:
            if op.processing_time_minutes is None:
                label = op.operation_name or op.operation_id
                questions.append(AskBackQuestion(
                    question_id=_qid(),
                    question_text=(
                        f"What is the processing time (in minutes) for operation "
                        f"'{label}' on job '{op.job_id}'?"
                    ),
                    expected_type="number",
                    target_field="processing_time_minutes",
                    target_scope="operation",
                    target_id=op.operation_id,
                ))

    if "eligibility_or_fallback" in critical_missing:
        questions.append(AskBackQuestion(
            question_id=_qid(),
            question_text=(
                "Operations have no eligible resources. Should we treat all "
                "resources as eligible for every operation, or do you want to "
                "specify per-operation eligibility?"
            ),
            expected_type="enum",
            target_field="operation_eligibility_policy",
            target_scope="global",
            fallback_if_skipped="all_eligible",
        ))

    if "due_times" in critical_missing and any(
        o.objective_name == "minimize_total_tardiness" for o in objectives
    ):
        # One question per job missing a due date.
        missing_jobs = [j for j in entities.jobs if j.due_time is None]
        if missing_jobs:
            for j in missing_jobs:
                questions.append(AskBackQuestion(
                    question_id=_qid(),
                    question_text=(
                        f"Tardiness is part of your objective but job '{j.job_id}' "
                        "has no due date. Provide a due date in ISO 8601 format, "
                        "or skip to drop the tardiness objective."
                    ),
                    expected_type="datetime",
                    target_field="due_time",
                    target_scope="job",
                    target_id=j.job_id,
                    fallback_if_skipped="drop_tardiness_objective",
                ))
        else:
            questions.append(AskBackQuestion(
                question_id=_qid(),
                question_text=(
                    "Tardiness is part of your objective but no job has a due "
                    "date. Provide due dates or drop the tardiness objective."
                ),
                expected_type="table",
                target_field="due_time",
                target_scope="job",
                target_id=None,
                fallback_if_skipped="drop_tardiness_objective",
            ))

    if "cost_basis" in critical_missing and any(
        o.objective_name == "minimize_total_cost" for o in objectives
    ):
        questions.append(AskBackQuestion(
            question_id=_qid(),
            question_text=(
                "Cost minimization needs an hourly machine cost or a per-operation "
                "cost basis. Provide one of these or drop the cost objective."
            ),
            expected_type="enum",
            target_field="cost_basis_policy",
            target_scope="global",
            fallback_if_skipped="drop_cost_objective",
        ))

    if "at_least_two_resources" in critical_missing and any(
        o.objective_name == "balance_resource_load" for o in objectives
    ):
        questions.append(AskBackQuestion(
            question_id=_qid(),
            question_text=(
                "Load balancing requires at least 2 comparable resources. "
                "Add more resources, or skip to drop the balance objective."
            ),
            expected_type="enum",
            target_field="balance_objective_policy",
            target_scope="global",
            fallback_if_skipped="drop_balance_objective",
        ))

    return questions


def _qid() -> str:
    return str(uuid.uuid4())


# =============================================================================
# LangGraph node
# =============================================================================

def check_sufficiency_node(state: SessionState) -> dict:
    if state.canonical_entities is None:
        return {"errors": state.errors + ["check_sufficiency: canonical_entities missing"]}
    report = check_sufficiency(
        state.canonical_entities,
        state.objectives,
        state.constraint_registry,
    )
    _logger.info(
        "[NODE] check_sufficiency | can_solve=%s | mode=%s | missing=%s | ask_back_q=%d",
        report.can_solve_now, report.solve_mode,
        report.critical_missing_fields, len(report.ask_back_questions),
    )
    delta: dict = {
        "sufficiency_report": report,
        "ask_back_questions": report.ask_back_questions,
    }
    if report.can_solve_now:
        delta["current_stage"] = "SUFFICIENCY_PASSED"
    else:
        if state.ask_back_round >= ASK_BACK_ROUND_LIMIT:
            delta["current_stage"] = "DEGRADED_SOLVE_CONFIRMED"
            delta["warnings"] = state.warnings + [
                f"Reached ask-back round limit ({ASK_BACK_ROUND_LIMIT}); "
                "proceeding in degraded mode with available data."
            ]
            delta["degraded_solve_confirmed"] = True
        else:
            delta["current_stage"] = "SUFFICIENCY_FAILED"
    return delta
