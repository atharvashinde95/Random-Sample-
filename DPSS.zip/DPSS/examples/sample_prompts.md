# Sample Scheduling Prompts

Copy any of these into the **Prompt** input on the Input tab to quickly demo the copilot.

---

## 1. Minimal Job Shop (makespan)

```
I have 3 machines (M1, M2, M3) and 4 jobs.

Job A: Op1 on M1 takes 30 min, Op2 on M2 takes 20 min.
Job B: Op1 on M2 takes 25 min, Op2 on M3 takes 15 min.
Job C: Op1 on M1 takes 40 min, Op2 on M3 takes 10 min.
Job D: Op1 on M3 takes 20 min, Op2 on M1 takes 30 min.

Minimize total makespan.
```

---

## 2. Tardiness with Due Dates

```
I run a print shop with 2 presses (Press-A, Press-B).

Job P1: 1 operation, 60 minutes, due 2024-03-01 12:00 UTC.
Job P2: 1 operation, 45 minutes, due 2024-03-01 10:00 UTC.
Job P3: 1 operation, 90 minutes, due 2024-03-01 14:00 UTC.

All jobs can run on either press.
Minimize total tardiness.
```

---

## 3. Setup Changeovers

```
I have 2 production lines (Line1, Line2).
Products belong to families: A and B.
Setup time when switching from family A to B: 30 minutes.
Setup time when switching from family B to A: 20 minutes.
Same-family changeover: 0 minutes.

Jobs:
  - Job1: 1 op, family A, 45 min
  - Job2: 1 op, family B, 30 min
  - Job3: 1 op, family A, 60 min
  - Job4: 1 op, family B, 50 min

Minimize makespan.
```

---

## 4. Working Calendar with Lunch Break

```
I have 2 machines (CNC-1, CNC-2).
Working hours: 08:00–17:00 UTC each day.
Lunch break: 12:00–13:00 UTC (all machines).

Jobs:
  - Job1: Op1 (CNC-1 or CNC-2, 120 min), Op2 (CNC-1 or CNC-2, 60 min)
  - Job2: Op1 (CNC-1 or CNC-2, 90 min)
  - Job3: Op1 (CNC-1, 180 min)

Horizon: 2024-01-08 (Monday). Minimize makespan.
```

---

## 5. Load Balancing

```
I have 4 identical machines (M1, M2, M3, M4) and 8 jobs.
Each job has a single operation of 60 minutes.
All machines are eligible for all jobs.
Primary objective: minimize makespan.
Secondary objective: balance load across machines.
```
