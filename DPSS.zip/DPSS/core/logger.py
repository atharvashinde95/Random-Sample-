"""Structured terminal logger for the Scheduling Copilot pipeline.

Uses Python's standard `logging` module so output is always visible in the
Streamlit terminal on all platforms (including Windows).

Usage:
    from core.logger import log

    log.pipeline("Starting pipeline run", session_id="abc123")
    log.node("understand_problem", "Calling LLM...")
    log.llm_call("call_json", schema="ProblemUnderstandingReport")
    log.llm_ok("call_json", duration_ms=1200)
    log.llm_retry("call_json", attempt=1, error="ValidationError")
    log.llm_fail("call_json", error="Failed twice")
    log.route("check_sufficiency -> generate_ask_back")
    log.solver("CP-SAT started", jobs=5, horizon=480)
    log.solver_ok("OPTIMAL", makespan=320, duration_s=0.45)
    log.warn("pipeline", "Missing due dates")
    log.error("pipeline", "Unhandled exception", exc=e)
"""
from __future__ import annotations

import logging
import sys
import time
import traceback
from typing import Any

# ---------------------------------------------------------------------------
# Configure the root scheduler logger once at import time
# ---------------------------------------------------------------------------

_LOGGER_NAME = "scheduling_copilot"

def _setup_logger() -> logging.Logger:
    logger = logging.getLogger(_LOGGER_NAME)
    if logger.handlers:
        return logger  # already configured

    logger.setLevel(logging.DEBUG)

    # Always write to stdout so Streamlit's terminal shows the output
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)

    # Simple format: timestamp + level-like tag + message
    fmt = logging.Formatter(
        fmt="%(asctime)s.%(msecs)03d  %(message)s",
        datefmt="%H:%M:%S",
    )
    handler.setFormatter(fmt)
    logger.addHandler(handler)
    logger.propagate = False
    return logger


_log = _setup_logger()

# ---------------------------------------------------------------------------
# ANSI colour helpers — used in log tag strings
# ---------------------------------------------------------------------------

_RESET   = "\033[0m"
_BOLD    = "\033[1m"
_DIM     = "\033[2m"
_CYAN    = "\033[96m"
_GREEN   = "\033[92m"
_YELLOW  = "\033[93m"
_RED     = "\033[91m"
_MAGENTA = "\033[95m"
_BLUE    = "\033[94m"


def _kv(kwargs: dict) -> str:
    if not kwargs:
        return ""
    return "  " + "  ".join(f"{k}={v!r}" for k, v in kwargs.items())


def _emit(colour: str, tag: str, msg: str, **kv: Any) -> None:
    line = f"{colour}{_BOLD}[{tag}]{_RESET}  {msg}{_DIM}{_kv(kv)}{_RESET}"
    _log.info(line)


# ---------------------------------------------------------------------------
# Public logger facade
# ---------------------------------------------------------------------------

class _Logger:
    """Singleton-style logger with domain-specific methods."""

    # ---- Pipeline lifecycle -----------------------------------------------

    def pipeline(self, msg: str, **kv: Any) -> None:
        _emit(_CYAN, "PIPELINE", msg, **kv)

    def node(self, node_name: str, msg: str, **kv: Any) -> None:
        _emit(_BLUE, f"NODE:{node_name}", msg, **kv)

    def route(self, decision: str, **kv: Any) -> None:
        _emit(_MAGENTA, "ROUTE", decision, **kv)

    # ---- LLM calls --------------------------------------------------------

    def llm_call(self, fn: str, **kv: Any) -> None:
        _emit(_YELLOW, "LLM\u2192", fn, **kv)

    def llm_ok(self, fn: str, **kv: Any) -> None:
        _emit(_GREEN, "LLM\u2713", fn, **kv)

    def llm_retry(self, fn: str, attempt: int, **kv: Any) -> None:
        _emit(_YELLOW, "LLM\u21bb", f"{fn} (retry {attempt})", **kv)

    def llm_fail(self, fn: str, **kv: Any) -> None:
        _emit(_RED, "LLM\u2717", fn, **kv)

    # ---- Solver -----------------------------------------------------------

    def solver(self, msg: str, **kv: Any) -> None:
        _emit(_CYAN, "SOLVER", msg, **kv)

    def solver_ok(self, status: str, **kv: Any) -> None:
        _emit(_GREEN, "SOLVER\u2713", status, **kv)

    def solver_fail(self, status: str, **kv: Any) -> None:
        _emit(_RED, "SOLVER\u2717", status, **kv)

    # ---- Ingestion --------------------------------------------------------

    def ingest(self, msg: str, **kv: Any) -> None:
        _emit(_BLUE, "INGEST", msg, **kv)

    # ---- General ----------------------------------------------------------

    def warn(self, tag: str, msg: str, **kv: Any) -> None:
        line = f"{_YELLOW}{_BOLD}[WARN:{tag}]{_RESET}  {msg}{_DIM}{_kv(kv)}{_RESET}"
        _log.warning(line)

    def error(self, tag: str, msg: str, exc: BaseException | None = None, **kv: Any) -> None:
        line = f"{_RED}{_BOLD}[ERROR:{tag}]{_RESET}  {msg}{_DIM}{_kv(kv)}{_RESET}"
        _log.error(line)
        if exc is not None:
            tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
            for tb_line in tb.splitlines():
                _log.error(f"  {_DIM}{tb_line}{_RESET}")

    def separator(self, label: str = "") -> None:
        bar = "\u2500" * 60
        if label:
            pad = (58 - len(label)) // 2
            bar = "\u2500" * pad + f" {label} " + "\u2500" * pad
        _log.info(f"\n{_DIM}{bar}{_RESET}\n")


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

log = _Logger()


# ---------------------------------------------------------------------------
# Timer helper (context manager)
# ---------------------------------------------------------------------------

class _Timer:
    def __init__(self, label: str = ""):
        self.label = label
        self.ms: float = 0.0
        self._start: float = 0.0

    def __enter__(self) -> "_Timer":
        self._start = time.perf_counter()
        return self

    def __exit__(self, *_: Any) -> None:
        self.ms = (time.perf_counter() - self._start) * 1000


def timer(label: str = "") -> _Timer:
    return _Timer(label)
