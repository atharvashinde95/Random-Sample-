"""Shared logging utilities for the Scheduling Copilot.

Sets up one project-wide Python logger rooted at ``scheduling_copilot``.
Every module in the project should use::

    from core.logging_utils import get_logger
    logger = get_logger(__name__)

Call ``setup_logging()`` once at app startup (app.py does this).
"""
from __future__ import annotations

import logging
import sys
import time
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

_PROJECT_ROOT = "scheduling_copilot"
_FMT = "%(asctime)s.%(msecs)03d  %(message)s"
_DATEFMT = "%H:%M:%S"


def setup_logging(level: int = logging.DEBUG) -> None:
    """Configure the project logger once. Safe to call multiple times."""
    root = logging.getLogger(_PROJECT_ROOT)
    if root.handlers:
        return  # Already configured

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    handler.setFormatter(logging.Formatter(fmt=_FMT, datefmt=_DATEFMT))

    root.setLevel(level)
    root.addHandler(handler)
    root.propagate = False


def get_logger(name: str) -> logging.Logger:
    """Return a project-namespaced logger.

    If *name* is already ``scheduling_copilot.*`` it is returned as-is.
    Otherwise it is prefixed so all project logs share the same root.
    """
    if name.startswith(_PROJECT_ROOT):
        return logging.getLogger(name)
    # Convert package path to sub-logger: e.g. "agents.ask_back" → "scheduling_copilot.agents.ask_back"
    return logging.getLogger(f"{_PROJECT_ROOT}.{name}")


# ---------------------------------------------------------------------------
# Node helpers
# ---------------------------------------------------------------------------

def log_node_start(logger: logging.Logger, node_name: str) -> float:
    """Log that a node is starting; return a perf_counter start time."""
    logger.info("[NODE] START %s", node_name)
    return time.perf_counter()


def log_node_end(
    logger: logging.Logger,
    node_name: str,
    t0: float,
    **kv: Any,
) -> None:
    """Log that a node finished with elapsed time and key/value summary."""
    elapsed_ms = (time.perf_counter() - t0) * 1000
    kv_str = "  ".join(f"{k}={v}" for k, v in kv.items() if v is not None)
    logger.info("[NODE] END %s | elapsed=%.0fms  %s", node_name, elapsed_ms, kv_str)


# ---------------------------------------------------------------------------
# State summary helper
# ---------------------------------------------------------------------------

def _g(state: Any, key: str, default: Any = None) -> Any:
    """Get a field from a SessionState or a plain dict."""
    if isinstance(state, dict):
        return state.get(key, default)
    return getattr(state, key, default)


def summarize_state(state: Any) -> dict:
    """Return a compact, non-sensitive summary of a SessionState."""
    entities = _g(state, "canonical_entities")
    registry = _g(state, "constraint_registry")
    sr = _g(state, "solver_result")
    return {
        "stage":       _g(state, "current_stage"),
        "source_type": _g(state, "source_type"),
        "jobs":        len(entities.jobs) if entities else 0,
        "operations":  len(entities.operations) if entities else 0,
        "resources":   len(entities.resources) if entities else 0,
        "objectives":  len(_g(state, "objectives") or []),
        "active_constraints":   len(registry.active_constraints)   if registry else 0,
        "degraded_constraints": len(registry.degraded_constraints) if registry else 0,
        "ask_back_round":       _g(state, "ask_back_round", 0),
        "solver_status":        sr.solve_status if sr else None,
        "errors":   len(_g(state, "errors") or []),
        "warnings": len(_g(state, "warnings") or []),
    }
