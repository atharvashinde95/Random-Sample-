"""System-wide constants for the Scheduling Copilot."""
from __future__ import annotations

import os

# =============================================================================
# LLM / Ollama
# =============================================================================

OLLAMA_URL: str = os.environ.get("OLLAMA_URL", "http://localhost:11434/api/generate")
OLLAMA_MODEL: str = os.environ.get("OLLAMA_MODEL", "qwen2.5:3b")
OLLAMA_TIMEOUT_SECONDS: int = int(os.environ.get("OLLAMA_TIMEOUT_SECONDS", "180"))
OLLAMA_NUM_CTX: int = int(os.environ.get("OLLAMA_NUM_CTX", "4096"))
OLLAMA_SEED: int = int(os.environ.get("OLLAMA_SEED", "7"))

# =============================================================================
# Solver
# =============================================================================

SOLVER_TIMEOUT_SECONDS: int = int(os.environ.get("SOLVER_TIMEOUT_SECONDS", "30"))
SOLVER_NUM_WORKERS: int = 1
SOLVER_RANDOM_SEED: int = 7
SOLVER_TIME_BUFFER_FRACTION: float = 0.7  # primary objective gets this share of the budget

# =============================================================================
# Payload builder
# =============================================================================

DEFAULT_HORIZON_DAYS: int = 30
MIN_OPERATION_DURATION_UNITS: int = 1  # solver does not robustly handle 0-length intervals

# =============================================================================
# Data sufficiency / ask-back
# =============================================================================

ASK_BACK_ROUND_LIMIT: int = 3

# =============================================================================
# Workbook profiler
# =============================================================================

MAX_SAMPLE_ROWS: int = 3
MAX_CELL_LEN: int = 64  # truncate cell values to limit token cost & PII exposure
