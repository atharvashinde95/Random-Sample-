"""Time conversion utilities for the Scheduling Copilot.

Strict rule for the entire system:
    solver_units = floor((dt - horizon_start).total_seconds() / 60 / time_unit_minutes)

All datetimes must be timezone-aware (UTC). Naive datetimes are rejected.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional


def ensure_utc(dt: datetime) -> datetime:
    """Normalize a datetime to UTC. Reject naive datetimes."""
    if dt.tzinfo is None:
        raise ValueError(
            f"Naive datetime not allowed: {dt!r}. "
            "All datetimes must be timezone-aware (UTC)."
        )
    return dt.astimezone(timezone.utc)


def to_solver_units(
    dt: datetime,
    horizon_start: datetime,
    time_unit_minutes: int = 1,
) -> int:
    """Convert a datetime into integer solver units measured from horizon_start."""
    if time_unit_minutes <= 0:
        raise ValueError("time_unit_minutes must be positive")
    dt_u = ensure_utc(dt)
    h_u = ensure_utc(horizon_start)
    delta_seconds = (dt_u - h_u).total_seconds()
    return int(delta_seconds // 60 // time_unit_minutes)


def from_solver_units(
    units: int,
    horizon_start: datetime,
    time_unit_minutes: int = 1,
) -> datetime:
    """Inverse of to_solver_units."""
    if time_unit_minutes <= 0:
        raise ValueError("time_unit_minutes must be positive")
    h_u = ensure_utc(horizon_start)
    minutes = units * time_unit_minutes
    return h_u.replace(microsecond=0) + _minutes_delta(minutes)


def _minutes_delta(minutes: int):
    from datetime import timedelta
    return timedelta(minutes=minutes)


def compute_horizon_minutes(
    horizon_start: datetime,
    horizon_end: Optional[datetime],
    time_unit_minutes: int = 1,
    default_days: int = 30,
) -> int:
    """Compute the horizon length in solver units. Falls back to default_days if no end is given."""
    if horizon_end is not None:
        return to_solver_units(horizon_end, horizon_start, time_unit_minutes)
    return int((default_days * 24 * 60) // time_unit_minutes)
