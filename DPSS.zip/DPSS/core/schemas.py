"""Canonical Pydantic schemas.

Single source of truth for all data models: business entities, LLM output
envelopes, solver payload / result, session state, and KPI structures.

All LLM-output schemas use ConfigDict(extra="forbid") so unexpected keys hard-fail.
Internal schemas are permissive (extra="ignore") to allow forward-compatible state evolution.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

# =============================================================================
# Shared literal types
# =============================================================================

SourceType = Literal["xlsx", "csv", "prompt"]

ObjectiveName = Literal[
    "minimize_makespan",
    "minimize_total_tardiness",
    "minimize_total_cost",
    "balance_resource_load",
]

ConstraintName = Literal[
    "machine_capacity_no_overlap",
    "operation_precedence",
    "machine_eligibility",
    "working_calendar",
    "lunch_break_or_downtime",
    "due_date",
    "setup_changeover",
    "batch_capacity",
    "inventory_availability",
    "material_availability",
]

PipelineStage = Literal[
    "INPUT_RECEIVED",
    "UNDERSTOOD",
    "MAPPED",
    "OBJECTIVES_EXTRACTED",
    "CONSTRAINTS_REGISTERED",
    "SUFFICIENCY_FAILED",
    "WAITING_FOR_USER_ANSWER",
    "REMAPPING",
    "SUFFICIENCY_PASSED",
    "DEGRADED_SOLVE_CONFIRMED",
    "PAYLOAD_BUILT",
    "SOLVED",
    "INFEASIBLE",
    "EXPLAINED",
]

SolveStatus = Literal["OPTIMAL", "FEASIBLE", "INFEASIBLE", "TIMEOUT", "UNKNOWN"]


# =============================================================================
# Canonical business entities
# =============================================================================

class Job(BaseModel):
    job_id: str
    external_id: Optional[str] = None
    product_id: Optional[str] = None
    quantity: Optional[float] = None
    release_time: Optional[datetime] = None
    due_time: Optional[datetime] = None
    priority: Optional[int] = None
    customer_deadline_type: Optional[Literal["firm", "soft"]] = None
    late_penalty_per_unit_time: Optional[float] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Operation(BaseModel):
    operation_id: str
    job_id: str
    sequence_index: int
    operation_name: Optional[str] = None
    operation_family: Optional[str] = None
    processing_time_minutes: Optional[int] = None
    batch_capacity_units: Optional[float] = None
    setup_family: Optional[str] = None
    requires_skill: Optional[str] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Resource(BaseModel):
    resource_id: str
    resource_type: Literal["machine", "worker", "line", "printer", "generic"] = "machine"
    resource_group: Optional[str] = None
    name: Optional[str] = None
    capacity: Optional[int] = 1
    hourly_cost: Optional[float] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class OperationEligibility(BaseModel):
    operation_id: str
    resource_id: str
    eligibility_type: Literal["allowed", "preferred", "exclusive"] = "allowed"


class CalendarWindow(BaseModel):
    resource_id: str
    start_time: datetime
    end_time: datetime
    availability_type: Literal["available", "blocked", "lunch", "maintenance"]


class SetupRule(BaseModel):
    from_family: str
    to_family: str
    setup_minutes: Optional[int] = None
    setup_cost: Optional[float] = None
    cleaning_minutes: Optional[int] = None
    cleaning_cost: Optional[float] = None


class Material(BaseModel):
    material_id: str
    material_name: Optional[str] = None
    unit_cost: Optional[float] = None
    safety_stock: Optional[float] = None


class InventoryRecord(BaseModel):
    inventory_id: str
    item_type: Literal["raw_material", "finished_good"]
    item_id: str
    on_hand_qty: float
    safety_stock_qty: Optional[float] = None


class BOMLink(BaseModel):
    product_id: str
    material_id: str
    quantity_per_unit: float


class CostParameter(BaseModel):
    name: str
    value: float
    unit: Optional[str] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class CanonicalEntities(BaseModel):
    jobs: list[Job] = Field(default_factory=list)
    operations: list[Operation] = Field(default_factory=list)
    resources: list[Resource] = Field(default_factory=list)
    resource_calendars: list[CalendarWindow] = Field(default_factory=list)
    operation_eligibilities: list[OperationEligibility] = Field(default_factory=list)
    setup_rules: list[SetupRule] = Field(default_factory=list)
    inventories: list[InventoryRecord] = Field(default_factory=list)
    materials: list[Material] = Field(default_factory=list)
    bom_links: list[BOMLink] = Field(default_factory=list)
    cost_parameters: list[CostParameter] = Field(default_factory=list)


# =============================================================================
# Understanding & mapping (LLM outputs)
# =============================================================================

class ProblemUnderstandingReport(BaseModel):
    model_config = ConfigDict(extra="forbid")
    domain: str
    problem_type: str
    candidate_solver: str
    can_solve_with_cpsat: bool
    confidence: float = Field(ge=0, le=1)
    reasoning_summary: str


class SourceInventory(BaseModel):
    source_type: SourceType
    detected_tables: list[str] = Field(default_factory=list)
    detected_columns: dict[str, list[str]] = Field(default_factory=dict)
    row_counts: dict[str, int] = Field(default_factory=dict)
    sample_summary: dict[str, list[dict]] = Field(default_factory=dict)
    file_metadata: dict[str, Any] = Field(default_factory=dict)


class SheetMapping(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source_name: str
    canonical_entity: str
    confidence: float = Field(ge=0, le=1)
    mapping_method: Literal["llm_proposed", "derived", "explicit_prompt"]


class FieldMapping(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source_field: str
    canonical_entity: str
    canonical_field: str
    confidence: float = Field(ge=0, le=1)
    mapping_method: Literal["llm_proposed", "derived", "explicit_prompt"]


class MappingAmbiguity(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source_field: str
    candidate_mappings: list[str]
    resolution_needed: bool
    reason: str


class MappingReport(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source_type: SourceType
    sheet_mappings: list[SheetMapping] = Field(default_factory=list)
    field_mappings: list[FieldMapping] = Field(default_factory=list)
    unmapped_source_fields: list[str] = Field(default_factory=list)
    unmapped_canonical_fields: list[str] = Field(default_factory=list)
    mapping_confidence: float = Field(ge=0, le=1)
    ambiguities: list[MappingAmbiguity] = Field(default_factory=list)


# =============================================================================
# Objectives & constraints
# =============================================================================

class Objective(BaseModel):
    model_config = ConfigDict(extra="forbid")
    objective_name: ObjectiveName
    priority_rank: int
    weight: Optional[float] = None


class ConstraintCandidate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    constraint_name: ConstraintName
    source: Literal["dataset", "prompt", "derived"]
    evidence: list[str] = Field(default_factory=list)
    required_fields: list[str] = Field(default_factory=list)
    detected: bool = True


class ActiveConstraint(BaseModel):
    constraint_name: ConstraintName
    status: Literal["active"] = "active"
    activation_reason: str
    required_fields_satisfied: list[str]


class DegradedConstraint(BaseModel):
    constraint_name: ConstraintName
    status: Literal["degraded"] = "degraded"
    missing_fields: list[str]
    fallback_behavior: str


class UnsupportedConstraint(BaseModel):
    constraint_name: ConstraintName
    status: Literal["unsupported"] = "unsupported"
    reason: str


class ConstraintRegistryState(BaseModel):
    detected_constraints: list[ConstraintCandidate] = Field(default_factory=list)
    active_constraints: list[ActiveConstraint] = Field(default_factory=list)
    degraded_constraints: list[DegradedConstraint] = Field(default_factory=list)
    unsupported_constraints: list[UnsupportedConstraint] = Field(default_factory=list)


# =============================================================================
# LLM extraction envelope (objective + constraint extraction)
# =============================================================================

class ObjectiveConstraintExtraction(BaseModel):
    model_config = ConfigDict(extra="forbid")
    objectives: list[Objective] = Field(default_factory=list)
    constraint_candidates: list[ConstraintCandidate] = Field(default_factory=list)
    missing_data_hints: list[str] = Field(default_factory=list)
    stated_preferences: list[str] = Field(default_factory=list)


# =============================================================================
# Sufficiency & ask-back
# =============================================================================

class AskBackQuestion(BaseModel):
    question_id: str
    question_text: str
    expected_type: Literal["number", "datetime", "enum", "table", "boolean", "free_text"]
    target_field: str
    target_scope: Literal["job", "operation", "resource", "global"]
    target_id: Optional[str] = None
    fallback_if_skipped: Any = None


class SufficiencyReport(BaseModel):
    can_solve_now: bool
    solve_mode: Literal["full", "degraded", "blocked"]
    critical_missing_fields: list[str] = Field(default_factory=list)
    noncritical_missing_fields: list[str] = Field(default_factory=list)
    objective_feasibility: dict[str, bool] = Field(default_factory=dict)
    constraint_feasibility: dict[str, str] = Field(default_factory=dict)
    ask_back_questions: list[AskBackQuestion] = Field(default_factory=list)


# =============================================================================
# Solver payload
# =============================================================================

class SolverOperation(BaseModel):
    operation_id: str
    job_id: str
    sequence_index: int
    duration_units: int = Field(ge=0)
    eligible_resource_ids: list[str]
    setup_family: Optional[str] = None


class SolverJob(BaseModel):
    job_id: str
    operations: list[SolverOperation]
    due_time_units: Optional[int] = None
    release_time_units: Optional[int] = None
    late_penalty_per_unit: Optional[float] = None


class SolverResource(BaseModel):
    resource_id: str
    capacity: int = 1


class SolverUnavailabilityWindow(BaseModel):
    resource_id: str
    start_units: int
    end_units: int


class SolverObjective(BaseModel):
    primary_type: ObjectiveName
    weights: dict[str, float] = Field(default_factory=dict)
    strategy: Literal["weighted_sum", "lexicographic"] = "lexicographic"
    secondary_types: list[ObjectiveName] = Field(default_factory=list)


class SolverSoftConstraint(BaseModel):
    constraint_name: ConstraintName
    penalty_weight: float


class SolverPayload(BaseModel):
    time_unit_minutes: int = 1
    horizon_minutes: int
    jobs: list[SolverJob]
    resources: list[SolverResource]
    unavailability_windows: list[SolverUnavailabilityWindow] = Field(default_factory=list)
    setup_matrix: dict[str, dict[str, int]] = Field(default_factory=dict)
    objective: SolverObjective
    hard_constraints: list[ConstraintName]
    soft_constraints: list[SolverSoftConstraint] = Field(default_factory=list)


# =============================================================================
# Solver result
# =============================================================================

class ScheduledOperation(BaseModel):
    operation_id: str
    job_id: str
    resource_id: str
    start_units: int
    end_units: int
    is_late: Optional[bool] = None
    tardiness_units: Optional[int] = None


class SolverResult(BaseModel):
    solve_status: SolveStatus
    objective_value: Optional[float] = None
    makespan_units: Optional[int] = None
    scheduled_operations: list[ScheduledOperation] = Field(default_factory=list)
    solve_time_seconds: float
    optimality_gap: Optional[float] = None


class InfeasibilityReport(BaseModel):
    status: Literal["INFEASIBLE"] = "INFEASIBLE"
    likely_conflict_areas: list[str] = Field(default_factory=list)
    candidate_relaxations: list[str] = Field(default_factory=list)
    suggested_user_actions: list[str] = Field(default_factory=list)


# =============================================================================
# Post-solve & explanation
# =============================================================================

class PostSolveValidation(BaseModel):
    all_operations_scheduled: bool
    no_overlap_violations: bool
    precedence_violations: list[str] = Field(default_factory=list)
    eligibility_violations: list[str] = Field(default_factory=list)
    calendar_violations: list[str] = Field(default_factory=list)
    due_date_violations: list[str] = Field(default_factory=list)
    validation_passed: bool
    validation_warnings: list[str] = Field(default_factory=list)


class KPISummary(BaseModel):
    makespan_units: Optional[int] = None
    total_tardiness_units: Optional[int] = None
    total_late_jobs: Optional[int] = None
    resource_utilization: dict[str, float] = Field(default_factory=dict)
    load_balance_score: Optional[float] = None
    estimated_total_cost: Optional[float] = None


class ExplanationContext(BaseModel):
    solver_result: SolverResult
    kpi_summary: KPISummary
    post_solve_validation: PostSolveValidation
    active_constraints: list[ActiveConstraint] = Field(default_factory=list)
    degraded_constraints: list[DegradedConstraint] = Field(default_factory=list)
    unsupported_constraints: list[UnsupportedConstraint] = Field(default_factory=list)
    ask_back_history: list[AskBackQuestion] = Field(default_factory=list)
    ask_back_answers: dict[str, Any] = Field(default_factory=dict)
    objectives: list[Objective] = Field(default_factory=list)


# =============================================================================
# Top-level session state (LangGraph state)
# =============================================================================

class SessionState(BaseModel):
    """Complete session state — also the LangGraph StateGraph state object."""
    model_config = ConfigDict(arbitrary_types_allowed=True)

    session_id: str
    source_type: SourceType
    raw_input_refs: list[str] = Field(default_factory=list)
    user_messages: list[dict] = Field(default_factory=list)
    current_stage: PipelineStage = "INPUT_RECEIVED"
    time_unit_minutes: int = 1
    horizon_start: Optional[datetime] = None

    # Stage 1 / 2 outputs
    problem_understanding: Optional[ProblemUnderstandingReport] = None
    source_inventory: Optional[SourceInventory] = None
    mapping_report: Optional[MappingReport] = None
    canonical_entities: Optional[CanonicalEntities] = None

    # Stage 3 outputs
    objectives: list[Objective] = Field(default_factory=list)
    constraint_candidates: list[ConstraintCandidate] = Field(default_factory=list)
    missing_data_hints: list[str] = Field(default_factory=list)
    stated_preferences: list[str] = Field(default_factory=list)
    constraint_registry: Optional[ConstraintRegistryState] = None

    # Stage 4 outputs
    sufficiency_report: Optional[SufficiencyReport] = None
    ask_back_questions: list[AskBackQuestion] = Field(default_factory=list)
    ask_back_answers: dict[str, Any] = Field(default_factory=dict)
    ask_back_round: int = 0
    degraded_solve_confirmed: bool = False

    # Stage 5 / 6 outputs
    solver_payload: Optional[SolverPayload] = None
    solver_result: Optional[SolverResult] = None
    infeasibility_report: Optional[InfeasibilityReport] = None
    post_solve_validation: Optional[PostSolveValidation] = None
    kpi_summary: Optional[KPISummary] = None
    explanation_context: Optional[ExplanationContext] = None
    explanation_text: Optional[str] = None
    qa_turns: list[dict] = Field(default_factory=list)

    # Diagnostics
    warnings: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
