"""State helpers for the Scheduling Copilot.

SessionState is the LangGraph state object and is defined in core.schemas.
This module exists only to give the project a cleaner import surface.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from core.schemas import SessionState


def new_session_state(
    session_id: str,
    source_type: str,
    raw_input_refs: list[str] | None = None,
    horizon_start: datetime | None = None,
    time_unit_minutes: int = 1,
) -> SessionState:
    """Create a fresh SessionState instance with safe defaults."""
    return SessionState(
        session_id=session_id,
        source_type=source_type,  # type: ignore[arg-type]
        raw_input_refs=raw_input_refs or [],
        user_messages=[],
        current_stage="INPUT_RECEIVED",
        time_unit_minutes=time_unit_minutes,
        horizon_start=horizon_start or datetime.now(tz=timezone.utc).replace(microsecond=0),
        objectives=[],
        constraint_candidates=[],
        missing_data_hints=[],
        stated_preferences=[],
        ask_back_questions=[],
        ask_back_answers={},
        ask_back_round=0,
        degraded_solve_confirmed=False,
        qa_turns=[],
        warnings=[],
        errors=[],
    )


__all__ = ["SessionState", "new_session_state"]