"""CP-SAT Solver — pure deterministic.

Implements the Phase 1 model: alternative-resource intervals per operation,
operation precedence within a job, no-overlap on each resource (including
unavailability windows), release/due times, and sequence-dependent
setup_changeover. Objective strategy: lexicographic by priority_rank.
Determinism: fixed random_seed, num_search_workers=1.

Implements the Phase 1 model:
    - alternative-resource intervals per operation
    - operation precedence within a job
    - no-overlap on each resource (incl. unavailability windows)
    - release / due times
    - sequence-dependent setup_changeover (when active and a setup_matrix exists)

Objective strategy: lexicographic by priority_rank.
Determinism: random_seed=7, num_search_workers=1.
"""
from __future__ import annotations

import time
from typing import Optional

from ortools.sat.python import cp_model

from core.logging_utils import get_logger, setup_logging
from core.schemas import (
    InfeasibilityReport,
    ScheduledOperation,
    SolverObjective,
    SolverPayload,
    SolverResult,
)


from core.constants import SOLVER_TIME_BUFFER_FRACTION as SOLVE_TIME_BUFFER_FRACTION, SOLVER_NUM_WORKERS, SOLVER_RANDOM_SEED, SOLVER_TIMEOUT_SECONDS

setup_logging()
_logger = get_logger(__name__)


# =============================================================================
# Public API
# =============================================================================

def solve(payload: SolverPayload, timeout_seconds: int = 30) -> SolverResult:
    """Solve a SolverPayload. Returns SolverResult with the literal solver status."""
    primary_only_secondary = payload.objective.secondary_types or []
    strategy = "weighted_sum" if (not primary_only_secondary or payload.objective.strategy == "weighted_sum") else "lexicographic"

    _logger.info(
        "[SOLVER] START | jobs=%d | resources=%d | horizon_min=%d | strategy=%s | objective=%s | timeout=%ds",
        len(payload.jobs), len(payload.resources), payload.horizon_minutes,
        strategy, payload.objective.primary_type, timeout_seconds,
    )

    t0 = time.perf_counter()
    if strategy == "weighted_sum":
        result = _solve_single(payload, timeout_seconds)
    else:
        result = _solve_lexicographic(payload, timeout_seconds)

    elapsed = time.perf_counter() - t0
    result = result.model_copy(update={"solve_time_seconds": round(elapsed, 4)})

    if result.solve_status in ("OPTIMAL", "FEASIBLE"):
        _logger.info(
            "[SOLVER] END | status=%s | makespan=%s | ops_scheduled=%d | solve_time=%.3fs | gap=%s",
            result.solve_status, result.makespan_units,
            len(result.scheduled_operations), elapsed, result.optimality_gap,
        )
    else:
        _logger.warning(
            "[SOLVER] END | status=%s | solve_time=%.3fs",
            result.solve_status, elapsed,
        )
    return result


def diagnose_infeasibility(payload: SolverPayload, result: SolverResult) -> InfeasibilityReport:
    conflicts: list[str] = []
    relax: list[str] = []
    actions: list[str] = []

    total_proc = sum(op.duration_units for j in payload.jobs for op in j.operations)
    if total_proc > payload.horizon_minutes:
        conflicts.append(
            f"Total processing time {total_proc} units exceeds horizon "
            f"{payload.horizon_minutes} units."
        )
        relax.append("Increase horizon_minutes or reduce per-operation durations.")
        actions.append("Provide a longer horizon (e.g., explicit due dates further out).")

    for j in payload.jobs:
        if j.due_time_units is None:
            continue
        proc_sum = sum(op.duration_units for op in j.operations)
        if j.release_time_units is not None and j.release_time_units + proc_sum > j.due_time_units:
            conflicts.append(
                f"Job '{j.job_id}' release_time + processing exceeds due_time "
                f"({j.release_time_units}+{proc_sum} > {j.due_time_units})."
            )
            relax.append(f"Push out due date for job '{j.job_id}' or shrink durations.")
            actions.append(f"Update due_time for job '{j.job_id}'.")

    for j in payload.jobs:
        for op in j.operations:
            if not op.eligible_resource_ids:
                conflicts.append(f"Operation '{op.operation_id}' has no eligible resource.")
                relax.append(f"Add eligibility for '{op.operation_id}' or use any-machine fallback.")
                actions.append(f"Provide eligibility for operation '{op.operation_id}'.")

    if not conflicts:
        conflicts.append("No obvious structural conflict detected; likely an interaction "
                          "of calendar windows with operation durations.")
        relax.append("Relax working_calendar (mark longer 'available' windows).")
        actions.append("Inspect resource calendars and reduce blocked windows.")

    return InfeasibilityReport(
        likely_conflict_areas=conflicts,
        candidate_relaxations=relax,
        suggested_user_actions=actions,
    )


# =============================================================================
# Single-objective solve
# =============================================================================

def _solve_single(payload: SolverPayload, timeout_seconds: int) -> SolverResult:
    model, ctx = _build_model(payload)
    _set_objective(model, ctx, payload.objective)
    return _run_solver(model, ctx, payload, timeout_seconds)


def _solve_lexicographic(payload: SolverPayload, timeout_seconds: int) -> SolverResult:
    """Lex strategy: solve primary, fix it (with small slack), solve secondaries."""
    primary_budget = max(1, int(timeout_seconds * SOLVE_TIME_BUFFER_FRACTION))
    secondary_budget = max(1, timeout_seconds - primary_budget)

    model, ctx = _build_model(payload)
    primary_expr = _build_objective_expr(model, ctx, payload.objective.primary_type)
    if primary_expr is None:
        return _run_solver(model, ctx, payload, timeout_seconds)
    model.Minimize(primary_expr)

    solver = _make_solver(primary_budget)
    status = solver.Solve(model)
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return _to_result(solver, status, ctx, payload)

    primary_value = int(solver.ObjectiveValue())
    # Continue: fix primary <= primary_value, minimize first secondary.
    for secondary in payload.objective.secondary_types:
        model.Add(primary_expr <= primary_value)
        sec_expr = _build_objective_expr(model, ctx, secondary)
        if sec_expr is None:
            continue
        model.Minimize(sec_expr)
        solver = _make_solver(secondary_budget)
        status = solver.Solve(model)
        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            break
        # Primary now fixed implicitly by constraint; iterate next secondary.

    return _to_result(solver, status, ctx, payload)


# =============================================================================
# Model construction
# =============================================================================

class _ModelContext:
    def __init__(self) -> None:
        self.starts: dict[str, cp_model.IntVar] = {}
        self.ends: dict[str, cp_model.IntVar] = {}
        self.assignment: dict[tuple[str, str], cp_model.IntVar] = {}  # (op_id, res_id) -> bool
        self.intervals_by_resource: dict[str, list[cp_model.IntervalVar]] = {}
        self.op_index: dict[str, object] = {}
        self.last_op_per_job: dict[str, str] = {}
        self.makespan: Optional[cp_model.IntVar] = None
        self.tardiness: dict[str, cp_model.IntVar] = {}
        self.resource_load: dict[str, cp_model.IntVar] = {}


def _build_model(payload: SolverPayload) -> tuple[cp_model.CpModel, _ModelContext]:
    m = cp_model.CpModel()
    ctx = _ModelContext()
    H = payload.horizon_minutes

    for r in payload.resources:
        ctx.intervals_by_resource[r.resource_id] = []

    # ---- Variables and alternative intervals
    for job in payload.jobs:
        for op in job.operations:
            ctx.op_index[op.operation_id] = op
            s = m.NewIntVar(0, H, f"s_{op.operation_id}")
            e = m.NewIntVar(0, H, f"e_{op.operation_id}")
            ctx.starts[op.operation_id] = s
            ctx.ends[op.operation_id] = e
            assign_lits: list[cp_model.IntVar] = []
            for r_id in op.eligible_resource_ids:
                lit = m.NewBoolVar(f"x_{op.operation_id}_{r_id}")
                iv = m.NewOptionalIntervalVar(
                    s, op.duration_units, e, lit,
                    f"iv_{op.operation_id}_{r_id}",
                )
                ctx.intervals_by_resource[r_id].append(iv)
                ctx.assignment[(op.operation_id, r_id)] = lit
                assign_lits.append(lit)
            if not assign_lits:
                # No eligible resource — model is infeasible by construction.
                m.AddBoolAnd([m.NewBoolVar("infeasible_no_eligible")]).OnlyEnforceIf(
                    [m.NewBoolVar("dead").Not()]
                )
                continue
            m.AddExactlyOne(assign_lits)

        # ---- Precedence within a job
        ops_sorted = sorted(job.operations, key=lambda o: o.sequence_index)
        for a, b in zip(ops_sorted, ops_sorted[1:]):
            m.Add(ctx.starts[b.operation_id] >= ctx.ends[a.operation_id])
        if ops_sorted:
            ctx.last_op_per_job[job.job_id] = ops_sorted[-1].operation_id

        # ---- Release time
        if job.release_time_units is not None and ops_sorted:
            m.Add(ctx.starts[ops_sorted[0].operation_id] >= max(0, job.release_time_units))

    # ---- Unavailability windows per resource as fixed intervals
    for w in payload.unavailability_windows:
        if w.resource_id not in ctx.intervals_by_resource:
            continue
        if w.end_units <= w.start_units:
            continue
        iv = m.NewIntervalVar(
            w.start_units, w.end_units - w.start_units, w.end_units,
            f"unav_{w.resource_id}_{w.start_units}",
        )
        ctx.intervals_by_resource[w.resource_id].append(iv)

    # ---- No-overlap per resource
    for r_id, intervals in ctx.intervals_by_resource.items():
        if intervals:
            m.AddNoOverlap(intervals)

    # ---- Sequence-dependent setup_changeover
    if "setup_changeover" in payload.hard_constraints and payload.setup_matrix:
        _add_setup_changeover(m, payload, ctx)

    # ---- Auxiliary expressions: makespan, tardiness, resource load
    ctx.makespan = m.NewIntVar(0, H, "makespan")
    if ctx.ends:
        m.AddMaxEquality(ctx.makespan, list(ctx.ends.values()))

    for job in payload.jobs:
        if job.due_time_units is None or job.job_id not in ctx.last_op_per_job:
            continue
        last_op_end = ctx.ends[ctx.last_op_per_job[job.job_id]]
        t = m.NewIntVar(0, H, f"t_{job.job_id}")
        m.AddMaxEquality(t, [last_op_end - job.due_time_units, m.NewConstant(0)])
        ctx.tardiness[job.job_id] = t

    for r in payload.resources:
        load = m.NewIntVar(0, H, f"load_{r.resource_id}")
        terms = []
        for job in payload.jobs:
            for op in job.operations:
                lit = ctx.assignment.get((op.operation_id, r.resource_id))
                if lit is None:
                    continue
                terms.append(op.duration_units * lit)
        if terms:
            m.Add(load == sum(terms))
        else:
            m.Add(load == 0)
        ctx.resource_load[r.resource_id] = load

    return m, ctx


def _add_setup_changeover(
    model: cp_model.CpModel, payload: SolverPayload, ctx: _ModelContext
) -> None:
    """For each pair of operations on the same resource with different setup
    families, enforce: if both are assigned to the same resource and op_a precedes
    op_b on that resource, then start_b >= end_a + setup_matrix[a.family][b.family].
    """
    matrix = payload.setup_matrix

    ops_by_resource: dict[str, list] = {}
    for job in payload.jobs:
        for op in job.operations:
            for r_id in op.eligible_resource_ids:
                ops_by_resource.setdefault(r_id, []).append(op)

    for r_id, ops in ops_by_resource.items():
        for i, a in enumerate(ops):
            for b in ops[i + 1:]:
                if a.operation_id == b.operation_id:
                    continue
                if a.setup_family is None or b.setup_family is None:
                    continue
                if a.setup_family == b.setup_family:
                    continue
                setup_ab = matrix.get(a.setup_family, {}).get(b.setup_family, 0)
                setup_ba = matrix.get(b.setup_family, {}).get(a.setup_family, 0)
                if setup_ab == 0 and setup_ba == 0:
                    continue
                la = ctx.assignment.get((a.operation_id, r_id))
                lb = ctx.assignment.get((b.operation_id, r_id))
                if la is None or lb is None:
                    continue
                # Direction lit: a before b
                ab = model.NewBoolVar(f"prec_{a.operation_id}_{b.operation_id}_{r_id}")
                # Both assigned to r and a-before-b => start_b >= end_a + setup
                model.Add(
                    ctx.starts[b.operation_id] >= ctx.ends[a.operation_id] + setup_ab
                ).OnlyEnforceIf([la, lb, ab])
                model.Add(
                    ctx.starts[a.operation_id] >= ctx.ends[b.operation_id] + setup_ba
                ).OnlyEnforceIf([la, lb, ab.Not()])


def _build_objective_expr(
    model: cp_model.CpModel, ctx: _ModelContext, name: str
):
    if name == "minimize_makespan":
        return ctx.makespan
    if name == "minimize_total_tardiness":
        if not ctx.tardiness:
            return None
        return sum(ctx.tardiness.values())
    if name == "balance_resource_load":
        if not ctx.resource_load:
            return None
        max_load = model.NewIntVar(0, 10**9, "max_load")
        model.AddMaxEquality(max_load, list(ctx.resource_load.values()))
        return max_load
    if name == "minimize_total_cost":
        # Without explicit per-op cost, fall back to sum of (load * proxy_cost=1) — i.e. makespan.
        return ctx.makespan
    return None


def _set_objective(
    model: cp_model.CpModel, ctx: _ModelContext, objective: SolverObjective
) -> None:
    expr = _build_objective_expr(model, ctx, objective.primary_type)
    if expr is None:
        return
    model.Minimize(expr)


def _make_solver(timeout_seconds: int) -> cp_model.CpSolver:
    s = cp_model.CpSolver()
    s.parameters.max_time_in_seconds = max(1, int(timeout_seconds))
    s.parameters.num_search_workers = SOLVER_NUM_WORKERS
    s.parameters.random_seed = SOLVER_RANDOM_SEED
    return s


def _run_solver(
    model: cp_model.CpModel, ctx: _ModelContext,
    payload: SolverPayload, timeout_seconds: int,
) -> SolverResult:
    solver = _make_solver(timeout_seconds)
    status = solver.Solve(model)
    return _to_result(solver, status, ctx, payload)


def _to_result(
    solver: cp_model.CpSolver, status: int,
    ctx: _ModelContext, payload: SolverPayload,
) -> SolverResult:
    status_label = _status_label(status)
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return SolverResult(
            solve_status=status_label,
            objective_value=None,
            makespan_units=None,
            scheduled_operations=[],
            solve_time_seconds=0.0,  # filled in by solve()
            optimality_gap=None,
        )

    scheduled: list[ScheduledOperation] = []
    for job in payload.jobs:
        for op in job.operations:
            assigned_resource: Optional[str] = None
            for r_id in op.eligible_resource_ids:
                lit = ctx.assignment.get((op.operation_id, r_id))
                if lit is None:
                    continue
                if solver.Value(lit) == 1:
                    assigned_resource = r_id
                    break
            if assigned_resource is None:
                continue
            start_v = int(solver.Value(ctx.starts[op.operation_id]))
            end_v = int(solver.Value(ctx.ends[op.operation_id]))
            tard = ctx.tardiness.get(job.job_id)
            tard_v = int(solver.Value(tard)) if tard is not None else None
            is_late = (tard_v is not None and tard_v > 0) if tard_v is not None else None
            scheduled.append(ScheduledOperation(
                operation_id=op.operation_id,
                job_id=job.job_id,
                resource_id=assigned_resource,
                start_units=start_v,
                end_units=end_v,
                is_late=is_late,
                tardiness_units=tard_v,
            ))

    makespan_v = int(solver.Value(ctx.makespan)) if ctx.makespan is not None else None
    obj_value = float(solver.ObjectiveValue()) if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None
    gap = (
        float(solver.BestObjectiveBound() / max(1.0, abs(obj_value)))
        if obj_value not in (None, 0)
        else None
    )

    return SolverResult(
        solve_status=status_label,
        objective_value=obj_value,
        makespan_units=makespan_v,
        scheduled_operations=scheduled,
        solve_time_seconds=0.0,  # filled in by solve()
        optimality_gap=None if status == cp_model.OPTIMAL else (gap if gap is not None else None),
    )


def _status_label(status: int) -> str:
    return {
        cp_model.OPTIMAL: "OPTIMAL",
        cp_model.FEASIBLE: "FEASIBLE",
        cp_model.INFEASIBLE: "INFEASIBLE",
        cp_model.MODEL_INVALID: "UNKNOWN",
        cp_model.UNKNOWN: "UNKNOWN",
    }.get(status, "UNKNOWN")


# =============================================================================
# LangGraph node
# =============================================================================




def solve_node(state) -> dict:  # noqa: kept here for import convenience
    if state.solver_payload is None:
        _logger.error("[NODE] solve | ERROR: solver_payload is missing")
        return {"errors": state.errors + ["solve: solver_payload missing"]}
    result = solve(state.solver_payload, timeout_seconds=SOLVER_TIMEOUT_SECONDS)
    delta: dict = {"solver_result": result}
    if result.solve_status in ("INFEASIBLE", "UNKNOWN", "TIMEOUT"):
        _logger.warning("[NODE] solve | status=%s | running infeasibility diagnosis", result.solve_status)
        delta["infeasibility_report"] = diagnose_infeasibility(state.solver_payload, result)
        delta["current_stage"] = "INFEASIBLE"
    else:
        _logger.info("[NODE] solve | status=%s | makespan=%s", result.solve_status, result.makespan_units)
        delta["current_stage"] = "SOLVED"
    return delta
