"""UI formatting helpers.

Pure functions that convert domain values into display-friendly strings or
Streamlit markup. No st.* calls live here — this module is importable
outside a Streamlit context (useful for tests or CLI tools).
"""
from __future__ import annotations

from typing import Optional


def pct(value: float) -> str:
    """Format a 0-1 float as a percentage string."""
    return f"{value:.0%}"


def badge(label: str, ok: bool) -> str:
    """Return a simple emoji-prefixed status badge string."""
    icon = "✅" if ok else "⏳"
    return f"{icon} {label}"


def solve_status_level(status: str) -> str:
    """Map a SolveStatus string to a Streamlit alert level."""
    return {
        "OPTIMAL": "success",
        "FEASIBLE": "info",
        "INFEASIBLE": "error",
        "TIMEOUT": "warning",
        "UNKNOWN": "warning",
    }.get(status, "info")


def units_to_hhmm(units: int, time_unit_minutes: int = 1) -> str:
    """Convert solver units to a HH:MM string for display."""
    total_minutes = units * time_unit_minutes
    hours, minutes = divmod(total_minutes, 60)
    return f"{hours:02d}:{minutes:02d}"


def truncate(text: str, max_len: int = 80) -> str:
    """Truncate a string with an ellipsis for display."""
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "…"
