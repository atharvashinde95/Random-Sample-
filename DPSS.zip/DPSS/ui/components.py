"""Streamlit UI component renderers — one function per tab.

Each renderer reads st.session_state and gates content on current_stage.
No direct LangGraph calls here — all graph interactions go through app.py.
"""
from __future__ import annotations

import json
import tempfile
from datetime import datetime, timezone
from typing import Any, Optional

import pandas as pd
import plotly.express as px
import streamlit as st

from core.schemas import (
    AskBackQuestion,
    ExplanationContext,
    KPISummary,
    SessionState,
    SolverResult,
)


# =============================================================================
# Helpers
# =============================================================================

def _state() -> Any:
    return st.session_state.get("state_snapshot")


def _get(s: Any, key: str, default: Any = None) -> Any:
    if s is None:
        return default
    if isinstance(s, dict):
        return s.get(key, default)
    return getattr(s, key, default)


def _stage() -> str:
    s = _state()
    return _get(s, "current_stage", "INPUT_RECEIVED")


def _badge(label: str, ok: bool) -> str:
    icon = "✅" if ok else "⏳"
    return f"{icon} {label}"


# =============================================================================
# Tab 1 — Input
# =============================================================================

def render_input_tab():
    st.header("📂 Input")
    src = st.radio("Source type", ["Prompt", "XLSX", "CSV"], horizontal=True, key="src_radio")

    horizon_start = st.date_input(
        "Horizon start date",
        value=datetime.now(tz=timezone.utc).date(),
        key="horizon_date",
    )
    horizon_dt = datetime(
        horizon_start.year, horizon_start.month, horizon_start.day,
        tzinfo=timezone.utc,
    )

    raw_ref: Optional[str] = None

    if src == "Prompt":
        raw_ref = st.text_area(
            "Describe your scheduling problem",
            height=220,
            placeholder=(
                "E.g. I have 3 machines and 5 jobs. Each job has 2 operations. "
                "I want to minimize makespan..."
            ),
            key="prompt_input",
        )
    elif src == "XLSX":
        f = st.file_uploader("Upload XLSX", type=["xlsx"], key="xlsx_upload")
        if f is not None:
            tmp = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False)
            tmp.write(f.read())
            tmp.flush()
            raw_ref = tmp.name
    else:
        f = st.file_uploader("Upload CSV", type=["csv"], key="csv_upload")
        if f is not None:
            tmp = tempfile.NamedTemporaryFile(suffix=".csv", delete=False)
            tmp.write(f.read())
            tmp.flush()
            raw_ref = tmp.name

    if st.button("▶ Run pipeline", type="primary", disabled=not raw_ref):
        st.session_state["pending_run"] = {
            "source_type": src.lower(),
            "raw_ref": raw_ref,
            "horizon_dt": horizon_dt,
        }
        st.rerun()

    s = _state()
    errors = _get(s, "errors")
    if s and errors:
        st.error("Pipeline errors:\n" + "\n".join(f"• {e}" for e in errors))
    
    warnings = _get(s, "warnings")
    if s and warnings:
        st.warning("Warnings:\n" + "\n".join(f"• {w}" for w in warnings))


# =============================================================================
# Tab 2 — Problem Understanding
# =============================================================================

def render_understanding_tab():
    st.header("🔍 Problem Understanding")
    s = _state()
    pu = _get(s, "problem_understanding")
    if s is None or pu is None:
        st.info("Run the pipeline first (Tab 1).")
        return

    inv = _get(s, "source_inventory")

    col1, col2, col3 = st.columns(3)
    col1.metric("Domain", pu.domain)
    col2.metric("Problem type", pu.problem_type)
    col3.metric("Confidence", f"{pu.confidence:.0%}")

    col4, col5 = st.columns(2)
    col4.metric("Candidate solver", pu.candidate_solver)
    col5.metric("CP-SAT suitable", "Yes" if pu.can_solve_with_cpsat else "No")

    st.markdown(f"**Reasoning:** {pu.reasoning_summary}")

    if inv:
        with st.expander("Source inventory"):
            st.write(f"**Type:** {inv.source_type}")
            st.write(f"**Tables:** {', '.join(inv.detected_tables) or '(none)'}")
            st.write(f"**Row counts:** {inv.row_counts}")


# =============================================================================
# Tab 3 — Schema Mapping
# =============================================================================

def render_mapping_tab():
    st.header("🗺️ Schema Mapping")
    s = _state()
    mr = _get(s, "mapping_report")
    if s is None or mr is None:
        st.info("Mapping not yet complete.")
        return

    col1, col2 = st.columns(2)
    col1.metric("Mapping confidence", f"{mr.mapping_confidence:.0%}")
    col2.metric("Ambiguities", len(mr.ambiguities))

    if mr.sheet_mappings:
        st.subheader("Sheet / Table mappings")
        rows = [
            {"Source": m.source_name, "Canonical entity": m.canonical_entity,
             "Confidence": f"{m.confidence:.0%}", "Method": m.mapping_method}
            for m in mr.sheet_mappings
        ]
        st.dataframe(pd.DataFrame(rows), use_container_width=True)

    if mr.field_mappings:
        st.subheader("Field mappings")
        rows = [
            {"Source field": m.source_field, "Entity": m.canonical_entity,
             "Canonical field": m.canonical_field,
             "Conf": f"{m.confidence:.0%}"}
            for m in mr.field_mappings
        ]
        st.dataframe(pd.DataFrame(rows), use_container_width=True)

    if mr.unmapped_source_fields:
        st.warning("Unmapped source fields: " + ", ".join(mr.unmapped_source_fields))

    if mr.ambiguities:
        st.subheader("⚠️ Ambiguities")
        for a in mr.ambiguities:
            with st.expander(f"Field: {a.source_field}"):
                st.write(f"**Candidates:** {', '.join(a.candidate_mappings)}")
                st.write(f"**Reason:** {a.reason}")
                st.write(f"**Needs resolution:** {a.resolution_needed}")

    canonical_entities = _get(s, "canonical_entities")
    if canonical_entities:
        e = canonical_entities
        st.subheader("Canonical entity preview")
        col1, col2, col3 = st.columns(3)
        col1.metric("Jobs", len(e.jobs))
        col2.metric("Operations", len(e.operations))
        col3.metric("Resources", len(e.resources))


# =============================================================================
# Tab 4 — Sufficiency & Ask-Back
# =============================================================================

def render_sufficiency_tab():
    st.header("✅ Data Sufficiency & Ask-Back")
    s = _state()
    sr = _get(s, "sufficiency_report")
    if s is None or sr is None:
        st.info("Sufficiency check not yet run.")
        return

    col1, col2, col3 = st.columns(3)
    col1.metric("Can solve now", "✅ Yes" if sr.can_solve_now else "❌ No")
    col2.metric("Solve mode", sr.solve_mode.upper())
    col3.metric("Critical missing", len(sr.critical_missing_fields))

    if sr.critical_missing_fields:
        st.error("Critical missing: " + ", ".join(sr.critical_missing_fields))

    if sr.objective_feasibility:
        st.subheader("Objective feasibility")
        rows = [{"Objective": k, "Feasible": "✅" if v else "❌"}
                for k, v in sr.objective_feasibility.items()]
        st.dataframe(pd.DataFrame(rows), use_container_width=True)

    # Ask-back form
    questions = _get(s, "ask_back_questions")
    current_stage = _get(s, "current_stage")
    if questions and current_stage == "WAITING_FOR_USER_ANSWER":
        st.subheader("📋 Questions for you")
        with st.form("ask_back_form"):
            answers: dict[str, Any] = {}
            for q in questions:
                answers[q.question_id] = _render_question(q)

            submitted = st.form_submit_button("Submit answers", type="primary")
            if submitted:
                st.session_state["pending_answers"] = answers
                st.rerun()

    # Degraded confirmation
    degraded_solve_confirmed = _get(s, "degraded_solve_confirmed")
    constraint_registry = _get(s, "constraint_registry")
    if current_stage == "DEGRADED_SOLVE_CONFIRMED" or (
        sr.solve_mode == "degraded" and not degraded_solve_confirmed
        and current_stage not in ("WAITING_FOR_USER_ANSWER",)
    ):
        if constraint_registry and constraint_registry.degraded_constraints:
            st.warning("⚠️ Some constraints will use fallback behaviour:")
            for d in constraint_registry.degraded_constraints:
                st.markdown(f"- **{d.constraint_name}**: {d.fallback_behavior}")
        if not degraded_solve_confirmed:
            if st.button("Proceed with degraded solve", type="primary"):
                st.session_state["pending_confirm_degraded"] = True
                st.rerun()


def _render_question(q: AskBackQuestion) -> Any:
    label = q.question_text
    if q.expected_type == "number":
        return st.number_input(label, min_value=0, step=1, key=f"q_{q.question_id}")
    if q.expected_type == "datetime":
        val = st.text_input(label + " (ISO 8601)", key=f"q_{q.question_id}")
        return val or None
    if q.expected_type == "enum":
        options = _enum_options(q.target_field)
        return st.selectbox(label, options=options, key=f"q_{q.question_id}")
    if q.expected_type == "boolean":
        return st.checkbox(label, key=f"q_{q.question_id}")
    # table / free_text
    raw = st.text_area(label + " (JSON array or text)", key=f"q_{q.question_id}")
    if raw:
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return raw
    return None


def _enum_options(field: str) -> list[str]:
    mapping = {
        "operation_eligibility_policy": ["all_eligible", "specify_per_operation"],
        "cost_basis_policy": ["drop_cost_objective", "provide_costs"],
        "balance_objective_policy": ["drop_balance_objective", "add_more_resources"],
    }
    return mapping.get(field, ["yes", "no"])


# =============================================================================
# Tab 5 — Optimization
# =============================================================================

def render_optimization_tab():
    st.header("⚙️ Optimization")
    s = _state()
    if s is None:
        st.info("Pipeline not started.")
        return

    reg = _get(s, "constraint_registry")
    if reg:
        col1, col2, col3 = st.columns(3)
        col1.metric("Active constraints", len(reg.active_constraints))
        col2.metric("Degraded", len(reg.degraded_constraints))
        col3.metric("Unsupported", len(reg.unsupported_constraints))

        if reg.active_constraints:
            st.subheader("✅ Active constraints")
            for c in reg.active_constraints:
                st.markdown(f"- **{c.constraint_name}** — {c.activation_reason}")

        if reg.degraded_constraints:
            st.subheader("⚠️ Degraded constraints")
            for c in reg.degraded_constraints:
                st.warning(f"**{c.constraint_name}**: {c.fallback_behavior}")

        if reg.unsupported_constraints:
            st.subheader("🚫 Unsupported (Phase 1)")
            for c in reg.unsupported_constraints:
                st.error(f"**{c.constraint_name}**: {c.reason}")

    payload = _get(s, "solver_payload")
    if payload:
        st.subheader("Solver payload summary")
        col1, col2, col3 = st.columns(3)
        col1.metric("Jobs", len(payload.jobs))
        col2.metric("Resources", len(payload.resources))
        col3.metric("Horizon (min)", payload.horizon_minutes)

    sr = _get(s, "solver_result")
    if sr:
        status_color = {"OPTIMAL": "success", "FEASIBLE": "info",
                        "INFEASIBLE": "error", "TIMEOUT": "warning"}.get(sr.solve_status, "info")
        getattr(st, status_color)(f"Solver status: **{sr.solve_status}** "
                                   f"({sr.solve_time_seconds:.2f}s)")
        if sr.optimality_gap is not None:
            st.write(f"Optimality gap: {sr.optimality_gap:.4f}")

    ir = _get(s, "infeasibility_report")
    if ir:
        st.subheader("🔴 Infeasibility report")
        st.markdown("**Likely conflict areas:**")
        for area in ir.likely_conflict_areas:
            st.markdown(f"- {area}")
        st.markdown("**Suggested actions:**")
        for action in ir.suggested_user_actions:
            st.markdown(f"- {action}")


# =============================================================================
# Tab 6 — Results
# =============================================================================

def render_results_tab():
    st.header("📊 Results")
    s = _state()
    result = _get(s, "solver_result")
    if s is None or result is None:
        st.info("No results yet. Complete the pipeline first.")
        return

    kpis = _get(s, "kpi_summary")
    validation = _get(s, "post_solve_validation")

    if kpis:
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Makespan (units)", kpis.makespan_units)
        col2.metric("Total tardiness", kpis.total_tardiness_units)
        col3.metric("Late jobs", kpis.total_late_jobs)
        if kpis.load_balance_score is not None:
            col4.metric("Load balance", f"{kpis.load_balance_score:.2f}")
        if kpis.estimated_total_cost is not None:
            st.metric("Estimated cost", f"{kpis.estimated_total_cost:.2f}")

    if result.scheduled_operations:
        st.subheader("Schedule table")
        rows = [
            {
                "Operation": o.operation_id,
                "Job": o.job_id,
                "Resource": o.resource_id,
                "Start": o.start_units,
                "End": o.end_units,
                "Tardiness": o.tardiness_units or 0,
                "Late": "⚠️" if o.is_late else "",
            }
            for o in result.scheduled_operations
        ]
        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True)

        st.subheader("Gantt chart")
        _render_gantt(result, _get(s, "horizon_start"))

    if kpis and kpis.resource_utilization:
        st.subheader("Resource utilization")
        util_df = pd.DataFrame(
            [{"Resource": k, "Utilization": v}
             for k, v in kpis.resource_utilization.items()]
        )
        fig = px.bar(util_df, x="Resource", y="Utilization",
                     range_y=[0, 1], text_auto=".0%")
        st.plotly_chart(fig, use_container_width=True)

    if validation:
        if validation.validation_passed:
            st.success("✅ Post-solve validation passed.")
        else:
            st.error("❌ Post-solve validation issues detected.")
            for v in validation.precedence_violations:
                st.warning(f"Precedence: {v}")
            for v in validation.eligibility_violations:
                st.warning(f"Eligibility: {v}")
            for v in validation.calendar_violations:
                st.warning(f"Calendar: {v}")


def _render_gantt(result: SolverResult, horizon_start=None):
    from datetime import timedelta
    ops = result.scheduled_operations
    if not ops:
        return

    base = horizon_start or datetime(2024, 1, 1, tzinfo=timezone.utc)
    rows = []
    for o in ops:
        start_dt = base + timedelta(minutes=o.start_units)
        end_dt = base + timedelta(minutes=o.end_units)
        rows.append({
            "Task": o.operation_id,
            "Resource": o.resource_id,
            "Start": start_dt,
            "Finish": end_dt,
            "Job": o.job_id,
        })
    df = pd.DataFrame(rows)
    fig = px.timeline(df, x_start="Start", x_end="Finish",
                      y="Resource", color="Job",
                      hover_data=["Task"],
                      title="Schedule Gantt")
    fig.update_yaxes(autorange="reversed")
    st.plotly_chart(fig, use_container_width=True)


# =============================================================================
# Tab 7 — Explanation & Q&A
# =============================================================================

def render_explanation_tab():
    st.header("💬 Explanation & Q&A")
    s = _state()
    explanation_text = _get(s, "explanation_text")
    if s is None or explanation_text is None:
        st.info("No explanation yet. Complete the full pipeline first.")
        return

    st.markdown(explanation_text)

    st.divider()
    st.subheader("Ask a follow-up question")

    if "qa_history" not in st.session_state:
        st.session_state["qa_history"] = []

    for turn in st.session_state["qa_history"]:
        st.markdown(f"**You:** {turn['q']}")
        st.markdown(f"**Copilot:** {turn['a']}")
        st.divider()

    question = st.text_input("Your question", key="qa_input")
    if st.button("Ask", disabled=not question):
        explanation_context = _get(s, "explanation_context")
        if explanation_context is not None:
            from agents.explanation_qa import answer_question_node
            answer = answer_question_node(s, question)
        else:
            answer = "No explanation context available."
        st.session_state["qa_history"].append({"q": question, "a": answer})
        st.rerun()
