"""Tab render function registry.

Re-exports all tab renderers from ui.components so that app.py can do:

    from ui.tabs import (
        render_explanation_tab,
        render_input_tab,
        ...
    )

Adding a new tab means only updating components.py and this list.
"""
from ui.components import (
    render_explanation_tab,
    render_input_tab,
    render_mapping_tab,
    render_optimization_tab,
    render_results_tab,
    render_sufficiency_tab,
    render_understanding_tab,
)

__all__ = [
    "render_explanation_tab",
    "render_input_tab",
    "render_mapping_tab",
    "render_optimization_tab",
    "render_results_tab",
    "render_sufficiency_tab",
    "render_understanding_tab",
]
