"""Scheduling Copilot — Streamlit entry point.

State management: LangGraph MemorySaver keyed on thread_id.
st.session_state stores only: thread_id, state_snapshot, qa_history.
Full SessionState lives in the LangGraph checkpointer.
"""
from __future__ import annotations

import streamlit as st

st.set_page_config(
    page_title="Scheduling Copilot",
    page_icon="🗓️",
    layout="wide",
    initial_sidebar_state="collapsed",
)

from orchestration.graph import build_graph, build_initial_state  # noqa: E402
from orchestration.checkpoints import make_config  # noqa: E402
from core.schemas import SessionState  # noqa: E402
from core.logging_utils import get_logger, setup_logging  # noqa: E402
from ui.tabs import (  # noqa: E402
    render_explanation_tab,
    render_input_tab,
    render_mapping_tab,
    render_optimization_tab,
    render_results_tab,
    render_sufficiency_tab,
    render_understanding_tab,
)

setup_logging()
_logger = get_logger(__name__)

# =============================================================================
# Session bootstrap
# =============================================================================

if "graph" not in st.session_state:
    st.session_state["graph"] = build_graph()
if "thread_id" not in st.session_state:
    st.session_state["thread_id"] = None
if "state_snapshot" not in st.session_state:
    st.session_state["state_snapshot"] = None
if "qa_history" not in st.session_state:
    st.session_state["qa_history"] = []
    _logger.info("\n" + "=" * 60)
    _logger.info("[APP] Scheduling Copilot started — graph compiled, session ready.")

graph = st.session_state["graph"]

# =============================================================================
# Pending actions (set by UI components, processed here before render)
# =============================================================================

# New pipeline run
if "pending_run" in st.session_state:
    run = st.session_state.pop("pending_run")
    st.session_state["thread_id"] = None
    st.session_state["qa_history"] = []

    import uuid
    tid = str(uuid.uuid4())
    st.session_state["thread_id"] = tid
    cfg = make_config(tid)

    init = build_initial_state(
        source_type=run["source_type"],
        raw_ref=run["raw_ref"],
        horizon_start=run["horizon_dt"],
    )
    with st.spinner("Running pipeline…"):
        try:
            _logger.info("[GRAPH] Starting invoke | thread_id=%s", tid)
            snapshot = graph.invoke(init, cfg)
            if isinstance(snapshot, dict):
                snapshot = SessionState.model_validate(snapshot)
            _logger.info(
                "[GRAPH] Invoke complete | final_stage=%s | errors=%d | warnings=%d",
                snapshot.current_stage, len(snapshot.errors), len(snapshot.warnings),
            )
            st.session_state["state_snapshot"] = snapshot
        except Exception as e:
            _logger.exception("[APP] Pipeline failed during graph.invoke()")
            st.error(f"Pipeline error: {e}")

# Ask-back answers submitted
if "pending_answers" in st.session_state and st.session_state["thread_id"]:
    answers = st.session_state.pop("pending_answers")
    cfg = make_config(st.session_state["thread_id"])
    graph.update_state(cfg, {"ask_back_answers": answers})
    with st.spinner("Processing answers…"):
        try:
            _logger.info(
                "[APP] Ask-back answers submitted | thread_id=%s | n_answers=%d",
                st.session_state["thread_id"], len(answers),
            )
            snapshot = graph.invoke(None, cfg)
            if isinstance(snapshot, dict):
                snapshot = SessionState.model_validate(snapshot)
            _logger.info(
                "[GRAPH] Invoke complete (resume) | final_stage=%s | errors=%d",
                snapshot.current_stage, len(snapshot.errors),
            )
            st.session_state["state_snapshot"] = snapshot
        except Exception as e:
            _logger.exception("[APP] Resume after ask-back failed")
            st.error(f"Resume error: {e}")

# Degraded solve confirmed
if "pending_confirm_degraded" in st.session_state and st.session_state["thread_id"]:
    st.session_state.pop("pending_confirm_degraded")
    cfg = make_config(st.session_state["thread_id"])
    graph.update_state(cfg, {"degraded_solve_confirmed": True})
    with st.spinner("Proceeding with degraded solve…"):
        try:
            _logger.info(
                "[APP] Degraded solve confirmed | thread_id=%s",
                st.session_state["thread_id"],
            )
            snapshot = graph.invoke(None, cfg)
            if isinstance(snapshot, dict):
                snapshot = SessionState.model_validate(snapshot)
            _logger.info(
                "[GRAPH] Invoke complete (degraded) | final_stage=%s | errors=%d",
                snapshot.current_stage, len(snapshot.errors),
            )
            st.session_state["state_snapshot"] = snapshot
        except Exception as e:
            _logger.exception("[APP] Resume after degraded-solve confirmation failed")
            st.error(f"Resume error: {e}")

# =============================================================================
# Sidebar — pipeline stage indicator
# =============================================================================

with st.sidebar:
    st.title("🗓️ Scheduling Copilot")
    s = st.session_state.get("state_snapshot")
    if s:
        stage = s.get("current_stage", "?") if isinstance(s, dict) else s.current_stage
        st.metric("Current stage", stage)
        errors = s.get("errors", []) if isinstance(s, dict) else s.errors
        if errors:
            st.error(f"{len(errors)} error(s)")
    else:
        st.caption("No session active.")

    if st.button("🔄 Reset"):
        for key in ["thread_id", "state_snapshot"]:
            st.session_state[key] = None
        st.session_state["qa_history"] = []
        st.rerun()

# =============================================================================
# Main tab layout
# =============================================================================

tabs = st.tabs([
    "1 · Input",
    "2 · Understanding",
    "3 · Mapping",
    "4 · Sufficiency",
    "5 · Optimization",
    "6 · Results",
    "7 · Explanation",
])

with tabs[0]:
    render_input_tab()
with tabs[1]:
    render_understanding_tab()
with tabs[2]:
    render_mapping_tab()
with tabs[3]:
    render_sufficiency_tab()
with tabs[4]:
    render_optimization_tab()
with tabs[5]:
    render_results_tab()
with tabs[6]:
    render_explanation_tab()
