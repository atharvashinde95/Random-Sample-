from __future__ import annotations

from langgraph.graph import StateGraph, START, END

from state import SchedulerState
from agents.smart_constraint_mapping_agent import smart_constraint_mapping_agent
from nodes.canonical_payload_validation_node import (
    canonical_payload_validation_node,
    payload_valid_router,
)
from nodes.cp_sat_scheduling_node import cp_sat_scheduling_node
from agents.insight_qa_agent import insight_qa_agent, qa_agent


# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------

def solver_success_router(state: dict) -> str:
    """Route to 'success' on OPTIMAL/FEASIBLE solve, 'failed' otherwise."""
    status = state.get("solver_status") or ""
    return "success" if status in ("OPTIMAL", "FEASIBLE") else "failed"


# ---------------------------------------------------------------------------
# Graph construction
# ---------------------------------------------------------------------------

def build_scheduling_graph():
    """
    Build and compile the main scheduling LangGraph workflow.

    Flow:
      START
        → smart_constraint_mapping_agent
        → canonical_payload_validation_node
        → [payload_valid_router]
            invalid → END
            valid   → cp_sat_scheduling_node
        → [solver_success_router]
            failed  → END
            success → insight_qa_agent
        → END
    """
    g = StateGraph(SchedulerState)

    # Nodes
    g.add_node("smart_constraint_mapping_agent", smart_constraint_mapping_agent)
    g.add_node("canonical_payload_validation_node", canonical_payload_validation_node)
    g.add_node("cp_sat_scheduling_node", cp_sat_scheduling_node)
    g.add_node("insight_qa_agent", insight_qa_agent)

    # Edges
    g.add_edge(START, "smart_constraint_mapping_agent")
    g.add_edge("smart_constraint_mapping_agent", "canonical_payload_validation_node")

    g.add_conditional_edges(
        "canonical_payload_validation_node",
        payload_valid_router,
        {"valid": "cp_sat_scheduling_node", "invalid": END},
    )

    g.add_conditional_edges(
        "cp_sat_scheduling_node",
        solver_success_router,
        {"success": "insight_qa_agent", "failed": END},
    )

    g.add_edge("insight_qa_agent", END)

    return g.compile()


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_compiled_graph = None


def get_scheduling_graph():
    """Return the compiled scheduling graph (lazy singleton)."""
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_scheduling_graph()
    return _compiled_graph


# ---------------------------------------------------------------------------
# Convenience runners
# ---------------------------------------------------------------------------

def run_scheduling_workflow(initial_state: dict) -> dict:
    """
    Run the full scheduling workflow from an initial state dict.
    For use from app.py (Streamlit) or other callers.

    Required state keys: file_path, current_date
    Optional: reference_date, domain_hint, user_query
    """
    state = dict(initial_state)
    state.setdefault("errors", [])
    state.setdefault("warnings", [])
    compiled = get_scheduling_graph()
    result = compiled.invoke(state)
    return dict(result)


def run_qa_workflow(existing_state: dict, user_question: str) -> dict:
    """
    Answer a follow-up question using an already-solved state.
    Does NOT rerun mapping or CP-SAT.

    Args:
        existing_state: the final state dict from a completed run_scheduling_workflow call.
        user_question:  the follow-up question string.

    Returns updated state with qa_response set.
    """
    state = dict(existing_state)
    state["user_followup_query"] = user_question
    state.setdefault("errors", [])
    state.setdefault("warnings", [])
    return qa_agent(state)


# ---------------------------------------------------------------------------
# Optional standalone Q&A graph (single-node, for future extensibility)
# ---------------------------------------------------------------------------

def build_qa_graph():
    """Build a minimal LangGraph that only runs qa_agent."""
    g = StateGraph(SchedulerState)
    g.add_node("qa_agent", qa_agent)
    g.add_edge(START, "qa_agent")
    g.add_edge("qa_agent", END)
    return g.compile()
