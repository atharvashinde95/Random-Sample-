"""
MCP client helpers for the domain-aware production scheduler.

Two client implementations are provided:

1. LocalToolClient  — calls the underlying Python functions directly.
                      No MCP server process required.
                      Intended for local development and unit testing.

2. MCPToolClient    — communicates through the MCP protocol.
                      Uses FastMCPTransport (in-process) or
                      PythonStdioTransport (subprocess) depending on
                      how it is constructed.
                      Requires the FastMCP server to be reachable.

The current Streamlit + LangGraph pipeline uses direct Python imports and
is NOT affected by either client class.
"""

from __future__ import annotations

import json
from typing import Any


# ---------------------------------------------------------------------------
# JSON helpers
# ---------------------------------------------------------------------------

def dumps_request(data: dict) -> str:
    """Serialize a request dict to a JSON string."""
    return json.dumps(data, ensure_ascii=False, default=str)


def loads_response(response: str | dict) -> dict:
    """Deserialize a response JSON string to a dict."""
    if isinstance(response, dict):
        return response
    try:
        return json.loads(response)
    except Exception as exc:
        return {"errors": [f"Response parse error: {exc}"], "warnings": []}


# ---------------------------------------------------------------------------
# LocalToolClient — direct Python calls, no server needed
# ---------------------------------------------------------------------------

class LocalToolClient:
    """
    Development-safe client that calls project Python functions directly.
    Provides the same method names as the MCP tool wrappers so callers can
    swap between LocalToolClient and MCPToolClient without code changes.
    """

    # ---- Phase 3 tools ----

    def workbook_reader_tool(self, request: dict) -> dict:
        from tools.workbook_reader_tool import read_workbook
        return read_workbook(
            file_path=request.get("file_path", ""),
            sample_size=int(request.get("sample_size", 5)),
        )

    def schema_detection_tool(self, request: dict) -> dict:
        from tools.schema_detection_tool import detect_sheet_mapping
        return detect_sheet_mapping(
            workbook_profile=request.get("workbook_profile", {}),
            domain_profile=request.get("domain_profile"),
        )

    def column_mapping_tool(self, request: dict) -> dict:
        from tools.column_mapping_tool import detect_column_mapping
        return detect_column_mapping(
            workbook_profile=request.get("workbook_profile", {}),
            sheet_mapping=request.get("sheet_mapping", {}),
            domain_profile=request.get("domain_profile"),
        )

    # ---- Phase 4 tools ----

    def unit_normalization_tool(self, request: dict) -> dict:
        from tools.unit_normalization_tool import normalize_tables
        return normalize_tables(
            file_path=request.get("file_path", ""),
            sheet_mapping=request.get("sheet_mapping", {}),
            column_mapping=request.get("column_mapping", {}),
            current_date=request.get("current_date"),
        )

    def constraint_mapping_tool(self, request: dict) -> dict:
        from tools.constraint_mapping_tool import map_constraints
        return map_constraints(
            normalized_tables=request.get("normalized_tables", {}),
            domain_profile=request.get("domain_profile", {}),
        )

    def canonical_payload_builder_tool(self, request: dict) -> dict:
        from tools.canonical_payload_builder_tool import build_canonical_payload
        return build_canonical_payload(
            normalized_tables=request.get("normalized_tables", {}),
            constraint_rules=request.get("constraint_rules", {}),
            domain_result=request.get("domain_result", {}),
            current_date=request.get("current_date", ""),
            reference_date=request.get("reference_date"),
        )

    def canonical_payload_validator_tool(self, request: dict) -> dict:
        from tools.canonical_payload_validator_tool import validate_canonical_payload
        return validate_canonical_payload(request.get("payload", {}))

    # ---- Phase 5 tools ----

    def cp_sat_solver_tool(self, request: dict) -> dict:
        from tools.cp_sat_solver_tool import solve_cp_sat
        return solve_cp_sat(
            payload=request.get("payload", {}),
            solve_config=request.get("solve_config") or {},
        )

    # ---- Phase 8A tools ----

    def report_gantt_generator_tool(self, request: dict) -> dict:
        from tools.report_gantt_tool import generate_report
        return generate_report(
            payload=request.get("payload", {}),
            solver_result=request.get("solver_result", {}),
            mapping_report=request.get("mapping_report"),
            output_dir=request.get("output_dir", "outputs"),
        )


# ---------------------------------------------------------------------------
# MCPToolClient — communicates through the FastMCP protocol
# ---------------------------------------------------------------------------

class MCPToolClient:
    """
    Async-backed client that calls tools through the MCP protocol.

    Construction options:
      • MCPToolClient()
            Uses PythonStdioTransport("mcp_server.py") — spawns the server
            as a subprocess.

      • MCPToolClient(server_script="path/to/mcp_server.py")
            Explicit subprocess path.

      • MCPToolClient(mcp_instance=<FastMCP>)
            Uses FastMCPTransport for in-process calls (testing / CI).

    All public methods are synchronous (asyncio.run is used internally).
    Do not call from within an existing async event loop.
    """

    def __init__(
        self,
        server_script: str = "mcp_server.py",
        mcp_instance: Any = None,
    ) -> None:
        self._server_script = server_script
        self._mcp_instance = mcp_instance

    # ---- Internal plumbing ----

    def _get_transport(self) -> Any:
        if self._mcp_instance is not None:
            from fastmcp.client.transports import FastMCPTransport
            return FastMCPTransport(self._mcp_instance)
        from fastmcp.client.transports import PythonStdioTransport
        return PythonStdioTransport(self._server_script)

    def _call_tool(self, tool_name: str, request: dict) -> dict:
        import asyncio
        from fastmcp import Client

        async def _async() -> dict:
            transport = self._get_transport()
            try:
                async with Client(transport) as c:
                    results = await c.call_tool(
                        tool_name,
                        {"request_json": dumps_request(request)},
                    )
                    if results:
                        first = results[0]
                        text = getattr(first, "text", None)
                        if text is not None:
                            return loads_response(text)
                        return {"errors": [f"Unexpected result type: {type(first).__name__}"], "warnings": []}
                    return {"errors": ["Tool returned no results."], "warnings": []}
            except Exception as exc:
                return {"errors": [f"MCPToolClient._call_tool failed: {exc}"], "warnings": []}

        return asyncio.run(_async())

    # ---- Public methods (mirror LocalToolClient) ----

    def workbook_reader_tool(self, request: dict) -> dict:
        return self._call_tool("workbook_reader_tool", request)

    def schema_detection_tool(self, request: dict) -> dict:
        return self._call_tool("schema_detection_tool", request)

    def column_mapping_tool(self, request: dict) -> dict:
        return self._call_tool("column_mapping_tool", request)

    def unit_normalization_tool(self, request: dict) -> dict:
        return self._call_tool("unit_normalization_tool", request)

    def constraint_mapping_tool(self, request: dict) -> dict:
        return self._call_tool("constraint_mapping_tool", request)

    def canonical_payload_builder_tool(self, request: dict) -> dict:
        return self._call_tool("canonical_payload_builder_tool", request)

    def canonical_payload_validator_tool(self, request: dict) -> dict:
        return self._call_tool("canonical_payload_validator_tool", request)

    def cp_sat_solver_tool(self, request: dict) -> dict:
        return self._call_tool("cp_sat_solver_tool", request)

    def report_gantt_generator_tool(self, request: dict) -> dict:
        return self._call_tool("report_gantt_generator_tool", request)
