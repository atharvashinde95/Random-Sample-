"""Automotive constraint pack. Activates ONLY from evidence in the data."""
from __future__ import annotations
from constraint_packs.base import BaseConstraintPack


class AutomotivePack(BaseConstraintPack):
    name = "automotive_pack"
    ACTIVATION_KEYWORDS = {
        "fixture", "paint", "curing", "cure", "assembly", "welding",
        "weld", "stamping", "press", "line_balance", "takt", "vehicle",
        "body", "chassis", "vin", "part_family", "jig", "subassembly",
    }

    def detect(self, normalized_tables: dict, evidence: dict) -> list[dict]:
        if not self._is_active(evidence):
            return []
        candidates: list[dict] = []
        corpus = evidence.get("text_corpus", "")
        op_families = set(evidence.get("operation_families", []))
        op_names = set(evidence.get("operation_names", []))
        all_ops = op_families | op_names

        # 1. fixture_availability
        if any(kw in corpus for kw in ("fixture", "jig", "tool", "pallet")):
            mm_rows = normalized_tables.get("Machine_Master", [])
            has_cap = any(r.get("capacity") is not None for r in mm_rows)
            candidates.append(self._make_candidate(
                "fixture_availability",
                confidence=0.68 if has_cap else 0.52,
                evidence_items=["Fixture/jig evidence detected"],
                required_fields=["machine_id", "capacity"],
                available_fields=["machine_id", "capacity"] if has_cap else [],
                recommended_enforcement="soft",
                source={"table": "Machine_Master"},
            ))

        # 2. paint_curing_wait
        has_paint = self._any_value_matches(list(all_ops), ["paint", "painting", "coat", "spray"])
        has_cure = self._any_value_matches(list(all_ops), ["cure", "curing", "bake", "oven"])
        if has_paint and has_cure:
            routing_rows = normalized_tables.get("Routing", [])
            has_min_wait = any(r.get("min_wait_minutes") is not None for r in routing_rows)
            has_max_wait = any(r.get("max_wait_minutes") is not None for r in routing_rows)
            avail = ["from_operation_family", "to_operation_family"]
            if has_min_wait:
                avail.append("min_wait_minutes")
            if has_max_wait:
                avail.append("max_wait_minutes")
            candidates.append(self._make_candidate(
                "paint_curing_wait",
                confidence=0.82 if (has_min_wait or has_max_wait) else 0.62,
                evidence_items=["Paint operation detected", "Curing operation detected",
                                 *(["Wait fields present in Routing"] if (has_min_wait or has_max_wait) else [])],
                required_fields=["from_operation_family", "to_operation_family", "min_wait_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Routing"},
            ))

        # 3. assembly_station_capacity
        has_assembly = self._any_value_matches(list(all_ops), ["assembly", "assemble", "subassembly"])
        if has_assembly or "assembly" in corpus:
            mm_rows = normalized_tables.get("Machine_Master", [])
            has_cap = any(r.get("capacity") is not None for r in mm_rows)
            candidates.append(self._make_candidate(
                "assembly_station_capacity",
                confidence=0.75 if has_cap else 0.55,
                evidence_items=["Assembly station evidence detected",
                                 *(["capacity data available"] if has_cap else [])],
                required_fields=["machine_id", "capacity"],
                available_fields=["machine_id", "capacity"] if has_cap else [],
                recommended_enforcement="hard",
                source={"table": "Machine_Master"},
            ))

        # 4. part_family_changeover
        if any(kw in corpus for kw in ("part_family", "vehicle", "model", "platform")):
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)
            has_setup = any(r.get("setup_minutes") is not None for r in sc_rows)
            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["setup_minutes"] if has_setup else [])
            candidates.append(self._make_candidate(
                "part_family_changeover",
                confidence=0.78 if (has_from and has_to and has_setup) else 0.55,
                evidence_items=["Part family/vehicle model changeover evidence detected"],
                required_fields=["from_family", "to_family", "setup_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        return candidates
