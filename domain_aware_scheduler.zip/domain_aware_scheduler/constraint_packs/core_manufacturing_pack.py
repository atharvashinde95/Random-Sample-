"""
Core manufacturing constraint pack.

Generic constraints that apply to virtually any manufacturing dataset.
Activates whenever demand + routing + machines are detected.
"""
from __future__ import annotations

from constraint_packs.base import BaseConstraintPack


class CoreManufacturingPack(BaseConstraintPack):
    name = "core_manufacturing_pack"
    ACTIVATION_KEYWORDS = {
        "demand", "order", "routing", "machine", "equipment", "resource",
        "operation", "process", "schedule",
    }

    # Structural constraints that don't need explicit evidence — they come from
    # the scheduling problem structure itself.
    _STRUCTURAL = [
        "demand_fulfillment",
        "operation_precedence",
        "machine_capacity_no_overlap",
        "machine_eligibility",
        "processing_time",
    ]

    def detect(self, normalized_tables: dict, evidence: dict) -> list[dict]:
        candidates: list[dict] = []
        corpus = evidence.get("text_corpus", "")

        has_demand = bool(normalized_tables.get("Demand_Orders"))
        has_routing = bool(normalized_tables.get("Routing"))
        has_machines = bool(normalized_tables.get("Machine_Master"))

        if not (has_demand or has_routing or has_machines):
            return []

        # 1. Demand fulfillment
        if has_demand:
            rows = normalized_tables["Demand_Orders"]
            has_qty = any(r.get("quantity") is not None for r in rows)
            has_due = any(r.get("due_date") is not None for r in rows)
            avail = ["product_id"] + (["quantity"] if has_qty else []) + (["due_date"] if has_due else [])
            candidates.append(self._make_candidate(
                "demand_fulfillment",
                confidence=0.98 if (has_qty and has_due) else 0.72,
                evidence_items=["Demand_Orders table present",
                                 *(["quantity column present"] if has_qty else []),
                                 *(["due_date column present"] if has_due else [])],
                required_fields=["product_id", "quantity", "due_date"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Demand_Orders"},
            ))

        # 2. Operation precedence
        if has_routing:
            rows = normalized_tables["Routing"]
            has_seq = any(r.get("stage_sequence") is not None for r in rows)
            has_dur = any(r.get("runtime_minutes_per_batch") is not None for r in rows)
            avail = ["product_id"] + (["stage_sequence"] if has_seq else []) + \
                    (["runtime_minutes_per_batch"] if has_dur else [])
            candidates.append(self._make_candidate(
                "operation_precedence",
                confidence=0.97 if (has_seq and has_dur) else 0.70,
                evidence_items=["Routing table present",
                                 *(["stage_sequence present"] if has_seq else []),
                                 *(["runtime_minutes_per_batch present"] if has_dur else [])],
                required_fields=["product_id", "stage_sequence", "runtime_minutes_per_batch"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Routing"},
            ))

        # 3. Machine capacity no-overlap
        if has_machines:
            rows = normalized_tables["Machine_Master"]
            has_mid = any(r.get("machine_id") is not None for r in rows)
            has_cap = any(r.get("capacity") is not None for r in rows)
            avail = (["machine_id"] if has_mid else []) + (["capacity"] if has_cap else [])
            candidates.append(self._make_candidate(
                "machine_capacity_no_overlap",
                confidence=0.95,
                evidence_items=["Machine_Master table present",
                                 *(["machine_id present"] if has_mid else []),
                                 *(["capacity present"] if has_cap else [])],
                required_fields=["machine_id"],
                available_fields=avail if avail else [],
                recommended_enforcement="hard",
                source={"table": "Machine_Master"},
            ))

        # 4. Machine eligibility
        if has_routing:
            rows = normalized_tables["Routing"]
            has_elig = any(r.get("eligible_machines") is not None for r in rows)
            has_mtype = any(r.get("machine_type") is not None for r in rows)
            if has_elig or has_mtype:
                avail = (["eligible_machines"] if has_elig else []) + \
                        (["machine_type"] if has_mtype else [])
                candidates.append(self._make_candidate(
                    "machine_eligibility",
                    confidence=0.92 if has_elig else 0.80,
                    evidence_items=["Routing table present",
                                     *(["eligible_machines column present"] if has_elig else []),
                                     *(["machine_type column present"] if has_mtype else [])],
                    required_fields=["eligible_machines"],
                    available_fields=avail,
                    recommended_enforcement="hard",
                    source={"table": "Routing"},
                ))

        # 5. Processing time
        if has_routing:
            rows = normalized_tables["Routing"]
            has_dur = any(r.get("runtime_minutes_per_batch") is not None for r in rows)
            if has_dur:
                candidates.append(self._make_candidate(
                    "processing_time",
                    confidence=0.98,
                    evidence_items=["runtime_minutes_per_batch present in Routing"],
                    required_fields=["runtime_minutes_per_batch"],
                    available_fields=["runtime_minutes_per_batch"],
                    recommended_enforcement="hard",
                    source={"table": "Routing"},
                ))

        # 6. Due-date tardiness
        if has_demand:
            rows = normalized_tables["Demand_Orders"]
            has_due = any(r.get("due_date") is not None for r in rows)
            if has_due:
                has_penalty = any(r.get("late_penalty_per_unit_per_day") is not None for r in rows)
                candidates.append(self._make_candidate(
                    "due_date_tardiness",
                    confidence=0.90 + (0.05 if has_penalty else 0),
                    evidence_items=["due_date present in Demand_Orders",
                                     *(["late_penalty present"] if has_penalty else [])],
                    required_fields=["due_date"],
                    available_fields=["due_date"],
                    recommended_enforcement="soft",
                    source={"table": "Demand_Orders"},
                ))

        # 7. Priority weighting
        if has_demand:
            rows = normalized_tables["Demand_Orders"]
            has_pclass = any(r.get("priority_class") is not None for r in rows)
            has_pweight = any(r.get("priority_weight") is not None for r in rows)
            if has_pclass or has_pweight:
                avail = (["priority_class"] if has_pclass else []) + \
                        (["priority_weight"] if has_pweight else [])
                candidates.append(self._make_candidate(
                    "priority_weighting",
                    confidence=0.88,
                    evidence_items=[*(["priority_class present"] if has_pclass else []),
                                     *(["priority_weight present"] if has_pweight else [])],
                    required_fields=["priority_class"],
                    available_fields=avail,
                    recommended_enforcement="soft",
                    source={"table": "Demand_Orders"},
                ))

        # 8. Machine calendar availability
        if normalized_tables.get("Machine_Calendar"):
            rows = normalized_tables["Machine_Calendar"]
            has_mid = any(r.get("machine_id") is not None for r in rows)
            has_avail = any(r.get("available") is not None or
                            r.get("available_minutes") is not None for r in rows)
            avail = (["machine_id"] if has_mid else []) + \
                    (["available"] if has_avail else [])
            candidates.append(self._make_candidate(
                "machine_calendar_availability",
                confidence=0.88 if (has_mid and has_avail) else 0.65,
                evidence_items=["Machine_Calendar table present",
                                 *(["machine_id present"] if has_mid else []),
                                 *(["availability data present"] if has_avail else [])],
                required_fields=["machine_id", "available"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Machine_Calendar"},
            ))

        # 9. Setup changeover
        sc_rows = normalized_tables.get("Setup_Changeover", [])
        if sc_rows:
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)
            has_setup = any(r.get("setup_minutes") is not None for r in sc_rows)
            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["setup_minutes"] if has_setup else [])
            candidates.append(self._make_candidate(
                "setup_changeover",
                confidence=0.90 if (has_from and has_to and has_setup) else 0.65,
                evidence_items=["Setup_Changeover table present",
                                 *(["from_family present"] if has_from else []),
                                 *(["to_family present"] if has_to else []),
                                 *(["setup_minutes present"] if has_setup else [])],
                required_fields=["from_family", "to_family", "setup_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        # 10. Cleaning changeover
        if sc_rows:
            has_cleaning = any(r.get("cleaning_minutes") is not None for r in sc_rows)
            if has_cleaning:
                has_from = any(r.get("from_family") is not None for r in sc_rows)
                has_to = any(r.get("to_family") is not None for r in sc_rows)
                avail = (["from_family"] if has_from else []) + \
                        (["to_family"] if has_to else []) + ["cleaning_minutes"]
                candidates.append(self._make_candidate(
                    "cleaning_changeover",
                    confidence=0.88,
                    evidence_items=["cleaning_minutes present in Setup_Changeover"],
                    required_fields=["from_family", "to_family", "cleaning_minutes"],
                    available_fields=avail,
                    recommended_enforcement="hard",
                    source={"table": "Setup_Changeover"},
                ))

        # 11. Wait between operations
        if has_routing:
            rows = normalized_tables["Routing"]
            has_min_wait = any(r.get("min_wait_minutes") is not None for r in rows)
            has_max_wait = any(r.get("max_wait_minutes") is not None for r in rows)
            if has_min_wait or has_max_wait:
                avail = (["min_wait_minutes"] if has_min_wait else []) + \
                        (["max_wait_minutes"] if has_max_wait else [])
                candidates.append(self._make_candidate(
                    "wait_between_operations",
                    confidence=0.88,
                    evidence_items=[*(["min_wait_minutes in Routing"] if has_min_wait else []),
                                     *(["max_wait_minutes in Routing"] if has_max_wait else [])],
                    required_fields=["from_operation_family", "to_operation_family"],
                    available_fields=avail,
                    recommended_enforcement="hard",
                    source={"table": "Routing"},
                ))

        # 12. Quality hold release
        sku_rows = normalized_tables.get("SKU_Master", [])
        if sku_rows:
            has_qa = any(r.get("qa_release_hours") is not None for r in sku_rows)
            if has_qa:
                candidates.append(self._make_candidate(
                    "quality_hold_release",
                    confidence=0.88,
                    evidence_items=["qa_release_hours present in SKU_Master"],
                    required_fields=["qa_release_hours"],
                    available_fields=["qa_release_hours"],
                    recommended_enforcement="hard",
                    source={"table": "SKU_Master"},
                ))

        return candidates
