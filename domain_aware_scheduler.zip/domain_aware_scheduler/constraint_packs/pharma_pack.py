"""
Pharmaceutical constraint pack.

Activates ONLY from evidence in the data, not from a domain label.
"""
from __future__ import annotations

from constraint_packs.base import BaseConstraintPack


class PharmaPack(BaseConstraintPack):
    name = "pharma_pack"
    ACTIVATION_KEYWORDS = {
        "quarantine", "batch_release", "gmp", "expiry", "potency",
        "api", "active_ingredient", "cleanroom", "room_class",
        "validated_cleaning", "lot", "batch_trace", "sterile",
        "aseptic", "tablet", "capsule", "vial", "blister", "lyophil",
    }

    def detect(self, normalized_tables: dict, evidence: dict) -> list[dict]:
        if not self._is_active(evidence):
            return []

        candidates: list[dict] = []
        corpus = evidence.get("text_corpus", "")
        br_texts = evidence.get("business_rule_texts", [])
        br_text = " ".join(br_texts).lower()
        op_families = set(evidence.get("operation_families", []))
        op_names = set(evidence.get("operation_names", []))

        # 1. quarantine_hold
        if any(kw in corpus for kw in ("quarantine", "hold", "release")):
            sku_rows = normalized_tables.get("SKU_Master", [])
            has_qa = any(r.get("qa_release_hours") is not None for r in sku_rows)
            ev = ["Quarantine/hold evidence in data corpus"]
            avail = ["qa_release_hours"] if has_qa else []
            if has_qa:
                ev.append("qa_release_hours present in SKU_Master")
            candidates.append(self._make_candidate(
                "quarantine_hold",
                confidence=0.82 if has_qa else 0.60,
                evidence_items=ev,
                required_fields=["qa_release_hours"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "SKU_Master"},
            ))

        # 2. batch_release_hold
        if any(kw in corpus for kw in ("batch_release", "batch release", "release", "lot")):
            ev = ["Batch release evidence in data"]
            sku_rows = normalized_tables.get("SKU_Master", [])
            has_qa = any(r.get("qa_release_hours") is not None for r in sku_rows)
            avail = ["qa_release_hours"] if has_qa else []
            candidates.append(self._make_candidate(
                "batch_release_hold",
                confidence=0.78 if has_qa else 0.58,
                evidence_items=ev,
                required_fields=["qa_release_hours"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "SKU_Master"},
            ))

        # 3. expiry_window
        sku_rows = normalized_tables.get("SKU_Master", [])
        has_shelf = any(r.get("shelf_life_days") is not None or
                        r.get("shelf_life_hours") is not None for r in sku_rows)
        if has_shelf or "expiry" in corpus or "potency" in corpus:
            ev = []
            avail = []
            if has_shelf:
                ev.append("Shelf life data present in SKU_Master")
                avail.append("shelf_life_days")
            if "expiry" in corpus:
                ev.append("Expiry evidence in data")
            candidates.append(self._make_candidate(
                "expiry_window",
                confidence=0.75 if has_shelf else 0.55,
                evidence_items=ev or ["Expiry/potency evidence found"],
                required_fields=["shelf_life_days"],
                available_fields=avail,
                recommended_enforcement="soft",
                source={"table": "SKU_Master"},
            ))

        # 4. cleanroom_class_constraint
        if any(kw in corpus for kw in ("cleanroom", "clean room", "room class", "aseptic", "sterile")):
            machine_types = set(evidence.get("machine_types", []))
            has_cleanroom = any("clean" in mt.lower() or "sterile" in mt.lower()
                                for mt in machine_types)
            ev = ["Cleanroom/sterile environment evidence detected"]
            if has_cleanroom:
                ev.append("Cleanroom machine type found")
            candidates.append(self._make_candidate(
                "cleanroom_class_constraint",
                confidence=0.70,
                evidence_items=ev,
                required_fields=["machine_type"],
                available_fields=["machine_type"] if has_cleanroom else [],
                recommended_enforcement="hard",
                source={"table": "Machine_Master"},
            ))

        # 5. validated_cleaning_changeover
        if any(kw in corpus for kw in ("validated_cleaning", "validated cleaning", "gmp", "contamination")):
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_cleaning = any(r.get("cleaning_minutes") is not None for r in sc_rows)
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)
            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["cleaning_minutes"] if has_cleaning else [])
            ev = ["GMP/validated cleaning evidence in data"]
            if has_cleaning:
                ev.append("cleaning_minutes in Setup_Changeover")
            candidates.append(self._make_candidate(
                "validated_cleaning_changeover",
                confidence=0.82 if has_cleaning else 0.60,
                evidence_items=ev,
                required_fields=["from_family", "to_family", "cleaning_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        # 6. active_ingredient_material_availability
        if any(kw in corpus for kw in ("api", "active_ingredient", "active ingredient")):
            inv_rows = normalized_tables.get("Inventory", [])
            has_inv = any(r.get("opening_inventory") is not None for r in inv_rows)
            ev = ["Active ingredient / API evidence found"]
            if has_inv:
                ev.append("Inventory data available")
            candidates.append(self._make_candidate(
                "active_ingredient_material_availability",
                confidence=0.68 if has_inv else 0.52,
                evidence_items=ev,
                required_fields=["item_id", "opening_inventory"],
                available_fields=["opening_inventory"] if has_inv else [],
                recommended_enforcement="soft",
                source={"table": "Inventory"},
            ))

        return candidates
