"""
Cosmetics/personal care constraint pack.

Activates ONLY from evidence in the data, not from a domain label.
"""
from __future__ import annotations

from constraint_packs.base import BaseConstraintPack


class CosmeticsPack(BaseConstraintPack):
    name = "cosmetics_pack"
    ACTIVATION_KEYWORDS = {
        "fragrance", "color", "colour", "shade", "cream", "lotion",
        "serum", "gel", "balm", "filling", "fill", "bulk", "blend",
        "gmp", "qc", "qa", "release", "contamination", "cleaning_family",
        "lip", "skin", "hair", "beauty", "cosmetic", "mascara", "foundation",
    }

    _FRAGRANCE_KEYWORDS = {"fragrance", "scent", "perfume", "aroma", "flavour", "flavor"}
    _COLOR_KEYWORDS = {"color", "colour", "shade", "pigment", "tint", "hue"}
    _MIX_KEYWORDS = {"mix", "blend", "bulk", "mixing", "blending", "compound"}
    _FILL_KEYWORDS = {"fill", "filling", "dispense", "bottle", "tube", "pouch"}
    _QA_KEYWORDS = {"gmp", "qa", "qc", "release", "hold", "quarantine", "inspection"}

    def detect(self, normalized_tables: dict, evidence: dict) -> list[dict]:
        if not self._is_active(evidence):
            return []

        candidates: list[dict] = []
        corpus = evidence.get("text_corpus", "")
        op_families = set(evidence.get("operation_families", []))
        op_names = set(evidence.get("operation_names", []))
        product_families = set(evidence.get("product_families", []))
        sc_families = set(evidence.get("setup_changeover_families", []))
        br_texts = evidence.get("business_rule_texts", [])
        br_text = " ".join(br_texts).lower()
        col_names = set(evidence.get("column_names", []))

        all_ops = op_families | op_names

        # -----------------------------------------------------------------------
        # 1. fragrance_changeover_cleaning
        # -----------------------------------------------------------------------
        has_fragrance = (
            any(kw in corpus for kw in self._FRAGRANCE_KEYWORDS)
            or self._any_value_matches(list(product_families | sc_families), list(self._FRAGRANCE_KEYWORDS))
        )

        if has_fragrance:
            ev = ["Fragrance evidence detected in data"]
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_cleaning = any(r.get("cleaning_minutes") is not None for r in sc_rows)
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)

            if has_cleaning:
                ev.append("cleaning_minutes present in Setup_Changeover")
            if any("fragrance" in str(r.get("from_family", "")).lower() or
                   "fragrance" in str(r.get("to_family", "")).lower()
                   for r in sc_rows):
                ev.append("Fragrance family found in Setup_Changeover")
            if "fragrance" in br_text:
                ev.append("Fragrance mentioned in Business_Rules")

            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["cleaning_minutes"] if has_cleaning else [])

            candidates.append(self._make_candidate(
                "fragrance_changeover_cleaning",
                confidence=0.88 if has_cleaning else 0.65,
                evidence_items=ev,
                required_fields=["from_family", "to_family", "cleaning_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        # -----------------------------------------------------------------------
        # 2. color_changeover_cleaning
        # -----------------------------------------------------------------------
        has_color = (
            any(kw in corpus for kw in self._COLOR_KEYWORDS)
            or self._any_value_matches(list(product_families | sc_families), list(self._COLOR_KEYWORDS))
        )

        if has_color:
            ev = ["Color/shade evidence detected in data"]
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_cleaning = any(r.get("cleaning_minutes") is not None for r in sc_rows)
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)

            if has_cleaning:
                ev.append("cleaning_minutes present in Setup_Changeover")
            if any("color" in str(r.get("from_family", "")).lower() or
                   "shade" in str(r.get("from_family", "")).lower()
                   for r in sc_rows):
                ev.append("Color/shade family found in Setup_Changeover")

            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["cleaning_minutes"] if has_cleaning else [])

            candidates.append(self._make_candidate(
                "color_changeover_cleaning",
                confidence=0.85 if has_cleaning else 0.62,
                evidence_items=ev,
                required_fields=["from_family", "to_family", "cleaning_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        # -----------------------------------------------------------------------
        # 3. bulk_mix_to_fill_max_wait
        # -----------------------------------------------------------------------
        has_mix = self._any_value_matches(list(all_ops), list(self._MIX_KEYWORDS))
        has_fill = self._any_value_matches(list(all_ops), list(self._FILL_KEYWORDS))

        if has_mix and has_fill:
            ev = ["Mix/blend operation detected", "Fill/filling operation detected"]
            routing_rows = normalized_tables.get("Routing", [])
            has_max_wait = any(r.get("max_wait_minutes") is not None for r in routing_rows)
            max_wait_value: int | None = None

            if has_max_wait:
                for r in routing_rows:
                    v = r.get("max_wait_minutes")
                    if v is not None:
                        try:
                            max_wait_value = int(float(v))
                        except (ValueError, TypeError):
                            pass
                        break
                ev.append("max_wait_minutes present in Routing")
            elif any(kw in br_text for kw in ("max wait", "wait time", "fill within")):
                ev.append("Wait constraint mentioned in Business_Rules")

            avail = ["from_operation_family", "to_operation_family"]
            data = {
                "from_operation_family": self._find_family(all_ops, self._MIX_KEYWORDS),
                "to_operation_family": self._find_family(all_ops, self._FILL_KEYWORDS),
            }
            if has_max_wait and max_wait_value is not None:
                avail.append("max_wait_minutes")
                data["max_wait_minutes"] = max_wait_value

            candidates.append(self._make_candidate(
                "bulk_mix_to_fill_max_wait",
                confidence=0.88 if has_max_wait else 0.68,
                evidence_items=ev,
                required_fields=["from_operation_family", "to_operation_family", "max_wait_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Routing"},
                data=data,
            ))

        # -----------------------------------------------------------------------
        # 4. GMP_QC_release_hold
        # -----------------------------------------------------------------------
        has_qa = any(kw in corpus for kw in self._QA_KEYWORDS)
        sku_rows = normalized_tables.get("SKU_Master", [])
        has_qa_col = any(r.get("qa_release_hours") is not None for r in sku_rows)

        if has_qa or has_qa_col:
            ev = []
            avail = []
            if has_qa_col:
                ev.append("qa_release_hours present in SKU_Master")
                avail.append("qa_release_hours")
            if has_qa:
                ev.append("GMP/QA/QC evidence in data corpus")
            if "gmp" in br_text or "release" in br_text:
                ev.append("GMP/release mentioned in Business_Rules")

            candidates.append(self._make_candidate(
                "GMP_QC_release_hold",
                confidence=0.85 if has_qa_col else 0.60,
                evidence_items=ev,
                required_fields=["qa_release_hours"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "SKU_Master"},
            ))

        return candidates

    def _find_family(self, values: set[str], keywords: set[str]) -> str:
        for v in sorted(values):
            vl = v.lower()
            if any(kw in vl for kw in keywords):
                return v.upper()
        return list(keywords)[0].upper()
