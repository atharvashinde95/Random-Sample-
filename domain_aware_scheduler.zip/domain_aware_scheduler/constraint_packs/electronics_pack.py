"""Electronics/PCB constraint pack. Activates ONLY from evidence in the data."""
from __future__ import annotations
from constraint_packs.base import BaseConstraintPack


class ElectronicsPack(BaseConstraintPack):
    name = "electronics_pack"
    # Specific PCB/electronics terms — "component", "testing", "assembly",
    # "inspection" are too generic (appear in any manufacturing domain).
    ACTIVATION_KEYWORDS = {
        "smt", "pcb", "solder", "reflow", "wave solder",
        "pick and place", "stencil", "aoi", "bga", "ict",
        "component reel", "reel feeder", "elec-",
    }

    def detect(self, normalized_tables: dict, evidence: dict) -> list[dict]:
        if not self._is_active(evidence):
            return []
        candidates: list[dict] = []
        corpus = evidence.get("text_corpus", "")
        op_families = set(evidence.get("operation_families", []))
        op_names = set(evidence.get("operation_names", []))
        machine_types = set(evidence.get("machine_types", []))
        all_ops = op_families | op_names

        # 1. SMT_line_setup
        if any(kw in corpus for kw in ("smt", "surface mount", "reflow", "solder")):
            mm_rows = normalized_tables.get("Machine_Master", [])
            has_smt = any("smt" in str(r.get("machine_type", "")).lower() or
                          "reflow" in str(r.get("machine_type", "")).lower()
                          for r in mm_rows)
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_setup = any(r.get("setup_minutes") is not None for r in sc_rows)
            candidates.append(self._make_candidate(
                "SMT_line_setup",
                confidence=0.78 if has_smt else 0.58,
                evidence_items=["SMT/solder/reflow evidence detected",
                                 *(["SMT machine type found"] if has_smt else [])],
                required_fields=["machine_id", "setup_minutes"],
                available_fields=(["machine_id", "setup_minutes"] if (has_smt and has_setup) else
                                  (["machine_id"] if has_smt else [])),
                recommended_enforcement="hard",
                source={"table": "Machine_Master"},
            ))

        # 2. component_reel_availability — requires PCB/electronics-specific terms,
        # NOT generic "component" (which appears in BOM of any manufacturing domain).
        if any(kw in corpus for kw in ("component reel", "reel feeder", "reel id",
                                        "tape reel", "smd", "smt component",
                                        "component placement", "feeder slot")):
            inv_rows = normalized_tables.get("Inventory", [])
            has_inv = bool(inv_rows)
            bom_rows = normalized_tables.get("BOM", [])
            has_bom = bool(bom_rows)
            candidates.append(self._make_candidate(
                "component_reel_availability",
                confidence=0.72 if (has_inv and has_bom) else 0.52,
                evidence_items=["Component/reel evidence detected",
                                 *(["Inventory data available"] if has_inv else []),
                                 *(["BOM data available"] if has_bom else [])],
                required_fields=["item_id", "opening_inventory"],
                available_fields=(["item_id", "opening_inventory"] if has_inv else []),
                recommended_enforcement="soft",
                source={"table": "Inventory"},
            ))

        # 3. test_stage_capacity
        has_test = self._any_value_matches(list(all_ops | machine_types),
                                            ["test", "testing", "ict", "functional", "inspection"])
        if has_test:
            mm_rows = normalized_tables.get("Machine_Master", [])
            has_cap = any(r.get("capacity") is not None for r in mm_rows)
            candidates.append(self._make_candidate(
                "test_stage_capacity",
                confidence=0.72 if has_cap else 0.55,
                evidence_items=["Test/inspection stage evidence detected",
                                 *(["capacity data available"] if has_cap else [])],
                required_fields=["machine_id", "capacity"],
                available_fields=(["machine_id", "capacity"] if has_cap else []),
                recommended_enforcement="soft",
                source={"table": "Machine_Master"},
            ))

        # 4. rework_loop_candidate — requires electronics-specific rework terms
        if any(kw in corpus for kw in ("pcb rework", "board rework", "solder rework",
                                        "rework station", "bga rework")):
            candidates.append(self._make_candidate(
                "rework_loop_candidate",
                confidence=0.60,
                evidence_items=["Rework/repair evidence detected in data"],
                required_fields=["operation_family"],
                available_fields=[],
                recommended_enforcement="soft",
                source={"table": "Routing"},
            ))

        return candidates
