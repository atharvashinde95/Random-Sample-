"""Textile/apparel constraint pack. Activates ONLY from evidence in the data."""
from __future__ import annotations
from constraint_packs.base import BaseConstraintPack


class TextilePack(BaseConstraintPack):
    name = "textile_pack"
    ACTIVATION_KEYWORDS = {
        "dye", "dyeing", "color", "colour", "loom", "fabric", "roll",
        "wash", "washing", "dry", "drying", "finishing", "weaving",
        "knitting", "yarn", "thread", "fiber", "fibre", "sewing",
    }

    def detect(self, normalized_tables: dict, evidence: dict) -> list[dict]:
        if not self._is_active(evidence):
            return []
        candidates: list[dict] = []
        corpus = evidence.get("text_corpus", "")
        op_families = set(evidence.get("operation_families", []))
        op_names = set(evidence.get("operation_names", []))
        all_ops = op_families | op_names

        # 1. dye_color_changeover
        if any(kw in corpus for kw in ("dye", "dyeing", "color", "colour")):
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)
            has_setup = any(r.get("setup_minutes") is not None for r in sc_rows)
            has_cleaning = any(r.get("cleaning_minutes") is not None for r in sc_rows)
            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["setup_minutes"] if has_setup else []) + \
                    (["cleaning_minutes"] if has_cleaning else [])
            candidates.append(self._make_candidate(
                "dye_color_changeover",
                confidence=0.82 if (has_from and has_to and (has_setup or has_cleaning)) else 0.60,
                evidence_items=["Dye/color evidence detected",
                                 *(["Setup_Changeover data available"] if has_from else [])],
                required_fields=["from_family", "to_family", "setup_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        # 2. loom_setup
        if any(kw in corpus for kw in ("loom", "weaving", "knitting", "warp", "weft")):
            mm_rows = normalized_tables.get("Machine_Master", [])
            has_loom = any("loom" in str(r.get("machine_type", "")).lower() or
                           "weav" in str(r.get("machine_type", "")).lower()
                           for r in mm_rows)
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_setup = any(r.get("setup_minutes") is not None for r in sc_rows)
            candidates.append(self._make_candidate(
                "loom_setup",
                confidence=0.75 if has_loom else 0.55,
                evidence_items=["Loom/weaving evidence detected",
                                 *(["Loom machine type found"] if has_loom else [])],
                required_fields=["machine_id", "setup_minutes"],
                available_fields=(["machine_id", "setup_minutes"] if (has_loom and has_setup) else
                                  (["machine_id"] if has_loom else [])),
                recommended_enforcement="hard",
                source={"table": "Machine_Master"},
            ))

        # 3. fabric_roll_length
        if any(kw in corpus for kw in ("roll", "fabric", "length", "meter")):
            sku_rows = normalized_tables.get("SKU_Master", [])
            has_batch = any(r.get("batch_size") is not None for r in sku_rows)
            candidates.append(self._make_candidate(
                "fabric_roll_length",
                confidence=0.68 if has_batch else 0.50,
                evidence_items=["Fabric/roll evidence detected",
                                 *(["batch_size present"] if has_batch else [])],
                required_fields=["batch_size"],
                available_fields=["batch_size"] if has_batch else [],
                recommended_enforcement="soft",
                source={"table": "SKU_Master"},
            ))

        # 4. wash_to_dry_wait
        has_wash = self._any_value_matches(list(all_ops), ["wash", "washing", "rinse"])
        has_dry = self._any_value_matches(list(all_ops), ["dry", "drying", "tumble"])
        if has_wash and has_dry:
            routing_rows = normalized_tables.get("Routing", [])
            has_max_wait = any(r.get("max_wait_minutes") is not None for r in routing_rows)
            avail = ["from_operation_family", "to_operation_family"]
            if has_max_wait:
                avail.append("max_wait_minutes")
            candidates.append(self._make_candidate(
                "wash_to_dry_wait",
                confidence=0.80 if has_max_wait else 0.60,
                evidence_items=["Wash operation detected", "Dry operation detected",
                                 *(["max_wait_minutes present"] if has_max_wait else [])],
                required_fields=["from_operation_family", "to_operation_family", "max_wait_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Routing"},
            ))

        # 5. drying_capacity
        if any(kw in corpus for kw in ("dry", "drying", "stenter", "dryer")):
            mm_rows = normalized_tables.get("Machine_Master", [])
            has_dryer = any("dry" in str(r.get("machine_type", "")).lower() for r in mm_rows)
            has_cap = any(r.get("capacity") is not None for r in mm_rows)
            candidates.append(self._make_candidate(
                "drying_capacity",
                confidence=0.72 if (has_dryer and has_cap) else 0.52,
                evidence_items=["Drying operation/machine evidence detected",
                                 *(["Dryer machine type found"] if has_dryer else [])],
                required_fields=["machine_id", "capacity"],
                available_fields=(["machine_id", "capacity"] if (has_dryer and has_cap) else
                                  (["machine_id"] if has_dryer else [])),
                recommended_enforcement="soft",
                source={"table": "Machine_Master"},
            ))

        return candidates
