"""
Base constraint pack class.

All domain-specific constraint packs extend BaseConstraintPack.
Packs detect candidates from evidence — they do NOT enforce anything.
"""
from __future__ import annotations

from typing import Any


class BaseConstraintPack:
    """Base class for evidence-based constraint packs."""

    name: str = "base"
    ACTIVATION_KEYWORDS: set[str] = set()

    # ---------------------------------------------------------------------------
    # Public interface
    # ---------------------------------------------------------------------------

    def detect(
        self,
        normalized_tables: dict,
        evidence: dict,
    ) -> list[dict]:
        """
        Inspect normalized_tables and evidence corpus, return constraint candidates.

        Returns a list of candidate dicts.  Each candidate MUST include:
          constraint_type, source_pack, confidence, evidence, required_fields,
          available_fields, missing_fields, recommended_enforcement, status, source.

        Status must be "candidate" or "needs_user_review" at this stage.
        Do NOT return "enforced" — that is the verifier's job.
        """
        return []

    def verify(
        self,
        candidate: dict,
        solver_capabilities: dict,
    ) -> dict:
        """
        Check whether a candidate can be sent to the solver.
        Default implementation passes the candidate through unchanged.
        Subclasses may override for pack-specific verification logic.
        """
        return candidate

    def compile(self, candidate: dict) -> dict | None:
        """
        Convert a verified candidate into a canonical rule structure.
        Returns None if compilation is not possible.
        Subclasses should override for specific constraint types.
        """
        return None

    def post_solve_validate(
        self,
        schedule: list[dict],
        payload: dict,
    ) -> dict:
        """
        Validate schedule output against pack-specific constraints.
        Returns {"errors": [...], "warnings": [...]}.
        """
        return {"errors": [], "warnings": []}

    # ---------------------------------------------------------------------------
    # Helpers for subclasses
    # ---------------------------------------------------------------------------

    def _is_active(self, evidence: dict) -> bool:
        """Return True if any activation keyword appears in the evidence corpus."""
        corpus = evidence.get("text_corpus", "")
        return bool(self.ACTIVATION_KEYWORDS) and any(
            kw in corpus for kw in self.ACTIVATION_KEYWORDS
        )

    def _make_candidate(
        self,
        constraint_type: str,
        confidence: float,
        evidence_items: list[str],
        required_fields: list[str],
        available_fields: list[str],
        recommended_enforcement: str = "hard",
        status: str = "candidate",
        source: dict | None = None,
        data: dict | None = None,
    ) -> dict:
        """
        Build a standard candidate dict.

        status must be "candidate" or "needs_user_review".
        Use "needs_user_review" when evidence is clear but a required value is absent.
        Never use "enforced" here — that is for the verifier.
        """
        missing = [f for f in required_fields if f not in available_fields]
        if missing and status == "candidate":
            status = "needs_user_review"

        candidate: dict[str, Any] = {
            "constraint_type": constraint_type,
            "source_pack": self.name,
            "confidence": round(confidence, 4),
            "evidence": evidence_items,
            "required_fields": required_fields,
            "available_fields": available_fields,
            "missing_fields": missing,
            "recommended_enforcement": recommended_enforcement,
            "status": status,
            "source": source or {},
        }
        if data:
            candidate["data"] = data
        return candidate

    def _has_in_corpus(self, keywords: list[str], evidence: dict) -> bool:
        """Return True if any keyword appears in the text corpus."""
        corpus = evidence.get("text_corpus", "")
        return any(kw in corpus for kw in keywords)

    def _collect_from_table(
        self,
        normalized_tables: dict,
        role_or_table: str,
        column: str,
    ) -> list[str]:
        """Collect non-null string values from a specific column in a table."""
        rows = normalized_tables.get(role_or_table, [])
        return [str(r[column]) for r in rows if r.get(column) is not None]

    def _table_has_col(
        self,
        normalized_tables: dict,
        role_or_table: str,
        column: str,
    ) -> bool:
        """Return True if the table has at least one non-null value in column."""
        rows = normalized_tables.get(role_or_table, [])
        return any(r.get(column) is not None for r in rows)

    def _any_value_matches(
        self,
        values: list[str],
        keywords: list[str],
    ) -> bool:
        """Return True if any keyword is a substring of any value (case-insensitive)."""
        lower_vals = [v.lower() for v in values]
        return any(kw in v for v in lower_vals for kw in keywords)
