"""
Constraint packs package.

Provides evidence-based constraint detection packs.
Each pack activates from data evidence, not domain labels.
"""
from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from constraint_packs.base import BaseConstraintPack


# ---------------------------------------------------------------------------
# Pack registry — (module_path, class_name)
# ---------------------------------------------------------------------------

_PACK_REGISTRY: list[tuple[str, str]] = [
    ("constraint_packs.core_manufacturing_pack", "CoreManufacturingPack"),
    ("constraint_packs.food_bakery_pack",        "FoodBakeryPack"),
    ("constraint_packs.cosmetics_pack",          "CosmeticsPack"),
    ("constraint_packs.pharma_pack",             "PharmaPack"),
    ("constraint_packs.steel_pack",              "SteelPack"),
    ("constraint_packs.textile_pack",            "TextilePack"),
    ("constraint_packs.electronics_pack",        "ElectronicsPack"),
    ("constraint_packs.packaging_pack",          "PackagingPack"),
    ("constraint_packs.automotive_pack",         "AutomotivePack"),
]


def load_constraint_packs() -> tuple[list["BaseConstraintPack"], list[str]]:
    """
    Load and instantiate all registered constraint packs.

    Returns (packs, warnings).

    Failures to import or instantiate a single pack do NOT crash the system.
    Instead they produce a warning entry.
    """
    packs: list[BaseConstraintPack] = []
    warnings: list[str] = []

    for module_path, class_name in _PACK_REGISTRY:
        try:
            module = importlib.import_module(module_path)
            cls = getattr(module, class_name)
            packs.append(cls())
        except Exception as exc:
            warnings.append(
                f"Failed to load constraint pack '{class_name}' "
                f"from '{module_path}': {exc}"
            )

    return packs, warnings


__all__ = ["load_constraint_packs"]
