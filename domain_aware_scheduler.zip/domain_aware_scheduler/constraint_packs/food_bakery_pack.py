"""
Food/Bakery constraint pack.

Activates ONLY from evidence in the data, not from a domain label.
Scans operation names, operation families, machine types, product families,
business rule text, and column names for bakery/food-specific patterns.
"""
from __future__ import annotations

from constraint_packs.base import BaseConstraintPack


class FoodBakeryPack(BaseConstraintPack):
    name = "food_bakery_pack"
    # Strong food/bakery-specific terms — generic words like "shelf", "cool",
    # "allergen" are excluded because they appear in cosmetics/pharma too.
    ACTIVATION_KEYWORDS = {
        "proof", "proofing", "prover", "bake", "baking",
        "dough", "bread", "pastry", "cake", "muffin", "roll", "ferment",
        "yeast", "flour", "croissant", "loaf", "bky-",
    }

    _PROOF_KEYWORDS = {"proof", "proofing", "prover", "ferment", "rise"}
    _BAKE_KEYWORDS = {"bake", "baking", "oven", "furnace"}
    _COOL_KEYWORDS = {"cool", "cooling", "chill", "chilling"}
    _PACK_KEYWORDS = {"pack", "packing", "packaging", "wrap", "bag"}
    _ALLERGEN_KEYWORDS = {"allergen", "non_allergen", "gluten", "nut", "dairy", "allergen_free"}
    _FRESHNESS_KEYWORDS = {"shelf_life", "shelf", "expiry", "freshness", "best_before", "bbf"}

    def detect(self, normalized_tables: dict, evidence: dict) -> list[dict]:
        if not self._is_active(evidence):
            return []

        candidates: list[dict] = []
        corpus = evidence.get("text_corpus", "")

        # Collect operation families and names for evidence checking
        op_families = set(evidence.get("operation_families", []))
        op_names = set(evidence.get("operation_names", []))
        machine_types = set(evidence.get("machine_types", []))
        product_families = set(evidence.get("product_families", []))
        br_texts = evidence.get("business_rule_texts", [])
        sc_families = set(evidence.get("setup_changeover_families", []))

        all_op_text = " ".join(op_families | op_names | machine_types).lower()
        br_text = " ".join(br_texts).lower()

        # -----------------------------------------------------------------------
        # 1. proof_to_bake_max_wait
        # -----------------------------------------------------------------------
        has_proof = self._any_value_matches(list(op_families | op_names | machine_types),
                                             list(self._PROOF_KEYWORDS))
        has_bake = self._any_value_matches(list(op_families | op_names | machine_types),
                                            list(self._BAKE_KEYWORDS))

        if has_proof and has_bake:
            ev = ["Proof/proofing operation detected", "Bake/baking/oven operation detected"]
            # Check for max_wait_minutes in routing or business rules
            routing_rows = normalized_tables.get("Routing", [])
            has_max_wait = any(r.get("max_wait_minutes") is not None for r in routing_rows)
            max_wait_value: int | None = None

            if has_max_wait:
                for r in routing_rows:
                    v = r.get("max_wait_minutes")
                    if v is not None:
                        try:
                            max_wait_value = int(float(v))
                        except (ValueError, TypeError):
                            pass
                        break
                ev.append("max_wait_minutes column present in Routing")
            elif any(kw in br_text for kw in ("max wait", "maximum wait", "time window", "within")):
                ev.append("max wait constraint mentioned in Business_Rules text")
            else:
                ev.append("No max_wait_minutes value found — user must confirm")

            avail = ["from_operation_family", "to_operation_family"]
            data = {
                "from_operation_family": self._find_family(op_families | op_names, self._PROOF_KEYWORDS),
                "to_operation_family": self._find_family(op_families | op_names, self._BAKE_KEYWORDS),
            }
            if has_max_wait and max_wait_value is not None:
                avail.append("max_wait_minutes")
                data["max_wait_minutes"] = max_wait_value

            candidates.append(self._make_candidate(
                "proof_to_bake_max_wait",
                confidence=0.90 if has_max_wait else 0.72,
                evidence_items=ev,
                required_fields=["from_operation_family", "to_operation_family", "max_wait_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Routing"},
                data=data,
            ))

        # -----------------------------------------------------------------------
        # 2. cool_to_pack_max_wait
        # -----------------------------------------------------------------------
        has_cool = self._any_value_matches(list(op_families | op_names | machine_types),
                                            list(self._COOL_KEYWORDS))
        has_pack = self._any_value_matches(list(op_families | op_names | machine_types),
                                            list(self._PACK_KEYWORDS))

        if has_cool and has_pack:
            ev = ["Cooling operation detected", "Packing operation detected"]
            routing_rows = normalized_tables.get("Routing", [])
            has_max_wait = any(r.get("max_wait_minutes") is not None for r in routing_rows)
            max_wait_value = None

            if has_max_wait:
                for r in routing_rows:
                    v = r.get("max_wait_minutes")
                    if v is not None:
                        try:
                            max_wait_value = int(float(v))
                        except (ValueError, TypeError):
                            pass
                        break
                ev.append("max_wait_minutes present in Routing")

            avail = ["from_operation_family", "to_operation_family"]
            data = {
                "from_operation_family": self._find_family(op_families | op_names, self._COOL_KEYWORDS),
                "to_operation_family": self._find_family(op_families | op_names, self._PACK_KEYWORDS),
            }
            if has_max_wait and max_wait_value is not None:
                avail.append("max_wait_minutes")
                data["max_wait_minutes"] = max_wait_value

            candidates.append(self._make_candidate(
                "cool_to_pack_max_wait",
                confidence=0.85 if has_max_wait else 0.65,
                evidence_items=ev,
                required_fields=["from_operation_family", "to_operation_family", "max_wait_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Routing"},
                data=data,
            ))

        # -----------------------------------------------------------------------
        # 3. allergen_cleaning
        # -----------------------------------------------------------------------
        has_allergen = (
            any(kw in corpus for kw in self._ALLERGEN_KEYWORDS)
            or self._any_value_matches(list(sc_families | product_families),
                                        list(self._ALLERGEN_KEYWORDS))
            or any(kw in br_text for kw in self._ALLERGEN_KEYWORDS)
        )

        # allergen_cleaning requires food-specific allergen context,
        # not just the word "allergen" which appears in cosmetics fragrance data.
        # Must also see food ingredients (gluten, nut, dairy, flour, egg) or
        # explicit bakery product families.
        has_food_allergen = has_allergen and (
            any(kw in corpus for kw in ("gluten", "nut", "dairy", "flour", "egg",
                                         "bread", "cake", "biscuit", "wheat"))
            or self._any_value_matches(list(product_families),
                                        ["bread", "cake", "pastry", "cookie", "roll"])
        )
        if has_food_allergen:
            has_allergen = True  # re-affirm for the block below
        else:
            has_allergen = False  # suppress: cosmetics fragrance is not food allergen

        if has_allergen:
            ev = ["Food allergen evidence detected in data"]
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_cleaning_min = any(r.get("cleaning_minutes") is not None for r in sc_rows)
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)

            if has_cleaning_min:
                ev.append("cleaning_minutes present in Setup_Changeover")
            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["cleaning_minutes"] if has_cleaning_min else [])
            if any("allergen" in str(r.get("from_family", "")).lower() or
                   "allergen" in str(r.get("to_family", "")).lower()
                   for r in sc_rows):
                ev.append("Allergen family found in Setup_Changeover rows")

            candidates.append(self._make_candidate(
                "allergen_cleaning",
                confidence=0.85 if has_cleaning_min else 0.65,
                evidence_items=ev,
                required_fields=["from_family", "to_family", "cleaning_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        # -----------------------------------------------------------------------
        # 4. freshness_or_shelf_life
        # -----------------------------------------------------------------------
        sku_rows = normalized_tables.get("SKU_Master", [])
        has_shelf_days = any(r.get("shelf_life_days") is not None for r in sku_rows)
        has_shelf_hours = any(r.get("shelf_life_hours") is not None for r in sku_rows)

        if has_shelf_days or has_shelf_hours or any(kw in corpus for kw in self._FRESHNESS_KEYWORDS):
            ev = []
            avail = []
            if has_shelf_days:
                ev.append("shelf_life_days present in SKU_Master")
                avail.append("shelf_life_days")
            if has_shelf_hours:
                ev.append("shelf_life_hours present in SKU_Master")
                avail.append("shelf_life_hours")
            if not ev:
                ev.append("Freshness/shelf-life keyword found in data")

            candidates.append(self._make_candidate(
                "freshness_or_shelf_life",
                confidence=0.80 if avail else 0.55,
                evidence_items=ev,
                required_fields=["shelf_life_days"],
                available_fields=avail,
                recommended_enforcement="soft",
                source={"table": "SKU_Master"},
            ))

        return candidates

    def _find_family(self, values: set[str], keywords: set[str]) -> str:
        """Return the first value that contains any of the keywords."""
        for v in sorted(values):
            vl = v.lower()
            if any(kw in vl for kw in keywords):
                return v.upper()
        return list(keywords)[0].upper()
