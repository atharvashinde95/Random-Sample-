"""
Steel/metal manufacturing constraint pack.

Activates ONLY from evidence in the data, not from a domain label.
"""
from __future__ import annotations

from constraint_packs.base import BaseConstraintPack


class SteelPack(BaseConstraintPack):
    name = "steel_pack"
    ACTIVATION_KEYWORDS = {
        "furnace", "heat_treatment", "heat treatment", "rolling", "grade",
        "thickness", "cooling", "coil", "slab", "billet", "annealing", "anneal",
        "quench", "quenching", "cast", "galvanize", "steel", "iron",
        "mill", "pickling", "temper",
    }

    def detect(self, normalized_tables: dict, evidence: dict) -> list[dict]:
        if not self._is_active(evidence):
            return []

        candidates: list[dict] = []
        corpus = evidence.get("text_corpus", "")
        op_families = set(evidence.get("operation_families", []))
        op_names = set(evidence.get("operation_names", []))
        machine_types = set(evidence.get("machine_types", []))
        sc_families = set(evidence.get("setup_changeover_families", []))
        all_ops = op_families | op_names

        # 1. furnace_batch_capacity
        if any(kw in corpus for kw in ("furnace", "kiln", "heat", "reheat")):
            routing_rows = normalized_tables.get("Routing", [])
            has_batch_cap = any(r.get("batch_capacity") is not None for r in routing_rows)
            mm_rows = normalized_tables.get("Machine_Master", [])
            has_furnace = any("furnace" in str(r.get("machine_type", "")).lower() or
                              "furnace" in str(r.get("machine_name", "")).lower()
                              for r in mm_rows)
            ev = ["Furnace/heat evidence detected"]
            avail = []
            if has_batch_cap:
                ev.append("batch_capacity present in Routing")
                avail.append("batch_capacity")
            if has_furnace:
                ev.append("Furnace machine type found")
                avail.append("machine_id")
            candidates.append(self._make_candidate(
                "furnace_batch_capacity",
                confidence=0.78 if (has_batch_cap or has_furnace) else 0.58,
                evidence_items=ev,
                required_fields=["machine_id", "batch_capacity"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Routing"},
            ))

        # 2. heat_treatment_sequence
        if any(kw in corpus for kw in ("heat_treatment", "heat treatment", "annealing", "anneal", "temper")):
            routing_rows = normalized_tables.get("Routing", [])
            has_seq = any(r.get("stage_sequence") is not None for r in routing_rows)
            ev = ["Heat treatment / annealing evidence detected"]
            if has_seq:
                ev.append("stage_sequence present in Routing")
            candidates.append(self._make_candidate(
                "heat_treatment_sequence",
                confidence=0.80 if has_seq else 0.60,
                evidence_items=ev,
                required_fields=["product_id", "stage_sequence"],
                available_fields=["product_id", "stage_sequence"] if has_seq else ["product_id"],
                recommended_enforcement="hard",
                source={"table": "Routing"},
            ))

        # 3. grade_changeover
        has_grade = any(kw in corpus for kw in ("grade", "thickness", "alloy", "spec"))
        if has_grade:
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)
            has_setup = any(r.get("setup_minutes") is not None for r in sc_rows)
            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["setup_minutes"] if has_setup else [])
            ev = ["Grade/thickness/alloy evidence detected"]
            if has_from and has_to:
                ev.append("from_family and to_family in Setup_Changeover")
            if has_setup:
                ev.append("setup_minutes present")
            data: dict = {}
            if has_setup and sc_rows:
                for r in sc_rows:
                    v = r.get("setup_minutes")
                    if v is not None:
                        try:
                            data["setup_minutes"] = int(float(v))
                        except (ValueError, TypeError):
                            pass
                        break

            candidates.append(self._make_candidate(
                "grade_changeover",
                confidence=0.85 if (has_from and has_to and has_setup) else 0.65,
                evidence_items=ev,
                required_fields=["from_family", "to_family", "setup_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
                data=data if data else None,
            ))

        # 4. thickness_changeover
        if any(kw in corpus for kw in ("thickness", "gauge", "width", "dimension")):
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_setup = any(r.get("setup_minutes") is not None for r in sc_rows)
            ev = ["Thickness/gauge changeover evidence detected"]
            if has_setup:
                ev.append("setup_minutes present in Setup_Changeover")
            candidates.append(self._make_candidate(
                "thickness_changeover",
                confidence=0.72 if has_setup else 0.55,
                evidence_items=ev,
                required_fields=["from_family", "to_family", "setup_minutes"],
                available_fields=["setup_minutes"] if has_setup else [],
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        # 5. cooling_wait_time
        has_cooling = any(kw in corpus for kw in ("cooling", "cool", "quench", "quenching"))
        if has_cooling:
            routing_rows = normalized_tables.get("Routing", [])
            has_max_wait = any(r.get("max_wait_minutes") is not None for r in routing_rows)
            has_min_wait = any(r.get("min_wait_minutes") is not None for r in routing_rows)
            avail = (["max_wait_minutes"] if has_max_wait else []) + \
                    (["min_wait_minutes"] if has_min_wait else [])
            ev = ["Cooling/quench evidence detected"]
            if has_max_wait:
                ev.append("max_wait_minutes in Routing")
            if has_min_wait:
                ev.append("min_wait_minutes in Routing")
            candidates.append(self._make_candidate(
                "cooling_wait_time",
                confidence=0.82 if (has_max_wait or has_min_wait) else 0.58,
                evidence_items=ev,
                required_fields=["from_operation_family", "to_operation_family"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Routing"},
            ))

        # 6. rolling_mill_capacity
        if any(kw in corpus for kw in ("rolling", "mill", "roll", "coil")):
            mm_rows = normalized_tables.get("Machine_Master", [])
            has_mill = any("mill" in str(r.get("machine_type", "")).lower() or
                           "roll" in str(r.get("machine_type", "")).lower()
                           for r in mm_rows)
            has_cap = any(r.get("capacity") is not None for r in mm_rows)
            ev = ["Rolling mill evidence detected"]
            if has_mill:
                ev.append("Mill/rolling machine type found")
            if has_cap:
                ev.append("capacity data available")
            candidates.append(self._make_candidate(
                "rolling_mill_capacity",
                confidence=0.75 if (has_mill and has_cap) else 0.55,
                evidence_items=ev,
                required_fields=["machine_id", "capacity"],
                available_fields=(["machine_id", "capacity"] if (has_mill and has_cap) else
                                  (["machine_id"] if has_mill else [])),
                recommended_enforcement="hard",
                source={"table": "Machine_Master"},
            ))

        return candidates
