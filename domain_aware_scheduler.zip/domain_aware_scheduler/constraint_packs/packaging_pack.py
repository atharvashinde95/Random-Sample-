"""Packaging/container constraint pack. Activates ONLY from evidence in the data."""
from __future__ import annotations
from constraint_packs.base import BaseConstraintPack


class PackagingPack(BaseConstraintPack):
    name = "packaging_pack"
    ACTIVATION_KEYWORDS = {
        "mold", "mould", "tool", "die", "print_plate", "plate",
        "carton", "label", "labeling", "film", "pouch", "blister",
        "capping", "sealing", "thermoform", "injection", "blow",
    }

    def detect(self, normalized_tables: dict, evidence: dict) -> list[dict]:
        if not self._is_active(evidence):
            return []
        candidates: list[dict] = []
        corpus = evidence.get("text_corpus", "")
        sc_families = set(evidence.get("setup_changeover_families", []))

        # 1. mold_changeover
        if any(kw in corpus for kw in ("mold", "mould", "injection", "blow")):
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)
            has_setup = any(r.get("setup_minutes") is not None for r in sc_rows)
            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["setup_minutes"] if has_setup else [])
            candidates.append(self._make_candidate(
                "mold_changeover",
                confidence=0.80 if (has_from and has_to and has_setup) else 0.58,
                evidence_items=["Mold/tooling evidence detected",
                                 *(["Setup_Changeover data available"] if has_from else [])],
                required_fields=["from_family", "to_family", "setup_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        # 2. print_plate_changeover
        if any(kw in corpus for kw in ("print_plate", "plate", "label", "print")):
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_setup = any(r.get("setup_minutes") is not None for r in sc_rows)
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)
            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["setup_minutes"] if has_setup else [])
            candidates.append(self._make_candidate(
                "print_plate_changeover",
                confidence=0.75 if has_setup else 0.55,
                evidence_items=["Print plate/label evidence detected"],
                required_fields=["from_family", "to_family", "setup_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        # 3. carton_size_changeover
        if any(kw in corpus for kw in ("carton", "box", "size", "format", "pack_size")):
            sc_rows = normalized_tables.get("Setup_Changeover", [])
            has_setup = any(r.get("setup_minutes") is not None for r in sc_rows)
            has_from = any(r.get("from_family") is not None for r in sc_rows)
            has_to = any(r.get("to_family") is not None for r in sc_rows)
            avail = (["from_family"] if has_from else []) + \
                    (["to_family"] if has_to else []) + \
                    (["setup_minutes"] if has_setup else [])
            candidates.append(self._make_candidate(
                "carton_size_changeover",
                confidence=0.72 if has_setup else 0.52,
                evidence_items=["Carton/box size changeover evidence detected"],
                required_fields=["from_family", "to_family", "setup_minutes"],
                available_fields=avail,
                recommended_enforcement="hard",
                source={"table": "Setup_Changeover"},
            ))

        # 4. tool_availability
        if any(kw in corpus for kw in ("tool", "die", "fixture")):
            mm_rows = normalized_tables.get("Machine_Master", [])
            has_cap = any(r.get("capacity") is not None for r in mm_rows)
            candidates.append(self._make_candidate(
                "tool_availability",
                confidence=0.65 if has_cap else 0.50,
                evidence_items=["Tool/die/fixture evidence detected"],
                required_fields=["machine_id", "capacity"],
                available_fields=["machine_id", "capacity"] if has_cap else [],
                recommended_enforcement="soft",
                source={"table": "Machine_Master"},
            ))

        return candidates
