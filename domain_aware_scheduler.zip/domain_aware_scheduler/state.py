from typing import Any, Dict, List, Optional
from typing_extensions import TypedDict


class SchedulerState(TypedDict, total=False):
    # User inputs
    user_query: Optional[str]
    user_followup_query: Optional[str]
    file_path: Optional[str]
    current_date: Optional[str]
    reference_date: Optional[str]

    # Workbook ingestion outputs
    raw_workbook_profile: Optional[Dict[str, Any]]
    domain_profile_id: Optional[str]
    domain_confidence: Optional[float]
    sheet_mapping: Optional[Dict[str, str]]
    column_mapping: Optional[Dict[str, Dict[str, str]]]
    normalized_tables: Optional[Dict[str, List[Dict[str, Any]]]]
    mapping_report: Optional[Dict[str, Any]]

    # Solver inputs
    canonical_solver_payload: Optional[Dict[str, Any]]
    payload_validation_report: Optional[Dict[str, Any]]

    # Solver outputs
    solver_result: Optional[Dict[str, Any]]
    solver_status: Optional[str]
    solver_debug: Optional[Dict[str, Any]]
    schedule_table: Optional[List[Dict[str, Any]]]
    cost_summary: Optional[Dict[str, Any]]
    info_summary: Optional[Dict[str, Any]]
    machine_utilization: Optional[List[Dict[str, Any]]]
    bottlenecks: Optional[List[Dict[str, Any]]]
    late_orders: Optional[List[Dict[str, Any]]]
    unscheduled_orders: Optional[List[Dict[str, Any]]]
    post_solve_validation_report: Optional[Dict[str, Any]]

    # Reporting outputs
    output_files: Optional[Dict[str, str]]
    gantt_chart_path: Optional[str]

    # LLM agent outputs
    final_response: Optional[str]
    qa_response: Optional[str]

    # Error tracking
    errors: Optional[List[str]]
    warnings: Optional[List[str]]

    # Debug / audit trail
    run_id: Optional[str]
    debug_dir: Optional[str]
    debug_files: Optional[Dict[str, str]]

    # Phase 3 — domain-free mapping intelligence
    mapping_mode: Optional[str]                          # domain_free_mapping | mixed_mapping | legacy_fallback_mapping
    optional_domain_guess: Optional[Dict[str, Any]]      # legacy domain detection result (optional)
    table_role_report: Optional[Dict[str, Any]]          # domain-free table role discovery
    semantic_column_report: Optional[Dict[str, Any]]     # semantic column classification
    sheet_mapping_source: Optional[Dict[str, str]]       # per-sheet: "domain_free" | "legacy_fallback"
    column_mapping_source: Optional[Dict[str, str]]      # per-column key: "semantic" | "legacy_fallback"
    manufacturing_dna: Optional[Dict[str, Any]]          # manufacturing DNA flags
    manufacturing_dna_report: Optional[Dict[str, Any]]   # full DNA report
    common_constraint_candidates: Optional[List[Dict[str, Any]]]
    constraint_pack_candidates: Optional[List[Dict[str, Any]]]
    activated_constraint_packs: Optional[List[Dict[str, Any]]]
    constraint_candidates: Optional[List[Dict[str, Any]]]    # merged all candidates
    verified_constraints: Optional[List[Dict[str, Any]]]
    partial_constraints: Optional[List[Dict[str, Any]]]
    unsupported_constraints: Optional[List[Dict[str, Any]]]
    constraint_enforcement_matrix: Optional[List[Dict[str, Any]]]
    compiled_verified_constraints: Optional[Dict[str, Any]]
    legacy_constraint_mapping: Optional[Dict[str, Any]]
    final_constraint_rules: Optional[Dict[str, Any]]
