"""
ui_helpers.py — pure helper functions shared by app.py and tests.
No streamlit dependency; safe to import in unit tests.
"""
from __future__ import annotations


def _capability_status_with_context(
    capability_key: str,
    manufacturing_dna: dict,
    enforcement_matrix: list,
) -> str:
    """Return display status for a DNA capability key, with context for machine capacity."""
    val = manufacturing_dna.get(capability_key)
    if capability_key == "has_machine_capacity" and not val:
        no_overlap_enforced = any(
            r.get("constraint") == "machine_capacity_no_overlap" and r.get("enforced")
            for r in enforcement_matrix
        )
        if no_overlap_enforced:
            return "⚠️ Explicit capacity not found; default capacity=1 assumed and no-overlap enforced"
    return "✅ Detected" if val else "❌ Not found"


def _is_partial_cost_summary(cost: dict) -> bool:
    """Return True if revenue or production cost is missing/zero but other costs exist."""
    revenue = float(cost.get("estimated_revenue") or 0)
    prod_cost = float(cost.get("estimated_production_cost") or 0)
    total_cost = float(
        cost.get("total_machine_cost")
        or cost.get("total_business_cost")
        or cost.get("total_cost")
        or 0
    )
    return total_cost > 0 and (revenue == 0 or prod_cost == 0)
