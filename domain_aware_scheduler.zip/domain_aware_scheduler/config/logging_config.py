from __future__ import annotations

import logging
import sys

_CONFIGURED = False
_FORMAT = "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


class _ShortNameFormatter(logging.Formatter):
    """Show only the last segment of the logger name.

    'production_scheduler.mapping' → 'mapping'
    """

    def format(self, record: logging.LogRecord) -> str:
        record = logging.makeLogRecord(record.__dict__)
        record.name = record.name.rsplit(".", 1)[-1]
        return super().format(record)


def setup_logging(level: int = logging.INFO) -> None:
    """Configure stdout terminal logging for the production scheduler.

    Idempotent — safe to call on every Streamlit rerun; handlers are never
    duplicated because we check root.handlers before attaching a new one.
    """
    global _CONFIGURED
    if _CONFIGURED:
        return

    root = logging.getLogger("production_scheduler")
    if root.handlers:
        _CONFIGURED = True
        return

    root.setLevel(level)
    root.propagate = False

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(_ShortNameFormatter(_FORMAT, datefmt=_DATE_FORMAT))
    root.addHandler(handler)
    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a named logger under the production_scheduler hierarchy.

    Accepted names:
      production_scheduler.app
      production_scheduler.workflow
      production_scheduler.mapping
      production_scheduler.validation
      production_scheduler.solver
      production_scheduler.qa
      production_scheduler.audit
    """
    setup_logging()
    return logging.getLogger(name)
