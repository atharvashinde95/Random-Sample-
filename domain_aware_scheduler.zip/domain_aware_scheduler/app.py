import os
import re
from pathlib import Path
from datetime import date

import pandas as pd
import streamlit as st

from graph import run_scheduling_workflow, run_qa_workflow
from ui_helpers import _capability_status_with_context, _is_partial_cost_summary

# ---------------------------------------------------------------------------
# Page config — must be the very first Streamlit call
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Production Scheduling Copilot",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
UPLOAD_DIR = Path("uploads")

_STATUS_COLORS = {
    "OPTIMAL": "#27ae60",
    "FEASIBLE": "#2980b9",
    "INFEASIBLE": "#c0392b",
    "MODEL_INVALID": "#c0392b",
    "POST_SOLVE_INVALID": "#e67e22",
    "UNKNOWN": "#7f8c8d",
    "ERROR": "#c0392b",
}

_STATUS_LABELS = {
    "OPTIMAL": "✅ OPTIMAL",
    "FEASIBLE": "🟡 FEASIBLE",
    "INFEASIBLE": "❌ INFEASIBLE",
    "MODEL_INVALID": "❌ MODEL INVALID",
    "POST_SOLVE_INVALID": "⚠️ POST-SOLVE INVALID",
    "UNKNOWN": "❓ UNKNOWN",
    "ERROR": "❌ ERROR",
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def apply_dark_theme() -> None:
    st.markdown(
        """
        <style>
        /* Section cards */
        .sched-card {
            background: #1a1f2e;
            border: 1px solid #2d3748;
            border-radius: 8px;
            padding: 16px 20px;
            margin-bottom: 14px;
        }
        /* Status badges */
        .sbadge {
            display: inline-block;
            padding: 3px 12px;
            border-radius: 5px;
            font-weight: 700;
            font-size: 0.88em;
            color: #fff;
        }
        /* Section sub-headers */
        .sec-hdr {
            color: #5dade2;
            font-size: 1.05em;
            font-weight: 700;
            margin: 10px 0 6px 0;
            border-bottom: 1px solid #2d3748;
            padding-bottom: 4px;
        }
        /* Sidebar info rows */
        .sinfo { font-size: 0.82em; color: #a0aec0; line-height: 1.7; }
        </style>
        """,
        unsafe_allow_html=True,
    )


def ensure_upload_dir() -> Path:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    return UPLOAD_DIR


def save_uploaded_file(uploaded_file) -> str:
    upload_dir = ensure_upload_dir()
    safe_name = re.sub(r"[^a-zA-Z0-9_.\-]", "_", uploaded_file.name)
    dest = upload_dir / safe_name
    dest.write_bytes(uploaded_file.getvalue())
    return str(dest)


def get_status_badge(status: str) -> str:
    color = _STATUS_COLORS.get(str(status).upper(), "#7f8c8d")
    label = _STATUS_LABELS.get(str(status).upper(), status)
    return (
        f"<span class='sbadge' style='background:{color}'>{label}</span>"
    )


def _show_df(df: pd.DataFrame) -> None:
    """Display a DataFrame using use_container_width for Streamlit 1.x compatibility."""
    try:
        st.dataframe(df, use_container_width=True)
    except TypeError:
        st.dataframe(df)


def render_html_file(path: str, height: int = 650) -> None:
    """Render an HTML file inline using Streamlit components so Plotly JS works."""
    try:
        html_content = Path(path).read_text(encoding="utf-8")
        import streamlit.components.v1 as components
        components.html(html_content, height=height, scrolling=True)
    except Exception as exc:
        st.warning(f"Could not render HTML file: {exc}")


def reset_session() -> None:
    st.session_state["workflow_state"] = None
    st.session_state["qa_history"] = []
    st.session_state["uploaded_file_path"] = None
    st.session_state.pop("qa_input", None)
    st.session_state.pop("suggested_question", None)


def init_session_state() -> None:
    st.session_state.setdefault("workflow_state", None)
    st.session_state.setdefault("qa_history", [])
    st.session_state.setdefault("uploaded_file_path", None)
    st.session_state.setdefault("suggested_question", "")


# ---------------------------------------------------------------------------
# Show helpers (modular display functions)
# ---------------------------------------------------------------------------

def show_errors_warnings(state: dict) -> None:
    errors = state.get("errors") or []
    warnings = state.get("warnings") or []
    if errors:
        with st.expander(f"❌ Errors ({len(errors)})", expanded=True):
            for e in errors:
                st.error(e)
    if warnings:
        with st.expander(f"⚠️ Warnings ({len(warnings)})", expanded=False):
            for w in warnings:
                st.warning(w)


def show_metric_cards(state: dict) -> None:
    status = str(state.get("solver_status") or "UNKNOWN").upper()
    domain_id = state.get("domain_profile_id") or "Unknown"
    domain_conf = state.get("domain_confidence") or 0.0
    info = state.get("info_summary") or {}
    cost = state.get("cost_summary") or {}
    current_date = (
        state.get("current_date")
        or info.get("current_date")
        or info.get("reference_time", "N/A")
    )

    st.markdown(
        f"<p class='sec-hdr'>Schedule Status</p>"
        f"Solver: {get_status_badge(status)}",
        unsafe_allow_html=True,
    )

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Domain", domain_id[:28])
    c2.metric("Confidence", f"{domain_conf:.0%}")
    c3.metric("Planning Date", str(current_date)[:10])
    c4.metric(
        "Scheduled Operations",
        info.get("scheduled_operations") or info.get("num_operations_scheduled") or 0,
    )

    c5, c6, c7, c8 = st.columns(4)
    c5.metric("Scheduled Jobs", info.get("num_scheduled_jobs") or info.get("total_jobs") or 0)
    late_n = int(cost.get("num_late_orders") or 0)
    c6.metric("Late Orders", late_n, delta=f"-{late_n}" if late_n else None,
              delta_color="inverse" if late_n else "normal")
    unsched = int(cost.get("num_unscheduled") or 0)
    c7.metric("Unscheduled", unsched, delta=f"-{unsched}" if unsched else None,
              delta_color="inverse" if unsched else "normal")
    tard = int(cost.get("total_tardiness_minutes") or 0)
    c8.metric("Total Tardiness", f"{tard} min")


def show_mapping_report(state: dict) -> None:
    mr = state.get("mapping_report") or {}
    if not mr:
        st.info("No mapping report available.")
        return
    with st.expander("🧭 Mapping / Optional Domain Metadata", expanded=False):
        st.caption("Metadata only — not used as source of truth for solver constraints.")
        col1, col2 = st.columns(2)
        with col1:
            st.markdown(f"**Optional Domain Guess:** `{mr.get('domain_profile_id', 'N/A')}`")
            st.markdown(f"**Guess Confidence:** `{mr.get('domain_confidence', 0.0):.2%}`")
            st.markdown(f"**Legacy Domain Reason:** {mr.get('domain_reason', 'N/A')}")
            st.markdown(f"**Requires Review:** `{mr.get('requires_user_review', False)}`")
        with col2:
            sm = mr.get("sheet_mapping") or {}
            if sm:
                st.markdown("**Sheet Mapping:**")
                _show_df(pd.DataFrame(
                    [{"Raw Sheet": k, "Canonical Role": v} for k, v in sm.items()]
                ))

        mapped = mr.get("mapped_constraints") or []
        if mapped:
            st.markdown("**Mapped Constraints:**")
            _show_df(pd.DataFrame(mapped))

        unsupported = mr.get("unsupported_rules") or []
        if unsupported:
            st.markdown("**⚠️ Unsupported Rules:**")
            _show_df(pd.DataFrame(unsupported))


def show_validation_report(state: dict) -> None:
    vr = state.get("payload_validation_report") or {}
    if not vr:
        st.info("No payload validation report available.")
        return
    with st.expander("✅ Payload Validation Report", expanded=False):
        is_valid = vr.get("is_valid", False)
        st.markdown(
            f"**Valid:** {'✅ Yes' if is_valid else '❌ No'}"
        )
        verrs = vr.get("errors") or []
        vwarns = vr.get("warnings") or []
        if verrs:
            for e in verrs:
                st.error(e)
        if vwarns:
            for w in vwarns:
                st.warning(w)
        if is_valid:
            st.success("Payload passed all validation checks.")


def show_info_summary(state: dict) -> None:
    info = state.get("info_summary") or {}
    if not info:
        st.info("No info summary available.")
        return
    with st.expander("ℹ️ Info Summary", expanded=False):
        _show_df(pd.DataFrame([info]))


def show_solver_quality_banner(state: dict) -> None:
    """Show a prominent solver quality / reproducibility banner under the status cards."""
    status = str(state.get("solver_status") or "UNKNOWN").upper()
    solver_debug = state.get("solver_debug") or {}
    wall_time = solver_debug.get("wall_time")
    obj_val = solver_debug.get("objective_value")
    best_bound = solver_debug.get("best_objective_bound")
    gap_pct = solver_debug.get("optimality_gap_pct")
    cfg = solver_debug.get("solve_config") or {}
    workers = cfg.get("num_search_workers", "?")
    seed = cfg.get("random_seed", "?")

    time_str = f"{wall_time:.1f}s" if wall_time is not None else "?"
    obj_str = f"{obj_val:,.0f}" if obj_val is not None else "?"
    gap_str = f"{gap_pct:.1f}%" if gap_pct is not None else "unknown"
    bound_str = f"{best_bound:,.0f}" if best_bound is not None else "?"

    if status == "OPTIMAL":
        st.success(
            f"**OPTIMAL** — Mathematically proven best schedule. "
            f"Re-running with identical input produces the exact same result. "
            f"Objective: **{obj_str}** | Wall time: {time_str} | Gap: 0.0% (proven)"
        )
    elif status == "FEASIBLE":
        st.warning(
            f"**FEASIBLE — Valid schedule, not yet proven optimal.**  \n"
            f"Solver ran for **{time_str}** (1 worker, seed={seed}). Best solution: **{obj_str}** | "
            f"Proven lower bound: **{bound_str}** | **Optimality gap: {gap_str}**  \n"
            f"This means the true optimal is at most {gap_str} better than this schedule.  \n"
            f"**Reproducibility:** 1 worker + fixed seed → identical file = identical result every run.  \n"
            f"**Objective ≠ Profit:** The solver minimises a scaled-integer cost proxy. "
            f"Estimated Profit below is computed post-solve in actual ₹ and is always deterministic."
        )
    elif status not in ("UNKNOWN", ""):
        st.error(
            f"**{status}** — Schedule could not be generated. Check Errors section below."
        )


def show_cost_summary(state: dict) -> None:
    cost = state.get("cost_summary") or {}
    if not cost:
        st.info("No cost summary available.")
        return
    is_partial = _is_partial_cost_summary(cost)
    title = "💰 Partial Business Cost Estimate" if is_partial else "💰 Cost / Profit Summary"
    with st.expander(title, expanded=False):
        if is_partial:
            st.warning(
                "Machine/tardiness/setup costs may be computed, but revenue or unit production cost "
                "is missing/zero in the dataset. Estimated profit is therefore partial and should "
                "not be treated as final financial profit."
            )
        display = {k: v for k, v in cost.items() if v is not None}
        c1, c2 = st.columns(2)
        with c1:
            st.metric("Objective Value", f"{display.get('objective_value', 0):.2f}")
            st.metric("Total Tardiness", f"{display.get('total_tardiness_minutes', 0)} min")
            st.metric("Late Orders", display.get("num_late_orders", 0))
        with c2:
            rev = display.get("estimated_revenue", 0) or 0
            cost_val = display.get("estimated_production_cost", 0) or 0
            profit = display.get("estimated_profit", 0) or 0
            st.metric("Est. Revenue", f"{rev:,.2f}")
            st.metric("Est. Prod. Cost", f"{cost_val:,.2f}")
            label = "Est. Profit (partial)" if is_partial else "Est. Profit"
            st.metric(label, f"{profit:,.2f}")


def show_schedule_table(state: dict) -> None:
    schedule = state.get("schedule_table") or []
    if not schedule:
        st.info("No scheduled tasks.")
        return
    with st.expander(f"📋 Schedule Table ({len(schedule)} rows)", expanded=False):
        df = pd.DataFrame(schedule)
        _show_df(df)


def show_machine_utilization(state: dict) -> None:
    util = state.get("machine_utilization") or []
    if not util:
        return
    with st.expander("⚙️ Machine Utilization", expanded=False):
        df = pd.DataFrame(util)
        _show_df(df)
        if "machine_id" in df.columns and "utilization_pct" in df.columns:
            chart_df = df.set_index("machine_id")[["utilization_pct"]]
            st.bar_chart(chart_df, color="#3498db")


def show_late_orders(state: dict) -> None:
    late = state.get("late_orders") or []
    if not late:
        return
    with st.expander(f"⏰ Late Orders ({len(late)})", expanded=False):
        _show_df(pd.DataFrame(late))


# ---------------------------------------------------------------------------
# Phase 4 — Manufacturing intelligence display helpers
# ---------------------------------------------------------------------------

_DNA_LABELS: dict[str, str] = {
    "has_demand":           "Demand Orders",
    "has_products":         "Products / SKUs",
    "has_routing":          "Routing / Operations",
    "has_machines":         "Machine / Resource Master",
    "has_machine_capacity": "Machine Capacity",
    "has_processing_times": "Processing Times",
    "has_due_dates":        "Due Dates",
    "has_priorities":       "Priorities",
    "has_bom":              "BOM / Recipe",
    "has_inventory":        "Inventory / Stock",
    "has_setup_changeover": "Setup / Changeover",
    "has_quality_hold":     "Quality Hold (QA Release)",
    "has_calendar":         "Machine Calendar",
    "has_labor":            "Labor Shifts",
    "has_maintenance":      "Maintenance Downtime",
    "has_overtime":         "Overtime Capacity",
    "has_costs":            "Cost Parameters",
}

_STATUS_ICONS: dict[str, str] = {
    "enforced":               "✅ Enforced",
    "detected_partial":       "⚠️ Detected (partial)",
    "detected_not_enforced":  "❌ Detected — not enforced",
    "needs_user_review":      "❓ Needs user review",
    "unsupported":            "🚫 Unsupported",
}

_MODE_TEXT: dict[str, str] = {
    "domain_free_mapping":    "✅ Domain-free mapping was sufficient. No YAML profiles required.",
    "mixed_mapping":          "⚠️ Domain-free mapping with legacy fallback for some sheets/columns.",
    "legacy_fallback_mapping":"⚠️ Legacy alias/YAML mapping handled most sheets. Domain-free had low confidence.",
}

# Constraints flagged as not fully enforced by current solver
_NOT_FULLY_ENFORCED = {
    "material_inventory", "material_time_phased_inventory", "shelf_life_freshness",
    "freshness_or_shelf_life", "expiry_window", "labor_shift_capacity",
    "overtime_capacity", "component_reel_availability", "fixture_availability",
}


def show_manufacturing_discovery(state: dict) -> None:
    """Section: 🧠 Manufacturing Structure Discovery."""
    dna = state.get("manufacturing_dna") or {}
    dna_report = state.get("manufacturing_dna_report") or {}
    table_role_report = state.get("table_role_report") or {}
    mapping_mode = state.get("mapping_mode") or ""
    optional_domain = state.get("optional_domain_guess") or {}
    sheet_mapping_source = state.get("sheet_mapping_source") or {}
    semantic_col_report = state.get("semantic_column_report") or {}
    col_mapping_source = state.get("column_mapping_source") or {}

    if not dna and not table_role_report and not mapping_mode:
        return  # No Phase 3 data — skip silently (old runs)

    with st.expander("🧠 Manufacturing Structure Discovery", expanded=True):
        # A. Mapping mode
        mode_text = _MODE_TEXT.get(mapping_mode, f"Mapping mode: {mapping_mode}")
        if mapping_mode == "domain_free_mapping":
            st.success(mode_text)
        else:
            st.warning(mode_text)

        # B. Optional domain guess — metadata only
        if optional_domain.get("domain_profile_id"):
            domain_id = optional_domain.get("domain_profile_id", "unknown")
            domain_conf = optional_domain.get("confidence", 0.0)
            st.info(
                f"**Optional domain guess:** `{domain_id}` (confidence: {domain_conf:.0%})  \n"
                "This is metadata only — scheduling is based on discovered structure "
                "and verified constraints, not on the domain label."
            )

        # C. Production model
        prod_model = dna.get("production_model", "")
        if prod_model:
            st.markdown(f"**Production model:** `{prod_model}`")

        st.markdown("---")

        # D. Manufacturing capability checklist
        st.markdown("**Manufacturing Capability Checklist**")
        if dna:
            rows = []
            enforce_matrix = state.get("constraint_enforcement_matrix") or []
            for key, label in _DNA_LABELS.items():
                status_text = _capability_status_with_context(key, dna, enforce_matrix)
                rows.append({"Capability": label, "Status": status_text})
            _show_df(pd.DataFrame(rows))
        else:
            st.info("Manufacturing DNA not available for this run.")

        # E. Missing requirements
        missing_basic = dna_report.get("missing_for_basic_scheduling") or []
        missing_adv = dna_report.get("missing_for_advanced_scheduling") or []
        if missing_basic:
            st.warning(f"**Missing for basic scheduling:** {', '.join(missing_basic)}")
        if missing_adv:
            st.info(f"**Missing for advanced scheduling** (optional features): "
                    f"{', '.join(missing_adv[:6])}{'...' if len(missing_adv) > 6 else ''}")

        st.markdown("---")

        # F. Detected sheet roles
        st.markdown("**Detected Sheet Roles**")
        candidates = table_role_report.get("table_role_candidates") or []
        if candidates:
            role_rows = []
            for c in candidates:
                conf = c.get("confidence", 0.0)
                conf_label = "High" if conf >= 0.85 else ("Medium" if conf >= 0.60 else "Low / Review")
                ev = c.get("evidence") or []
                ev_short = "; ".join(str(e) for e in ev[:2]) + ("..." if len(ev) > 2 else "")
                src = sheet_mapping_source.get(c.get("raw_sheet", ""), "unknown")
                role_rows.append({
                    "Raw Sheet": c.get("raw_sheet", ""),
                    "Detected Role": c.get("selected_role", "Unknown"),
                    "Confidence": f"{conf:.0%}",
                    "Confidence Level": conf_label,
                    "Source": src,
                    "Evidence": ev_short,
                })
            _show_df(pd.DataFrame(role_rows))
        else:
            st.info("No table role discovery data available.")

        # G. Semantic column mapping — checkbox toggle (expanders cannot be nested)
        if st.checkbox("Show Semantic Column Mapping", key="show_sem_col_map", value=False):
            col_report = semantic_col_report.get("column_mapping_report") or {}
            ambiguous = semantic_col_report.get("ambiguous_columns") or []
            if ambiguous:
                st.warning(
                    f"**{len(ambiguous)} ambiguous columns** were unmapped or used legacy fallback."
                )
            if col_report:
                sem_rows = []
                for sheet, col_details in col_report.items():
                    for raw_col, detail in col_details.items():
                        if not isinstance(detail, dict):
                            continue
                        canon = detail.get("canonical_column", "")
                        conf = detail.get("confidence", 0.0)
                        ev = detail.get("evidence") or []
                        src = col_mapping_source.get(f"{sheet}.{raw_col}", "unknown")
                        sem_rows.append({
                            "Sheet": sheet,
                            "Raw Column": raw_col,
                            "Canonical Column": canon or "(unmapped)",
                            "Confidence": f"{conf:.0%}" if conf else "—",
                            "Source": src,
                            "Evidence": "; ".join(str(e) for e in ev[:2]),
                        })
                if sem_rows:
                    _show_df(pd.DataFrame(sem_rows[:200]))
                    if len(sem_rows) > 200:
                        st.caption(f"Showing 200 of {len(sem_rows)} column mappings. "
                                   "Full data in debug JSON.")
                else:
                    st.info("No semantic column mapping data.")
            else:
                st.info("Semantic column report not available for this run.")


def show_constraint_enforcement_matrix(state: dict) -> None:
    """Section: 🔒 Constraint Enforcement Matrix."""
    matrix = state.get("constraint_enforcement_matrix") or []
    verified = state.get("verified_constraints") or []
    partial = state.get("partial_constraints") or []
    unsupported = state.get("unsupported_constraints") or []

    if not matrix and not verified and not partial and not unsupported:
        return  # No Phase 3 data — skip for old runs

    with st.expander("🔒 Constraint Enforcement Matrix", expanded=True):
        # Summary callouts
        n_enforced = len([c for c in (matrix or []) if c.get("enforced")])
        n_partial = len(partial)
        n_unsup = len(unsupported)

        c1, c2, c3 = st.columns(3)
        c1.metric("Enforced Constraints", n_enforced)
        c2.metric("Partial / Review", n_partial, delta=None)
        c3.metric("Detected — Not Enforced", n_unsup, delta=None)

        if n_partial:
            st.info(
                f"**{n_partial} constraint(s)** were detected but only partially supported. "
                "They were not sent to CP-SAT as hard constraints. "
                "Check Missing Fields to understand what data is needed."
            )
        if n_unsup:
            st.warning(
                f"**{n_unsup} constraint(s)** were detected from the dataset but are NOT "
                "enforced by the current solver. Examples: material inventory, shelf life, "
                "overtime capacity. These are visible here as information only."
            )

        if matrix:
            mat_rows = []
            for r in matrix:
                status_raw = r.get("status", "")
                status_display = _STATUS_ICONS.get(status_raw, status_raw)
                ev = r.get("evidence") or []
                mat_rows.append({
                    "Constraint": r.get("constraint", ""),
                    "Detected": "✅" if r.get("detected") else "❌",
                    "Verified": "✅" if r.get("verified") else "❌",
                    "Solver Supported": "✅" if r.get("solver_supported") else "❌",
                    "Enforced": "✅" if r.get("enforced") else "❌",
                    "Status": status_display,
                    "Reason": str(r.get("reason", ""))[:120],
                    "Evidence": "; ".join(str(e) for e in ev[:2]),
                })
            _show_df(pd.DataFrame(mat_rows))
        elif verified or partial or unsupported:
            # Fallback: build from lists
            rows = []
            for c in verified:
                rows.append({"Constraint": c.get("constraint_type", ""), "Status": "✅ Enforced"})
            for c in partial:
                rows.append({"Constraint": c.get("constraint_type", ""), "Status": "⚠️ Partial"})
            for c in unsupported:
                rows.append({"Constraint": c.get("constraint_type", ""), "Status": "❌ Not enforced"})
            _show_df(pd.DataFrame(rows))
        else:
            st.info("Constraint enforcement matrix not available for this run.")


def show_constraint_pack_detection(state: dict) -> None:
    """Section: 🧩 Evidence-Based Constraint Family Detection."""
    activated_packs = state.get("activated_constraint_packs") or []
    pack_candidates = state.get("constraint_pack_candidates") or []
    enforcement_matrix = state.get("constraint_enforcement_matrix") or []

    if not activated_packs and not pack_candidates:
        return  # No Phase 3 data

    enforced_constraint_types = {
        r["constraint"] for r in enforcement_matrix if r.get("enforced")
    }

    _PACK_DISPLAY_NAMES: dict[str, str] = {
        "food_bakery_pack":       "Food/Bakery constraint signals",
        "cosmetics_pack":         "Cosmetics/personal-care constraint signals",
        "pharma_pack":            "Pharma/regulatory constraint signals",
        "electronics_pack":       "Electronics/rework/component constraint signals",
        "packaging_pack":         "Packaging/label/carton constraint signals",
        "steel_pack":             "Steel/metal constraint signals",
        "automotive_pack":        "Automotive constraint signals",
        "textile_pack":           "Textile/apparel constraint signals",
        "core_manufacturing_pack":"Core manufacturing constraint signals",
    }

    with st.expander("🧩 Evidence-Based Constraint Family Detection", expanded=False):
        st.caption(
            "These are **not domain classifications**. They are constraint-family detectors "
            "that activate when matching evidence appears in the workbook."
        )

        if activated_packs:
            # Split into primary/strong vs related/weak
            primary, related = [], []
            for p in activated_packs:
                pack_cands = [c for c in pack_candidates if c.get("source_pack") == p.get("pack_name")]
                has_enforced = any(c.get("constraint_type") in enforced_constraint_types for c in pack_cands)
                max_conf = max((c.get("confidence", 0) for c in pack_cands), default=0)
                if has_enforced or max_conf >= 0.75:
                    primary.append((p, "Primary / strong signal"))
                else:
                    related.append((p, "Related / low-confidence signal"))

            st.markdown("**Constraint Families Activated from Evidence**")
            pack_rows = []
            for p, strength in primary + related:
                pack_rows.append({
                    "Constraint Family": _PACK_DISPLAY_NAMES.get(p.get("pack_name", ""), p.get("pack_name", "")),
                    "Signal Strength": strength,
                    "Activated": "✅" if p.get("activated") else "❌",
                    "Avg Confidence": f"{p.get('confidence', 0):.0%}",
                    "Candidates": p.get("num_candidates", 0),
                    "Reason": str(p.get("reason", ""))[:100],
                })
            _show_df(pd.DataFrame(pack_rows))

        if pack_candidates:
            st.markdown("**Pack Constraint Candidates**")
            cand_rows = []
            for c in pack_candidates:
                ev = c.get("evidence") or []
                missing = c.get("missing_fields") or []
                status_raw = c.get("status", "")
                status_display = _STATUS_ICONS.get(status_raw, status_raw)
                cand_rows.append({
                    "Constraint Type": c.get("constraint_type", ""),
                    "Source Family": _PACK_DISPLAY_NAMES.get(c.get("source_pack", ""), c.get("source_pack", "")),
                    "Confidence": f"{c.get('confidence', 0):.0%}",
                    "Status": status_display,
                    "Evidence": "; ".join(str(e) for e in ev[:2]),
                    "Missing Fields": ", ".join(missing) if missing else "—",
                })
            _show_df(pd.DataFrame(cand_rows))
        else:
            st.info("No constraint pack candidates were generated.")


def show_mapping_provenance(state: dict) -> None:
    """Expander: 📌 Mapping Provenance."""
    mapping_mode = state.get("mapping_mode") or ""
    sheet_src = state.get("sheet_mapping_source") or {}
    col_src = state.get("column_mapping_source") or {}
    optional_domain = state.get("optional_domain_guess") or {}

    if not mapping_mode and not sheet_src:
        return

    with st.expander("📌 Mapping Provenance", expanded=False):
        st.markdown(
            "**domain_free** = mapping came from manufacturing structure discovery (no YAML).  \n"
            "**legacy_fallback** = older alias/YAML-based mapping helped fill missing pieces."
        )

        if mapping_mode:
            st.markdown(f"**Mapping Mode:** `{mapping_mode}`")

        if optional_domain:
            st.markdown(
                f"**Optional Domain Guess:** `{optional_domain.get('domain_profile_id', 'N/A')}` "
                f"(confidence: {optional_domain.get('confidence', 0):.0%}) — metadata only, "
                "not used to select constraints."
            )

        if sheet_src:
            st.markdown("**Sheet Mapping Sources:**")
            _show_df(pd.DataFrame([
                {"Sheet": k, "Source": v} for k, v in sheet_src.items()
            ]))

        if col_src:
            domain_free_cols = sum(1 for v in col_src.values() if v == "semantic")
            legacy_cols = sum(1 for v in col_src.values() if v == "legacy_fallback")
            st.markdown(
                f"**Column mapping:** {domain_free_cols} semantic, {legacy_cols} legacy fallback "
                f"({len(col_src)} total mappings)"
            )


def show_debug_downloads(state: dict) -> None:
    """Show debug audit trail section: dir path + download buttons for key JSON files."""
    debug_dir = state.get("debug_dir") or (
        (state.get("mapping_report") or {}).get("debug_dir") or ""
    )
    if not debug_dir:
        return

    st.markdown("<p class='sec-hdr'>🔍 Debug Audit Trail</p>", unsafe_allow_html=True)
    st.code(f"Debug dir: {debug_dir}")

    debug_files = state.get("debug_files") or (
        (state.get("mapping_report") or {}).get("debug_files") or {}
    )

    audit_defs = [
        # --- Existing files (backward compatible) ---
        ("workbook_profile",      "01_workbook_profile.json",           "📂 Workbook Profile"),
        ("column_mapping",        "04_column_mapping.json",             "🗂️ Column Mapping"),
        ("constraint_mapping",    "06_constraint_mapping.json",         "⚙️ Constraint Mapping"),
        ("payload_full",          "08_canonical_payload_full.json",     "📦 Full Canonical Payload"),
        ("solver_input_payload",  "11_solver_input_payload.json",       "🔢 Solver Input Payload"),
        ("solver_result_summary", "12_solver_result_summary.json",      "📊 Solver Result Summary"),
        # --- Phase 3 new files ---
        ("legacy_domain_detection","02_domain_detection.json",          "🏷️ Domain Detection (optional)"),
        ("table_role_discovery",  "09_table_role_discovery.json",       "🗺️ Table Role Discovery"),
        ("semantic_column_mapping","10_semantic_column_mapping.json",    "🔤 Semantic Column Mapping"),
        ("manufacturing_dna",     "11_manufacturing_dna.json",          "🧬 Manufacturing DNA"),
        ("common_candidates",     "12_common_constraint_candidates.json","🔍 Common Candidates"),
        ("pack_candidates",       "13_constraint_pack_candidates.json",  "🧩 Pack Candidates"),
        ("all_candidates",        "14_all_constraint_candidates.json",   "📋 All Candidates"),
        ("enforcement_matrix",    "10_constraint_enforcement_matrix.json","🔒 Enforcement Matrix"),
        ("verified_constraints_debug","11_verified_constraints.json",   "✅ Verified Constraints"),
        ("compiled_constraints",  "12_compiled_verified_constraints.json","⚙️ Compiled Constraints"),
        ("final_constraint_rules","14_final_constraint_rules.json",     "📐 Final Constraint Rules"),
    ]

    cols = st.columns(2)
    for idx, (key, filename, label) in enumerate(audit_defs):
        file_path = debug_files.get(key) or os.path.join(debug_dir, filename)
        with cols[idx % 2]:
            if file_path and os.path.isfile(file_path):
                with open(file_path, "rb") as fh:
                    st.download_button(
                        label=label,
                        data=fh.read(),
                        file_name=filename,
                        mime="application/json",
                        key=f"dbg_{key}",
                    )
            else:
                st.button(label, disabled=True, key=f"dbg_{key}_na",
                          help="File not yet generated.")


def show_downloads(state: dict) -> None:
    if not state:
        st.info("Generate a schedule first to enable downloads.")
        return
    of = state.get("output_files") or {}
    if not any(of.values()):
        st.warning("No output files were generated.")
        return

    st.markdown("<p class='sec-hdr'>Downloadable Files</p>", unsafe_allow_html=True)
    cols = st.columns(2)

    download_defs = [
        ("schedule_csv", "📄 Download Schedule CSV", "text/csv", "schedule.csv"),
        ("schedule_xlsx", "📊 Download Schedule Excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "schedule.xlsx"),
        ("report_html", "📑 Download HTML Report", "text/html", "report.html"),
        ("gantt_html", "📈 Download Gantt HTML", "text/html", "gantt.html"),
    ]

    for idx, (key, label, mime, fname) in enumerate(download_defs):
        path = of.get(key) or ""
        with cols[idx % 2]:
            if path and os.path.isfile(path):
                with open(path, "rb") as fh:
                    st.download_button(
                        label=label,
                        data=fh.read(),
                        file_name=fname,
                        mime=mime,
                        key=f"dl_{key}",
                    )
            else:
                st.button(label, disabled=True, key=f"dl_{key}_na",
                          help="File not available.")

    with st.expander("📁 Output File Paths", expanded=False):
        for k, v in of.items():
            st.code(f"{k}: {v or 'not generated'}")


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

def render_sidebar() -> date:
    with st.sidebar:
        st.markdown("## 🏭 Production Scheduling Copilot")
        st.divider()

        st.markdown(
            "<div class='sinfo'>"
            "<b>Stack</b><br>"
            "• UI: Streamlit<br>"
            "• Workflow: LangGraph<br>"
            "• Tools: deterministic (MCP-ready)<br>"
            "• Optimizer: OR-Tools CP-SAT<br>"
            "• LLM: Claude 3.5 Sonnet (Capgemini Generative Engine)"
            "</div>",
            unsafe_allow_html=True,
        )
        st.divider()

        selected_date = st.date_input(
            "Current Planning Date",
            value=date.today(),
            help="This becomes the solver time-zero (reference_time). "
                 "Jobs due before this date are treated as backlog.",
        )
        st.caption(f"📅 Planning Date Used: **{selected_date.isoformat()}**")
        st.divider()

        st.markdown("**Detected Domain Support**")
        st.markdown(
            "<div class='sinfo'>"
            "• Cosmetics<br>"
            "• Bakery<br>"
            "• Generic Manufacturing<br>"
            "(auto-detected from data)"
            "</div>",
            unsafe_allow_html=True,
        )
        st.divider()

        st.markdown("**Required Sheets (minimum)**")
        st.markdown(
            "<div class='sinfo'>"
            "• Demand_Orders<br>"
            "• Routing<br>"
            "• Machine_Master"
            "</div>",
            unsafe_allow_html=True,
        )

        st.markdown("**Optional Sheets**")
        st.markdown(
            "<div class='sinfo'>"
            "• SKU_Master &nbsp;• Inventory &nbsp;• BOM<br>"
            "• Machine_Calendar &nbsp;• Setup_Changeover<br>"
            "• Maintenance &nbsp;• Labor_Shifts<br>"
            "• Cost_Parameters &nbsp;• Business_Rules<br>"
            "• Material_Receipts"
            "</div>",
            unsafe_allow_html=True,
        )
        st.divider()

        if st.button("🔄 Reset Session", use_container_width=True):
            reset_session()
            st.rerun()

    return selected_date


# ---------------------------------------------------------------------------
# Tab 1 — Generate Schedule
# ---------------------------------------------------------------------------

def render_tab_generate(selected_date: date) -> None:
    st.markdown("### 📤 Upload Production Dataset")
    uploaded_file = st.file_uploader(
        "Upload your Excel or CSV manufacturing dataset",
        type=["xlsx", "xls", "csv"],
        help="Must contain at least: Demand_Orders, Routing, Machine_Master sheets.",
    )

    if uploaded_file:
        saved_path = save_uploaded_file(uploaded_file)
        st.session_state["uploaded_file_path"] = saved_path
        st.success(f"✅ File saved: **{uploaded_file.name}**")

    file_path = st.session_state.get("uploaded_file_path")

    if not file_path:
        st.info("👆 Upload a dataset above to get started.")
        return

    st.divider()

    # Solver configuration
    solver_time = 300
    st.info(
        "Solver: 300s | 4 workers | seed=42 | 2% gap tolerance | "
        "OPTIMAL = proven best schedule. "
        "FEASIBLE = valid schedule found; solver stopped within 2% of optimum."
    )

    if st.button("🚀 Generate Optimized Schedule", type="primary", use_container_width=True):
        initial_state = {
            "file_path": file_path,
            "current_date": selected_date.isoformat(),
            "reference_date": selected_date.isoformat(),
            "user_query": "Generate optimized production schedule",
            "solve_config": {
                "max_time_seconds":   solver_time,
                "num_search_workers": 4,      # 4 workers: reliable feasibility + low variance
                "random_seed":        42,
                "relative_gap_limit": 0.02,   # stop within 2% of proven optimal
            },
            "errors": [],
            "warnings": [],
        }
        with st.spinner(
            f"Optimizing schedule — {solver_time}s · 4 workers · seed=42 · 2% gap ..."
        ):
            try:
                final_state = run_scheduling_workflow(initial_state)
                st.session_state["workflow_state"] = final_state
            except Exception as exc:
                st.error(f"Workflow failed with an unexpected error: {exc}")
                return

        status = str(final_state.get("solver_status") or "UNKNOWN").upper()
        if status in ("OPTIMAL", "FEASIBLE"):
            st.success(f"Schedule generated — Solver: **{status}**")
        elif status in ("INFEASIBLE", "MODEL_INVALID", "ERROR"):
            st.error(f"Scheduling failed — Status: **{status}**")
        else:
            st.warning(f"Solver returned status: **{status}**")

    # ---- Results ----
    state = st.session_state.get("workflow_state")
    if not state:
        return

    st.divider()

    # Errors / Warnings
    show_errors_warnings(state)

    # Status metric cards
    show_metric_cards(state)
    show_solver_quality_banner(state)
    st.divider()

    # AI/business explanation
    final_response = state.get("final_response")
    if final_response:
        st.markdown("### 🤖 Business Explanation")
        st.markdown(
            f"<div class='sched-card'><pre style='white-space:pre-wrap;font-size:0.85em;"
            f"color:#e0e0e0;font-family:monospace'>{final_response}</pre></div>",
            unsafe_allow_html=True,
        )
        st.divider()

    # Gantt chart
    gantt_path = state.get("gantt_chart_path") or (
        (state.get("output_files") or {}).get("gantt_html")
    )
    if gantt_path and os.path.isfile(gantt_path):
        st.markdown("### 📈 Gantt Chart")
        render_html_file(gantt_path, height=780)
        st.divider()

    # Phase 4 — Manufacturing intelligence sections
    show_manufacturing_discovery(state)
    show_constraint_enforcement_matrix(state)
    show_constraint_pack_detection(state)
    show_mapping_provenance(state)
    st.divider()

    # Existing detailed sections
    show_schedule_table(state)
    show_machine_utilization(state)
    show_late_orders(state)
    show_cost_summary(state)
    show_mapping_report(state)
    show_validation_report(state)
    show_info_summary(state)


# ---------------------------------------------------------------------------
# Tab 2 — Q&A Copilot
# ---------------------------------------------------------------------------

def render_tab_qa() -> None:
    state = st.session_state.get("workflow_state")

    if not state:
        st.info("💡 Generate a schedule first (Tab 1), then ask questions here.")
        return

    solver_status = str(state.get("solver_status") or "UNKNOWN")
    if solver_status not in ("OPTIMAL", "FEASIBLE"):
        st.warning(
            f"The last solve returned **{solver_status}**. "
            "Q&A is available but schedule data may be incomplete."
        )

    st.markdown("### 💬 Ask About Your Schedule")
    st.caption("Questions are answered from the solved schedule — the solver is NOT rerun.")

    # Suggested questions
    st.markdown("**Quick questions:**")
    suggestions = [
        "What current date was used?",
        "Which machine is the bottleneck?",
        "Why are orders late?",
        "How can we reduce cost?",
        "Which orders are unscheduled?",
        "What happens if I change current date?",
    ]
    cols = st.columns(3)
    for i, suggestion in enumerate(suggestions):
        if cols[i % 3].button(suggestion, key=f"sug_{i}", use_container_width=True):
            st.session_state["suggested_question"] = suggestion
            st.rerun()

    st.divider()

    # Pre-fill from suggestion click
    if st.session_state.get("suggested_question"):
        st.session_state["qa_input"] = st.session_state.pop("suggested_question")

    question = st.text_input(
        "Or type your own question:",
        key="qa_input",
        placeholder="e.g. Why is order J1 late?",
    )

    if st.button("🔍 Ask Copilot", type="primary", disabled=not question):
        with st.spinner("Answering..."):
            try:
                updated_state = run_qa_workflow(state, question)
                answer = updated_state.get("qa_response") or "No answer generated."
                st.session_state["qa_history"].append(
                    {"question": question, "answer": answer}
                )
                st.session_state["workflow_state"] = updated_state
            except Exception as exc:
                st.error(f"Q&A failed: {exc}")

    # Q&A history
    history = st.session_state.get("qa_history") or []
    if history:
        st.markdown("### 🗂️ Q&A History")
        for entry in reversed(history):
            with st.container():
                st.markdown(
                    f"<div class='sched-card'>"
                    f"<b>Q:</b> {entry['question']}<br><br>"
                    f"<b>A:</b><br><pre style='white-space:pre-wrap;font-size:0.85em;"
                    f"color:#c8d6e5;font-family:inherit'>{entry['answer']}</pre>"
                    f"</div>",
                    unsafe_allow_html=True,
                )


# ---------------------------------------------------------------------------
# Tab 3 — Downloads
# ---------------------------------------------------------------------------

def render_tab_downloads() -> None:
    state = st.session_state.get("workflow_state")

    if not state:
        st.info("💡 Generate a schedule first (Tab 1) to enable downloads.")
        return

    show_downloads(state)
    st.divider()
    show_debug_downloads(state)

    st.divider()
    st.markdown("### 📑 Report Preview")
    report_path = (state.get("output_files") or {}).get("report_html") or ""
    if report_path and os.path.isfile(report_path):
        render_html_file(report_path, height=700)
    else:
        st.info("Report HTML not available.")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    apply_dark_theme()
    init_session_state()

    selected_date = render_sidebar()

    # Header
    st.markdown(
        "<h1 style='margin-bottom:4px'>🏭 Domain-Aware Production Scheduling Copilot</h1>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<p style='color:#a0aec0;margin-top:0'>Upload an Excel/CSV manufacturing dataset "
        "and generate a CP-SAT optimized schedule with business explanation.</p>",
        unsafe_allow_html=True,
    )
    st.divider()

    tab1, tab2, tab3 = st.tabs([
        "📤 Generate Schedule",
        "💬 Q&A Copilot",
        "📥 Downloads",
    ])

    with tab1:
        render_tab_generate(selected_date)

    with tab2:
        render_tab_qa()

    with tab3:
        render_tab_downloads()


main()