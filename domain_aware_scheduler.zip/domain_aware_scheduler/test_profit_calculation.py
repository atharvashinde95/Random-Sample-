"""Quick smoke test: verify revenue/production_cost/profit are non-zero."""
from graph import run_scheduling_workflow


def _run(file_path: str, label: str) -> None:
    state = {"file_path": file_path, "current_date": "2026-04-28"}
    result = run_scheduling_workflow(state)
    cs = result.get("cost_summary") or {}

    rev = cs.get("estimated_revenue", 0)
    prod = cs.get("estimated_production_cost", 0)
    profit = cs.get("estimated_profit", 0)
    solver_costs = cs.get("total_business_cost") or cs.get("total_cost", 0)

    print(f"\n=== {label} ===")
    print(f"  Solver status      : {result.get('solver_status')}")
    print(f"  Estimated Revenue  : ${rev:,.2f}")
    print(f"  Production Cost    : ${prod:,.2f}")
    print(f"  Solver Costs       : ${solver_costs:,.2f}")
    print(f"  Estimated Profit   : ${profit:,.2f}")

    assert rev > 0, f"[{label}] Revenue is $0 — pricing fix failed"
    assert prod > 0, f"[{label}] Production cost is $0 — pricing fix failed"
    assert profit > 0, f"[{label}] Profit is negative: ${profit:,.2f}"
    print(f"  PASS")


if __name__ == "__main__":
    _run(
        "uploads/balanced_cosmetic_production_scheduling_dataset_cpsat.xlsx",
        "Cosmetics",
    )
    _run(
        "uploads/balanced_bakery_production_scheduling_dataset_cpsat.xlsx",
        "Bakery",
    )
    print("\nAll tests PASSED — profit calculation fixed.")
