# Domain-Aware Production Scheduling Copilot

A full-stack, domain-free production scheduling system that accepts an uploaded
Excel or CSV manufacturing dataset, automatically discovers its manufacturing
structure, maps it to a canonical schema, solves an optimized schedule using
OR-Tools CP-SAT, generates downloadable reports and a Gantt chart, and answers
business Q&A about the results — all without requiring YAML domain profiles.

---

## Quick Start

```powershell
# 1. Create and activate virtual environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the app
.\.venv\Scripts\streamlit.exe run app.py
```

Open **http://localhost:8501** in your browser.

---

## What it does

1. **Upload** an Excel or CSV production dataset (orders, routing, machines, etc.)
2. **Discover** manufacturing structure without YAML domain profiles — sheet roles, column semantics, and manufacturing DNA are detected from the data itself
3. **Detect** constraint candidates evidence-based (setup/changeover, quality hold, allergen cleaning, etc.)
4. **Verify** which constraints CP-SAT can enforce; honestly report which it cannot
5. **Solve** an optimized schedule with OR-Tools CP-SAT (OPTIMAL / FEASIBLE)
6. **Generate** downloadable outputs: `schedule.csv`, `schedule.xlsx`, `report.html`, `gantt.html`
7. **Explain** results in business language with an honest constraint enforcement matrix
8. **Answer** follow-up Q&A about constraints, domain detection, YAML dependency, and solver behavior

---

## Installation

### Requirements

- Python 3.10 – 3.12
- Windows, macOS, or Linux
- Optional: [Ollama](https://ollama.com) with `qwen2.5:3b` for LLM explanation polishing

### Steps

```powershell
# Clone or unzip the project, then:
python -m venv .venv
.\.venv\Scripts\Activate.ps1          # Windows PowerShell
# source .venv/bin/activate           # macOS / Linux

pip install --upgrade pip
pip install -r requirements.txt
```

**requirements.txt includes:**
```
streamlit==1.45.0
langgraph==0.4.1
fastmcp==2.3.3
ortools==9.12.4544
ollama==0.4.8
langchain-ollama==0.3.2
openpyxl==3.1.5
pandas==2.2.3
pyyaml==6.0.2
pydantic==2.11.4
plotly==6.0.1
typing_extensions==4.13.2
```

---

## Running the Streamlit app

```powershell
.\.venv\Scripts\streamlit.exe run app.py
```

On macOS / Linux:

```bash
.venv/bin/streamlit run app.py
```

Opens at **http://localhost:8501**.

### Usage

1. Select a **Current Planning Date** in the sidebar (this becomes solver time-zero)
2. **Tab 1 — Generate Schedule**: Upload your Excel/CSV file, click **🚀 Generate Optimized Schedule**
3. View results:
   - **🧠 Manufacturing Structure Discovery** — detected sheet roles, column mappings, DNA
   - **🔒 Constraint Enforcement Matrix** — which constraints are enforced vs. detected-only
   - **🧩 Constraint Pack Detection** — evidence-based pack activation
   - **📈 Gantt Chart** — interactive Plotly timeline
   - Schedule table, machine utilization, late orders, cost summary
4. **Tab 2 — Q&A Copilot**: Ask questions about constraints, solver status, bottlenecks, costs
5. **Tab 3 — Downloads**: Download CSV, Excel, HTML report, Gantt chart, and debug JSON files

### Sidebar options

| Option | Description |
|---|---|
| Current Planning Date | Date picker — sets `reference_time` (time-zero) for the solver |
| Reset Session | Clears the current workflow state |

---

## Running the test suite

```powershell
.\.venv\Scripts\python.exe -m pytest
```

On macOS / Linux:

```bash
.venv/bin/python -m pytest
```

**Current result: 566 passed, 1 skipped** (as of Phase 5).

### Run specific test groups

```powershell
# Schema and Pydantic validation
.\.venv\Scripts\python.exe -m pytest tests/test_schema_validation.py -v

# CP-SAT solver tests
.\.venv\Scripts\python.exe -m pytest tests/test_cp_sat_solver.py -v

# Phase 1: domain-free discovery tools
.\.venv\Scripts\python.exe -m pytest tests/test_manufacturing_structure_discovery.py tests/test_semantic_column_classifier.py tests/test_manufacturing_dna_tool.py tests/test_constraint_candidate_discovery.py -v

# Phase 2: constraint packs and verifier
.\.venv\Scripts\python.exe -m pytest tests/test_constraint_packs.py tests/test_constraint_pack_runner_tool.py tests/test_solver_capability_verifier.py tests/test_compile_verified_constraints.py -v

# Phase 3: smart mapping agent integration
.\.venv\Scripts\python.exe -m pytest tests/test_smart_mapping_agent_domain_free_integration.py -v

# Phase 4: UI and report artifacts
.\.venv\Scripts\python.exe -m pytest tests/test_ui_report_contains_discovery_sections.py -v

# Phase 5: Q&A truthfulness
.\.venv\Scripts\python.exe -m pytest tests/test_insight_agent_constraint_truthfulness.py -v

# Final regression suite
.\.venv\Scripts\python.exe -m pytest tests/test_no_yaml_required_end_to_end.py tests/test_regression_bakery_cosmetics.py tests/test_unsupported_constraints_not_in_solver_payload.py tests/test_verified_constraints_compile_end_to_end.py tests/test_output_artifacts_with_discovery.py tests/test_qa_end_to_end_domain_free.py tests/test_debug_file_validation.py -v

# Exclude tests that require a running server
.\.venv\Scripts\python.exe -m pytest --ignore=tests/test_graph_smoke.py --ignore=tests/test_mcp_local_client.py
```

---

## Running the MCP server

```powershell
.\.venv\Scripts\python.exe mcp_server.py
```

Starts on **stdio transport** (JSON-RPC on stdout, logs on stderr).
Compatible with Claude Desktop, VS Code MCP extension, and any MCP host that
launches tools as subprocesses.

---

## Dataset format

### Minimum required sheets

| Sheet name (or alias) | Purpose |
|---|---|
| `Demand_Orders` (or `orders`, `demand`, `customer_plan`, …) | Orders: product, quantity, due date |
| `Routing` (or `processdata`, `operations`, `process_flow`, …) | Operation sequences, durations, machine groups |
| `Machine_Master` (or `machines`, `equipmentlist`, `resources`, …) | Machine IDs, types, capacity |

**Non-canonical sheet names are automatically detected.** The system discovers manufacturing
structure from column names, sample values, and data patterns — YAML domain profiles are
optional fallback/metadata only.

### Optional sheets (auto-detected when present)

`SKU_Master`, `Inventory`, `BOM`, `Machine_Calendar`, `Setup_Changeover`,
`Maintenance`, `Labor_Shifts`, `Cost_Parameters`, `Business_Rules`, `Material_Receipts`

### Minimum required columns (any naming style)

For **Demand_Orders**: a product identifier, a quantity, a due/promise date.  
For **Routing**: a product identifier, a step/sequence number, a duration/runtime, a machine type or eligible machine.  
For **Machine_Master**: a machine identifier, a machine type/group, capacity.

---

## Technology stack

| Layer | Technology |
|---|---|
| UI | Streamlit 1.45 |
| Workflow | LangGraph |
| Optimizer | OR-Tools CP-SAT |
| Domain-free mapping | Custom token-matching + scoring (no external NLP) |
| Evidence-based packs | Python constraint detectors (9 packs) |
| LLM (optional) | Ollama `qwen2.5:3b` — explanation polishing only |
| Data processing | pandas, openpyxl |
| Schema validation | Pydantic v2 |
| Reports | Plotly (Gantt), openpyxl (Excel), HTML |
| MCP integration | FastMCP 2.3.3 |

---

## Architecture

```
Streamlit UI (app.py)
    │
    └─► LangGraph workflow (graph.py)
            │
            ├─► Smart Constraint Mapping Agent
            │       Step 1:  read_workbook
            │       Step 2:  optional legacy domain detection (YAML, graceful fallback)
            │       Step 3:  discover_manufacturing_structure  ← domain-free
            │       Step 4:  merge sheet mappings (domain-free preferred, legacy fallback)
            │       Step 5:  classify_columns_semantically     ← domain-free
            │       Step 6:  merge column mappings
            │       Step 7:  normalize_tables
            │       Step 8:  detect_manufacturing_dna
            │       Step 9:  discover_constraint_candidates
            │       Step 10: run_constraint_packs (9 evidence-based packs)
            │       Step 11: merge & deduplicate candidates
            │       Step 12: verify_constraint_candidates (solver capability check)
            │       Step 13: compile_verified_constraints → canonical rules
            │       Step 14: legacy map_constraints (backward compat)
            │       Step 15: merge_final_constraint_rules
            │       Step 16: build_canonical_payload
            │
            ├─► Canonical Payload Validation Node
            │       Pydantic v2 validation + cross-reference checks
            │       [invalid → END]
            │
            ├─► CP-SAT Scheduling Node
            │       OR-Tools CP-SAT solver
            │       → post-solve validation
            │       → report/Gantt generation
            │       [failed → END]
            │
            └─► Insight + Q&A Agent
                    10-section deterministic analysis
                    Constraint enforcement truthfulness guard
                    Optional LLM polishing (validated before use)
```

---

## Constraint enforcement model

The system separates detected constraints from enforced constraints:

| Status | Meaning |
|---|---|
| `enforced` | Verified and sent to CP-SAT as a hard rule |
| `detected_partial` | Detected but some required fields are missing |
| `detected_not_enforced` | Detected but current solver does not fully model it |
| `needs_user_review` | Evidence present but a required value must be supplied |
| `unsupported` | Constraint type not in the current solver capability registry |

**Constraints that are detected but NOT enforced** (visible in the UI, not sent to solver):
- Material inventory / time-phased material consumption
- Shelf life / freshness windows
- Labor shift capacity
- Overtime capacity
- Component reel availability

---

## Solver statuses

| Status | Meaning |
|---|---|
| `OPTIMAL` | CP-SAT proved the schedule globally optimal for the enforced constraints |
| `FEASIBLE` | Valid schedule found; global optimality not proven within time limit |
| `INFEASIBLE` | No valid schedule exists under the enforced constraints |
| `MODEL_INVALID` | Model could not be built (input data problem) |
| `UNKNOWN` | Solver timed out or hit a resource limit |
| `ERROR` | Unexpected internal error |
| `POST_SOLVE_INVALID` | Schedule found but failed post-solve constraint checks |

> **Important:** `FEASIBLE` is never described as "globally optimal" in the UI, reports, or Q&A.

---

## Output files

### Schedule outputs (saved to `outputs/`)

| File | Contents |
|---|---|
| `schedule_{date}_{domain}.csv` | Flat CSV of all scheduled operations |
| `schedule_{date}_{domain}.xlsx` | Multi-sheet Excel (see below) |
| `report_{date}_{domain}.html` | Full HTML report with manufacturing intelligence sections |
| `gantt_{date}_{domain}.html` | Interactive Plotly Gantt chart (colour-coded by operation family) |

### Excel sheets

| Sheet | Contents |
|---|---|
| `Schedule` | All scheduled operations |
| `Cost_Summary` | Objective score, tardiness, revenue, profit |
| `Info_Summary` | Job/operation counts, domain, date |
| `Machine_Utilization` | Utilization % per machine |
| `Late_Orders` | Orders that missed their due date |
| `Bottlenecks` | Machines above the bottleneck threshold |
| `Warnings` | Non-fatal warnings from the pipeline |
| `Errors` | Errors if any occurred |
| `Manufacturing_DNA` | Detected manufacturing capabilities |
| `Constraint_Enforcement` | Full constraint enforcement matrix |
| `Table_Role_Mapping` | How each raw sheet was mapped to a canonical role |
| `Constraint_Packs` | Evidence-based constraint pack candidates |

### HTML report sections

1. Planning Date & Reference Time
2. Domain Information (optional guess — metadata only)
3. Solver Status
4. Schedule Summary
5. Cost / Profit Summary
6. Machine Utilization
7. Bottleneck Machines
8. Late Orders
9. Unscheduled Orders
10. Schedule Table (first 50 rows)
11. Warnings
12. Errors
13. Mapping Summary (sheet mapping, constraints)
14. **Manufacturing Structure Discovery** ← Phase 4
15. **Constraint Enforcement Matrix** ← Phase 4
16. **Evidence-Based Constraint Pack Detection** ← Phase 4
17. Post-Solve Validation
18. Solver Debug

---

## Debug audit trail

Every run writes a full audit trail to:

```
outputs/debug/<run_id>/
```

### Debug files written per run

| File | Contents |
|---|---|
| `01_workbook_profile.json` | Sheet names, column lists, row counts, sample rows |
| `02_domain_detection.json` | Optional legacy domain detection result |
| `03_sheet_mapping.json` | Domain-free + legacy sheet mapping (with sources) |
| `04_column_mapping.json` | Semantic + legacy column mapping |
| `05_normalized_table_summary.json` | Row counts of normalized tables |
| `06_constraint_mapping.json` | Legacy constraint mapping result (backward compat) |
| `07_canonical_payload_summary.json` | Compact solver payload summary |
| `08_canonical_payload_full.json` | Full canonical payload sent to CP-SAT |
| `09_table_role_discovery.json` | Domain-free table role discovery candidates |
| `10_constraint_enforcement_matrix.json` | Constraint enforcement matrix |
| `11_manufacturing_dna.json` | Manufacturing DNA flags and evidence |
| `11_verified_constraints.json` | Verified (enforced) constraints |
| `12_common_constraint_candidates.json` | Common constraint candidates |
| `12_compiled_verified_constraints.json` | Compiled canonical rule structures |
| `13_constraint_pack_candidates.json` | Evidence-based pack candidates |
| `13_legacy_constraint_mapping.json` | Legacy constraint mapping |
| `14_all_constraint_candidates.json` | All merged candidates |
| `14_final_constraint_rules.json` | Final merged constraint rules |
| `10_semantic_column_mapping.json` | Semantic column classifier output |
| `11_solver_input_payload.json` | Exact payload received by the solver |
| `12_solver_result_summary.json` | Solver output summary |

Debug files are available as **download buttons in the Downloads tab** of the Streamlit UI.

---

## Project structure

```
app.py                              Streamlit UI
graph.py                            LangGraph workflow
state.py                            SchedulerState TypedDict (Phase 1–5 fields)
mcp_server.py                       FastMCP server
mcp_client.py                       MCP client utilities

agents/
  smart_constraint_mapping_agent.py  17-step domain-free mapping pipeline
  insight_qa_agent.py                10-section insight + Q&A with truthfulness guard

nodes/
  canonical_payload_validation_node.py
  cp_sat_scheduling_node.py

tools/
  workbook_reader_tool.py
  domain_profile_tool.py             (optional YAML domain detection)
  schema_detection_tool.py
  column_mapping_tool.py
  unit_normalization_tool.py
  constraint_mapping_tool.py
  canonical_payload_builder_tool.py
  canonical_payload_validator_tool.py
  cp_sat_model_builder_tool.py
  cp_sat_solver_tool.py
  post_solve_validator_tool.py
  report_gantt_tool.py
  manufacturing_structure_discovery_tool.py   ← Phase 1
  semantic_column_classifier_tool.py          ← Phase 1
  manufacturing_dna_tool.py                   ← Phase 1
  constraint_candidate_discovery_tool.py      ← Phase 1
  constraint_pack_runner_tool.py              ← Phase 2
  solver_capability_verifier_tool.py          ← Phase 2

constraint_packs/
  __init__.py                        Pack loader (safe, per-pack error isolation)
  base.py                            BaseConstraintPack
  core_manufacturing_pack.py         Generic manufacturing constraints
  food_bakery_pack.py                Proof/bake/allergen/freshness evidence
  cosmetics_pack.py                  Fragrance/color/GMP/fill evidence
  pharma_pack.py                     Quarantine/GMP/cleanroom evidence
  steel_pack.py                      Furnace/grade/cooling evidence
  textile_pack.py                    Dye/loom/wash/dry evidence
  electronics_pack.py                SMT/PCB/test evidence
  packaging_pack.py                  Mold/die/carton evidence
  automotive_pack.py                 Fixture/paint/assembly evidence

schemas/
  canonical_schema.py                Pydantic v2 models

profiles/
  generic_manufacturing.v1.yaml      Optional fallback profiles
  cosmetics.v1.yaml
  bakery.v1.yaml

config/
  logging_config.py

utils/
  debug_audit.py

tests/
  conftest.py
  test_schema_validation.py
  test_current_date.py
  test_mapping_tools.py
  test_schema_adaptive_mapping.py
  test_cosmetics_mapping.py
  test_bakery_mapping.py
  test_cp_sat_solver.py
  test_post_solve_validation.py
  test_report_generation.py
  test_debug_audit.py
  test_graph_smoke.py               (requires running graph — excluded by default)
  test_mcp_local_client.py          (requires MCP server — excluded by default)
  test_manufacturing_structure_discovery.py   ← Phase 1
  test_semantic_column_classifier.py          ← Phase 1
  test_manufacturing_dna_tool.py              ← Phase 1
  test_constraint_candidate_discovery.py      ← Phase 1
  test_constraint_packs.py                    ← Phase 2
  test_constraint_pack_runner_tool.py         ← Phase 2
  test_solver_capability_verifier.py          ← Phase 2
  test_compile_verified_constraints.py        ← Phase 2
  test_smart_mapping_agent_domain_free_integration.py  ← Phase 3
  test_ui_report_contains_discovery_sections.py        ← Phase 4
  test_insight_agent_constraint_truthfulness.py        ← Phase 5
  test_no_yaml_required_end_to_end.py                  ← Final
  test_regression_bakery_cosmetics.py                  ← Final
  test_unsupported_constraints_not_in_solver_payload.py ← Final
  test_verified_constraints_compile_end_to_end.py      ← Final
  test_output_artifacts_with_discovery.py              ← Final
  test_qa_end_to_end_domain_free.py                    ← Final
  test_debug_file_validation.py                        ← Final
```

---

## LLM usage policy

**LLM is only used for (optional):**
- Polishing the schedule explanation text
- Refining Q&A answer wording

**LLM is validated before use** — refined responses that claim FEASIBLE is "globally optimal",
hide partial constraints, or treat the optional domain guess as a source of truth are
rejected in favor of the deterministic output.

**LLM is never used for:**
- Scheduling or optimization
- CP-SAT constraint generation
- Cost / revenue calculation
- Date arithmetic
- Manufacturing structure discovery

The entire pipeline is deterministic and works without Ollama running.

---

## Current Planning Date behavior

- Selected in the Streamlit sidebar with a date picker
- Passed as `current_date` / `reference_date` into the workflow
- Becomes `SolverPayload.reference_time` (time-zero for CP-SAT)
- All job start/end times are relative to this date
- Jobs with `due_at` **before** `reference_time` are treated as backlog (always late)
- `datetime.now()` is never called in scheduling logic

---

## Known limitations

- **Shelf life / freshness windows**: detected and visible in the enforcement matrix but not modeled as hard CP-SAT constraints (current solver limitation).
- **Time-phased material inventory**: BOM + Inventory tables are detected but time-phased material consumption is not enforced by the solver.
- **Labor shifts / overtime**: detected but not modeled as cumulative resource constraints.
- **Large datasets**: the Streamlit app runs the solver synchronously; very large problems may cause long spinner waits.
- **Ollama optional**: LLM polishing is a no-op when Ollama is not running; all deterministic outputs remain fully functional.
- **Cosmetics with QA hold**: compiled quality-hold constraints (e.g. 24h QA release) require sufficient planning horizon; very short horizons may produce INFEASIBLE.
