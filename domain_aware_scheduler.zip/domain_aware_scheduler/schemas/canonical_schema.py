from datetime import datetime
from typing import Any, Dict, List, Optional, Literal
from pydantic import BaseModel, Field, field_validator, model_validator


class MachineSpec(BaseModel):
    machine_id: str
    machine_name: Optional[str] = None
    machine_type: str
    capacity: int = 1
    hourly_cost: float = 0.0

    @field_validator("capacity")
    @classmethod
    def capacity_at_least_one(cls, v: int) -> int:
        if v < 1:
            raise ValueError("capacity must be >= 1")
        return v

    @field_validator("hourly_cost")
    @classmethod
    def hourly_cost_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ValueError("hourly_cost must be >= 0")
        return v


class CalendarWindow(BaseModel):
    machine_id: str
    start: datetime
    end: datetime
    available: bool = True

    @model_validator(mode="after")
    def end_after_start(self) -> "CalendarWindow":
        if self.end <= self.start:
            raise ValueError("end must be strictly after start")
        return self


class OperationSpec(BaseModel):
    op_id: str
    operation_family: str
    operation_name: Optional[str] = None
    sequence: int
    duration_minutes: int
    eligible_machines: List[str]
    demand_load: int = 1
    min_wait_to_next_minutes: Optional[int] = None
    max_wait_to_next_minutes: Optional[int] = None

    @field_validator("duration_minutes")
    @classmethod
    def duration_positive(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("duration_minutes must be > 0")
        return v

    @field_validator("eligible_machines")
    @classmethod
    def eligible_machines_not_empty(cls, v: List[str]) -> List[str]:
        if not v:
            raise ValueError("eligible_machines must not be empty")
        return v

    @field_validator("sequence")
    @classmethod
    def sequence_at_least_one(cls, v: int) -> int:
        if v < 1:
            raise ValueError("sequence must be >= 1")
        return v

    @field_validator("demand_load")
    @classmethod
    def demand_load_at_least_one(cls, v: int) -> int:
        if v < 1:
            raise ValueError("demand_load must be >= 1")
        return v

    @field_validator("min_wait_to_next_minutes")
    @classmethod
    def min_wait_non_negative(cls, v: Optional[int]) -> Optional[int]:
        if v is not None and v < 0:
            raise ValueError("min_wait_to_next_minutes must be >= 0")
        return v

    @field_validator("max_wait_to_next_minutes")
    @classmethod
    def max_wait_non_negative(cls, v: Optional[int]) -> Optional[int]:
        if v is not None and v < 0:
            raise ValueError("max_wait_to_next_minutes must be >= 0")
        return v


class JobSpec(BaseModel):
    job_id: str
    order_id: str
    product_id: str
    product_family: Optional[str] = None
    quantity: float
    due_at: datetime
    priority_class: str = "MEDIUM"
    priority_weight: float = 1.0
    late_penalty_per_minute: float = 0.0
    holding_cost_per_minute: float = 0.0
    selling_price_per_unit: float = 0.0
    unit_production_cost: float = 0.0
    # shelf_life_minutes: if set, the job must complete no earlier than
    # (due_at - shelf_life_minutes) to avoid the product expiring before delivery.
    shelf_life_minutes: Optional[int] = None
    operations: List[OperationSpec]

    @field_validator("quantity")
    @classmethod
    def quantity_positive(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("quantity must be > 0")
        return v

    @field_validator("priority_weight")
    @classmethod
    def priority_weight_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ValueError("priority_weight must be >= 0")
        return v

    @field_validator(
        "late_penalty_per_minute",
        "holding_cost_per_minute",
        "selling_price_per_unit",
        "unit_production_cost",
    )
    @classmethod
    def cost_fields_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ValueError("cost fields must be >= 0")
        return v

    @field_validator("operations")
    @classmethod
    def operations_not_empty(cls, v: List[OperationSpec]) -> List[OperationSpec]:
        if not v:
            raise ValueError("operations must not be empty")
        return v

    @model_validator(mode="after")
    def unique_operation_sequences(self) -> "JobSpec":
        seqs = [op.sequence for op in self.operations]
        if len(seqs) != len(set(seqs)):
            raise ValueError(
                f"operation sequences must be unique within job '{self.job_id}'"
            )
        return self


class MaterialSpec(BaseModel):
    material_id: str
    material_name: Optional[str] = None
    unit: str
    available_quantity: float = 0.0
    safety_stock: float = 0.0
    receipt_date: Optional[datetime] = None

    @field_validator("available_quantity")
    @classmethod
    def available_quantity_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ValueError("available_quantity must be >= 0")
        return v

    @field_validator("safety_stock")
    @classmethod
    def safety_stock_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ValueError("safety_stock must be >= 0")
        return v


class SetupRule(BaseModel):
    rule_id: str
    constraint_type: Literal["sequence_dependent_setup"] = "sequence_dependent_setup"
    machine_id: Optional[str] = None
    machine_type: Optional[str] = None
    from_family: str
    to_family: str
    setup_minutes: int
    setup_cost: float = 0.0
    hard: bool = True
    source: Optional[Dict[str, Any]] = None

    @field_validator("setup_minutes")
    @classmethod
    def setup_minutes_non_negative(cls, v: int) -> int:
        if v < 0:
            raise ValueError("setup_minutes must be >= 0")
        return v

    @field_validator("setup_cost")
    @classmethod
    def setup_cost_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ValueError("setup_cost must be >= 0")
        return v


class CleaningRule(BaseModel):
    rule_id: str
    constraint_type: Literal["sequence_dependent_cleaning"] = "sequence_dependent_cleaning"
    machine_id: Optional[str] = None
    machine_type: Optional[str] = None
    from_family: str
    to_family: str
    cleaning_minutes: int
    cleaning_cost: float = 0.0
    hard: bool = True
    source: Optional[Dict[str, Any]] = None

    @field_validator("cleaning_minutes")
    @classmethod
    def cleaning_minutes_non_negative(cls, v: int) -> int:
        if v < 0:
            raise ValueError("cleaning_minutes must be >= 0")
        return v

    @field_validator("cleaning_cost")
    @classmethod
    def cleaning_cost_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ValueError("cleaning_cost must be >= 0")
        return v


class WaitRule(BaseModel):
    rule_id: str
    constraint_type: Literal[
        "max_wait_between_operations",
        "min_wait_between_operations",
        "fixed_wait_between_operations",
        "quality_release_hold",
        "freshness_window",
    ]
    from_operation_family: str
    to_operation_family: str
    min_wait_minutes: Optional[int] = None
    max_wait_minutes: Optional[int] = None
    hard: bool = True
    penalty_per_minute: float = 0.0
    source: Optional[Dict[str, Any]] = None

    @field_validator("min_wait_minutes")
    @classmethod
    def min_wait_non_negative(cls, v: Optional[int]) -> Optional[int]:
        if v is not None and v < 0:
            raise ValueError("min_wait_minutes must be >= 0")
        return v

    @field_validator("max_wait_minutes")
    @classmethod
    def max_wait_non_negative(cls, v: Optional[int]) -> Optional[int]:
        if v is not None and v < 0:
            raise ValueError("max_wait_minutes must be >= 0")
        return v

    @field_validator("penalty_per_minute")
    @classmethod
    def penalty_non_negative(cls, v: float) -> float:
        if v < 0:
            raise ValueError("penalty_per_minute must be >= 0")
        return v

    @model_validator(mode="after")
    def max_wait_gte_min_wait(self) -> "WaitRule":
        if (
            self.min_wait_minutes is not None
            and self.max_wait_minutes is not None
            and self.max_wait_minutes < self.min_wait_minutes
        ):
            raise ValueError("max_wait_minutes must be >= min_wait_minutes")
        return self


class BatchRule(BaseModel):
    rule_id: str
    product_id: Optional[str] = None
    product_family: Optional[str] = None
    min_batch_size: Optional[float] = None
    max_batch_size: Optional[float] = None
    batch_multiple: Optional[float] = None
    split_allowed: bool = False
    source: Optional[Dict[str, Any]] = None

    @field_validator("min_batch_size")
    @classmethod
    def min_batch_positive(cls, v: Optional[float]) -> Optional[float]:
        if v is not None and v <= 0:
            raise ValueError("min_batch_size must be positive")
        return v

    @field_validator("max_batch_size")
    @classmethod
    def max_batch_positive(cls, v: Optional[float]) -> Optional[float]:
        if v is not None and v <= 0:
            raise ValueError("max_batch_size must be positive")
        return v

    @field_validator("batch_multiple")
    @classmethod
    def batch_multiple_positive(cls, v: Optional[float]) -> Optional[float]:
        if v is not None and v <= 0:
            raise ValueError("batch_multiple must be positive")
        return v

    @model_validator(mode="after")
    def max_batch_gte_min_batch(self) -> "BatchRule":
        if (
            self.min_batch_size is not None
            and self.max_batch_size is not None
            and self.max_batch_size < self.min_batch_size
        ):
            raise ValueError("max_batch_size must be >= min_batch_size")
        return self


class QualityRule(BaseModel):
    rule_id: str
    product_id: Optional[str] = None
    product_family: Optional[str] = None
    operation_family: Optional[str] = None
    hold_minutes: int
    hard: bool = True
    source: Optional[Dict[str, Any]] = None

    @field_validator("hold_minutes")
    @classmethod
    def hold_minutes_non_negative(cls, v: int) -> int:
        if v < 0:
            raise ValueError("hold_minutes must be >= 0")
        return v


class SharedResourceSpec(BaseModel):
    resource_id: str
    resource_name: Optional[str] = None
    capacity: int
    applicable_operation_families: List[str]

    @field_validator("capacity")
    @classmethod
    def capacity_at_least_one(cls, v: int) -> int:
        if v < 1:
            raise ValueError("capacity must be >= 1")
        return v

    @field_validator("applicable_operation_families")
    @classmethod
    def families_not_empty(cls, v: List[str]) -> List[str]:
        if not v:
            raise ValueError("applicable_operation_families must not be empty")
        return v


class ObjectiveWeights(BaseModel):
    tardiness_weight: float = 1.0
    holding_weight: float = 1.0
    setup_weight: float = 1.0
    cleaning_weight: float = 1.0
    machine_cost_weight: float = 1.0
    overtime_weight: float = 1.0
    freshness_waste_weight: float = 1.0

    @model_validator(mode="after")
    def all_weights_non_negative(self) -> "ObjectiveWeights":
        for field_name, value in self.model_dump().items():
            if value < 0:
                raise ValueError(f"{field_name} must be >= 0")
        return self


class SolverPayload(BaseModel):
    reference_time: datetime
    domain_profile_id: str
    metadata: Dict[str, Any] = Field(default_factory=dict)
    jobs: List[JobSpec]
    machines: List[MachineSpec]
    calendars: List[CalendarWindow] = Field(default_factory=list)
    materials: List[MaterialSpec] = Field(default_factory=list)
    setup_rules: List[SetupRule] = Field(default_factory=list)
    cleaning_rules: List[CleaningRule] = Field(default_factory=list)
    wait_rules: List[WaitRule] = Field(default_factory=list)
    batch_rules: List[BatchRule] = Field(default_factory=list)
    quality_rules: List[QualityRule] = Field(default_factory=list)
    shared_resources: List[SharedResourceSpec] = Field(default_factory=list)
    objective_weights: ObjectiveWeights = Field(default_factory=ObjectiveWeights)
    constraints: List[Dict[str, Any]] = Field(default_factory=list)
    provenance: List[Dict[str, Any]] = Field(default_factory=list)
    horizon_seconds: int

    @field_validator("jobs")
    @classmethod
    def jobs_not_empty(cls, v: List[JobSpec]) -> List[JobSpec]:
        if not v:
            raise ValueError("jobs must not be empty")
        return v

    @field_validator("machines")
    @classmethod
    def machines_not_empty(cls, v: List[MachineSpec]) -> List[MachineSpec]:
        if not v:
            raise ValueError("machines must not be empty")
        return v

    @field_validator("horizon_seconds")
    @classmethod
    def horizon_positive(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("horizon_seconds must be > 0")
        return v

    @model_validator(mode="after")
    def cross_reference_validations(self) -> "SolverPayload":
        machine_ids = {m.machine_id for m in self.machines}

        for job in self.jobs:
            for op in job.operations:
                for mid in op.eligible_machines:
                    if mid not in machine_ids:
                        raise ValueError(
                            f"eligible_machine '{mid}' in op '{op.op_id}' "
                            f"of job '{job.job_id}' not found in machines list"
                        )

        for cal in self.calendars:
            if cal.machine_id not in machine_ids:
                raise ValueError(
                    f"calendar machine_id '{cal.machine_id}' not found in machines list"
                )

        return self


class MappingReport(BaseModel):
    domain_profile_id: str
    domain_confidence: float
    domain_reason: Optional[str] = None
    sheet_mapping: Dict[str, str] = Field(default_factory=dict)
    column_mapping: Dict[str, Dict[str, str]] = Field(default_factory=dict)
    mapped_constraints: List[Dict[str, Any]] = Field(default_factory=list)
    unsupported_rules: List[Dict[str, Any]] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)
    requires_user_review: bool = False


class ScheduledTask(BaseModel):
    job_id: str
    order_id: str
    product_id: str
    operation_id: str
    operation_family: str
    machine_id: str
    start: datetime
    end: datetime
    duration_minutes: int
    due_at: datetime
    is_late: bool
    tardiness_minutes: int = 0
    priority_class: str = "MEDIUM"


class SolverResult(BaseModel):
    solver_status: Literal[
        "OPTIMAL",
        "FEASIBLE",
        "INFEASIBLE",
        "MODEL_INVALID",
        "UNKNOWN",
        "ERROR",
        "POST_SOLVE_INVALID",
    ]
    objective_value: Optional[float] = None
    schedule_table: List[ScheduledTask] = Field(default_factory=list)
    late_orders: List[Dict[str, Any]] = Field(default_factory=list)
    unscheduled_orders: List[Dict[str, Any]] = Field(default_factory=list)
    machine_utilization: List[Dict[str, Any]] = Field(default_factory=list)
    bottlenecks: List[Dict[str, Any]] = Field(default_factory=list)
    cost_summary: Dict[str, Any] = Field(default_factory=dict)
    info_summary: Dict[str, Any] = Field(default_factory=dict)
    solver_debug: Dict[str, Any] = Field(default_factory=dict)
    post_solve_validation_report: Dict[str, Any] = Field(default_factory=dict)
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
