from __future__ import annotations

import json
import math
import re
from datetime import datetime, date
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Run ID / directory helpers
# ---------------------------------------------------------------------------

def make_run_id(
    file_path: str,
    current_date: str,
    domain_profile_id: str | None = None,
) -> str:
    """Build a deterministic, filesystem-safe run identifier.

    Example output:
      2026-04-27_balanced_cosmetic_production_scheduling_dataset_cpsat_cosmetics_v1
    """
    stem = Path(file_path).stem
    safe_stem = re.sub(r"[^a-zA-Z0-9_-]", "_", stem).lower()
    safe_stem = re.sub(r"_+", "_", safe_stem).strip("_")
    parts = [current_date, safe_stem]
    if domain_profile_id:
        safe_domain = re.sub(r"[^a-zA-Z0-9_-]", "_", domain_profile_id).lower()
        safe_domain = re.sub(r"_+", "_", safe_domain).strip("_")
        parts.append(safe_domain)
    return "_".join(parts)


def make_debug_dir(run_id: str) -> str:
    """Create outputs/debug/<run_id>/ and return the path as string."""
    debug_path = Path("outputs") / "debug" / run_id
    debug_path.mkdir(parents=True, exist_ok=True)
    return str(debug_path)


# ---------------------------------------------------------------------------
# JSON serialization
# ---------------------------------------------------------------------------

def json_safe(obj: Any) -> Any:
    """Recursively convert obj to JSON-serializable Python types.

    Handles: Pydantic BaseModel, pandas DataFrame/Series/Timestamp,
    numpy scalars/arrays, datetime, date, float (nan/inf), bytes, dict, list.
    """
    if obj is None:
        return None

    # Pydantic BaseModel → dict first so nested models are unwrapped
    try:
        from pydantic import BaseModel
        if isinstance(obj, BaseModel):
            return json_safe(obj.model_dump())
    except ImportError:
        pass

    # pandas types
    try:
        import pandas as pd
        if isinstance(obj, pd.DataFrame):
            return [json_safe(row) for row in obj.to_dict(orient="records")]
        if isinstance(obj, pd.Series):
            return [json_safe(v) for v in obj.tolist()]
        if isinstance(obj, pd.Timestamp):
            return None if pd.isna(obj) else obj.isoformat()
        try:
            if pd.isna(obj):
                return None
        except (TypeError, ValueError):
            pass
    except ImportError:
        pass

    # numpy types
    try:
        import numpy as np
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            f = float(obj)
            return None if (math.isnan(f) or math.isinf(f)) else f
        if isinstance(obj, np.bool_):
            return bool(obj)
        if isinstance(obj, np.ndarray):
            return [json_safe(v) for v in obj.tolist()]
    except ImportError:
        pass

    # stdlib datetime / date
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, date):
        return obj.isoformat()

    # plain float (nan / inf guard)
    if isinstance(obj, float):
        return None if (math.isnan(obj) or math.isinf(obj)) else obj

    # bytes
    if isinstance(obj, bytes):
        return obj.decode("utf-8", errors="replace")

    # dict → recurse
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}

    # list / tuple / set → recurse
    if isinstance(obj, (list, tuple, set)):
        return [json_safe(v) for v in obj]

    return obj


def write_debug_json(debug_dir: str, filename: str, data: Any) -> str:
    """Serialize data to pretty JSON and write to debug_dir/filename.

    Returns the written file path as a string.
    Creates debug_dir if it does not already exist.
    Falls back to writing an error envelope on serialization failure.
    """
    path = Path(debug_dir) / filename
    Path(debug_dir).mkdir(parents=True, exist_ok=True)
    try:
        serialized = json_safe(data)
        path.write_text(
            json.dumps(serialized, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception as exc:
        path.write_text(
            json.dumps({"_write_error": str(exc)}, indent=2),
            encoding="utf-8",
        )
    return str(path)


# ---------------------------------------------------------------------------
# Summarizers — compact views of each pipeline stage
# ---------------------------------------------------------------------------

def summarize_workbook_profile(workbook_profile: dict) -> dict:
    """Return sheet count, columns, and first-3 sample rows per sheet.

    Never includes the full dataset — safe to store as audit JSON.
    """
    sheets_raw: dict = workbook_profile.get("sheets") or {}
    sheets_summary: dict = {}
    for sheet_name, sheet_data in sheets_raw.items():
        sample_rows = (sheet_data.get("sample_rows") or [])[:3]
        sheets_summary[str(sheet_name)] = {
            "row_count": sheet_data.get("row_count", 0),
            "columns": sheet_data.get("columns", []),
            "sample_rows_first_3": json_safe(sample_rows),
        }
    return {
        "file_path": workbook_profile.get("file_path"),
        "file_type": workbook_profile.get("file_type"),
        "sheet_count": len(sheets_raw),
        "sheets": sheets_summary,
        "errors": workbook_profile.get("errors") or [],
        "warnings": workbook_profile.get("warnings") or [],
    }


def summarize_normalized_tables(normalized_tables: dict) -> dict:
    """Row count + column list + first-3 rows per normalized table."""
    summary: dict = {}
    try:
        import pandas as pd
        _has_pandas = True
    except ImportError:
        _has_pandas = False

    for table_name, table_data in (normalized_tables or {}).items():
        if _has_pandas and isinstance(table_data, __import__("pandas").DataFrame):
            rows = table_data.to_dict(orient="records")
        elif isinstance(table_data, list):
            rows = table_data
        else:
            rows = []
        summary[str(table_name)] = {
            "row_count": len(rows),
            "columns": list(rows[0].keys()) if rows else [],
            "sample_rows_first_3": json_safe(rows[:3]),
        }
    return summary


def summarize_canonical_payload(payload: Any) -> dict:
    """Return counts and samples from a SolverPayload (Pydantic model or dict)."""
    if payload is None:
        return {"error": "payload is None"}

    try:
        from pydantic import BaseModel
        p = payload.model_dump() if isinstance(payload, BaseModel) else dict(payload)
    except Exception:
        p = dict(payload) if isinstance(payload, dict) else {}

    jobs: list = p.get("jobs") or []
    machines: list = p.get("machines") or []
    operations_count = sum(len(j.get("operations") or []) for j in jobs)

    sample_jobs = [
        {
            "job_id": j.get("job_id"),
            "order_id": j.get("order_id"),
            "product_id": j.get("product_id"),
            "quantity": j.get("quantity"),
            "due_at": json_safe(j.get("due_at")),
            "priority_class": j.get("priority_class"),
            "operations_count": len(j.get("operations") or []),
        }
        for j in jobs[:3]
    ]

    sample_machines = [
        {
            "machine_id": m.get("machine_id"),
            "machine_type": m.get("machine_type"),
            "capacity": m.get("capacity"),
        }
        for m in machines[:5]
    ]

    sample_constraints: dict = {}
    for key in ("setup_rules", "cleaning_rules", "wait_rules", "quality_rules"):
        items = p.get(key) or []
        if items:
            sample_constraints[key] = json_safe(items[:2])

    ow = p.get("objective_weights") or {}
    if hasattr(ow, "model_dump"):
        ow = ow.model_dump()

    return {
        "reference_time": json_safe(p.get("reference_time")),
        "domain_profile_id": p.get("domain_profile_id"),
        "jobs_count": len(jobs),
        "machines_count": len(machines),
        "operations_count": operations_count,
        "calendars_count": len(p.get("calendars") or []),
        "materials_count": len(p.get("materials") or []),
        "setup_rules_count": len(p.get("setup_rules") or []),
        "cleaning_rules_count": len(p.get("cleaning_rules") or []),
        "wait_rules_count": len(p.get("wait_rules") or []),
        "quality_rules_count": len(p.get("quality_rules") or []),
        "objective_weights": json_safe(ow),
        "sample_jobs_first_3": sample_jobs,
        "sample_machines_first_5": sample_machines,
        "sample_constraints": sample_constraints,
    }


def summarize_solver_result(result: Any) -> dict:
    """Return a compact summary of a solver result (dict or Pydantic model)."""
    if result is None:
        return {"error": "result is None"}

    try:
        from pydantic import BaseModel
        r = result.model_dump() if isinstance(result, BaseModel) else dict(result)
    except Exception:
        r = dict(result) if isinstance(result, dict) else {}

    schedule_rows: list = r.get("schedule_table") or []
    late_orders: list = r.get("late_orders") or []
    unscheduled: list = r.get("unscheduled_orders") or []
    machine_util: list = r.get("machine_utilization") or []
    errors_list: list = r.get("errors") or []
    warnings_list: list = r.get("warnings") or []

    return {
        "solver_status": r.get("solver_status"),
        "schedule_rows": len(schedule_rows),
        "late_orders_count": len(late_orders),
        "unscheduled_orders_count": len(unscheduled),
        "cost_summary": json_safe(r.get("cost_summary") or {}),
        "info_summary": json_safe(r.get("info_summary") or {}),
        "machine_utilization_top_10": json_safe(machine_util[:10]),
        "solver_debug": json_safe(r.get("solver_debug") or {}),
        "errors_count": len(errors_list),
        "warnings_count": len(warnings_list),
        "errors_first_20": errors_list[:20],
        "warnings_first_20": warnings_list[:20],
    }
