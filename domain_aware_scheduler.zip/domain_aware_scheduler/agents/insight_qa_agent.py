"""
Insight / Q&A agent for the Production Scheduling Copilot.

Phase 5 update:
- Explains manufacturing structure discovery and mapping mode.
- Lists enforced constraints from the enforcement matrix.
- Honestly reports partial / not-enforced constraints.
- Explains evidence-based constraint pack findings.
- Optional domain guess is described as metadata only.
- LLM refinement is validated for truthfulness before use.
"""
from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# Safe accessors
# ---------------------------------------------------------------------------

def _safe_list(value: Any) -> list:
    return value if isinstance(value, list) else []


def _safe_dict(value: Any) -> dict:
    return value if isinstance(value, dict) else {}


def _format_money(value: Any) -> str:
    try:
        return f"{float(value):,.2f}"
    except (TypeError, ValueError):
        return "N/A"


def _format_pct(value: Any) -> str:
    try:
        return f"{float(value):.1f}%"
    except (TypeError, ValueError):
        return "N/A"


def _get_current_date(state: dict) -> str:
    if state.get("current_date"):
        return str(state["current_date"])
    rt = _safe_dict(state.get("info_summary")).get("reference_time")
    if rt:
        return str(rt)
    payload = _safe_dict(state.get("canonical_solver_payload"))
    rt2 = payload.get("reference_time") or payload.get("metadata", {}).get("current_date")
    if rt2:
        return str(rt2)
    return "Not available"


def _question_contains(question: str, words: list[str]) -> bool:
    q = question.lower()
    return any(w.lower() in q for w in words)


# ---------------------------------------------------------------------------
# State accessors for Phase 3/4 fields (check both top-level and mapping_report)
# ---------------------------------------------------------------------------

def _get_enforcement_matrix(state: dict) -> list:
    matrix = state.get("constraint_enforcement_matrix")
    if matrix is not None:
        return _safe_list(matrix)
    return _safe_list(_safe_dict(state.get("mapping_report")).get("constraint_enforcement_matrix"))


def _get_verified_constraints(state: dict) -> list:
    vc = state.get("verified_constraints")
    if vc is not None:
        return _safe_list(vc)
    return _safe_list(_safe_dict(state.get("mapping_report")).get("verified_constraints"))


def _get_partial_constraints(state: dict) -> list:
    pc = state.get("partial_constraints")
    if pc is not None:
        return _safe_list(pc)
    return _safe_list(_safe_dict(state.get("mapping_report")).get("partial_constraints"))


def _get_unsupported_constraints(state: dict) -> list:
    uc = state.get("unsupported_constraints")
    if uc is not None:
        return _safe_list(uc)
    return _safe_list(_safe_dict(state.get("mapping_report")).get("unsupported_constraints"))


def _get_dna(state: dict) -> dict:
    dna = state.get("manufacturing_dna")
    if dna is not None:
        return _safe_dict(dna)
    return _safe_dict(_safe_dict(state.get("mapping_report")).get("manufacturing_dna"))


def _get_dna_report(state: dict) -> dict:
    dr = state.get("manufacturing_dna_report")
    if dr is not None:
        return _safe_dict(dr)
    return _safe_dict(_safe_dict(state.get("mapping_report")).get("manufacturing_dna_report"))


def _get_activated_packs(state: dict) -> list:
    ap = state.get("activated_constraint_packs")
    if ap is not None:
        return _safe_list(ap)
    return _safe_list(_safe_dict(state.get("mapping_report")).get("activated_constraint_packs"))


def _get_pack_candidates(state: dict) -> list:
    pc = state.get("constraint_pack_candidates")
    if pc is not None:
        return _safe_list(pc)
    return _safe_list(_safe_dict(state.get("mapping_report")).get("constraint_pack_candidates"))


def _get_mapping_mode(state: dict) -> str:
    mode = state.get("mapping_mode") or ""
    if mode:
        return mode
    return _safe_dict(state.get("mapping_report")).get("mapping_mode") or ""


def _get_optional_domain(state: dict) -> dict:
    od = state.get("optional_domain_guess")
    if od is not None:
        return _safe_dict(od)
    mr = _safe_dict(state.get("mapping_report"))
    return _safe_dict(mr.get("optional_domain_guess"))


# ---------------------------------------------------------------------------
# Solver status — precise, honest wording
# ---------------------------------------------------------------------------

_SOLVER_STATUS_EXPLANATION: dict[str, str] = {
    "OPTIMAL": (
        "CP-SAT proved the schedule globally optimal for the modeled and enforced constraints. "
        "No better feasible schedule exists within the defined problem space."
    ),
    "FEASIBLE": (
        "CP-SAT found a valid feasible schedule, but global optimality was not proven "
        "within the configured time limit. A better schedule may exist."
    ),
    "INFEASIBLE": (
        "No feasible schedule was found under the enforced constraints. "
        "Check machine capacity, routing eligibility, and hard constraint tightness."
    ),
    "MODEL_INVALID": "The scheduling model could not be built. Review input data and column mappings.",
    "UNKNOWN": "The solver stopped without proving feasibility or optimality — likely hit a time/resource limit.",
    "ERROR": "An internal error occurred during scheduling. See error log for details.",
    "POST_SOLVE_INVALID": "A schedule was found but failed post-solve constraint validation checks.",
}

# DNA capability labels
_DNA_LABELS: dict[str, str] = {
    "has_demand": "Demand Orders",
    "has_products": "Products / SKUs",
    "has_routing": "Routing / Operations",
    "has_machines": "Machines / Resources",
    "has_machine_capacity": "Machine Capacity",
    "has_processing_times": "Processing Times",
    "has_due_dates": "Due Dates",
    "has_priorities": "Priorities",
    "has_bom": "BOM / Recipe",
    "has_inventory": "Inventory / Stock",
    "has_setup_changeover": "Setup / Changeover",
    "has_quality_hold": "Quality Hold (QA Release)",
    "has_calendar": "Machine Calendar",
    "has_labor": "Labor Shifts",
    "has_maintenance": "Maintenance Downtime",
    "has_overtime": "Overtime Capacity",
    "has_costs": "Cost Parameters",
}


# ---------------------------------------------------------------------------
# Existing helper functions (unchanged)
# ---------------------------------------------------------------------------

def _summarize_bottlenecks(machine_utilization: list, bottlenecks: list, limit: int = 5) -> str:
    if not bottlenecks:
        if machine_utilization:
            top = sorted(machine_utilization, key=lambda m: m.get("utilization_pct", 0), reverse=True)[:limit]
            lines = [f"  - {m.get('machine_id','?')}: {_format_pct(m.get('utilization_pct'))} utilization" for m in top]
            return "\n".join(lines) if lines else "  None detected."
        return "  No utilization data available."
    lines = [f"  - {b.get('machine_id','?')}: {_format_pct(b.get('utilization_pct'))} utilization (HIGH)" for b in bottlenecks[:limit]]
    return "\n".join(lines)


def _summarize_late_orders(late_orders: list, limit: int = 5) -> str:
    if not late_orders:
        return "  None — all orders on time."
    lines = []
    for lo in late_orders[:limit]:
        jid = lo.get("job_id") or lo.get("order_id", "?")
        tard = lo.get("tardiness_minutes", 0)
        prod = lo.get("product_id", "")
        due = lo.get("due_at", "")
        due_part = f", due {due[:10]}" if due else ""
        lines.append(f"  - {jid} (product: {prod}): {tard} min late{due_part}")
    if len(late_orders) > limit:
        lines.append(f"  ... and {len(late_orders) - limit} more.")
    return "\n".join(lines)


def _summarize_costs(cost_summary: dict) -> str:
    obj = cost_summary.get("objective_value")
    tard = cost_summary.get("total_tardiness_minutes", 0)
    late_n = cost_summary.get("num_late_orders", 0)
    unsched = cost_summary.get("num_unscheduled", 0)
    lines = []
    # Check if this is a partial estimate
    revenue = float(cost_summary.get("estimated_revenue") or 0)
    prod_cost = float(cost_summary.get("estimated_production_cost") or 0)
    total_cost = float(cost_summary.get("total_machine_cost") or cost_summary.get("total_business_cost") or 0)
    is_partial = total_cost > 0 and (revenue == 0 or prod_cost == 0)
    if is_partial:
        lines.append("  NOTE: Business cost accounting is partial. Revenue or unit production")
        lines.append("        cost is missing/zero, so estimated profit is not final business profit.")
    if obj is not None:
        lines.append(f"  Solver Objective Score:  {_format_money(obj)}")
    lines.append(f"  Total Tardiness:         {tard} min")
    lines.append(f"  Late Orders:             {late_n}")
    lines.append(f"  Unscheduled Orders:      {unsched}")
    if revenue:
        lines.append(f"  Estimated Revenue:       {_format_money(revenue)}")
    profit = cost_summary.get("estimated_profit")
    if profit is not None:
        label = "  Est. Profit (partial):   " if is_partial else "  Estimated Profit:        "
        lines.append(f"{label}{_format_money(profit)}")
    return "\n".join(lines) if lines else "  Not available."


def _find_order_in_schedule(schedule_table: list, query: str) -> list[dict]:
    q = query.lower().strip()
    return [
        t for t in schedule_table
        if q in str(t.get("job_id", "")).lower()
        or q in str(t.get("order_id", "")).lower()
        or q in str(t.get("product_id", "")).lower()
    ]


# ---------------------------------------------------------------------------
# Phase 5 — New section builders for deterministic insight
# ---------------------------------------------------------------------------

def _section_manufacturing_understanding(state: dict) -> list[str]:
    """Section 2: Manufacturing Understanding."""
    dna = _get_dna(state)
    dna_report = _get_dna_report(state)
    mapping_mode = _get_mapping_mode(state)
    optional_domain = _get_optional_domain(state)

    if not dna and not mapping_mode:
        return []

    lines = ["MANUFACTURING UNDERSTANDING"]

    # Mapping mode
    mode_map = {
        "domain_free_mapping":    "Domain-free (no YAML profiles required)",
        "mixed_mapping":          "Mixed (domain-free primary + legacy fallback for some sheets/columns)",
        "legacy_fallback_mapping":"Legacy fallback (YAML/alias-based)",
    }
    if mapping_mode:
        lines.append(f"  Mapping Mode   : {mode_map.get(mapping_mode, mapping_mode)}")

    # Optional domain guess — metadata only
    domain_id = optional_domain.get("domain_profile_id", "")
    if domain_id:
        domain_conf = float(optional_domain.get("confidence") or 0)
        lines.append(
            f"  Optional Domain Guess : {domain_id} ({domain_conf:.0%} confidence)"
        )
        lines.append(
            "  NOTE: The domain guess is metadata only. Scheduling is based on discovered"
        )
        lines.append(
            "        manufacturing structure and verified constraints — not on the domain label."
        )

    # Production model
    prod_model = dna.get("production_model", "")
    if prod_model:
        lines.append(f"  Production Model: {prod_model}")

    # Capability summary — Fix 1: machine_capacity special case
    enforcement_matrix = _get_enforcement_matrix(state)
    no_overlap_enforced = any(
        r.get("constraint") == "machine_capacity_no_overlap" and r.get("enforced")
        for r in enforcement_matrix
    )
    detected = [label for key, label in _DNA_LABELS.items() if dna.get(key)]
    not_found_raw = [key for key, label in _DNA_LABELS.items() if not dna.get(key)]
    not_found_labels = []
    for key in not_found_raw:
        if key == "has_machine_capacity" and no_overlap_enforced:
            continue  # will be mentioned separately below
        not_found_labels.append(_DNA_LABELS[key])
    if detected:
        lines.append(f"  Detected       : {', '.join(detected)}")
    if not_found_labels:
        lines.append(f"  Not found      : {', '.join(not_found_labels[:6])}{'...' if len(not_found_labels) > 6 else ''}")
    if not dna.get("has_machine_capacity") and no_overlap_enforced:
        lines.append(
            "  Machine Capacity: Explicit capacity field not found, but machine "
            "no-overlap is enforced using default capacity=1 assumptions."
        )

    # Missing for basic scheduling
    missing_basic = dna_report.get("missing_for_basic_scheduling") or []
    if missing_basic:
        lines.append(f"  MISSING (basic): {', '.join(missing_basic)}")

    lines.append("")
    return lines


def _section_enforced_constraints(state: dict) -> list[str]:
    """Section 3: Verified and Enforced Constraints."""
    matrix = _get_enforcement_matrix(state)
    if not matrix:
        return []

    enforced = [r["constraint"] for r in matrix if r.get("enforced") and r.get("detected")]
    if not enforced:
        return [
            "VERIFIED AND ENFORCED CONSTRAINTS",
            "  No constraints passed full verification for this run.",
            "",
        ]

    lines = ["VERIFIED AND ENFORCED CONSTRAINTS"]
    lines.append("  Only verified constraints are sent to CP-SAT as hard rules:")
    for name in enforced:
        lines.append(f"  - {name}")
    lines.append("")
    return lines


def _section_partial_unsupported(state: dict) -> list[str]:
    """Section 4: Detected but Partial / Not Enforced Constraints."""
    matrix = _get_enforcement_matrix(state)
    partial = _get_partial_constraints(state)
    unsupported = _get_unsupported_constraints(state)

    if not matrix and not partial and not unsupported:
        return []

    # Collect from matrix
    not_enforced_rows = [
        r for r in matrix
        if r.get("detected") and not r.get("enforced")
    ]

    if not not_enforced_rows and not partial and not unsupported:
        return []

    lines = ["DETECTED BUT NOT FULLY ENFORCED"]
    lines.append("  These constraints were discovered in the dataset but are NOT sent to CP-SAT:")

    seen = set()
    for r in not_enforced_rows:
        name = r.get("constraint", "")
        if name in seen:
            continue
        seen.add(name)
        status = r.get("status", "")
        reason = r.get("reason", "")
        reason_short = reason[:120] if reason else "See debug file for details."
        status_label = {
            "detected_not_enforced": "Detected — not enforced",
            "detected_partial":      "Detected — partial support",
            "needs_user_review":     "Needs user review",
            "unsupported":           "Unsupported",
        }.get(status, status)
        lines.append(f"  - {name}: [{status_label}] {reason_short}")

    # Also add any from partial/unsupported lists not covered above
    all_names_above = seen
    for c in partial + unsupported:
        name = c.get("constraint_type", "")
        if name and name not in all_names_above:
            all_names_above.add(name)
            reason = c.get("verification_reason", "")[:100] or "See enforcement matrix."
            lines.append(f"  - {name}: {reason}")

    lines.append("")
    return lines


def _section_constraint_packs(state: dict) -> list[str]:
    """Section 5: Evidence-Based Constraint Pack Findings."""
    activated_packs = _get_activated_packs(state)
    pack_candidates = _get_pack_candidates(state)

    if not activated_packs and not pack_candidates:
        return []

    active = [p for p in activated_packs if p.get("activated")]
    inactive = [p for p in activated_packs if not p.get("activated")]

    lines = ["EVIDENCE-BASED CONSTRAINT PACK FINDINGS"]
    lines.append(
        "  These are not domain labels. Constraint packs activate ONLY when "
        "matching evidence appears in the workbook."
    )

    if active:
        lines.append("  Activated constraint packs:")
        for p in active:
            reason = str(p.get("reason", ""))[:100]
            n = p.get("num_candidates", 0)
            lines.append(f"  - {p.get('pack_name','?')}: {reason} ({n} candidate(s))")
    else:
        lines.append("  No domain-specific pack had strong evidence in this dataset.")
        lines.append("  Core manufacturing constraints only (no domain pack activated).")

    if inactive:
        inactive_names = [p.get("pack_name", "?") for p in inactive]
        lines.append(f"  Packs with no evidence: {', '.join(inactive_names)}")

    lines.append("")
    return lines


# ---------------------------------------------------------------------------
# Deterministic insight generator — complete Phase 5 rewrite
# ---------------------------------------------------------------------------

def generate_deterministic_insight(state: dict) -> str:
    """
    Build a structured, honest schedule analysis report from state.
    No LLM required. Phase 5: includes manufacturing intelligence sections.
    """
    info = _safe_dict(state.get("info_summary"))
    cost = _safe_dict(state.get("cost_summary"))
    machine_util = _safe_list(state.get("machine_utilization"))
    bottlenecks = _safe_list(state.get("bottlenecks"))
    late_orders = _safe_list(state.get("late_orders"))
    unscheduled = _safe_list(state.get("unscheduled_orders"))
    warnings = _safe_list(state.get("warnings"))
    errors = _safe_list(state.get("errors"))

    current_date = _get_current_date(state)
    solver_status = state.get("solver_status") or info.get("solver_status") or "UNKNOWN"
    status_expl = _SOLVER_STATUS_EXPLANATION.get(solver_status, "Unknown solver status.")

    num_jobs = info.get("num_scheduled_jobs", 0) or info.get("total_jobs", 0)
    num_ops = info.get("num_operations_scheduled", 0) or info.get("scheduled_operations", 0)
    num_late = cost.get("num_late_orders", len(late_orders))
    num_unsched = cost.get("num_unscheduled", len(unscheduled))

    lines: list[str] = [
        "=" * 60,
        "  PRODUCTION SCHEDULE ANALYSIS",
        "=" * 60,
        "",
        # Section 1: Solver Status (precise wording)
        "1. SOLVER STATUS",
        f"  Status        : {solver_status}",
        f"  Explanation   : {status_expl}",
        f"  Planning Date : {current_date}",
        "",
    ]

    # Section 2: Manufacturing Understanding
    lines += _section_manufacturing_understanding(state)

    # Section 3: Enforced Constraints
    lines += _section_enforced_constraints(state)

    # Section 4: Partial / Not Enforced
    lines += _section_partial_unsupported(state)

    # Section 5: Constraint Packs
    lines += _section_constraint_packs(state)

    # Section 6: Schedule Summary
    lines += [
        "6. SCHEDULE SUMMARY",
        f"  Jobs Scheduled        : {num_jobs}",
        f"  Operations Scheduled  : {num_ops}",
        f"  Late Orders           : {num_late}",
        f"  Unscheduled Orders    : {num_unsched}",
        "",
    ]

    # Section 7: Bottlenecks / Utilization
    if bottlenecks:
        lines += [
            "7. BOTTLENECK MACHINES (≥80% utilization)",
            _summarize_bottlenecks(machine_util, bottlenecks),
            "",
        ]
    else:
        lines += [
            "7. MACHINE UTILIZATION (TOP 5)",
            _summarize_bottlenecks(machine_util, [], limit=5),
            "",
        ]

    # Section 8: Late / Unscheduled Orders
    lines += ["8. LATE ORDERS", _summarize_late_orders(late_orders), ""]
    if unscheduled:
        lines += [
            "   UNSCHEDULED ORDERS",
            *[f"  - {u.get('job_id','?')}: {u.get('reason','unknown reason')}" for u in unscheduled[:5]],
            "",
        ]

    # Section 9: Cost / Objective Summary
    lines += [
        "9. COST / OBJECTIVE SUMMARY",
        "   (Solver Objective Score is the CP-SAT objective — not necessarily full business cost.)",
        _summarize_costs(cost),
        "",
    ]

    # Section 10: Recommended Next Improvements
    recs: list[str] = []

    # From partial/unsupported constraints
    not_enforced = [
        r.get("constraint", "") for r in _get_enforcement_matrix(state)
        if r.get("detected") and not r.get("enforced")
    ]
    if "material_inventory" in not_enforced or "material_time_phased_inventory" in not_enforced:
        recs.append("Add solver support for time-phased material inventory (BOM + Inventory detected).")
    if any("shelf" in n or "freshness" in n or "expiry" in n for n in not_enforced):
        recs.append("Add shelf-life / freshness window enforcement to the solver.")
    if any("labor" in n or "overtime" in n for n in not_enforced):
        recs.append("Add labor shift / overtime capacity modeling if needed.")

    # From schedule analysis
    if num_late > 0:
        recs.append(
            f"Review due dates for {num_late} late order(s). Consider relaxing constraints or adding capacity."
        )
    if bottlenecks:
        names = [b.get("machine_id", "?") for b in bottlenecks[:3]]
        recs.append(f"Bottleneck machine(s) {', '.join(names)} are above 80% utilization — add parallel capacity.")
    if num_unsched > 0:
        recs.append(f"{num_unsched} order(s) could not be scheduled. Verify routing, capacity, and horizon.")

    if not recs:
        recs.append("Schedule looks healthy — no immediate corrective actions identified.")

    lines += ["10. RECOMMENDED NEXT IMPROVEMENTS"]
    lines += [f"  {i + 1}. {r}" for i, r in enumerate(recs)]
    lines.append("")

    critical_warnings = [w for w in warnings if "error" in w.lower() or "missing" in w.lower() or "invalid" in w.lower()]
    if critical_warnings or errors:
        lines += ["WARNINGS / ERRORS"]
        for e in errors[:5]:
            lines.append(f"  [ERROR] {e}")
        for w in critical_warnings[:5]:
            lines.append(f"  [WARN]  {w}")
        lines.append("")

    lines.append("=" * 60)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Deterministic Q&A generator — Phase 5 additions
# ---------------------------------------------------------------------------

def generate_deterministic_qa(state: dict, question: str) -> str:
    """Answer common scheduling questions deterministically from state data."""
    info = _safe_dict(state.get("info_summary"))
    cost = _safe_dict(state.get("cost_summary"))
    late_orders = _safe_list(state.get("late_orders"))
    unscheduled = _safe_list(state.get("unscheduled_orders"))
    machine_util = _safe_list(state.get("machine_utilization"))
    bottlenecks = _safe_list(state.get("bottlenecks"))
    schedule_table = _safe_list(state.get("schedule_table"))
    mapping_report = _safe_dict(state.get("mapping_report"))
    solver_status = state.get("solver_status") or "UNKNOWN"

    q = question.lower().strip()

    # ---- LLM mapping / solver questions ----
    if _question_contains(q, ["did llm map", "llm map", "llm solve", "llm optim",
                               "llm control", "ai map", "ai decide", "ai select constraint",
                               "gpt map", "gpt solve", "does llm", "did ai map",
                               "llm generate", "ai generate"]):
        mapping_mode = _get_mapping_mode(state)
        return (
            "NO — LLM did not map this dataset, generate constraints, or solve the schedule.\n\n"
            "What actually happened:\n"
            "  1. TABLE ROLES: Detected by domain-free manufacturing structure discovery "
            "(column names, value patterns, row counts — no LLM).\n"
            "  2. COLUMN MAPPING: Detected by semantic token matching against canonical aliases "
            "(deterministic, no LLM).\n"
            "  3. CONSTRAINT GENERATION: Only verified constraints enter CP-SAT. "
            "They come from evidence in the data, not from LLM output.\n"
            "  4. CP-SAT SOLVER: OR-Tools CP-SAT — deterministic optimization, no LLM.\n"
            "  5. COST/PROFIT: Calculated from SKU pricing data + solver costs — no LLM.\n"
            f"  Mapping mode used: {mapping_mode or 'domain_free_mapping'}.\n\n"
            "LLM (if enabled) is ONLY used to polish wording in explanations/Q&A. "
            "It cannot change numbers, constraints, or schedule results."
        )

    # ---- Why values change / FEASIBLE variability ----
    if _question_contains(q, ["why did values change", "why objective changed", "why profit changed",
                               "why late orders changed", "why different result", "every run",
                               "changes every", "different every", "why change", "result different",
                               "objective value change", "value change", "objective change",
                               "is cp-sat deterministic", "cp-sat deterministic",
                               "deterministic", "reproducible", "why vary"]):
        info = _safe_dict(state.get("info_summary"))
        solver_status = state.get("solver_status") or "UNKNOWN"
        mapping_report = _safe_dict(state.get("mapping_report"))
        solver_dbg = _safe_dict(state.get("solver_debug"))
        cfg = _safe_dict(solver_dbg.get("solve_config"))
        seed = cfg.get("random_seed", "unknown")
        workers = cfg.get("num_search_workers", "unknown")
        det_mode = cfg.get("deterministic_mode", False)

        lines = [
            "WHY RESULTS MAY VARY BETWEEN RUNS",
            "",
            "1. LLM DID NOT CHANGE ANYTHING.",
            "   Mapping, constraints, solving, and cost calculation are all deterministic code.",
            "   LLM is only used for wording polish if enabled.",
            "",
            f"2. SOLVER STATUS IS: {solver_status}",
            "   FEASIBLE means CP-SAT found a VALID schedule within the time limit,",
            "   but global optimality was NOT proven. A better schedule may exist.",
            "   OPTIMAL means CP-SAT proved the result is the best possible under enforced constraints.",
            "",
            "3. WHY VALUES DIFFER BETWEEN RUNS:",
            "   - If status was FEASIBLE, CP-SAT stops at the time limit with whatever solution it found.",
            "   - Different runs may find different feasible solutions depending on:",
            "     · random_seed (controls search order)",
            "     · num_search_workers (parallel workers introduce non-determinism)",
            "     · solver version, machine load, time limit",
            "",
            "4. CURRENT SOLVER CONFIG:",
            f"   random_seed = {seed}",
            f"   num_search_workers = {workers}",
            f"   deterministic_mode = {det_mode}",
            "   With deterministic_mode=True (seed=42, workers=1), same input → same result.",
            "",
            "5. REVENUE/PROFIT STABILITY:",
            "   Estimated Revenue and Production Cost are stable (they come from SKU prices × quantities).",
            "   Solver costs (machine, setup, tardiness) may vary between FEASIBLE runs.",
            "   Profit = Revenue − Production Cost − Solver Costs, so profit varies too.",
        ]
        return "\n".join(lines)

    # ---- Debug / proof questions — checked FIRST to avoid "constraint" catch ----
    if _question_contains(q, ["debug file", "debug files", "which file", "which debug",
                               "proof", "prove", "how do i know", "solver input", "json file",
                               "verify this"]):
        debug_dir = state.get("debug_dir", "outputs/debug/<run_id>")
        return (
            "DEBUG FILES THAT PROVE SOLVER BOUNDARY\n"
            f"  Debug directory: {debug_dir}\n"
            "  Key files:\n"
            "  - 10_constraint_enforcement_matrix.json : detected vs enforced status\n"
            "  - 11_verified_constraints.json          : what passed verification\n"
            "  - 12_compiled_verified_constraints.json : what became solver rules\n"
            "  - 13_legacy_constraint_mapping.json     : legacy rules (metadata only)\n"
            "  - 14_final_constraint_rules.json        : final verified-only rule set\n"
            "  - 11_solver_input_payload.json          : exact CP-SAT input\n"
            "  - 09_payload_validation.json            : pre-solve validation\n"
            "  - 13_post_solve_validation.json         : post-solve checks\n"
            "\n  The 'final_constraint_rules.json' has:\n"
            "    final_constraints_source.solver_rule_source = 'verified_constraints_only'\n"
            "    final_constraints_source.legacy_rules_used_for_solver = false\n"
            "  This proves legacy/YAML rules did not enter CP-SAT."
        )

    # ---- Legacy / YAML / constraint source — checked BEFORE generic "constraint" catch ----
    if _question_contains(q, ["legacy rule", "yaml rule", "did yaml", "did legacy",
                               "profile enter", "legacy enter", "legacy fallback", "constraint source",
                               "which source", "bakery profile", "cosmetics profile",
                               "verified only", "verified constraint", "how were constraints",
                               "domain profile rule"]):
        mr = _safe_dict(state.get("mapping_report"))
        final_src = (
            _safe_dict(state.get("final_constraint_rules", {}).get("final_constraints_source"))
            or _safe_dict(mr.get("final_constraint_rules", {}).get("final_constraints_source"))
            or {}
        )
        solver_rule_source = final_src.get("solver_rule_source", "verified_constraints_only")
        legacy_used = final_src.get("legacy_rules_used_for_solver", False)
        legacy_count = final_src.get("legacy_rules_count", "unknown")
        verified_count = final_src.get("compiled_verified_rules_count", "unknown")
        mapping_mode = _get_mapping_mode(state)
        lines = [
            "CONSTRAINT SOURCE TRANSPARENCY",
            f"  Mapping mode          : {mapping_mode or 'unknown'}",
            f"  Solver rule source    : {solver_rule_source}",
            f"  Legacy rules entered CP-SAT : {str(legacy_used).upper()}",
        ]
        if not legacy_used:
            lines.append("  RESULT: Legacy/YAML/domain-profile rules did NOT enter CP-SAT directly.")
            lines.append("  Legacy rules are preserved as metadata for debugging only.")
        lines.append(f"  Legacy rules detected : {legacy_count}")
        lines.append(f"  Verified rules used   : {verified_count}")
        lines.append(
            "\n  Only verified constraints entered CP-SAT. "
            "Others are documented as partial/unsupported in the enforcement matrix."
        )
        return "\n".join(lines)

    # ---- Revenue / profit / cost detail — checked BEFORE narrow cost catch ----
    if _question_contains(q, ["revenue", "production cost", "unit cost", "selling price",
                               "financial", "what is profit", "what is the profit",
                               "estimated profit", "estimated revenue", "profit",
                               "cost summary", "cost breakdown"]):
        revenue = float(cost.get("estimated_revenue") or 0)
        prod_cost = float(cost.get("estimated_production_cost") or 0)
        total_cost = float(cost.get("total_business_cost") or cost.get("total_cost") or 0)
        profit = cost.get("estimated_profit")
        tard_cost = float(cost.get("total_tardiness_cost") or 0)
        machine_cost = float(cost.get("total_machine_cost") or 0)
        setup_cost = float(cost.get("total_setup_cleaning_cost") or 0)
        is_partial = total_cost > 0 and (revenue == 0 or prod_cost == 0)

        lines = ["COST / PROFIT SUMMARY"]
        if is_partial:
            lines.append(
                "  WARNING: Profit estimate is PARTIAL. Revenue or unit production cost "
                "is missing/zero. Do not treat this as final financial profit."
            )
        lines.append(f"  Estimated Revenue       : {_format_money(revenue)}")
        lines.append(f"  Estimated Prod. Cost    : {_format_money(prod_cost)}")
        lines.append(f"  Total Machine Cost      : {_format_money(machine_cost)}")
        lines.append(f"  Total Tardiness Cost    : {_format_money(tard_cost)}")
        lines.append(f"  Total Setup/Clean Cost  : {_format_money(setup_cost)}")
        lines.append(f"  Total Business Cost     : {_format_money(total_cost)}")
        if profit is not None:
            label = "  Est. Profit (PARTIAL)   :" if is_partial else "  Estimated Profit       :"
            lines.append(f"{label} {_format_money(profit)}")
        return "\n".join(lines)

    # ---- Machine utilization (add to bottleneck route below, or handle here) ----
    if _question_contains(q, ["machine utilization", "utilization", "resource load",
                               "how loaded", "machine load"]):
        if machine_util:
            top = sorted(machine_util, key=lambda m: m.get("utilization_pct", 0), reverse=True)[:5]
            lines = ["MACHINE UTILIZATION (TOP 5)"]
            for m in top:
                lines.append(f"  {m.get('machine_id', '?')}: {_format_pct(m.get('utilization_pct'))}")
            if bottlenecks:
                lines.append("\nBottleneck machines (≥80%):")
                for b in bottlenecks[:3]:
                    lines.append(f"  {b.get('machine_id','?')}: {_format_pct(b.get('utilization_pct'))}")
            return "\n".join(lines)
        return "No machine utilization data available in the current schedule result."

    # ---- What date was used? ----
    if _question_contains(q, ["current date", "planning date", "reference date", "reference time",
                               "what date", "which date", "date used"]):
        current_date = _get_current_date(state)
        return (
            f"The current planning date used was: {current_date}\n"
            "This is the time-zero reference for the schedule. All start/end times "
            "are calculated relative to this date."
        )

    # ---- Bottleneck machines ----
    if _question_contains(q, ["bottleneck", "busiest machine", "overloaded machine", "constrained machine"]):
        if not bottlenecks:
            if machine_util:
                top = sorted(machine_util, key=lambda m: m.get("utilization_pct", 0), reverse=True)[:3]
                lines = [f"  {m.get('machine_id')}: {_format_pct(m.get('utilization_pct'))}" for m in top]
                return "No machines exceeded 80% utilization. Top machines by load:\n" + "\n".join(lines)
            return "No machine utilization data is available in the current schedule."
        lines = [f"  {b.get('machine_id')}: {_format_pct(b.get('utilization_pct'))} utilization" for b in bottlenecks]
        return (
            "The following machines are bottlenecks (≥80% utilization):\n"
            + "\n".join(lines)
            + "\nConsider adding parallel capacity or redistributing workload."
        )

    # ---- Late orders ----
    if _question_contains(q, ["late order", "which order", "delayed", "overdue", "tardiness"]):
        if not late_orders:
            return "There are no late orders — all jobs completed on time."
        return (
            f"There are {len(late_orders)} late order(s):\n"
            + _summarize_late_orders(late_orders, limit=10)
        )

    # ---- Why is an order late (require "late" or "reason" to avoid false positives) ----
    if _question_contains(q, ["why", "late", "reason"]) and ("late" in q or "reason" in q):
        tokens = q.split()
        candidate_ids = [t for t in tokens if len(t) > 2 and not t.isspace()]
        matched: list[dict] = []
        for cid in candidate_ids:
            matched = _find_order_in_schedule(schedule_table, cid)
            if matched:
                break
        if matched:
            t = matched[0]
            tard = t.get("tardiness_minutes", 0)
            if tard > 0:
                return (
                    f"Order {t.get('job_id')} ended at {t.get('end','unknown')} "
                    f"but was due at {t.get('due_at','unknown')}, "
                    f"resulting in {tard} minutes of tardiness.\n"
                    "Common causes: machine contention, long earlier operations, or backlog due dates."
                )
        if late_orders:
            lo = late_orders[0]
            return (
                f"The most tardy order is {lo.get('job_id')} "
                f"({lo.get('tardiness_minutes',0)} min late). "
                "Lateness typically results from machine contention, insufficient capacity, "
                "setup/cleaning time, or a due date before the planning date."
            )
        return "No late orders found in the current schedule."

    # ---- Unscheduled orders ----
    if _question_contains(q, ["unscheduled", "not scheduled", "missing order", "cannot schedule"]):
        if not unscheduled:
            return "All orders in the input were successfully scheduled."
        lines = [f"  - {u.get('job_id')}: {u.get('reason','unknown reason')}" for u in unscheduled]
        return (
            f"{len(unscheduled)} order(s) could not be scheduled:\n"
            + "\n".join(lines)
            + "\nCommon causes: no eligible machine, missing routing, or conflicting hard constraints."
        )

    # ---- Phase 5: Material inventory enforcement ----
    if _question_contains(q, ["inventory", "material inventory", "is inventory", "stock"]):
        matrix = _get_enforcement_matrix(state)
        inv_row = next((r for r in matrix if "material_inventory" in r.get("constraint", "")), None)
        if inv_row:
            if inv_row.get("enforced"):
                return "Material inventory is enforced in this schedule."
            else:
                reason = inv_row.get("reason", "")
                return (
                    "Material inventory was detected in the dataset "
                    "(BOM + Inventory tables found), but the current solver does NOT fully enforce "
                    "time-phased material consumption.\n"
                    f"Reason: {reason}\n"
                    "This is a known limitation — the constraint is visible in the enforcement "
                    "matrix but is not sent to CP-SAT as a hard rule."
                )
        return (
            "Material inventory constraint was not detected in this run, "
            "or the enforcement matrix is not available. "
            "Check if BOM and Inventory tables were present in the input."
        )

    # ---- Phase 5: Shelf life / freshness enforcement ----
    if _question_contains(q, ["shelf life", "shelf_life", "freshness", "expiry", "best before",
                               "is shelf", "shelf enforced"]):
        matrix = _get_enforcement_matrix(state)
        shelf_row = next(
            (r for r in matrix if any(
                kw in r.get("constraint", "") for kw in ["shelf", "freshness", "expiry"]
            )), None
        )
        if shelf_row:
            if shelf_row.get("enforced"):
                return "Shelf life / freshness is enforced in this schedule."
            else:
                reason = shelf_row.get("reason", "")
                return (
                    "Shelf life / freshness was detected in the dataset, "
                    "but it is NOT fully enforced by the current solver.\n"
                    f"Reason: {reason}\n"
                    "This is a known limitation. The field is detected and visible "
                    "in the enforcement matrix but not modeled as a hard constraint."
                )
        return (
            "Shelf life / freshness was not detected in this run. "
            "Check if shelf_life_days or qa_release_hours are in the SKU_Master table."
        )

    # ---- Phase 5: Domain / YAML questions ----
    if _question_contains(q, ["what domain", "which domain", "domain detected", "domain guess",
                               "yaml", "need yaml", "requires yaml", "profile", "domain profile"]):
        mapping_mode = _get_mapping_mode(state)
        optional_domain = _get_optional_domain(state)
        domain_id = optional_domain.get("domain_profile_id", "Not available")
        domain_conf = float(optional_domain.get("confidence") or 0)

        mode_text = {
            "domain_free_mapping":    "domain-free (no YAML profiles required)",
            "mixed_mapping":          "mixed (domain-free + legacy fallback)",
            "legacy_fallback_mapping":"legacy fallback (YAML/alias-based)",
        }.get(mapping_mode, mapping_mode or "unknown")

        return (
            f"The mapping pipeline used: {mode_text}.\n\n"
            f"Optional domain guess: {domain_id} ({domain_conf:.0%} confidence).\n"
            "IMPORTANT: The domain guess is metadata only. Scheduling is based on discovered "
            "manufacturing structure and verified constraints — not on the domain label.\n\n"
            "The system does NOT require YAML domain profiles to work. "
            "It can discover manufacturing structure directly from workbook data. "
            "YAML profiles are optional fallback/metadata only."
        )

    # ---- Phase 5: Constraint packs ----
    if _question_contains(q, ["pack", "constraint pack", "bakery pack", "cosmetics pack",
                               "food pack", "which pack", "activated pack", "evidence pack"]):
        activated_packs = _get_activated_packs(state)
        if not activated_packs:
            return (
                "No constraint pack information is available for this run. "
                "This may be an older run or the packs produced no candidates."
            )
        active = [p for p in activated_packs if p.get("activated")]
        inactive = [p for p in activated_packs if not p.get("activated")]
        lines = [
            "Evidence-based constraint packs activate ONLY when matching evidence appears in the workbook.",
            "They do not activate from domain labels or YAML files.\n",
        ]
        if active:
            lines.append("Activated packs:")
            for p in active:
                lines.append(f"  - {p.get('pack_name','?')}: {str(p.get('reason',''))[:100]} ({p.get('num_candidates',0)} candidates)")
        else:
            lines.append("No domain-specific pack activated — core manufacturing constraints only.")
        if inactive:
            names = [p.get("pack_name","?") for p in inactive]
            lines.append(f"\nPacks with no matching evidence: {', '.join(names)}")
        return "\n".join(lines)

    # ---- Phase 5: Partial / not enforced question ----
    if _question_contains(q, ["partial", "not enforced", "what cannot", "what is partial",
                               "limitation", "what doesn't", "what does not enforce"]):
        matrix = _get_enforcement_matrix(state)
        not_enforced = [r for r in matrix if r.get("detected") and not r.get("enforced")]
        partial = _get_partial_constraints(state)
        unsupported = _get_unsupported_constraints(state)
        if not not_enforced and not partial and not unsupported:
            return "No partial or unsupported constraints were detected in this run."
        lines = ["Detected but NOT fully enforced by the current solver:"]
        seen = set()
        for r in not_enforced:
            n = r.get("constraint", "")
            if n in seen:
                continue
            seen.add(n)
            status = r.get("status", "")
            reason = r.get("reason", "")[:100]
            lines.append(f"  - {n} [{status}]: {reason}")
        return "\n".join(lines)

    # ---- Phase 5: Pipeline / smart question ----
    if _question_contains(q, ["smart", "how does it work", "how does this work", "what is discovered",
                               "how agent", "why agent", "domain free", "domain-free",
                               "how does this agent", "how does the agent", "how does it",
                               "how this works", "how the system"]):
        return (
            "The scheduling system works as follows:\n\n"
            "1. MANUFACTURING STRUCTURE DISCOVERY: Sheets and columns are detected "
            "from workbook data — no YAML domain profiles required.\n"
            "2. SEMANTIC COLUMN CLASSIFICATION: Raw column names are mapped to canonical "
            "names using token matching and value patterns.\n"
            "3. MANUFACTURING DNA DETECTION: The system identifies what scheduling features "
            "are available (demand, routing, machines, BOM, inventory, etc.).\n"
            "4. CONSTRAINT CANDIDATE DISCOVERY: Common manufacturing constraints are proposed "
            "as candidates based on what data exists.\n"
            "5. EVIDENCE-BASED CONSTRAINT PACKS: Domain-specific packs (bakery, cosmetics, etc.) "
            "activate ONLY when evidence appears in the data — not from domain labels.\n"
            "6. SOLVER CAPABILITY VERIFICATION: Only verified constraints are sent to CP-SAT. "
            "Unsupported/partial constraints are documented but not enforced.\n"
            "7. CP-SAT OPTIMIZATION: OR-Tools CP-SAT is the only optimizer. "
            "No heuristics, no fake defaults, no greedy fallback."
        )

    # ---- Phase 5: Constraints question (updated to use enforcement matrix) ----
    if _question_contains(q, ["constraint", "domain rule", "what rule", "which constraint",
                               "what constraint", "applied constraint", "enforced constraint"]):
        matrix = _get_enforcement_matrix(state)
        if matrix:
            enforced = [r["constraint"] for r in matrix if r.get("enforced")]
            not_enforced = [r["constraint"] for r in matrix if r.get("detected") and not r.get("enforced")]
            lines = []
            if enforced:
                lines.append(f"ENFORCED CONSTRAINTS ({len(enforced)} — sent to CP-SAT):")
                for name in enforced:
                    lines.append(f"  - {name}")
            if not_enforced:
                lines.append(f"\nDETECTED BUT NOT ENFORCED ({len(not_enforced)}):")
                for name in not_enforced:
                    lines.append(f"  - {name}")
            lines.append(
                "\nOnly verified constraints enter the CP-SAT model as hard rules. "
                "Unsupported constraints are visible in the enforcement matrix but do not affect the schedule."
            )
            return "\n".join(lines)

        # Fallback to legacy mapped_constraints
        mapped = _safe_list(mapping_report.get("mapped_constraints"))
        if mapped:
            lines = [
                f"  - {c.get('rule_id')} ({c.get('constraint_type')}, "
                f"source: {c.get('source')}, hard: {c.get('hard')})"
                for c in mapped[:10]
            ]
            result = f"{len(mapped)} constraint(s) were mapped and applied:\n" + "\n".join(lines)
            if len(mapped) > 10:
                result += f"\n  ... and {len(mapped) - 10} more."
            return result
        return (
            "No explicit constraint information is available in the enforcement matrix. "
            "Standard operation-sequencing and machine no-overlap constraints were applied."
        )

    # ---- Cost / why cost high (old narrow route — superseded by detailed route below) ----
    if _question_contains(q, ["expensive", "reduce cost", "high cost"]):
        total_tard = cost.get("total_tardiness_minutes", 0)
        obj = cost.get("objective_value")
        lines = [f"  Solver Objective Score: {_format_money(obj)}"]
        lines.append(f"  Total Tardiness:        {total_tard} min")
        if total_tard > 0:
            lines.append("The main objective driver is tardiness (late deliveries).")
        else:
            lines.append("No tardiness in this schedule.")
        return "COST / OBJECTIVE SUMMARY\n" + "\n".join(lines)

    # ---- What-if questions ----
    if _question_contains(q, ["what if", "what happens if", "change date", "change priority",
                               "if i change", "if we change", "different date", "different priority"]):
        return (
            "What-if analysis requires re-running the schedule with the modified inputs. "
            "Please update the input file and run the scheduling workflow again. "
            "I cannot predict outcomes without re-solving."
        )

    # ---- Can we reduce late orders ----
    if _question_contains(q, ["reduce late", "fewer late", "less late", "improve schedule",
                               "how to improve", "reduce tardiness"]):
        suggestions: list[str] = []
        if bottlenecks:
            names = [b.get("machine_id", "?") for b in bottlenecks[:2]]
            suggestions.append(f"Add capacity to bottleneck machine(s): {', '.join(names)}.")
        suggestions.append("Extend the planning horizon to give the solver more scheduling freedom.")
        suggestions.append("Review due dates — some may be unrealistically tight.")
        suggestions.append("Raise priority_weight for time-critical orders.")
        return "Suggestions to reduce late orders:\n" + "\n".join(f"  {i+1}. {s}" for i, s in enumerate(suggestions))

    # ---- Solver status / optimality ----
    if _question_contains(q, ["solver status", "solver result", "solve", "optimal", "feasible",
                               "infeasible", "is it optimal", "globally optimal", "proven optimal",
                               "better schedule"]):
        expl = _SOLVER_STATUS_EXPLANATION.get(solver_status, "Unknown.")
        optimality_note = ""
        if solver_status == "FEASIBLE":
            optimality_note = (
                "\nIMPORTANT: FEASIBLE does NOT mean globally optimal. "
                "CP-SAT found a valid schedule within the time limit, "
                "but a better schedule may exist."
            )
        elif solver_status == "OPTIMAL":
            optimality_note = (
                "\nOPTIMAL means globally optimal only for the modeled and enforced constraints. "
                "Unsupported/partial constraints are NOT included in the optimality proof."
            )
        return f"Solver status: {solver_status}\n{expl}{optimality_note}"

    return "I cannot determine that from the current schedule data."


# ---------------------------------------------------------------------------
# LLM refinement truthfulness guard (Phase 5)
# ---------------------------------------------------------------------------

def validate_refined_response(
    deterministic_text: str,
    refined_text: str,
    state: dict,
) -> tuple[bool, list[str]]:
    """
    Validate that the LLM-refined response has not altered factual truthfulness.

    Returns (is_valid, list_of_issues).
    If is_valid is False, use deterministic_text instead.
    """
    issues: list[str] = []
    solver_status = (state.get("solver_status") or "UNKNOWN").upper()
    refined_lower = refined_text.lower()

    # A. FEASIBLE must not claim globally optimal
    if solver_status == "FEASIBLE":
        bad_phrases = [
            "globally optimal",
            "optimal schedule proven",
            "proved optimal",
            "proven optimal",
            "global optimum",
        ]
        for phrase in bad_phrases:
            if phrase in refined_lower:
                issues.append(
                    f"Rejected: refined text claims '{phrase}' but solver was FEASIBLE, not OPTIMAL."
                )

    # B. If partial/unsupported constraints exist, response must acknowledge them
    partial = _get_partial_constraints(state)
    unsupported = _get_unsupported_constraints(state)
    if partial or unsupported:
        expected_phrases = ["partial", "not enforced", "not fully enforced", "unsupported", "detected but"]
        if not any(p in refined_lower for p in expected_phrases):
            issues.append(
                "Rejected: refined text removed all partial/unsupported constraint warnings."
            )

    # C. If deterministic text mentioned not-enforced, refined must not silently remove it
    det_lower = deterministic_text.lower()
    if "not enforced" in det_lower or "not fully enforced" in det_lower:
        if "not enforced" not in refined_lower and "not fully enforced" not in refined_lower:
            issues.append(
                "Rejected: refined text removed 'not enforced' warnings present in deterministic text."
            )

    # C2. LLM must not be claimed to have mapped, solved, or generated constraints
    llm_false_claims = [
        "llm mapped", "llm performed mapping", "llm solved", "llm generated constraints",
        "llm optimized", "ai mapped", "ai solved", "gpt mapped", "gpt solved",
        "llm selected constraints", "llm decided",
    ]
    for phrase in llm_false_claims:
        if phrase in refined_lower:
            issues.append(f"Rejected: refined falsely claims '{phrase}'.")

    # D. Domain guess must remain metadata, not be converted to source of truth
    bad_domain_phrases = [
        "domain selected therefore",
        "because domain is",
        "since domain is",
        "domain was selected, therefore",
        "domain profile was the source of truth",
        "yaml profile was the source of truth",
        "yaml controlled solver",
        "yaml controlled cp-sat",
        "domain profile controlled solver",
        "bakery profile controlled cp-sat",
        "cosmetics profile controlled cp-sat",
        "legacy rules were enforced",
        "legacy rules were sent to cp-sat",
        "yaml rules were sent to cp-sat",
    ]
    for phrase in bad_domain_phrases:
        if phrase in refined_lower:
            issues.append(
                f"Rejected: refined text violates truthfulness: '{phrase}'."
            )

    # E. If legacy_rules_used_for_solver is False, reject claims that legacy entered solver
    mr = _safe_dict(state.get("mapping_report"))
    final_src = (
        _safe_dict(state.get("final_constraint_rules", {}).get("final_constraints_source"))
        or _safe_dict(mr.get("final_constraint_rules", {}).get("final_constraints_source"))
        or {}
    )
    if final_src.get("legacy_rules_used_for_solver") is False:
        legacy_false_claims = [
            "legacy rules were enforced",
            "legacy fallback controlled",
            "yaml rules entered cp-sat",
            "domain profile rules entered cp-sat",
        ]
        for phrase in legacy_false_claims:
            if phrase in refined_lower:
                issues.append(
                    f"Rejected: legacy_rules_used_for_solver=False but refined claims '{phrase}'."
                )

    # F. Reject "all constraints enforced" when partial/unsupported exist
    if partial or unsupported:
        all_enforced_phrases = [
            "all constraints are enforced",
            "all detected constraints are enforced",
            "every constraint is modeled",
            "no unsupported constraints",
            "nothing unsupported",
            "no partial constraints",
        ]
        for phrase in all_enforced_phrases:
            if phrase in refined_lower:
                issues.append(
                    f"Rejected: refined claims '{phrase}' but partial/unsupported constraints exist."
                )

    # G. Number sanity — obvious contradictions only
    cost = _safe_dict(state.get("cost_summary"))
    num_late = int(cost.get("num_late_orders", len(_safe_list(state.get("late_orders")))))
    if num_late > 0 and "no late orders" in refined_lower:
        issues.append(f"Rejected: refined says 'no late orders' but num_late_orders={num_late}.")

    revenue = float(cost.get("estimated_revenue") or 0)
    if revenue > 0 and "zero revenue" in refined_lower:
        issues.append("Rejected: refined says 'zero revenue' but estimated_revenue > 0.")

    return len(issues) == 0, issues


# ---------------------------------------------------------------------------
# Optional LLM refinement (Claude 3.5 Sonnet via Capgemini Generative Engine)
# ---------------------------------------------------------------------------

def optional_llm_refine(prompt: str, fallback_text: str) -> str:
    """
    Polish text using Claude 3.5 Sonnet. Returns fallback_text if unavailable.
    Never changes factual numbers — only language quality.
    """
    try:
        import os
        from dotenv import load_dotenv
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        load_dotenv()
        llm = ChatOpenAI(
            model="us.anthropic.claude-3-5-sonnet-20240620-v1:0",
            base_url="https://openai.generative.engine.capgemini.com/v1",
            api_key=os.getenv("GENERATIVE_ENGINE_API_KEY"),
            timeout=30,
        )
        response = llm.invoke([HumanMessage(content=prompt)])
        refined = str(response.content).strip()
        return refined if refined else fallback_text
    except Exception:
        return fallback_text


def _build_compact_facts(state: dict) -> str:
    """Build a short fact block for LLM prompts — avoids passing raw tables."""
    info = _safe_dict(state.get("info_summary"))
    cost = _safe_dict(state.get("cost_summary"))
    bottlenecks = _safe_list(state.get("bottlenecks"))
    late_orders = _safe_list(state.get("late_orders"))
    solver_status = state.get("solver_status") or "UNKNOWN"
    current_date = _get_current_date(state)

    # Phase 5: include intelligence summary
    dna = _get_dna(state)
    mapping_mode = _get_mapping_mode(state)
    optional_domain = _get_optional_domain(state)
    matrix = _get_enforcement_matrix(state)

    n_enforced = sum(1 for r in matrix if r.get("enforced"))
    n_not_enforced = sum(1 for r in matrix if r.get("detected") and not r.get("enforced"))
    activated = [p.get("pack_name","?") for p in _get_activated_packs(state) if p.get("activated")]
    prod_model = dna.get("production_model", "unknown")

    bn_text = ", ".join(
        f"{b.get('machine_id')}({_format_pct(b.get('utilization_pct'))})"
        for b in bottlenecks[:3]
    ) or "none"
    late_text = ", ".join(
        f"{lo.get('job_id')}({lo.get('tardiness_minutes')}min)"
        for lo in late_orders[:3]
    ) or "none"

    domain_id = optional_domain.get("domain_profile_id", "none")
    domain_conf = float(optional_domain.get("confidence") or 0)

    return (
        f"planning_date={current_date} | solver_status={solver_status} | "
        f"mapping_mode={mapping_mode} | "
        f"optional_domain_guess={domain_id}({domain_conf:.0%},metadata_only) | "
        f"production_model={prod_model} | "
        f"jobs={info.get('num_scheduled_jobs',0)} | "
        f"ops={info.get('num_operations_scheduled',0)} | "
        f"late={cost.get('num_late_orders',0)} | "
        f"unscheduled={cost.get('num_unscheduled',0)} | "
        f"tardiness_min={cost.get('total_tardiness_minutes',0)} | "
        f"enforced_constraints={n_enforced} | "
        f"not_enforced_constraints={n_not_enforced} | "
        f"activated_packs=[{','.join(activated)}] | "
        f"bottlenecks=[{bn_text}] | late_orders=[{late_text}]"
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def insight_qa_agent(state: dict) -> dict:
    """
    Generate initial business explanation after a successful CP-SAT solve.
    Writes state["final_response"]. Does not mutate schedule data.
    LLM refinement is optional and validated; falls back to deterministic output if unavailable.
    """
    base_text = generate_deterministic_insight(state)
    solver_status = (state.get("solver_status") or "UNKNOWN").upper()

    facts = _build_compact_facts(state)
    partial = _get_partial_constraints(state)
    unsupported = _get_unsupported_constraints(state)
    partial_note = ""
    if partial or unsupported:
        n = len(partial) + len(unsupported)
        partial_note = (
            f"IMPORTANT: {n} constraint(s) were detected but are NOT enforced by the solver. "
            "You MUST mention them and MUST NOT claim they are enforced. "
        )
    feasible_note = ""
    if solver_status == "FEASIBLE":
        feasible_note = (
            "IMPORTANT: The solver returned FEASIBLE, NOT OPTIMAL. "
            "Do NOT say 'globally optimal', 'proved optimal', or 'optimal schedule proven'. "
        )

    llm_prompt = (
        "You are a production scheduling assistant. "
        "Refine the draft report below into polished business language. "
        "Keep ALL numbers exactly as given — do not invent or change any facts. "
        f"{feasible_note}"
        f"{partial_note}"
        "Keep ALL warnings about partial or not-enforced constraints. "
        "Do NOT treat the optional domain guess as the source of constraints. "
        f"\n\nFACTS: {facts}"
        f"\n\nDRAFT:\n{base_text}"
        "\n\nRefined report (keep structure, improve readability):"
    )
    refined = optional_llm_refine(llm_prompt, base_text)

    # Phase 5: Validate before using
    is_valid, issues = validate_refined_response(base_text, refined, state)
    if is_valid:
        final_response = refined
    else:
        issue_summary = "; ".join(issues)
        final_response = (
            base_text
            + f"\n\n[Note: LLM refinement was not used because: {issue_summary}]"
        )

    return {**state, "final_response": final_response}


def qa_agent(state: dict) -> dict:
    """
    Answer a follow-up question using existing schedule state.
    Writes state["qa_response"]. Never reruns the solver.
    LLM refinement is optional and validated; falls back to deterministic output if unavailable.
    """
    question: str = str(state.get("user_followup_query") or "").strip()

    if not question:
        return {**state, "qa_response": "No question was provided."}

    base_answer = generate_deterministic_qa(state, question)

    facts = _build_compact_facts(state)
    solver_status = (state.get("solver_status") or "UNKNOWN").upper()
    feasible_note = ""
    if solver_status == "FEASIBLE":
        feasible_note = "IMPORTANT: solver was FEASIBLE not OPTIMAL — do not say globally optimal. "

    llm_prompt = (
        "You are a production scheduling assistant. "
        "Answer the question below using only the provided facts. "
        "Do not invent information or recompute the schedule. "
        f"{feasible_note}"
        "Do not hide warnings about partial or not-enforced constraints. "
        f"\n\nQUESTION: {question}"
        f"\n\nFACTS: {facts}"
        f"\n\nDRAFT ANSWER:\n{base_answer}"
        "\n\nRefined answer (clear, concise, factual):"
    )
    refined_answer = optional_llm_refine(llm_prompt, base_answer)

    # Full truthfulness guard — same validator as insight_qa_agent
    is_valid_qa, qa_issues = validate_refined_response(base_answer, refined_answer, state)
    if is_valid_qa:
        qa_response = refined_answer
    else:
        issue_summary = "; ".join(qa_issues)
        qa_response = (
            base_answer
            + f"\n\n[Note: LLM refinement was not used because it failed truthfulness checks: {issue_summary}]"
        )

    return {**state, "qa_response": qa_response}