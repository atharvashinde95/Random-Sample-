"""
Smart Constraint Mapping Agent — Phase 3 (Domain-Free First + Legacy Fallback).

New flow:
  1.  read_workbook
  2.  optional legacy domain detection (graceful fallback)
  3.  discover_manufacturing_structure  [Phase 1]
  4.  merge with legacy sheet mapping
  5.  classify_columns_semantically     [Phase 1]
  6.  merge with legacy column mapping
  7.  normalize_tables
  8.  detect_manufacturing_dna           [Phase 1]
  9.  discover_constraint_candidates     [Phase 1]
  10. run_constraint_packs               [Phase 2]
  11. merge & deduplicate candidates
  12. verify_constraint_candidates       [Phase 2]
  13. compile_verified_constraints       [Phase 2]
  14. map_constraints (legacy, for compat)
  15. merge_final_constraint_rules
  16. build_canonical_payload
  17. assemble mapping_report + state + debug files
"""
from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# Legacy tool imports (kept for backward compatibility)
# ---------------------------------------------------------------------------
from tools.workbook_reader_tool import read_workbook
from tools.unit_normalization_tool import aggregate_warnings, normalize_tables
from tools.schema_detection_tool import detect_sheet_mapping
from tools.column_mapping_tool import detect_column_mapping
from tools.constraint_mapping_tool import map_constraints
from tools.canonical_payload_builder_tool import build_canonical_payload

# ---------------------------------------------------------------------------
# Phase 1 tool imports
# ---------------------------------------------------------------------------
from tools.manufacturing_structure_discovery_tool import discover_manufacturing_structure
from tools.semantic_column_classifier_tool import classify_columns_semantically
from tools.manufacturing_dna_tool import detect_manufacturing_dna
from tools.constraint_candidate_discovery_tool import discover_constraint_candidates

# ---------------------------------------------------------------------------
# Phase 2 tool imports
# ---------------------------------------------------------------------------
from tools.constraint_pack_runner_tool import run_constraint_packs, build_evidence_corpus
from tools.solver_capability_verifier_tool import (
    verify_constraint_candidates,
    compile_verified_constraints,
)

# ---------------------------------------------------------------------------
# Debug / audit imports
# ---------------------------------------------------------------------------
from config.logging_config import get_logger
from utils.debug_audit import (
    make_run_id,
    make_debug_dir,
    write_debug_json,
    json_safe,
    summarize_workbook_profile,
    summarize_normalized_tables,
    summarize_canonical_payload,
)

_log = get_logger("production_scheduler.mapping")
_log_audit = get_logger("production_scheduler.audit")

# ── Terminal display helpers ─────────────────────────────────────────────────
_DIV  = "─" * 60          # section divider
_TICK = "✓"               # enforced / domain-free / ok
_CROSS= "✗"               # not enforced / failed
_WAVE = "~"               # partial / ambiguous
_STAR = "★"               # fallback used — calls attention


def _hdr(title: str) -> str:
    """Return a titled section divider for terminal logs."""
    return f"{_DIV}\n  {title}"


# ---------------------------------------------------------------------------
# SKU pricing patch — fallback when normalized SKU_Master has no financial data
# ---------------------------------------------------------------------------

def _patch_job_pricing(
    canonical_payload: dict,
    file_path: str,
    sheet_mapping: dict,
    col_mapping: dict,
    warnings: list,
) -> dict:
    """
    Defensive pricing recovery layer.

    Reads selling_price_per_unit and unit_production_cost directly from the
    workbook for any job whose price or cost is still 0.  Does NOT overwrite
    valid non-zero values and does NOT touch qa_release_hours, qa_release_minutes,
    or any constraint-related column.

    Returns a diagnostics dict:
        sheets_considered, sku_rows_read, jobs_total, jobs_patched,
        jobs_missing_price, jobs_missing_cost, unmatched_product_ids
    """
    import math
    import pandas as pd

    raw_col_map: dict[str, dict] = col_mapping.get("column_mapping", col_mapping)
    sku_sheets = [raw for raw, role in sheet_mapping.items() if role == "SKU_Master"]

    diag: dict = {
        "sheets_considered": sku_sheets,
        "sku_rows_read": 0,
        "jobs_total": len(canonical_payload.get("jobs") or []),
        "jobs_patched": 0,
        "jobs_missing_price": 0,
        "jobs_missing_cost": 0,
        "unmatched_product_ids": [],
    }

    if not sku_sheets:
        warnings.append("SKU pricing patch: no sheets mapped to SKU_Master role.")
        return diag

    def _sf(v: Any) -> float:
        try:
            f = float(v)
            return 0.0 if (math.isnan(f) or math.isinf(f)) else f
        except Exception:
            return 0.0

    # Build pricing lookup from all candidate SKU sheets
    sku_price_map: dict[str, dict] = {}
    for sheet_name in sku_sheets:
        col_map_for_sheet = raw_col_map.get(sheet_name, {})
        try:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
        except Exception as exc:
            warnings.append(f"SKU pricing patch: could not read sheet '{sheet_name}': {exc}")
            continue

        rename = {rc: canon for rc, canon in col_map_for_sheet.items() if rc in df.columns}
        df = df.rename(columns=rename)
        if "product_id" not in df.columns:
            continue

        rows_before = len(sku_price_map)
        for _, row in df.iterrows():
            pid = row.get("product_id")
            if pid is None:
                continue
            pid_str = str(pid).strip()
            if not pid_str or pid_str.lower() in ("nan", "none", "null"):
                continue
            price = _sf(
                row.get("selling_price_per_unit")
                or row.get("selling_price")
                or row.get("unit_price")
                or 0
            )
            cost = _sf(
                row.get("unit_production_cost")
                or row.get("unit_cost")
                or row.get("production_cost")
                or 0
            )
            # Only store if this is the first entry OR if it has real price data
            if pid_str not in sku_price_map or price > 0:
                sku_price_map[pid_str] = {
                    "selling_price_per_unit": price,
                    "unit_production_cost": cost,
                }
        diag["sku_rows_read"] += len(sku_price_map) - rows_before

    if not sku_price_map:
        warnings.append(
            "SKU pricing patch: no valid product_id rows found in candidate SKU sheets. "
            f"Sheets checked: {sku_sheets}"
        )
        return diag

    # Patch only jobs that are missing price or cost — never overwrite valid values
    patched = 0
    unmatched: list[str] = []
    for job in (canonical_payload.get("jobs") or []):
        pid = str(job.get("product_id") or "").strip()
        current_price = _sf(job.get("selling_price_per_unit"))
        current_cost = _sf(job.get("unit_production_cost"))
        needs_patch = (current_price == 0.0) or (current_cost == 0.0)
        if not needs_patch:
            continue
        pricing = sku_price_map.get(pid)
        if pricing is None:
            if pid not in unmatched:
                unmatched.append(pid)
            continue
        if current_price == 0.0:
            job["selling_price_per_unit"] = round(pricing["selling_price_per_unit"], 6)
        if current_cost == 0.0:
            job["unit_production_cost"] = round(pricing["unit_production_cost"], 6)
        patched += 1

    # Post-patch validation
    jobs_missing_price = sum(
        1 for j in (canonical_payload.get("jobs") or [])
        if _sf(j.get("selling_price_per_unit")) == 0.0
    )
    jobs_missing_cost = sum(
        1 for j in (canonical_payload.get("jobs") or [])
        if _sf(j.get("unit_production_cost")) == 0.0
    )

    diag.update({
        "jobs_patched": patched,
        "jobs_missing_price": jobs_missing_price,
        "jobs_missing_cost": jobs_missing_cost,
        "unmatched_product_ids": unmatched[:10],
    })

    # Emit structured warnings
    warnings.append(
        f"SKU pricing patch summary: sheets_checked={sku_sheets}, "
        f"sku_rows_in_map={len(sku_price_map)}, jobs_patched={patched}, "
        f"jobs_missing_price={jobs_missing_price}, jobs_missing_cost={jobs_missing_cost}"
    )
    if unmatched:
        warnings.append(
            f"SKU pricing patch: {len(unmatched)} job product_id(s) not found in SKU data "
            f"(first 10): {unmatched[:10]}"
        )
    if jobs_missing_price > 0 or jobs_missing_cost > 0:
        warnings.append(
            f"SKU pricing patch: {jobs_missing_price} job(s) still have selling_price=0; "
            f"{jobs_missing_cost} job(s) still have production_cost=0 after patching."
        )

    return diag


# ---------------------------------------------------------------------------
# Safe domain-detection fallback
# ---------------------------------------------------------------------------

_SAFE_DOMAIN_FALLBACK: dict[str, Any] = {
    "domain_profile_id": "generic_manufacturing.v1",
    "domain_name": "Generic Manufacturing",
    "confidence": 0.0,
    "profile": {},
    "reason": "Domain detection failed or skipped — using safe fallback.",
    "scores": {},
    "matched_keywords": {},
    "errors": [],
    "warnings": [],
}


# ---------------------------------------------------------------------------
# Core helpers
# ---------------------------------------------------------------------------

def _merge_messages(existing: list | None, new: list | None) -> list:
    base = list(existing) if existing else []
    if new:
        base.extend(new)
    return base


def _count_operations(payload: Any) -> int:
    try:
        from pydantic import BaseModel
        if isinstance(payload, BaseModel):
            payload = payload.model_dump()
    except ImportError:
        pass
    jobs = payload.get("jobs") or [] if isinstance(payload, dict) else []
    return sum(len(j.get("operations") or []) for j in jobs)


def _payload_counts(payload: Any) -> dict:
    try:
        from pydantic import BaseModel
        if isinstance(payload, BaseModel):
            payload = payload.model_dump()
    except ImportError:
        pass
    if not isinstance(payload, dict):
        return {}
    jobs = payload.get("jobs") or []
    ow = payload.get("objective_weights") or {}
    if hasattr(ow, "model_dump"):
        ow = ow.model_dump()
    return {
        "reference_time": str(payload.get("reference_time") or ""),
        "domain_profile_id": payload.get("domain_profile_id") or "",
        "jobs": len(jobs),
        "machines": len(payload.get("machines") or []),
        "operations": sum(len(j.get("operations") or []) for j in jobs),
        "calendars": len(payload.get("calendars") or []),
        "setup_rules": len(payload.get("setup_rules") or []),
        "cleaning_rules": len(payload.get("cleaning_rules") or []),
        "wait_rules": len(payload.get("wait_rules") or []),
        "quality_rules": len(payload.get("quality_rules") or []),
        "objective_weights": ow,
    }


# ---------------------------------------------------------------------------
# Logging helpers (kept from original agent)
# ---------------------------------------------------------------------------

def _log_sheet_mapping(sheet_mapping: dict, sheet_names: list) -> None:
    unmapped = [s for s in sheet_names if s not in sheet_mapping]
    lines = [
        "Sheet mapping result:",
        f"  Raw sheets: {len(sheet_names)}  Mapped: {len(sheet_mapping)}  Unmapped: {len(unmapped)}",
    ]
    for raw, canon in sheet_mapping.items():
        lines.append(f"  {raw} → {canon}")
    if unmapped:
        lines.append(f"  [unmapped: {', '.join(unmapped)}]")
    _log.info("\n".join(lines))


def _log_column_mapping(column_mapping: dict, col_map_result: dict, debug_file: str = "") -> None:
    lines = ["Column mapping result:"]
    total_all = sum(len(v) for v in column_mapping.values())
    printed = 0
    for sheet, col_map in column_mapping.items():
        if not col_map:
            continue
        lines.append(f"  {sheet} ({len(col_map)} mapped):")
        for raw_col, canon_col in col_map.items():
            if printed < 80:
                lines.append(f"    {raw_col} → {canon_col}")
                printed += 1
    if total_all > 80:
        lines.append(f"  ... {total_all - 80} more column mappings saved in debug file")
    _log.info("\n".join(lines))


def _log_payload_summary(counts: dict, debug_file: str = "") -> None:
    ow = counts.get("objective_weights") or {}
    ow_parts = [f"{k.replace('_weight', '')}={v}" for k, v in ow.items() if isinstance(v, (int, float))]
    ow_str = "  ".join(ow_parts) if ow_parts else "(defaults)"
    lines = [
        "Canonical payload built:",
        f"  reference_time: {counts.get('reference_time', 'N/A')}",
        f"  domain:         {counts.get('domain_profile_id', 'N/A')}",
        f"  jobs:           {counts.get('jobs', 0)}",
        f"  machines:       {counts.get('machines', 0)}",
        f"  operations:     {counts.get('operations', 0)}",
        f"  setup_rules:    {counts.get('setup_rules', 0)}",
        f"  cleaning_rules: {counts.get('cleaning_rules', 0)}",
        f"  wait_rules:     {counts.get('wait_rules', 0)}",
        f"  quality_rules:  {counts.get('quality_rules', 0)}",
        f"  objective_weights: {ow_str}",
    ]
    if debug_file:
        lines.append(f"  Full payload saved: {debug_file}")
    _log.info("\n".join(lines))


# ---------------------------------------------------------------------------
# Step 2: Safe legacy domain detection
# ---------------------------------------------------------------------------

def _safe_detect_domain(
    workbook_profile: dict,
    domain_hint: str | None,
    profile_dir: str = "profiles",
) -> dict:
    """
    YAML/domain profile detection is disabled.
    The agent discovers structure from data directly — no YAML profiles required.
    Returns generic fallback so downstream code has a valid domain_result object.
    """
    fallback = dict(_SAFE_DOMAIN_FALLBACK)
    fallback["warnings"] = [
        "YAML domain detection disabled. "
        "Manufacturing structure and constraints are discovered from data only."
    ]
    return fallback


# ---------------------------------------------------------------------------
# Step 4: Merge sheet mappings (domain-free primary, legacy fallback)
# ---------------------------------------------------------------------------

def _merge_sheet_mappings(
    domain_free_mapping: dict[str, str],
    domain_free_candidates: list[dict],
    legacy_mapping: dict[str, str],
) -> tuple[dict[str, str], dict[str, str], str]:
    """
    Merge domain-free and legacy sheet mappings.

    Returns (final_sheet_mapping, sheet_mapping_source, mapping_mode).
    Priority: domain-free >= 0.60 confidence > legacy.
    """
    # Build confidence lookup from domain-free candidates
    conf_by_sheet: dict[str, float] = {
        c["raw_sheet"]: c["confidence"]
        for c in domain_free_candidates
        if c.get("selected_role") and c.get("selected_role") != "Unknown"
    }

    final: dict[str, str] = {}
    source: dict[str, str] = {}

    # 1. Use domain-free mappings (confidence >= 0.60 already filtered by discover)
    for raw_sheet, canonical_role in domain_free_mapping.items():
        if canonical_role and canonical_role != "Unknown":
            final[raw_sheet] = canonical_role
            source[raw_sheet] = "domain_free"

    # 2. Fill missing roles from legacy — ONLY for sheets NOT seen by domain-free.
    # If domain-free explicitly evaluated a sheet and rejected it (low confidence /
    # unknown), we trust that judgment and do NOT override via legacy fallback.
    # This prevents e.g. INFO → SKU_Master false-positive substring matches.
    seen_by_domain_free: set[str] = {
        c["raw_sheet"] for c in domain_free_candidates if c.get("raw_sheet")
    }
    legacy_added = 0
    for raw_sheet, canonical_role in legacy_mapping.items():
        if raw_sheet not in final and raw_sheet not in seen_by_domain_free and canonical_role:
            final[raw_sheet] = canonical_role
            source[raw_sheet] = "legacy_fallback"
            legacy_added += 1

    # Determine mapping mode
    total = len(final)
    df_count = sum(1 for s in source.values() if s == "domain_free")
    if total == 0:
        mode = "legacy_fallback_mapping"
    elif df_count == 0:
        mode = "legacy_fallback_mapping"
    elif legacy_added == 0:
        mode = "domain_free_mapping"
    else:
        mode = "mixed_mapping"

    return final, source, mode


# ---------------------------------------------------------------------------
# Step 6: Merge column mappings (semantic primary, legacy fallback)
# ---------------------------------------------------------------------------

def _merge_column_mappings(
    semantic_mapping: dict[str, dict[str, str]],
    semantic_report: dict[str, dict[str, Any]],
    legacy_mapping: dict[str, dict[str, str]],
) -> tuple[dict[str, dict[str, str]], dict[str, str]]:
    """
    Merge semantic and legacy column mappings.
    Returns (final_column_mapping, column_mapping_source).
    """
    final: dict[str, dict[str, str]] = {}
    source: dict[str, str] = {}

    all_sheets = set(list(semantic_mapping.keys()) + list(legacy_mapping.keys()))

    for sheet in all_sheets:
        final[sheet] = {}
        sem_cols = semantic_mapping.get(sheet, {})
        leg_cols = legacy_mapping.get(sheet, {})

        # Semantic mapping — accept all (already filtered by confidence >= 0.60 in classifier)
        for raw_col, canon_col in sem_cols.items():
            if canon_col:
                final[sheet][raw_col] = canon_col
                source[f"{sheet}.{raw_col}"] = "semantic"

        # Legacy fallback for unmapped columns
        for raw_col, canon_col in leg_cols.items():
            if raw_col not in final[sheet] and canon_col:
                final[sheet][raw_col] = canon_col
                source[f"{sheet}.{raw_col}"] = "legacy_fallback"

    return final, source


# ---------------------------------------------------------------------------
# Step 11: Merge and deduplicate constraint candidates
# ---------------------------------------------------------------------------

def _merge_candidates(
    common: list[dict],
    pack: list[dict],
) -> list[dict]:
    """
    Merge common + pack candidates and deduplicate by:
    (constraint_type, source_pack, from_family, to_family, from_op, to_op).
    Keeps the candidate with the highest confidence.
    """
    seen: dict[tuple, dict] = {}
    for c in common + pack:
        key = (
            c.get("constraint_type", ""),
            c.get("source_pack", ""),
            (c.get("data") or {}).get("from_family", ""),
            (c.get("data") or {}).get("to_family", ""),
            (c.get("data") or {}).get("from_operation_family", ""),
            (c.get("data") or {}).get("to_operation_family", ""),
        )
        existing = seen.get(key)
        if existing is None:
            seen[key] = c
        elif c.get("confidence", 0) > existing.get("confidence", 0):
            # Merge evidence lists
            merged_ev = list({*existing.get("evidence", []), *c.get("evidence", [])})
            seen[key] = {**c, "evidence": merged_ev}
    return list(seen.values())


# ---------------------------------------------------------------------------
# Step 15: Merge final constraint rules
# ---------------------------------------------------------------------------

def _merge_constraint_rules(
    legacy_result: dict,
    compiled_verified: dict,
    verification_result: dict,
) -> dict:
    """
    Build final constraint rules for the CP-SAT solver.

    Safety rule (DETECTED ≠ ENFORCED):
      Solver-enforced rule lists come ONLY from compile_verified_constraints().
      Legacy map_constraints() output is preserved as metadata for debugging,
      UI reporting, and backward compatibility but NEVER enters solver rules.

    The canonical_payload_builder reads: setup_rules, cleaning_rules,
    wait_rules, quality_rules, batch_rules, shared_resources, constraints.
    All of these are populated solely from compiled_verified.
    """
    # ── Solver-enforced rules: verified-only ─────────────────────────────────
    verified_setup    = list(compiled_verified.get("setup_rules")    or [])
    verified_cleaning = list(compiled_verified.get("cleaning_rules") or [])
    verified_wait     = list(compiled_verified.get("wait_rules")     or [])
    verified_quality  = list(compiled_verified.get("quality_rules")  or [])
    verified_batch    = list(compiled_verified.get("batch_rules")    or [])
    verified_shared   = list(compiled_verified.get("shared_resources") or [])
    verified_generic  = list(compiled_verified.get("constraints")    or [])
    verified_mapped   = list(compiled_verified.get("mapped_constraints") or [])

    # ── Partial/unsupported: visible in reports, not enforced ─────────────────
    partial     = verification_result.get("partial_constraints")    or []
    unsupported = verification_result.get("unsupported_constraints") or []
    unresolved_meta = [
        {
            "rule_id": f"UNRESOLVED_{c.get('constraint_type', 'UNKNOWN')}",
            "constraint_type": c.get("constraint_type"),
            "source_pack": c.get("source_pack"),
            "status": c.get("status"),
            "reason": c.get("verification_reason", "Not enforced"),
            "confidence": c.get("confidence", 0.0),
        }
        for c in partial + unsupported
    ]
    # Legacy unsupported_rules are also exposed for the UI
    legacy_unsupported = list(legacy_result.get("unsupported_rules") or [])

    # ── Counts ────────────────────────────────────────────────────────────────
    legacy_rule_count = sum(
        len(legacy_result.get(k) or [])
        for k in ("setup_rules", "cleaning_rules", "wait_rules", "quality_rules",
                  "batch_rules", "shared_resources")
    )
    compiled_rule_count = (
        len(verified_setup) + len(verified_cleaning) +
        len(verified_wait) + len(verified_quality) +
        len(verified_batch) + len(verified_shared)
    )

    # ── Warnings ──────────────────────────────────────────────────────────────
    merged_warnings: list[str] = []
    merged_warnings.extend(compiled_verified.get("warnings") or [])
    merged_warnings.extend(verification_result.get("warnings") or [])
    if legacy_rule_count > 0:
        merged_warnings.append(
            f"Legacy constraint rules ({legacy_rule_count} rules across "
            "setup/cleaning/wait/quality/batch/shared) were detected but were NOT "
            "passed to CP-SAT. Only solver-verified constraints may be enforced. "
            "Legacy rules are preserved as 'legacy_rules_metadata' for debugging."
        )

    return {
        # ── Solver-enforced (verified-only) ───────────────────────────────────
        "setup_rules":    verified_setup,
        "cleaning_rules": verified_cleaning,
        "wait_rules":     verified_wait,
        "quality_rules":  verified_quality,
        "batch_rules":    verified_batch,
        "shared_resources": verified_shared,
        "constraints":    verified_generic,
        "mapped_constraints": verified_mapped,

        # ── Reporting / UI only (not sent to solver) ──────────────────────────
        "unsupported_rules": unresolved_meta + legacy_unsupported,
        "legacy_rules_metadata": {
            "setup_rules":       legacy_result.get("setup_rules", []),
            "cleaning_rules":    legacy_result.get("cleaning_rules", []),
            "wait_rules":        legacy_result.get("wait_rules", []),
            "quality_rules":     legacy_result.get("quality_rules", []),
            "batch_rules":       legacy_result.get("batch_rules", []),
            "shared_resources":  legacy_result.get("shared_resources", []),
            "mapped_constraints":legacy_result.get("mapped_constraints", []),
            "unsupported_rules": legacy_result.get("unsupported_rules", []),
            "errors":            legacy_result.get("errors", []),
            "warnings":          legacy_result.get("warnings", []),
        },

        # ── Enforcement matrix + errors ───────────────────────────────────────
        "constraint_enforcement_matrix": (
            verification_result.get("constraint_enforcement_matrix") or []
        ),
        "errors": (
            (compiled_verified.get("errors") or []) +
            (verification_result.get("errors") or [])
        ),
        "warnings": merged_warnings,

        # ── Honest source provenance ──────────────────────────────────────────
        "final_constraints_source": {
            "solver_rule_source":           "verified_constraints_only",
            "legacy_rules_used_for_solver": False,
            "legacy_rules_count":           legacy_rule_count,
            "compiled_verified_rules_count": compiled_rule_count,
            "partial_constraints_count":    len(partial),
            "unsupported_constraints_count": len(unsupported),
        },
    }


# ---------------------------------------------------------------------------
# Optional LLM placeholder (not required; pipeline works without it)
# ---------------------------------------------------------------------------

def optional_llm_mapping_review(mapping_report: dict, user_query: str | None = None) -> dict:
    return {"used": False, "notes": []}


# ---------------------------------------------------------------------------
# Main public API
# ---------------------------------------------------------------------------

def smart_constraint_mapping_agent(state: dict) -> dict:
    """
    Phase 3 domain-free mapping agent.

    Reads from state: file_path, current_date, reference_date, user_query, domain_hint
    Writes to state: all mapping + constraint intelligence fields
    """
    file_path: str | None = state.get("file_path")
    current_date: str = state.get("current_date") or ""
    reference_date: str | None = state.get("reference_date")
    domain_hint: str | None = state.get("domain_hint")

    errors: list[str] = _merge_messages(state.get("errors"), None)
    warnings: list[str] = _merge_messages(state.get("warnings"), None)

    if not file_path:
        errors.append("smart_constraint_mapping_agent: file_path is required.")
        return {**state, "errors": errors, "warnings": warnings}

    # -----------------------------------------------------------------------
    # Setup: run_id, debug_dir, debug_files
    # -----------------------------------------------------------------------
    run_id = make_run_id(file_path, current_date)
    debug_dir = make_debug_dir(run_id)
    debug_files: dict[str, str] = {}
    _log_audit.info("Debug audit dir: %s", debug_dir)
    state = {**state, "run_id": run_id, "debug_dir": debug_dir}

    # -----------------------------------------------------------------------
    # Step 1 — Read workbook
    # -----------------------------------------------------------------------
    workbook_result = read_workbook(file_path)
    errors = _merge_messages(errors, workbook_result.get("errors"))
    warnings = _merge_messages(warnings, workbook_result.get("warnings"))
    state = {**state, "raw_workbook_profile": workbook_result,
             "errors": errors, "warnings": warnings}

    sheet_names: list[str] = workbook_result.get("sheet_names") or []
    _log.info(
        "%s\n  file   : %s\n  sheets : %d  %s\n  errors : %d  warnings: %d",
        _hdr("STEP 1 — Read Workbook"),
        file_path,
        len(sheet_names), sheet_names,
        len(workbook_result.get("errors") or []),
        len(workbook_result.get("warnings") or []),
    )
    wb_summary = summarize_workbook_profile(workbook_result)
    debug_files["workbook_profile"] = write_debug_json(debug_dir, "01_workbook_profile.json", wb_summary)

    if workbook_result.get("errors"):
        return {**state, "debug_dir": debug_dir, "debug_files": debug_files}

    workbook_profile = workbook_result

    # -----------------------------------------------------------------------
    # Step 2 — Data-driven domain detection (no YAML required)
    # Reads product names, operation names, machine names, cleaning families
    # directly from workbook content to identify the manufacturing domain.
    # -----------------------------------------------------------------------
    from tools.data_driven_domain_detector import detect_domain_from_data

    dd_result = detect_domain_from_data(workbook_profile)
    domain_id    = dd_result["domain_id"]
    domain_label = dd_result["domain_label"]
    domain_conf  = dd_result["confidence"]
    dd_evidence  = dd_result.get("evidence", [])
    dd_all       = dd_result.get("all_scores", {})

    _domain_status = (
        f"{_TICK} Data-driven domain detected: {domain_id}  "
        f"({domain_label})  conf={domain_conf:.0%}"
    )
    _log.info(
        "%s\n  %s\n  evidence : %s\n  all scores : %s"
        "\n  NOTE: Domain label is metadata only — constraints come from data evidence.",
        _hdr("STEP 2 — Data-Driven Domain Detection"),
        _domain_status,
        "; ".join(dd_evidence[:4]),
        str({k: f"{v:.0%}" for k, v in sorted(dd_all.items(), key=lambda x: -x[1])[:4]}),
    )

    # Build a legacy_domain_result-compatible dict for downstream code
    legacy_domain_result = {
        **dict(_SAFE_DOMAIN_FALLBACK),
        "domain_profile_id": domain_id,
        "confidence": domain_conf,
        "reason": f"Data-driven detection: {'; '.join(dd_evidence[:3])}",
        "profile": {},       # no YAML profile — constraints from data only
        "domain_label": domain_label,
        "all_scores": dd_all,
        "method": "data_driven",
        "warnings": [],
        "errors": [],
    }

    debug_files["domain_detection"] = write_debug_json(
        debug_dir, "02_domain_detection.json", json_safe(legacy_domain_result)
    )

    state = {
        **state,
        "domain_profile_id": domain_id,
        "domain_confidence": domain_conf,
        "optional_domain_guess": json_safe(legacy_domain_result),
        "errors": errors,
        "warnings": warnings,
    }

    # -----------------------------------------------------------------------
    # Step 3 — Domain-free table role discovery
    # -----------------------------------------------------------------------
    try:
        structure_result = discover_manufacturing_structure(workbook_profile)
        errors = _merge_messages(errors, structure_result.get("errors"))
        warnings = _merge_messages(warnings, structure_result.get("warnings"))
        domain_free_sheet_mapping: dict[str, str] = structure_result.get("selected_sheet_mapping") or {}
        domain_free_candidates: list[dict] = structure_result.get("table_role_candidates") or []
    except Exception as exc:
        _log.warning("discover_manufacturing_structure failed: %s", exc)
        warnings.append(f"Domain-free table role discovery failed (non-critical): {exc}")
        structure_result = {"errors": [], "warnings": [str(exc)], "table_role_candidates": [],
                            "selected_sheet_mapping": {}, "unknown_sheets": []}
        domain_free_sheet_mapping = {}
        domain_free_candidates = []

    # Build per-sheet confidence lines for the log
    _conf_lookup = {c["raw_sheet"]: c for c in domain_free_candidates}
    _df_lines: list[str] = []
    for sheet, role in domain_free_sheet_mapping.items():
        cand = _conf_lookup.get(sheet, {})
        conf = cand.get("confidence", 0.0)
        conf_label = "HIGH" if conf >= 0.85 else ("MEDIUM" if conf >= 0.60 else "LOW")
        _df_lines.append(f"    {sheet:<28} →  {role:<22} [conf={conf:.0%}  {conf_label}]")
    for sheet in (structure_result.get("unknown_sheets") or []):
        _df_lines.append(f"    {sheet:<28} →  (unknown — too low confidence to map)")
    _log.info(
        "%s\n%s",
        _hdr("STEP 3 — Domain-Free Table Role Discovery"),
        "\n".join(_df_lines) if _df_lines else "    (no sheets mapped)",
    )
    debug_files["table_role_discovery"] = write_debug_json(
        debug_dir, "09_table_role_discovery.json", json_safe(structure_result)
    )

    # -----------------------------------------------------------------------
    # Step 4 — Legacy sheet mapping + merge
    # -----------------------------------------------------------------------
    legacy_profile = legacy_domain_result.get("profile") or {}
    try:
        legacy_sheet_result = detect_sheet_mapping(workbook_profile, legacy_profile)
        legacy_sheet_mapping: dict[str, str] = legacy_sheet_result.get("sheet_mapping") or {}
        errors = _merge_messages(errors, legacy_sheet_result.get("errors"))
        warnings = _merge_messages(warnings, legacy_sheet_result.get("warnings"))
    except Exception as exc:
        _log.warning("Legacy sheet mapping failed: %s", exc)
        warnings.append(f"Legacy sheet mapping failed (non-critical): {exc}")
        legacy_sheet_mapping = {}
        legacy_sheet_result = {"sheet_mapping": {}, "errors": [], "warnings": [str(exc)]}

    final_sheet_mapping, sheet_mapping_source, mapping_mode = _merge_sheet_mappings(
        domain_free_sheet_mapping, domain_free_candidates, legacy_sheet_mapping
    )

    if mapping_mode in ("mixed_mapping", "legacy_fallback_mapping"):
        warnings.append(
            f"Sheet mapping mode: {mapping_mode}. "
            "Some sheets used legacy fallback because domain-free confidence was low."
        )

    # Detailed merge log — show source per sheet
    _merge_lines: list[str] = []
    for sheet, role in final_sheet_mapping.items():
        src = sheet_mapping_source.get(sheet, "unknown")
        if src == "domain_free":
            _merge_lines.append(f"    {_TICK} {sheet:<28} →  {role:<22} [domain_free]")
        else:
            _merge_lines.append(f"    {_STAR} {sheet:<28} →  {role:<22} [*** LEGACY FALLBACK ***]")
    unmapped_sheets = [s for s in sheet_names if s not in final_sheet_mapping]
    for sheet in unmapped_sheets:
        _merge_lines.append(f"    {_CROSS} {sheet:<28} →  (unmapped)")

    _mode_label = {
        "domain_free_mapping":    f"{_TICK} domain_free_mapping  — all sheets mapped by domain-free intelligence",
        "mixed_mapping":          f"{_STAR} mixed_mapping        — some sheets fell back to legacy YAML/alias matching",
        "legacy_fallback_mapping":f"{_STAR}{_STAR} legacy_fallback_mapping — domain-free had low confidence; legacy handled it",
    }.get(mapping_mode, mapping_mode)

    _log.info(
        "%s\n  MODE : %s\n%s",
        _hdr("STEP 4 — Sheet Mapping Merge"),
        _mode_label,
        "\n".join(_merge_lines),
    )
    _log_sheet_mapping(final_sheet_mapping, sheet_names)
    debug_files["sheet_mapping"] = write_debug_json(
        debug_dir, "03_sheet_mapping.json",
        json_safe({
            "domain_free_mapping": domain_free_sheet_mapping,
            "legacy_mapping": legacy_sheet_mapping,
            "final_mapping": final_sheet_mapping,
            "mapping_mode": mapping_mode,
            "sheet_mapping_source": sheet_mapping_source,
        })
    )

    state = {
        **state,
        "sheet_mapping": final_sheet_mapping,
        "sheet_mapping_source": sheet_mapping_source,
        "mapping_mode": mapping_mode,
        "table_role_report": json_safe(structure_result),
        "errors": errors,
        "warnings": warnings,
    }

    if not final_sheet_mapping:
        errors.append(
            "smart_constraint_mapping_agent: No sheets could be mapped. "
            "Domain-free and legacy mapping both returned empty results."
        )
        return {**state, "errors": errors, "debug_dir": debug_dir, "debug_files": debug_files}

    # -----------------------------------------------------------------------
    # Step 5 — Semantic column classification
    # -----------------------------------------------------------------------
    try:
        semantic_result = classify_columns_semantically(workbook_profile, final_sheet_mapping)
        errors = _merge_messages(errors, semantic_result.get("errors"))
        warnings = _merge_messages(warnings, semantic_result.get("warnings"))
        semantic_col_mapping: dict[str, dict[str, str]] = semantic_result.get("column_mapping") or {}
        semantic_col_report: dict = semantic_result.get("column_mapping_report") or {}
    except Exception as exc:
        _log.warning("Semantic column classification failed: %s", exc)
        warnings.append(f"Semantic column classification failed (non-critical): {exc}")
        semantic_result = {"errors": [], "warnings": [str(exc)], "column_mapping": {},
                           "column_mapping_report": {}, "ambiguous_columns": []}
        semantic_col_mapping = {}
        semantic_col_report = {}

    # Log semantic classification per sheet
    _sem_lines: list[str] = []
    for sheet, col_map in semantic_col_mapping.items():
        if not col_map:
            continue
        _sem_lines.append(f"    {sheet}:")
        col_report_sheet = semantic_col_report.get(sheet, {})
        for raw_col, canon_col in col_map.items():
            conf = col_report_sheet.get(raw_col, {}).get("confidence", 0.0)
            _sem_lines.append(f"      {_TICK} {raw_col:<28} →  {canon_col:<28} [semantic  conf={conf:.0%}]")
    ambiguous = semantic_result.get("ambiguous_columns") or []
    for a in ambiguous[:10]:
        _sem_lines.append(
            f"      {_WAVE} {a.get('column','?'):<28} →  (ambiguous/unmapped  best={a.get('best_candidate','?')}  conf={a.get('confidence',0):.0%})"
        )
    if len(ambiguous) > 10:
        _sem_lines.append(f"      ... and {len(ambiguous) - 10} more ambiguous columns (see debug JSON)")
    _log.info(
        "%s\n%s",
        _hdr("STEP 5 — Semantic Column Classification"),
        "\n".join(_sem_lines) if _sem_lines else "    (no columns classified)",
    )
    debug_files["semantic_column_mapping"] = write_debug_json(
        debug_dir, "10_semantic_column_mapping.json", json_safe(semantic_result)
    )

    # -----------------------------------------------------------------------
    # Step 6 — Legacy column mapping + merge
    # -----------------------------------------------------------------------
    try:
        legacy_col_result = detect_column_mapping(workbook_profile, legacy_sheet_result, legacy_profile)
        legacy_col_mapping: dict[str, dict[str, str]] = legacy_col_result.get("column_mapping") or {}
        errors = _merge_messages(errors, legacy_col_result.get("errors"))
        warnings = _merge_messages(warnings, legacy_col_result.get("warnings"))
    except Exception as exc:
        _log.warning("Legacy column mapping failed: %s", exc)
        warnings.append(f"Legacy column mapping failed (non-critical): {exc}")
        legacy_col_mapping = {}
        legacy_col_result = {"column_mapping": {}, "column_mapping_report": {},
                             "errors": [], "warnings": [str(exc)]}

    final_col_mapping, col_mapping_source = _merge_column_mappings(
        semantic_col_mapping, semantic_col_report, legacy_col_mapping
    )

    # Count semantic vs legacy sources
    _n_semantic  = sum(1 for v in col_mapping_source.values() if v == "semantic")
    _n_legacy    = sum(1 for v in col_mapping_source.values() if v == "legacy_fallback")
    _leg_cols    = [(k, v) for k, v in col_mapping_source.items() if v == "legacy_fallback"]
    _leg_lines   = [f"      {_STAR} {k}" for k in (_leg_cols[:10])]
    if len(_leg_cols) > 10:
        _leg_lines.append(f"      ... and {len(_leg_cols) - 10} more legacy columns (see debug JSON)")
    _col_status = (
        f"{_TICK} All columns mapped by semantic classifier"
        if _n_legacy == 0
        else f"{_STAR} {_n_legacy} column(s) used LEGACY FALLBACK"
    )
    _log.info(
        "%s\n  semantic : %d  |  legacy fallback : %d  |  total : %d\n  %s%s",
        _hdr("STEP 6 — Column Mapping Merge"),
        _n_semantic, _n_legacy, _n_semantic + _n_legacy,
        _col_status,
        ("\n" + "\n".join(_leg_lines)) if _leg_lines else "",
    )
    _log_column_mapping(final_col_mapping, {"column_mapping_report": semantic_col_report})

    col_map_debug = {
        "column_mapping": json_safe(final_col_mapping),
        "semantic_column_mapping_report": json_safe(semantic_col_report),
        "legacy_column_mapping": json_safe(legacy_col_mapping),
        "column_mapping_source": col_mapping_source,
        "ambiguous_columns": json_safe(semantic_result.get("ambiguous_columns") or []),
        "warnings": semantic_result.get("warnings") or [],
        "errors": semantic_result.get("errors") or [],
    }
    col_debug_path = write_debug_json(debug_dir, "04_column_mapping.json", col_map_debug)
    debug_files["column_mapping"] = col_debug_path

    state = {
        **state,
        "column_mapping": final_col_mapping,
        "column_mapping_source": col_mapping_source,
        "semantic_column_report": json_safe(semantic_result),
        "errors": errors,
        "warnings": warnings,
    }

    # -----------------------------------------------------------------------
    # Step 7 — Normalize tables
    # -----------------------------------------------------------------------
    norm_result = normalize_tables(file_path, final_sheet_mapping, final_col_mapping, current_date)
    errors = _merge_messages(errors, norm_result.get("errors"))
    warnings = _merge_messages(warnings, norm_result.get("warnings"))
    canonical_tables: dict = norm_result.get("normalized_tables") or {}

    state = {
        **state,
        "normalized_tables": canonical_tables,
        "errors": errors,
        "warnings": warnings,
    }

    norm_summary = summarize_normalized_tables(canonical_tables)
    table_lines = ["Normalized tables:"]
    for name, meta in norm_summary.items():
        table_lines.append(f"  {name}: {meta['row_count']} rows")
    _log.info("\n".join(table_lines) if len(table_lines) > 1 else "Normalized tables: (none)")
    debug_files["normalized_summary"] = write_debug_json(
        debug_dir, "05_normalized_table_summary.json", norm_summary
    )

    if norm_result.get("errors"):
        return {**state, "debug_dir": debug_dir, "debug_files": debug_files}

    # Build identity sheet_mapping for Phase 1/2 tools
    # (canonical_tables is keyed by role name, so identity mapping = role → role)
    identity_mapping: dict[str, str] = {role: role for role in canonical_tables}

    # -----------------------------------------------------------------------
    # Step 8 — Discover manufacturing DNA
    # -----------------------------------------------------------------------
    try:
        dna_result = detect_manufacturing_dna(
            normalized_tables=canonical_tables,
            sheet_mapping=identity_mapping,
            column_mapping={},
        )
        manufacturing_dna: dict = dna_result.get("manufacturing_dna") or {}
        errors = _merge_messages(errors, dna_result.get("errors"))
        warnings = _merge_messages(warnings, dna_result.get("warnings"))
    except Exception as exc:
        _log.warning("detect_manufacturing_dna failed: %s", exc)
        warnings.append(f"Manufacturing DNA detection failed (non-critical): {exc}")
        dna_result = {"manufacturing_dna": {}, "evidence": {}, "errors": [],
                      "warnings": [str(exc)], "missing_for_basic_scheduling": [],
                      "missing_for_advanced_scheduling": []}
        manufacturing_dna = {}

    missing_basic = dna_result.get("missing_for_basic_scheduling") or []
    if missing_basic:
        warnings.append(
            f"Basic scheduling may be incomplete. Missing: {', '.join(missing_basic)}"
        )

    _dna_flags = {
        "demand":    manufacturing_dna.get("has_demand"),
        "products":  manufacturing_dna.get("has_products"),
        "routing":   manufacturing_dna.get("has_routing"),
        "machines":  manufacturing_dna.get("has_machines"),
        "capacity":  manufacturing_dna.get("has_machine_capacity"),
        "proc.times":manufacturing_dna.get("has_processing_times"),
        "due dates": manufacturing_dna.get("has_due_dates"),
        "priorities":manufacturing_dna.get("has_priorities"),
        "BOM":       manufacturing_dna.get("has_bom"),
        "inventory": manufacturing_dna.get("has_inventory"),
        "setup/CO":  manufacturing_dna.get("has_setup_changeover"),
        "QA hold":   manufacturing_dna.get("has_quality_hold"),
        "calendar":  manufacturing_dna.get("has_calendar"),
        "labor":     manufacturing_dna.get("has_labor"),
        "maintenance":manufacturing_dna.get("has_maintenance"),
        "overtime":  manufacturing_dna.get("has_overtime"),
        "costs":     manufacturing_dna.get("has_costs"),
    }
    _dna_yes = [k for k, v in _dna_flags.items() if v]
    _dna_no  = [k for k, v in _dna_flags.items() if not v]
    _missing_basic = dna_result.get("missing_for_basic_scheduling") or []
    _log.info(
        "%s\n  model    : %s\n  detected : %s\n  missing  : %s%s",
        _hdr("STEP 8 — Manufacturing DNA"),
        manufacturing_dna.get("production_model", "unknown"),
        ", ".join(_dna_yes) if _dna_yes else "(none)",
        ", ".join(_dna_no[:8]) + ("..." if len(_dna_no) > 8 else "") if _dna_no else "(none)",
        (f"\n  WARN — missing for basic scheduling: {', '.join(_missing_basic)}" if _missing_basic else ""),
    )
    debug_files["manufacturing_dna"] = write_debug_json(
        debug_dir, "11_manufacturing_dna.json", json_safe(dna_result)
    )

    state = {
        **state,
        "manufacturing_dna": json_safe(manufacturing_dna),
        "manufacturing_dna_report": json_safe(dna_result),
        "errors": errors,
        "warnings": warnings,
    }

    # -----------------------------------------------------------------------
    # Step 9 — Discover common constraint candidates
    # -----------------------------------------------------------------------
    try:
        common_candidates_result = discover_constraint_candidates(
            normalized_tables=canonical_tables,
            sheet_mapping=identity_mapping,
            column_mapping={},
            manufacturing_dna=manufacturing_dna,
        )
        common_candidates: list[dict] = common_candidates_result.get("constraint_candidates") or []
        errors = _merge_messages(errors, common_candidates_result.get("errors"))
        warnings = _merge_messages(warnings, common_candidates_result.get("warnings"))
    except Exception as exc:
        _log.warning("discover_constraint_candidates failed: %s", exc)
        warnings.append(f"Constraint candidate discovery failed (non-critical): {exc}")
        common_candidates = []
        common_candidates_result = {"constraint_candidates": [], "errors": [], "warnings": [str(exc)]}

    _cand_by_type = {}
    for c in common_candidates:
        _cand_by_type.setdefault(c.get("constraint_type", "?"), []).append(c.get("status", "?"))
    _cand_lines = [f"    {ct:<40} [{st[0]}]" for ct, st in list(_cand_by_type.items())[:15]]
    if len(_cand_by_type) > 15:
        _cand_lines.append(f"    ... and {len(_cand_by_type) - 15} more (see debug JSON)")
    _log.info(
        "%s\n  %d candidates discovered:\n%s",
        _hdr("STEP 9 — Common Constraint Candidates"),
        len(common_candidates),
        "\n".join(_cand_lines) if _cand_lines else "    (none)",
    )
    debug_files["common_candidates"] = write_debug_json(
        debug_dir, "12_common_constraint_candidates.json", json_safe(common_candidates_result)
    )

    state = {
        **state,
        "common_constraint_candidates": json_safe(common_candidates),
        "errors": errors,
        "warnings": warnings,
    }

    # -----------------------------------------------------------------------
    # Step 10 — Run constraint packs
    # -----------------------------------------------------------------------
    try:
        evidence = build_evidence_corpus(canonical_tables, manufacturing_dna)
        pack_result = run_constraint_packs(
            normalized_tables=canonical_tables,
            manufacturing_dna=manufacturing_dna,
            evidence=evidence,
        )
        pack_candidates: list[dict] = pack_result.get("pack_candidates") or []
        activated_packs: list[dict] = pack_result.get("activated_packs") or []
        errors = _merge_messages(errors, pack_result.get("errors"))
        warnings = _merge_messages(warnings, pack_result.get("warnings"))
    except Exception as exc:
        _log.warning("run_constraint_packs failed: %s", exc)
        warnings.append(f"Constraint pack runner failed (non-critical): {exc}")
        pack_candidates = []
        activated_packs = []
        pack_result = {"pack_candidates": [], "activated_packs": [], "errors": [], "warnings": [str(exc)]}

    _pack_lines: list[str] = []
    for p in activated_packs:
        icon = _TICK if p.get("activated") else _CROSS
        n = p.get("num_candidates", 0)
        reason = str(p.get("reason", ""))[:80]
        _pack_lines.append(
            f"    {icon} {p.get('pack_name','?'):<35} {'ACTIVATED' if p.get('activated') else 'not active':<12}"
            f" [{n} candidate(s)]  {reason}"
        )
    _log.info(
        "%s\n  packs run: %d  |  activated: %d  |  total candidates: %d\n%s",
        _hdr("STEP 10 — Evidence-Based Constraint Packs"),
        len(activated_packs),
        sum(1 for p in activated_packs if p.get("activated")),
        len(pack_candidates),
        "\n".join(_pack_lines) if _pack_lines else "    (no packs loaded)",
    )
    debug_files["pack_candidates"] = write_debug_json(
        debug_dir, "13_constraint_pack_candidates.json", json_safe(pack_result)
    )

    state = {
        **state,
        "constraint_pack_candidates": json_safe(pack_candidates),
        "activated_constraint_packs": json_safe(activated_packs),
        "errors": errors,
        "warnings": warnings,
    }

    # -----------------------------------------------------------------------
    # Step 11 — Merge and deduplicate candidates
    # -----------------------------------------------------------------------
    all_candidates = _merge_candidates(common_candidates, pack_candidates)
    _log.info("Merged constraint candidates: %d total", len(all_candidates))
    debug_files["all_candidates"] = write_debug_json(
        debug_dir, "14_all_constraint_candidates.json", json_safe(all_candidates)
    )

    state = {
        **state,
        "constraint_candidates": json_safe(all_candidates),
    }

    # -----------------------------------------------------------------------
    # Step 12 — Verify constraints against solver capability
    # -----------------------------------------------------------------------
    try:
        verification_result = verify_constraint_candidates(
            constraint_candidates=all_candidates,
            normalized_tables=canonical_tables,
            manufacturing_dna=manufacturing_dna,
        )
        verified: list[dict] = verification_result.get("verified_constraints") or []
        partial: list[dict] = verification_result.get("partial_constraints") or []
        unsupported: list[dict] = verification_result.get("unsupported_constraints") or []
        enforcement_matrix: list[dict] = verification_result.get("constraint_enforcement_matrix") or []
        errors = _merge_messages(errors, verification_result.get("errors"))
        warnings = _merge_messages(warnings, verification_result.get("warnings"))
    except Exception as exc:
        _log.warning("verify_constraint_candidates failed: %s", exc)
        warnings.append(f"Constraint verification failed (non-critical): {exc}")
        verified, partial, unsupported, enforcement_matrix = [], [], [], []
        verification_result = {"verified_constraints": [], "partial_constraints": [],
                               "unsupported_constraints": [], "constraint_enforcement_matrix": [],
                               "errors": [], "warnings": [str(exc)]}

    _ver_lines: list[str] = []
    if verified:
        _ver_lines.append(f"  ENFORCED ({len(verified)}) — will enter CP-SAT as hard rules:")
        for c in verified[:20]:
            _ver_lines.append(f"    {_TICK} {c.get('constraint_type','?')}")
        if len(verified) > 20:
            _ver_lines.append(f"    ... and {len(verified)-20} more")
    if partial:
        _ver_lines.append(f"  PARTIAL / NEEDS REVIEW ({len(partial)}) — missing required fields:")
        for c in partial[:10]:
            missing = ", ".join(c.get("missing_fields") or [])
            _ver_lines.append(f"    {_WAVE} {c.get('constraint_type','?'):<40} missing: {missing}")
    if unsupported:
        _ver_lines.append(f"  NOT ENFORCED ({len(unsupported)}) — detected but solver does not support:")
        for c in unsupported[:10]:
            reason = (c.get("verification_reason") or "")[:80]
            _ver_lines.append(f"    {_CROSS} {c.get('constraint_type','?'):<40} {reason}")
    _log.info(
        "%s\n%s",
        _hdr("STEP 12 — Constraint Enforcement Verification"),
        "\n".join(_ver_lines) if _ver_lines else "    (no candidates to verify)",
    )
    debug_files["enforcement_matrix"] = write_debug_json(
        debug_dir, "10_constraint_enforcement_matrix.json", json_safe(enforcement_matrix)
    )
    debug_files["verified_constraints_debug"] = write_debug_json(
        debug_dir, "11_verified_constraints.json", json_safe(verified)
    )

    state = {
        **state,
        "verified_constraints": json_safe(verified),
        "partial_constraints": json_safe(partial),
        "unsupported_constraints": json_safe(unsupported),
        "constraint_enforcement_matrix": json_safe(enforcement_matrix),
        "errors": errors,
        "warnings": warnings,
    }

    # -----------------------------------------------------------------------
    # Step 13 — Compile verified constraints
    # -----------------------------------------------------------------------
    try:
        compiled_verified = compile_verified_constraints(verified, canonical_tables)
        warnings = _merge_messages(warnings, compiled_verified.get("warnings"))
    except Exception as exc:
        _log.warning("compile_verified_constraints failed: %s", exc)
        warnings.append(f"Constraint compilation failed (non-critical): {exc}")
        compiled_verified = {"setup_rules": [], "cleaning_rules": [], "wait_rules": [],
                             "quality_rules": [], "batch_rules": [], "shared_resources": [],
                             "warnings": [str(exc)]}

    _n_setup   = len(compiled_verified.get("setup_rules") or [])
    _n_clean   = len(compiled_verified.get("cleaning_rules") or [])
    _n_wait    = len(compiled_verified.get("wait_rules") or [])
    _n_quality = len(compiled_verified.get("quality_rules") or [])
    _compile_warns = compiled_verified.get("warnings") or []
    _log.info(
        "%s\n  setup_rules    : %d\n  cleaning_rules : %d\n  wait_rules     : %d\n  quality_rules  : %d%s",
        _hdr("STEP 13 — Compile Verified Constraints → Canonical Rules"),
        _n_setup, _n_clean, _n_wait, _n_quality,
        ("\n  WARN: " + "; ".join(_compile_warns[:3])) if _compile_warns else "",
    )
    debug_files["compiled_constraints"] = write_debug_json(
        debug_dir, "12_compiled_verified_constraints.json", json_safe(compiled_verified)
    )

    state = {
        **state,
        "compiled_verified_constraints": json_safe(compiled_verified),
        "warnings": warnings,
    }

    # -----------------------------------------------------------------------
    # Step 14 — Legacy map_constraints (backward compatibility)
    # -----------------------------------------------------------------------
    try:
        legacy_constraint_result = map_constraints(norm_result, legacy_domain_result)
        errors = _merge_messages(errors, legacy_constraint_result.get("errors"))
        warnings = _merge_messages(warnings, legacy_constraint_result.get("warnings"))
    except Exception as exc:
        _log.warning("Legacy map_constraints failed: %s", exc)
        warnings.append(f"Legacy constraint mapping failed (non-critical): {exc}")
        legacy_constraint_result = {
            "setup_rules": [], "cleaning_rules": [], "wait_rules": [],
            "batch_rules": [], "quality_rules": [], "shared_resources": [],
            "constraints": [], "mapped_constraints": [], "unsupported_rules": [],
            "errors": [], "warnings": [str(exc)],
        }

    legacy_mapped_count = len(legacy_constraint_result.get("mapped_constraints") or [])
    legacy_unsup_count  = len(legacy_constraint_result.get("unsupported_rules") or [])
    _log.info(
        "%s\n  mapped     : %d  |  unsupported : %d",
        _hdr("STEP 14 — Legacy Constraint Mapping (backward compat)"),
        legacy_mapped_count, legacy_unsup_count,
    )

    constraint_debug_path = write_debug_json(
        debug_dir, "06_constraint_mapping.json", json_safe(legacy_constraint_result)
    )
    debug_files["constraint_mapping"] = constraint_debug_path

    debug_files["legacy_constraint_mapping"] = write_debug_json(
        debug_dir, "13_legacy_constraint_mapping.json", json_safe(legacy_constraint_result)
    )

    state = {
        **state,
        "legacy_constraint_mapping": json_safe(legacy_constraint_result),
        "errors": errors,
        "warnings": warnings,
    }

    if legacy_constraint_result.get("errors"):
        return {**state, "debug_dir": debug_dir, "debug_files": debug_files}

    # -----------------------------------------------------------------------
    # Step 15 — Merge final constraint rules
    # -----------------------------------------------------------------------
    final_constraint_rules = _merge_constraint_rules(
        legacy_constraint_result, compiled_verified, verification_result
    )
    final_rules_debug = write_debug_json(
        debug_dir, "14_final_constraint_rules.json", json_safe(final_constraint_rules)
    )
    debug_files["final_constraint_rules"] = final_rules_debug

    state = {
        **state,
        "final_constraint_rules": json_safe(final_constraint_rules),
    }

    merged_setup   = len(final_constraint_rules.get("setup_rules") or [])
    merged_clean   = len(final_constraint_rules.get("cleaning_rules") or [])
    merged_wait    = len(final_constraint_rules.get("wait_rules") or [])
    merged_quality = len(final_constraint_rules.get("quality_rules") or [])
    _src_counts    = final_constraint_rules.get("final_constraints_source") or {}
    _log.info(
        "%s\n  setup_rules    : %d\n  cleaning_rules : %d\n  wait_rules     : %d\n  quality_rules  : %d"
        "\n  [source=verified_only  legacy_detected=%d  verified=%d  partial=%d  unsupported=%d]",
        _hdr("STEP 15 — Final Merged Constraint Rules (verified-only)"),
        merged_setup, merged_clean, merged_wait, merged_quality,
        _src_counts.get("legacy_rules_count", 0),
        _src_counts.get("compiled_verified_rules_count", 0),
        _src_counts.get("partial_constraints_count", 0),
        _src_counts.get("unsupported_constraints_count", 0),
    )

    # -----------------------------------------------------------------------
    # Step 16 — Build canonical payload
    # -----------------------------------------------------------------------
    payload_result = build_canonical_payload(
        canonical_tables,
        final_constraint_rules,
        legacy_domain_result,
        current_date,
        reference_date,
    )
    errors = _merge_messages(errors, payload_result.get("errors"))
    warnings = _merge_messages(warnings, payload_result.get("warnings"))

    canonical_payload = payload_result.get("canonical_solver_payload")

    # Defensive pricing recovery: patch any job whose selling_price or
    # unit_production_cost is still 0 (e.g., normalization collision caused
    # a metadata sheet to overwrite the real SKU_Master — see TECH DEBT below).
    # Activates for partial missing pricing too, not only all-zero cases.
    #
    # TECH DEBT #1 (unit_normalization_tool.py):
    #   When multiple raw sheets map to the same canonical role the later sheet
    #   silently overwrites earlier data.  A guard based on canonical-column count
    #   was prototyped but reverted because loading real SKU_Master data activates
    #   per-product QA hold constraints (qa_release_hours) in constraint_mapping_tool.py
    #   which make the CP-SAT model INFEASIBLE (see TECH DEBT #2).
    #   Safe fix: implement the normalization guard ONLY after resolving TECH DEBT #2.
    #
    # TECH DEBT #2 (constraint_mapping_tool.py lines ~366-385):
    #   qa_release_hours from SKU_Master is converted to hard per-product quality
    #   hold constraints (2-4 day holds for the cosmetics dataset).  These are
    #   generated unconditionally and override the domain-profile QC rule (120 min).
    #   Safe fix: make per-product QA rules soft, or skip them when a domain-profile
    #   QC rule already exists, or make them horizon-aware so infeasibility cannot
    #   occur.  Requires a dedicated feasibility analysis before implementing.
    _pricing_diag: dict = {}
    if canonical_payload is not None:
        _jobs = canonical_payload.get("jobs") or []
        _needs_patch = any(
            float(j.get("selling_price_per_unit") or 0) == 0.0
            or float(j.get("unit_production_cost") or 0) == 0.0
            for j in _jobs
        )
        if _needs_patch:
            try:
                _pricing_diag = _patch_job_pricing(
                    canonical_payload,
                    file_path,
                    final_sheet_mapping,
                    final_col_mapping,
                    warnings,
                )
            except Exception as _patch_exc:
                warnings.append(f"SKU pricing patch failed (non-fatal): {_patch_exc}")

    if canonical_payload is not None:
        counts = _payload_counts(canonical_payload)
        ps = summarize_canonical_payload(canonical_payload)
        debug_files["payload_summary"] = write_debug_json(
            debug_dir, "07_canonical_payload_summary.json", ps
        )
        payload_full_path = write_debug_json(
            debug_dir, "08_canonical_payload_full.json", json_safe(canonical_payload)
        )
        debug_files["payload_full"] = payload_full_path
        _log_payload_summary(counts, debug_file=payload_full_path)
        if _pricing_diag:
            debug_files["pricing_patch"] = write_debug_json(
                debug_dir, "08b_pricing_patch_diagnostics.json", _pricing_diag
            )
    else:
        _log.warning("Canonical payload is None after build step — check errors above.")
        debug_files["payload_summary"] = write_debug_json(
            debug_dir, "07_canonical_payload_summary.json",
            {"error": "payload is None", "build_errors": payload_result.get("errors")},
        )

    # -----------------------------------------------------------------------
    # Assemble mapping_report
    # -----------------------------------------------------------------------
    unsupported_rules_for_report = legacy_constraint_result.get("unsupported_rules") or []
    requires_review: bool = (
        (domain_conf < 0.5)
        or bool(unsupported_rules_for_report)
        or bool(payload_result.get("errors"))
        or structure_result.get("requires_user_review", False)
    )

    aggregated_warnings = aggregate_warnings(warnings)

    mapping_report: dict[str, Any] = {
        # ---- Legacy / backward-compat fields ----
        "domain_profile_id": domain_id,
        "domain_confidence": domain_conf,
        "domain_reason": legacy_domain_result.get("reason"),
        "sheet_mapping": final_sheet_mapping,
        "column_mapping": final_col_mapping,
        "mapped_constraints": final_constraint_rules.get("mapped_constraints") or [],
        "unsupported_rules": final_constraint_rules.get("unsupported_rules") or [],
        "warnings": aggregated_warnings[:],
        "errors": errors[:],
        "requires_user_review": requires_review,
        "debug_dir": debug_dir,
        "debug_files": debug_files,
        # ---- Phase 3 new fields ----
        "mapping_mode": mapping_mode,
        "optional_domain_guess": json_safe(legacy_domain_result),
        "table_role_report": json_safe(structure_result),
        "semantic_column_report": json_safe(semantic_result),
        "sheet_mapping_source": sheet_mapping_source,
        "column_mapping_source": col_mapping_source,
        "manufacturing_dna": json_safe(manufacturing_dna),
        "manufacturing_dna_report": json_safe(dna_result),
        "common_constraint_candidates": json_safe(common_candidates),
        "constraint_pack_candidates": json_safe(pack_candidates),
        "activated_constraint_packs": json_safe(activated_packs),
        "constraint_candidates": json_safe(all_candidates),
        "verified_constraints": json_safe(verified),
        "partial_constraints": json_safe(partial),
        "unsupported_constraints": json_safe(unsupported),
        "constraint_enforcement_matrix": json_safe(enforcement_matrix),
        "compiled_verified_constraints": json_safe(compiled_verified),
        "legacy_constraint_mapping": json_safe(legacy_constraint_result),
        "final_constraint_rules": json_safe(final_constraint_rules),
    }

    _log_audit.info("Audit files written to: %s  (%d files)", debug_dir, len(debug_files))
    _log.info(
        "%s\n"
        "  mapping_mode       : %s\n"
        "  yaml_domain_guess  : %s  (conf=%.0f%%)  ← metadata only\n"
        "  sheets mapped      : %d  (domain_free=%d  legacy_fallback=%d)\n"
        "  columns mapped     : %d  (semantic=%d  legacy_fallback=%d)\n"
        "  enforced           : %d constraint(s)  → entering CP-SAT\n"
        "  not_enforced       : %d  (detected but solver limitation)\n"
        "  partial            : %d  (missing required fields)\n"
        "  debug dir          : %s",
        _hdr("MAPPING COMPLETE"),
        mapping_mode,
        domain_id, domain_conf * 100,
        len(final_sheet_mapping),
        sum(1 for s in sheet_mapping_source.values() if s == "domain_free"),
        sum(1 for s in sheet_mapping_source.values() if s == "legacy_fallback"),
        _n_semantic + _n_legacy, _n_semantic, _n_legacy,
        len(verified), len(unsupported), len(partial),
        debug_dir,
    )

    return {
        **state,
        "canonical_solver_payload": canonical_payload,
        "mapping_report": mapping_report,
        "errors": errors,
        "warnings": aggregated_warnings,
        "debug_dir": debug_dir,
        "debug_files": debug_files,
        # Phase 3 state fields
        "mapping_mode": mapping_mode,
        "optional_domain_guess": json_safe(legacy_domain_result),
        "table_role_report": json_safe(structure_result),
        "semantic_column_report": json_safe(semantic_result),
        "sheet_mapping_source": sheet_mapping_source,
        "column_mapping_source": col_mapping_source,
        "manufacturing_dna": json_safe(manufacturing_dna),
        "manufacturing_dna_report": json_safe(dna_result),
        "common_constraint_candidates": json_safe(common_candidates),
        "constraint_pack_candidates": json_safe(pack_candidates),
        "activated_constraint_packs": json_safe(activated_packs),
        "constraint_candidates": json_safe(all_candidates),
        "verified_constraints": json_safe(verified),
        "partial_constraints": json_safe(partial),
        "unsupported_constraints": json_safe(unsupported),
        "constraint_enforcement_matrix": json_safe(enforcement_matrix),
        "compiled_verified_constraints": json_safe(compiled_verified),
        "legacy_constraint_mapping": json_safe(legacy_constraint_result),
        "final_constraint_rules": json_safe(final_constraint_rules),
    }
