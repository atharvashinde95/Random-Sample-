from __future__ import annotations

from tools.canonical_payload_validator_tool import validate_canonical_payload
from config.logging_config import get_logger
from utils.debug_audit import write_debug_json, summarize_canonical_payload

_log = get_logger("production_scheduler.validation")

_MISSING_PAYLOAD_REPORT: dict = {
    "is_valid": False,
    "errors": ["canonical_solver_payload is missing."],
    "warnings": [],
    "validated_payload": None,
}


def canonical_payload_validation_node(state: dict) -> dict:
    """
    Validate state["canonical_solver_payload"] using validate_canonical_payload.

    Reads from state:  canonical_solver_payload, debug_dir
    Writes to state:   payload_validation_report, canonical_solver_payload (if valid),
                        errors (merged), warnings (merged)
    """
    payload = state.get("canonical_solver_payload")
    errors: list[str] = list(state.get("errors") or [])
    warnings: list[str] = list(state.get("warnings") or [])
    debug_dir: str = state.get("debug_dir") or ""

    _log.info("Payload validation started")

    if not payload:
        errors.append("canonical_solver_payload is missing.")
        _log.error("Payload validation FAILED — canonical_solver_payload is missing")
        if debug_dir:
            write_debug_json(debug_dir, "09_payload_validation.json", {
                "is_valid": False,
                "errors": ["canonical_solver_payload is missing."],
                "warnings": [],
            })
        return {
            **state,
            "payload_validation_report": _MISSING_PAYLOAD_REPORT,
            "errors": errors,
            "warnings": warnings,
        }

    validation_result = validate_canonical_payload(payload)
    validation_errors: list[str] = validation_result.get("errors", [])
    validation_warnings: list[str] = validation_result.get("warnings", [])

    errors = errors + validation_errors
    warnings = warnings + validation_warnings

    updated_payload = payload
    if validation_result.get("is_valid") and validation_result.get("validated_payload"):
        updated_payload = validation_result["validated_payload"]

    if not validation_result.get("is_valid", False):
        for err in validation_errors:
            if err not in errors:
                errors.append(err)

    is_valid = validation_result.get("is_valid", False)
    _log.info(
        "Payload validation: %s | errors=%d warnings=%d",
        "VALID" if is_valid else "INVALID",
        len(validation_errors),
        len(validation_warnings),
    )

    if debug_dir:
        debug_payload = {
            "is_valid": is_valid,
            "errors": validation_errors,
            "warnings": validation_warnings,
        }
        if is_valid:
            debug_payload["validated_payload_summary"] = summarize_canonical_payload(
                updated_payload
            )
        write_debug_json(debug_dir, "09_payload_validation.json", debug_payload)

    return {
        **state,
        "canonical_solver_payload": updated_payload,
        "payload_validation_report": validation_result,
        "errors": errors,
        "warnings": warnings,
    }


def payload_valid_router(state: dict) -> str:
    """
    LangGraph conditional-edge router.

    Returns "valid"   if payload_validation_report["is_valid"] is True.
    Returns "invalid" otherwise.
    """
    report = state.get("payload_validation_report") or {}
    return "valid" if report.get("is_valid", False) else "invalid"
