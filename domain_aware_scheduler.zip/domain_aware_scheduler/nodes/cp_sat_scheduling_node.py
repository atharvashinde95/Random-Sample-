from __future__ import annotations

from tools.cp_sat_solver_tool import solve_cp_sat
from tools.post_solve_validator_tool import validate_schedule
from tools.report_gantt_tool import generate_report
from config.logging_config import get_logger
from utils.debug_audit import (
    write_debug_json,
    json_safe,
    summarize_canonical_payload,
    summarize_solver_result,
)

_log = get_logger("production_scheduler.solver")


# ---------------------------------------------------------------------------
# Logging helpers
# ---------------------------------------------------------------------------

def _log_solver_input(ps: dict, debug_file: str = "") -> None:
    """Emit a readable multi-line CP-SAT input summary."""
    ow = ps.get("objective_weights") or {}
    ow_parts = [
        f"{k.replace('_weight', '')}={v}"
        for k, v in ow.items()
        if isinstance(v, (int, float))
    ]
    ow_str = "  ".join(ow_parts) if ow_parts else "(defaults)"

    lines = [
        "CP-SAT input summary:",
        f"  reference_time: {ps.get('reference_time', 'N/A')}",
        f"  domain:         {ps.get('domain_profile_id', 'N/A')}",
        f"  jobs:           {ps.get('jobs_count', 0)}",
        f"  machines:       {ps.get('machines_count', 0)}",
        f"  operations:     {ps.get('operations_count', 0)}",
        f"  calendars:      {ps.get('calendars_count', 0)}",
        f"  setup_rules:    {ps.get('setup_rules_count', 0)}",
        f"  cleaning_rules: {ps.get('cleaning_rules_count', 0)}",
        f"  wait_rules:     {ps.get('wait_rules_count', 0)}",
        f"  quality_rules:  {ps.get('quality_rules_count', 0)}",
        f"  objective_weights: {ow_str}",
    ]
    if debug_file:
        lines.append(f"Exact solver input saved:\n  {debug_file}")
    _log.info("\n".join(lines))


def _log_solver_output(result: dict, debug_file: str = "") -> None:
    """Emit a readable multi-line CP-SAT output summary."""
    solver_debug = result.get("solver_debug") or {}
    # key in solver_debug is "wall_time" (set by cp_model.CpSolver().WallTime())
    wall_time = solver_debug.get("wall_time") or solver_debug.get("wall_time_seconds")
    obj_value = result.get("objective_value")

    lines = [
        "CP-SAT output:",
        f"  status:              {result.get('solver_status', 'UNKNOWN')}",
        f"  schedule_rows:       {len(result.get('schedule_table') or [])}",
        f"  late_orders:         {len(result.get('late_orders') or [])}",
        f"  unscheduled_orders:  {len(result.get('unscheduled_orders') or [])}",
    ]
    if wall_time is not None:
        lines.append(f"  wall_time:           {wall_time:.2f}s")
    if obj_value is not None:
        lines.append(f"  objective_value:     {obj_value:.4f}")
    if debug_file:
        lines.append(f"Solver summary saved:\n  {debug_file}")
    _log.info("\n".join(lines))


# ---------------------------------------------------------------------------
# Node
# ---------------------------------------------------------------------------

def cp_sat_scheduling_node(state: dict) -> dict:
    """
    LangGraph-compatible node that runs the CP-SAT solver, post-solve validator,
    and report/Gantt generator.

    Reads from state:
      - canonical_solver_payload (dict)
      - solve_config (dict, optional)
      - mapping_report (dict, optional)
      - debug_dir (str, optional)

    Writes to state:
      - solver_result
      - solver_status
      - schedule_table
      - cost_summary
      - info_summary
      - machine_utilization
      - bottlenecks
      - late_orders
      - unscheduled_orders
      - post_solve_validation_report
      - solver_debug
      - output_files
      - gantt_chart_path
      - errors (merged)
      - warnings (merged)
    """
    payload = state.get("canonical_solver_payload")
    solve_config = state.get("solve_config")
    debug_dir: str = state.get("debug_dir") or ""
    debug_files: dict = dict(state.get("debug_files") or {})

    errors: list[str] = list(state.get("errors") or [])
    warnings: list[str] = list(state.get("warnings") or [])

    if not payload:
        errors.append("cp_sat_scheduling_node: canonical_solver_payload is missing.")
        return {**state, "errors": errors, "warnings": warnings}

    # -----------------------------------------------------------------------
    # Pre-solve: log and write solver input
    # -----------------------------------------------------------------------
    ps = summarize_canonical_payload(payload)

    if debug_dir:
        debug_files["solver_input_summary"] = write_debug_json(
            debug_dir, "10_solver_input_summary.json", ps
        )
        solver_input_path = write_debug_json(
            debug_dir, "11_solver_input_payload.json", json_safe(payload)
        )
        debug_files["solver_input_payload"] = solver_input_path
    else:
        solver_input_path = ""

    _log_solver_input(ps, debug_file=solver_input_path)

    # -----------------------------------------------------------------------
    # Solve
    # -----------------------------------------------------------------------
    result = solve_cp_sat(payload, solve_config)
    errors.extend(result.get("errors", []))
    warnings.extend(result.get("warnings", []))

    solver_status = result.get("solver_status")

    # -----------------------------------------------------------------------
    # Post-solve validation
    # -----------------------------------------------------------------------
    validation_report: dict = {}
    if solver_status in ("OPTIMAL", "FEASIBLE"):
        validation_report = validate_schedule(payload, result)
        if not validation_report.get("is_valid", True):
            errors.extend(
                [f"[post_solve] {e}" for e in validation_report.get("errors", [])]
            )
            result["solver_status"] = "POST_SOLVE_INVALID"
            solver_status = "POST_SOLVE_INVALID"
        warnings.extend(
            [f"[post_solve] {w}" for w in validation_report.get("warnings", [])]
        )

    # Write result summary before logging so we can pass the path into the log
    result_summary_path = ""
    if debug_dir:
        result_summary_path = write_debug_json(
            debug_dir, "12_solver_result_summary.json",
            summarize_solver_result(result)
        )
        debug_files["solver_result_summary"] = result_summary_path
        write_debug_json(debug_dir, "13_post_solve_validation.json", {
            "is_valid": validation_report.get("is_valid", True),
            "errors": validation_report.get("errors") or [],
            "warnings": validation_report.get("warnings") or [],
        })

    _log_solver_output(result, debug_file=result_summary_path)

    if validation_report:
        psv_valid = validation_report.get("is_valid", True)
        psv_errors = len(validation_report.get("errors") or [])
        psv_warnings = len(validation_report.get("warnings") or [])
        _log.info(
            "Post-solve validation: %s  errors=%d  warnings=%d",
            "VALID" if psv_valid else "INVALID",
            psv_errors,
            psv_warnings,
        )

    result["post_solve_validation_report"] = validation_report

    # -----------------------------------------------------------------------
    # Report + Gantt generation (only on valid successful solve)
    # -----------------------------------------------------------------------
    output_files: dict = {}
    gantt_chart_path: str = ""

    if solver_status in ("OPTIMAL", "FEASIBLE"):
        try:
            report_result = generate_report(
                payload=payload,
                solver_result=result,
                mapping_report=state.get("mapping_report"),
                output_dir="outputs",
            )
            warnings.extend(report_result.get("warnings", []))
            errors.extend(report_result.get("errors", []))

            output_files = report_result.get("output_files", {})
            gantt_chart_path = report_result.get("gantt_chart_path", "")

            result["output_files"] = output_files
            result["gantt_chart_path"] = gantt_chart_path
            result["info_summary"] = report_result.get(
                "info_summary", result.get("info_summary", {})
            )
            result["cost_summary"] = report_result.get(
                "cost_summary", result.get("cost_summary", {})
            )

            _log.info(
                "Report generation complete:\n"
                "  csv:   %s\n"
                "  xlsx:  %s\n"
                "  html:  %s\n"
                "  gantt: %s",
                output_files.get("schedule_csv", ""),
                output_files.get("schedule_xlsx", ""),
                output_files.get("report_html", ""),
                gantt_chart_path or output_files.get("gantt_html", ""),
            )
            if debug_dir:
                debug_files["report_generation"] = write_debug_json(
                    debug_dir, "14_report_generation.json", {
                        "output_files": output_files,
                        "gantt_chart_path": gantt_chart_path,
                        "warnings": report_result.get("warnings") or [],
                        "errors": report_result.get("errors") or [],
                    }
                )
        except Exception as exc:
            warnings.append(f"Report generation failed (non-fatal): {exc}")
            _log.warning("Report generation failed: %s", exc)
            if debug_dir:
                write_debug_json(debug_dir, "14_report_generation.json", {
                    "error": str(exc),
                    "output_files": {},
                })

    return {
        **state,
        "solver_result": result,
        "solver_status": solver_status,
        "schedule_table": result.get("schedule_table", []),
        "cost_summary": result.get("cost_summary", {}),
        "info_summary": result.get("info_summary", {}),
        "machine_utilization": result.get("machine_utilization", []),
        "bottlenecks": result.get("bottlenecks", []),
        "late_orders": result.get("late_orders", []),
        "unscheduled_orders": result.get("unscheduled_orders", []),
        "post_solve_validation_report": validation_report,
        "solver_debug": result.get("solver_debug", {}),
        "output_files": output_files,
        "gantt_chart_path": gantt_chart_path,
        "errors": errors,
        "warnings": warnings,
        "debug_dir": debug_dir,
        "debug_files": debug_files,
    }
