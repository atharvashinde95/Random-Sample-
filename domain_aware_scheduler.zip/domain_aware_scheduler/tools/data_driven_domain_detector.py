"""
Data-driven domain detector.

Identifies manufacturing domain purely from workbook content —
no YAML files required. Reads product names, operation names,
machine names, cleaning families, and column names from the workbook
and scores them against domain keyword signatures.

Returns the best-matching domain with confidence and evidence.
"""
from __future__ import annotations

import re
from typing import Any


# ---------------------------------------------------------------------------
# Domain keyword signatures
# Each domain has: required (must-have signals) and supporting keywords.
# Score = weighted match count / total possible.
# ---------------------------------------------------------------------------

_DOMAIN_SIGNATURES: dict[str, dict] = {
    "cosmetics_personal_care": {
        "label": "Cosmetics / Personal Care Manufacturing",
        "required_any": [
            "cream", "serum", "lotion", "moisturizer", "toner", "gel",
            "balm", "shampoo", "conditioner", "lipstick", "mascara",
            "compounding", "cream_light", "cream_rich", "serum_citrus",
            "bulk_hold", "kettle", "filling line", "fragrance", "colour",
            "cos-", "gmp-a", "gmp-b", "gmp line",
        ],
        "supporting": [
            "aloe", "vitamin c", "hydrating", "moisturising", "rose water",
            "night cream", "face wash", "body lotion", "eye cream",
            "filling", "labeling", "cartoning", "packaging",
            "allergen", "fragrance changeover", "color changeover",
            "qa_release", "qa release", "microbiology", "shelf life",
            "gmp", "cleanroom", "bulk", "formulation",
            "jar", "bottle", "tube", "stick",
        ],
        "negative": ["bread", "dough", "bake", "oven", "tablet", "pcb", "weld"],
        "weight": 1.0,
    },
    "food_bakery": {
        "label": "Food / Bakery Manufacturing",
        "required_any": [
            "bread", "cake", "dough", "bake", "oven", "proof", "ferment",
            "yeast", "flour", "croissant", "muffin", "cookie", "biscuit",
            "loaf", "pastry", "bakery", "bky-",
        ],
        "supporting": [
            "mixing", "proofing", "baking", "cooling", "packaging",
            "allergen", "gluten", "dairy", "nuts",
            "shelf life", "freshness", "expiry",
            "bread loaf", "white bread", "whole wheat",
        ],
        "negative": ["cream", "serum", "gmp-a", "kettle", "compounding", "tablet", "pcb"],
        "weight": 1.0,
    },
    "pharmaceutical": {
        "label": "Pharmaceutical Manufacturing",
        "required_any": [
            "tablet", "capsule", "api", "granulation", "compression",
            "coating", "sterile", "injectable", "vial", "ampoule",
            "pharma", "drug", "active ingredient", "excipient",
            "phr-", "blending", "milling",
        ],
        "supporting": [
            "dissolution", "qa release", "batch record", "validation",
            "gmp", "cleanroom", "fda", "ich", "pharmacopoeia",
            "tablet press", "coating pan", "granulator",
            "lyophilisation", "freeze dry",
        ],
        "negative": ["bread", "dough", "cream", "serum", "pcb", "weld", "kettle"],
        "weight": 1.0,
    },
    "electronics": {
        "label": "Electronics / PCB Manufacturing",
        "required_any": [
            "pcb", "smt", "reflow", "solder", "component reel", "board",
            "chip", "ic", "bga", "aoi", "wave solder", "pick and place",
            "elec-", "circuit",
        ],
        "supporting": [
            "stencil", "paste", "flux", "inspection", "x-ray",
            "component", "reel", "feeder", "nozzle",
        ],
        "negative": ["cream", "bread", "tablet", "kettle", "oven"],
        "weight": 1.0,
    },
    "automotive": {
        "label": "Automotive Manufacturing",
        "required_any": [
            "welding", "stamping", "paint", "chassis", "body", "assembly",
            "engine", "transmission", "suspension", "auto-", "vehicle",
            "body shop", "press shop",
        ],
        "supporting": [
            "robotic", "jig", "fixture", "torque", "trim", "door",
            "bumper", "hood", "windshield",
        ],
        "negative": ["cream", "bread", "tablet", "pcb"],
        "weight": 1.0,
    },
    "steel_metals": {
        "label": "Steel / Metals Manufacturing",
        "required_any": [
            "rolling", "casting", "furnace", "quench", "anneal", "forge",
            "steel", "aluminium", "aluminum", "coil", "slab", "billet",
            "hot roll", "cold roll",
        ],
        "supporting": [
            "heat treatment", "pickling", "galvanizing", "temper",
            "mill", "ladle", "tundish",
        ],
        "negative": ["cream", "bread", "tablet", "pcb"],
        "weight": 1.0,
    },
}


def _normalize(text: str) -> str:
    return re.sub(r"[^a-z0-9 _-]", " ", text.lower()).strip()


def _extract_signals(workbook_profile: dict) -> list[str]:
    """Pull all meaningful text strings from the workbook profile."""
    signals: list[str] = []

    sheets: dict = workbook_profile.get("sheets", {})
    for sheet_name, sheet_data in sheets.items():
        signals.append(_normalize(sheet_name))

        # Column headers
        for col in sheet_data.get("columns", []):
            signals.append(_normalize(str(col)))

        # Sample row values (strings only)
        for row in sheet_data.get("sample_rows", []):
            for v in row.values():
                if v and isinstance(v, str) and len(v) > 1:
                    signals.append(_normalize(v))

    # Also include sheet names list
    for sn in workbook_profile.get("sheet_names", []):
        signals.append(_normalize(sn))

    return signals


def _score_domain(signals: list[str], sig: dict) -> tuple[float, list[str]]:
    """Return (confidence 0-1, evidence list) for a domain signature."""
    corpus = " ".join(signals)
    evidence: list[str] = []

    # Check negatives — strong disqualifier
    neg_hits = sum(1 for kw in sig["negative"] if kw in corpus)
    if neg_hits >= 2:
        return 0.0, [f"disqualified: {neg_hits} negative signals found"]

    # Required (must match at least 1)
    req_hits = [kw for kw in sig["required_any"] if kw in corpus]
    if not req_hits:
        return 0.0, ["no required signals found"]

    for kw in req_hits[:5]:
        evidence.append(f"required: '{kw}'")

    # Supporting
    sup_hits = [kw for kw in sig["supporting"] if kw in corpus]
    for kw in sup_hits[:5]:
        evidence.append(f"supporting: '{kw}'")

    # Confidence: required contribution (60%) + supporting (40%)
    req_score = min(1.0, len(req_hits) / max(1, min(3, len(sig["required_any"]) // 3)))
    sup_score = min(1.0, len(sup_hits) / max(1, min(5, len(sig["supporting"]) // 2)))
    confidence = round(0.60 * req_score + 0.40 * sup_score, 4)

    # Penalty for any negative signal (soft)
    if neg_hits == 1:
        confidence = round(confidence * 0.7, 4)

    return confidence, evidence


def detect_domain_from_data(workbook_profile: dict) -> dict:
    """
    Detect manufacturing domain purely from workbook content.

    Returns:
    {
        "domain_id":    str,
        "domain_label": str,
        "confidence":   float (0-1),
        "evidence":     [str],
        "all_scores":   {domain_id: float},
        "method":       "data_driven"
    }
    """
    signals = _extract_signals(workbook_profile)

    scores: dict[str, tuple[float, list[str]]] = {}
    for domain_id, sig in _DOMAIN_SIGNATURES.items():
        conf, evidence = _score_domain(signals, sig)
        scores[domain_id] = (conf, evidence)

    # Pick best
    best_id = max(scores, key=lambda d: scores[d][0])
    best_conf, best_ev = scores[best_id]

    if best_conf < 0.15:
        return {
            "domain_id":    "generic_manufacturing",
            "domain_label": "Generic Manufacturing",
            "confidence":   best_conf,
            "evidence":     ["No strong domain signals found — using generic fallback"],
            "all_scores":   {d: round(v[0], 4) for d, v in scores.items()},
            "method":       "data_driven",
        }

    return {
        "domain_id":    best_id,
        "domain_label": _DOMAIN_SIGNATURES[best_id]["label"],
        "confidence":   best_conf,
        "evidence":     best_ev,
        "all_scores":   {d: round(v[0], 4) for d, v in scores.items()},
        "method":       "data_driven",
    }
