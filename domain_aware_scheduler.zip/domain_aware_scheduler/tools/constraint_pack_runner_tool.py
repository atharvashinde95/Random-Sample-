"""
Constraint pack runner tool.

Runs all registered constraint packs and collects evidence-based candidates.
Packs activate from evidence in the data, not from domain labels.
"""
from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# Evidence corpus builder
# ---------------------------------------------------------------------------

def build_evidence_corpus(
    normalized_tables: dict,
    manufacturing_dna: dict | None = None,
) -> dict:
    """
    Build a JSON-serializable evidence corpus from normalized_tables.

    The corpus is a dict containing:
      - Lists of extracted values per semantic category
      - A single lowercase text_corpus string for fast keyword search

    Input normalized_tables may use canonical role names (Demand_Orders,
    Routing, etc.) or raw sheet names — both work because we iterate all rows.
    """
    operation_names: set[str] = set()
    operation_families: set[str] = set()
    machine_names: set[str] = set()
    machine_types: set[str] = set()
    product_families: set[str] = set()
    material_names: set[str] = set()
    business_rule_texts: set[str] = set()
    setup_changeover_families: set[str] = set()
    column_names: set[str] = set()
    table_names: set[str] = set(normalized_tables.keys())

    for tname, rows in normalized_tables.items():
        if not isinstance(rows, list):
            continue
        if rows:
            column_names.update(rows[0].keys())

        for row in rows:
            if not isinstance(row, dict):
                continue

            _add_str(operation_names, row.get("operation_name"))
            _add_str(operation_families, row.get("operation_family"))
            _add_str(machine_names, row.get("machine_name"))
            _add_str(machine_types, row.get("machine_type"))
            _add_str(product_families, row.get("product_family"))

            for key in ("component_id", "item_id", "material_id", "material_name"):
                _add_str(material_names, row.get(key))

            for key in ("rule_text", "description", "constraint", "rule_description"):
                _add_str(business_rule_texts, row.get(key))

            for key in ("from_family", "to_family"):
                _add_str(setup_changeover_families, row.get(key))

    # Build unified lowercase text corpus
    corpus_parts = [
        *table_names, *column_names,
        *operation_names, *operation_families,
        *machine_names, *machine_types,
        *product_families, *material_names,
        *business_rule_texts, *setup_changeover_families,
    ]
    text_corpus = " ".join(str(p).lower().replace("_", " ") for p in corpus_parts if p)
    # Also add underscore forms so "shelf_life" matches "shelf life" and vice versa
    text_corpus += " " + " ".join(str(p).lower() for p in corpus_parts if p)

    return {
        "operation_names": sorted(operation_names),
        "operation_families": sorted(operation_families),
        "machine_names": sorted(machine_names),
        "machine_types": sorted(machine_types),
        "product_families": sorted(product_families),
        "material_names": sorted(material_names),
        "table_names": sorted(table_names),
        "column_names": sorted(column_names),
        "business_rule_texts": sorted(business_rule_texts),
        "setup_changeover_families": sorted(setup_changeover_families),
        "text_corpus": text_corpus,
    }


def _add_str(target: set, value: Any) -> None:
    if value is not None:
        sv = str(value).strip()
        if sv:
            target.add(sv)


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def run_constraint_packs(
    normalized_tables: dict,
    manufacturing_dna: dict | None = None,
    evidence: dict | None = None,
) -> dict:
    """
    Run all registered constraint packs and collect candidates.

    Input:
        normalized_tables: {table_name: [row_dict, ...]}
        manufacturing_dna:  output of detect_manufacturing_dna()["manufacturing_dna"]
        evidence:           pre-built evidence corpus (built automatically if None)

    Output: {
        "pack_candidates": [...],
        "activated_packs": [{"pack_name", "activated", "confidence", "reason",
                              "num_candidates", "warnings"}],
        "evidence_corpus": {...},
        "errors": [...],
        "warnings": [...]
    }

    Safety guarantee: one pack failure never crashes the whole runner.
    """
    from constraint_packs import load_constraint_packs

    errors: list[str] = []
    warnings: list[str] = []

    # Build evidence corpus if not provided
    if evidence is None:
        try:
            evidence = build_evidence_corpus(normalized_tables, manufacturing_dna)
        except Exception as exc:
            errors.append(f"build_evidence_corpus failed: {exc}")
            evidence = {"text_corpus": "", "operation_names": [], "operation_families": [],
                        "machine_names": [], "machine_types": [], "product_families": [],
                        "material_names": [], "table_names": [], "column_names": [],
                        "business_rule_texts": [], "setup_changeover_families": []}

    # Load packs
    packs, load_warnings = load_constraint_packs()
    warnings.extend(load_warnings)

    pack_candidates: list[dict] = []
    activated_packs: list[dict] = []

    for pack in packs:
        pack_warnings: list[str] = []
        pack_candidates_local: list[dict] = []
        try:
            pack_candidates_local = pack.detect(normalized_tables, evidence)
            if not isinstance(pack_candidates_local, list):
                pack_candidates_local = []
                pack_warnings.append(
                    f"Pack '{pack.name}' returned non-list — ignoring."
                )
        except Exception as exc:
            pack_warnings.append(
                f"Pack '{pack.name}' raised an exception: {exc}"
            )
            pack_candidates_local = []

        activated = len(pack_candidates_local) > 0
        avg_conf = (
            sum(c.get("confidence", 0.0) for c in pack_candidates_local) /
            len(pack_candidates_local)
            if pack_candidates_local else 0.0
        )

        if activated:
            reasons = list({c["constraint_type"] for c in pack_candidates_local})
            reason_str = f"Detected: {', '.join(reasons[:4])}" + \
                         ("..." if len(reasons) > 4 else "")
        else:
            reason_str = "No matching evidence found in data"

        activated_packs.append({
            "pack_name": pack.name,
            "activated": activated,
            "confidence": round(avg_conf, 4),
            "reason": reason_str,
            "num_candidates": len(pack_candidates_local),
            "warnings": pack_warnings,
        })

        pack_candidates.extend(pack_candidates_local)
        if pack_warnings:
            warnings.extend(pack_warnings)

    # Deduplicate candidates by constraint_type + source_pack (keep highest confidence)
    pack_candidates = _deduplicate_candidates(pack_candidates)

    return {
        "pack_candidates": pack_candidates,
        "activated_packs": activated_packs,
        "evidence_corpus": evidence,
        "errors": errors,
        "warnings": warnings,
    }


def _deduplicate_candidates(candidates: list[dict]) -> list[dict]:
    """
    Remove duplicate candidates by (constraint_type, source_pack).
    Keeps the one with highest confidence.
    """
    seen: dict[tuple, dict] = {}
    for c in candidates:
        key = (c.get("constraint_type", ""), c.get("source_pack", ""))
        existing = seen.get(key)
        if existing is None or c.get("confidence", 0) > existing.get("confidence", 0):
            seen[key] = c
    return list(seen.values())
