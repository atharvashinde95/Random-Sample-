"""
Constraint candidate discovery tool.

Discovers common manufacturing scheduling constraint candidates from
normalized tables. Does NOT modify the CP-SAT model.
Candidates are NOT enforced — they are proposals for review.
"""
from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _has_role(sheet_mapping: dict, role: str) -> bool:
    return role in sheet_mapping.values()


def _get_sheets_for_role(sheet_mapping: dict, role: str) -> list[str]:
    return [s for s, r in sheet_mapping.items() if r == role]


def _get_rows(normalized_tables: dict, role: str, sheet_mapping: dict) -> list[dict]:
    rows: list[dict] = []
    for s in _get_sheets_for_role(sheet_mapping, role):
        rows.extend(normalized_tables.get(s, []))
    return rows


def _col_in_rows(rows: list[dict], col: str) -> bool:
    return any(row.get(col) is not None for row in rows)


def _col_in_mapping(column_mapping: dict, role: str, sheet_mapping: dict, col: str) -> bool:
    for s in _get_sheets_for_role(sheet_mapping, role):
        if col in column_mapping.get(s, {}).values():
            return True
    return False


def _any_col_in_mapping(column_mapping: dict, role: str, sheet_mapping: dict, cols: list[str]) -> bool:
    return any(_col_in_mapping(column_mapping, role, sheet_mapping, c) for c in cols)


def _available_fields(
    required_fields: list[str],
    rows: list[dict],
    column_mapping: dict,
    role: str,
    sheet_mapping: dict,
) -> tuple[list[str], list[str]]:
    """Return (available, missing) from required_fields."""
    available = []
    missing = []
    for f in required_fields:
        if _col_in_rows(rows, f) or _col_in_mapping(column_mapping, role, sheet_mapping, f):
            available.append(f)
        else:
            missing.append(f)
    return available, missing


def _make_candidate(
    constraint_type: str,
    confidence: float,
    evidence: list[str],
    required_fields: list[str],
    available_fields: list[str],
    missing_fields: list[str],
    recommended_enforcement: str,
    source_role: str,
    source_table: str | None = None,
) -> dict:
    return {
        "constraint_type": constraint_type,
        "confidence": round(confidence, 4),
        "evidence": evidence,
        "required_fields": required_fields,
        "available_fields": available_fields,
        "missing_fields": missing_fields,
        "recommended_enforcement": recommended_enforcement,
        "source": {"role": source_role, "table": source_table},
        "status": "candidate",
    }


# ---------------------------------------------------------------------------
# Individual constraint detectors
# ---------------------------------------------------------------------------

def _detect_demand_fulfillment(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_demand"):
        return None
    rows = _get_rows(normalized_tables, "Demand_Orders", sheet_mapping)
    evidence = ["Demand_Orders detected"]
    required = ["product_id", "quantity", "due_date"]
    available, missing = _available_fields(required, rows, column_mapping, "Demand_Orders", sheet_mapping)
    if "product_id" in available:
        evidence.append("product_id present")
    if "quantity" in available:
        evidence.append("quantity present")
    if "due_date" in available:
        evidence.append("due_date present")
    conf = 0.6 + 0.13 * len(available)
    table = _get_sheets_for_role(sheet_mapping, "Demand_Orders")
    return _make_candidate(
        "demand_fulfillment", min(1.0, conf), evidence,
        required, available, missing, "hard",
        "Demand_Orders", table[0] if table else None,
    )


def _detect_operation_precedence(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_routing"):
        return None
    rows = _get_rows(normalized_tables, "Routing", sheet_mapping)
    evidence = ["Routing table detected"]
    required = ["product_id", "stage_sequence", "runtime_minutes_per_batch"]
    available, missing = _available_fields(required, rows, column_mapping, "Routing", sheet_mapping)
    if "stage_sequence" in available:
        evidence.append("stage_sequence column present")
    # Check for multiple operations per product
    from collections import Counter
    pid_counts: Counter = Counter(
        row.get("product_id") for row in rows if row.get("product_id") is not None
    )
    if any(c > 1 for c in pid_counts.values()):
        evidence.append("multiple operations per product detected")
    conf = 0.65 + 0.11 * len(available)
    table = _get_sheets_for_role(sheet_mapping, "Routing")
    return _make_candidate(
        "operation_precedence", min(1.0, conf), evidence,
        required, available, missing, "hard",
        "Routing", table[0] if table else None,
    )


def _detect_machine_capacity_no_overlap(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_machines"):
        return None
    rows = _get_rows(normalized_tables, "Machine_Master", sheet_mapping)
    evidence = ["Machine_Master detected"]
    required = ["machine_id"]
    available, missing = _available_fields(required, rows, column_mapping, "Machine_Master", sheet_mapping)
    if "machine_id" in available:
        evidence.append("machine_id present")
    if dna.get("has_machine_capacity"):
        evidence.append("capacity field detected")
    conf = 0.90 if available else 0.60
    table = _get_sheets_for_role(sheet_mapping, "Machine_Master")
    return _make_candidate(
        "machine_capacity_no_overlap", conf, evidence,
        required, available, missing, "hard",
        "Machine_Master", table[0] if table else None,
    )


def _detect_machine_eligibility(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_routing"):
        return None
    rows = _get_rows(normalized_tables, "Routing", sheet_mapping)
    evidence = []
    required = ["eligible_machines"]
    optional_alt = ["machine_type"]

    has_eligible = _col_in_rows(rows, "eligible_machines") or _col_in_mapping(
        column_mapping, "Routing", sheet_mapping, "eligible_machines"
    )
    has_machine_type = _col_in_rows(rows, "machine_type") or _col_in_mapping(
        column_mapping, "Routing", sheet_mapping, "machine_type"
    )

    if has_eligible:
        evidence.append("eligible_machines column in Routing")
        available = ["eligible_machines"]
        missing = []
        conf = 0.95
    elif has_machine_type:
        evidence.append("machine_type column in Routing (used for eligibility matching)")
        available = ["machine_type"]
        missing = ["eligible_machines"]
        conf = 0.80
    else:
        return None

    if dna.get("has_machines"):
        evidence.append("Machine_Master present for cross-reference")

    table = _get_sheets_for_role(sheet_mapping, "Routing")
    return _make_candidate(
        "machine_eligibility", conf, evidence,
        required, available, missing, "hard",
        "Routing", table[0] if table else None,
    )


def _detect_processing_time(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_routing"):
        return None
    rows = _get_rows(normalized_tables, "Routing", sheet_mapping)
    evidence = ["Routing detected"]
    required = ["runtime_minutes_per_batch"]
    available, missing = _available_fields(required, rows, column_mapping, "Routing", sheet_mapping)
    if available:
        evidence.append("runtime_minutes_per_batch present")
        conf = 0.98
    else:
        conf = 0.50
    table = _get_sheets_for_role(sheet_mapping, "Routing")
    return _make_candidate(
        "processing_time", conf, evidence,
        required, available, missing, "hard",
        "Routing", table[0] if table else None,
    )


def _detect_due_date_tardiness(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_due_dates"):
        return None
    rows = _get_rows(normalized_tables, "Demand_Orders", sheet_mapping)
    evidence = ["due_date found in Demand_Orders"]
    required = ["due_date"]
    optional = ["priority_class", "priority_weight", "late_penalty_per_unit_per_day"]
    available, missing = _available_fields(required, rows, column_mapping, "Demand_Orders", sheet_mapping)
    opt_available = [f for f in optional if _col_in_rows(rows, f) or _col_in_mapping(
        column_mapping, "Demand_Orders", sheet_mapping, f
    )]
    if opt_available:
        evidence.append(f"optional fields present: {opt_available}")
    conf = 0.88 + 0.04 * len(opt_available)
    table = _get_sheets_for_role(sheet_mapping, "Demand_Orders")
    return _make_candidate(
        "due_date_tardiness", min(1.0, conf), evidence,
        required, available, missing, "soft",
        "Demand_Orders", table[0] if table else None,
    )


def _detect_priority_weighting(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_priorities"):
        return None
    rows = _get_rows(normalized_tables, "Demand_Orders", sheet_mapping)
    evidence = []
    has_class = _col_in_rows(rows, "priority_class")
    has_weight = _col_in_rows(rows, "priority_weight")
    if has_class:
        evidence.append("priority_class in Demand_Orders")
    if has_weight:
        evidence.append("priority_weight in Demand_Orders")
    if not evidence:
        return None
    required = ["priority_class"]
    available = ["priority_class"] if has_class else []
    missing = [] if has_class else ["priority_class"]
    conf = 0.85
    table = _get_sheets_for_role(sheet_mapping, "Demand_Orders")
    return _make_candidate(
        "priority_weighting", conf, evidence,
        required, available, missing, "soft",
        "Demand_Orders", table[0] if table else None,
    )


def _detect_batch_size_rules(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    sku_rows = _get_rows(normalized_tables, "SKU_Master", sheet_mapping)
    routing_rows = _get_rows(normalized_tables, "Routing", sheet_mapping)
    evidence = []
    batch_cols = ["min_batch_size", "max_batch_size", "batch_multiple", "batch_size", "batch_capacity"]
    found = []
    for col in batch_cols:
        if _col_in_rows(sku_rows, col) or _col_in_rows(routing_rows, col):
            found.append(col)
            evidence.append(f"{col} found")
    if not found:
        return None
    conf = 0.70 + 0.05 * len(found)
    role = "SKU_Master" if _has_role(sheet_mapping, "SKU_Master") else "Routing"
    tables = _get_sheets_for_role(sheet_mapping, role)
    return _make_candidate(
        "batch_size_rules", min(1.0, conf), evidence,
        batch_cols[:3], found, [c for c in batch_cols[:3] if c not in found], "hard",
        role, tables[0] if tables else None,
    )


def _detect_setup_changeover(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_setup_changeover"):
        return None
    rows = _get_rows(normalized_tables, "Setup_Changeover", sheet_mapping)
    evidence = ["Setup_Changeover table detected"]
    required = ["from_family", "to_family", "setup_minutes"]
    available, missing = _available_fields(required, rows, column_mapping, "Setup_Changeover", sheet_mapping)
    for f in available:
        evidence.append(f"{f} present")
    conf = 0.65 + 0.12 * len(available)
    table = _get_sheets_for_role(sheet_mapping, "Setup_Changeover")
    return _make_candidate(
        "setup_changeover", min(1.0, conf), evidence,
        required, available, missing, "hard",
        "Setup_Changeover", table[0] if table else None,
    )


def _detect_cleaning_changeover(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    rows = _get_rows(normalized_tables, "Setup_Changeover", sheet_mapping)
    if not rows:
        return None
    evidence = []
    has_cleaning = _col_in_rows(rows, "cleaning_minutes") or _col_in_mapping(
        column_mapping, "Setup_Changeover", sheet_mapping, "cleaning_minutes"
    )
    has_cleaning_cost = _col_in_rows(rows, "cleaning_cost")
    if has_cleaning:
        evidence.append("cleaning_minutes in Setup_Changeover")
    if has_cleaning_cost:
        evidence.append("cleaning_cost in Setup_Changeover")
    if not evidence:
        return None
    required = ["from_family", "to_family", "cleaning_minutes"]
    available = ["cleaning_minutes"] if has_cleaning else []
    missing = [f for f in required if f not in available]
    for f in ["from_family", "to_family"]:
        if _col_in_rows(rows, f):
            available.append(f)
            if f in missing:
                missing.remove(f)
    conf = 0.80
    table = _get_sheets_for_role(sheet_mapping, "Setup_Changeover")
    return _make_candidate(
        "cleaning_changeover", conf, evidence,
        required, available, missing, "hard",
        "Setup_Changeover", table[0] if table else None,
    )


def _detect_wait_between_operations(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    routing_rows = _get_rows(normalized_tables, "Routing", sheet_mapping)
    evidence = []
    has_min = _col_in_rows(routing_rows, "min_wait_minutes")
    has_max = _col_in_rows(routing_rows, "max_wait_minutes")
    # Also check Business_Rules for wait-related text
    br_rows = _get_rows(normalized_tables, "Business_Rules", sheet_mapping)
    br_wait = any(
        "wait" in str(row.get("rule_text", "")).lower() or
        "wait" in str(row.get("description", "")).lower()
        for row in br_rows
    )
    if has_min:
        evidence.append("min_wait_minutes in Routing")
    if has_max:
        evidence.append("max_wait_minutes in Routing")
    if br_wait:
        evidence.append("wait-related rule text in Business_Rules")
    if not evidence:
        return None
    required = ["min_wait_minutes"]
    available = []
    if has_min:
        available.append("min_wait_minutes")
    if has_max:
        available.append("max_wait_minutes")
    missing = [f for f in required if f not in available]
    conf = 0.85
    table = _get_sheets_for_role(sheet_mapping, "Routing")
    return _make_candidate(
        "wait_between_operations", conf, evidence,
        required, available, missing, "hard",
        "Routing", table[0] if table else None,
    )


def _detect_quality_hold_release(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_quality_hold"):
        return None
    sku_rows = _get_rows(normalized_tables, "SKU_Master", sheet_mapping)
    evidence = ["qa_release_hours detected in SKU_Master"]
    routing_rows = _get_rows(normalized_tables, "Routing", sheet_mapping)
    qa_op = any(
        "qa" in str(row.get("operation_name", "")).lower() or
        "qc" in str(row.get("operation_name", "")).lower() or
        "hold" in str(row.get("operation_name", "")).lower()
        for row in routing_rows
    )
    if qa_op:
        evidence.append("QA/QC operation found in Routing")
    required = ["qa_release_hours"]
    available = ["qa_release_hours"] if _col_in_rows(sku_rows, "qa_release_hours") else []
    missing = [f for f in required if f not in available]
    conf = 0.88
    table = _get_sheets_for_role(sheet_mapping, "SKU_Master")
    return _make_candidate(
        "quality_hold_release", conf, evidence,
        required, available, missing, "hard",
        "SKU_Master", table[0] if table else None,
    )


def _detect_machine_calendar_availability(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_calendar"):
        return None
    rows = _get_rows(normalized_tables, "Machine_Calendar", sheet_mapping)
    evidence = ["Machine_Calendar detected"]
    required = ["machine_id", "available"]
    available, missing = _available_fields(required, rows, column_mapping, "Machine_Calendar", sheet_mapping)
    for f in available:
        evidence.append(f"{f} present")
    conf = 0.65 + 0.15 * len(available)
    table = _get_sheets_for_role(sheet_mapping, "Machine_Calendar")
    return _make_candidate(
        "machine_calendar_availability", min(1.0, conf), evidence,
        required, available, missing, "hard",
        "Machine_Calendar", table[0] if table else None,
    )


def _detect_maintenance_downtime(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_maintenance"):
        return None
    rows = _get_rows(normalized_tables, "Maintenance", sheet_mapping)
    evidence = ["Maintenance table detected"]
    required = ["machine_id", "start", "end"]
    available, missing = _available_fields(required, rows, column_mapping, "Maintenance", sheet_mapping)
    for f in available:
        evidence.append(f"{f} present")
    conf = 0.65 + 0.12 * len(available)
    table = _get_sheets_for_role(sheet_mapping, "Maintenance")
    return _make_candidate(
        "maintenance_downtime", min(1.0, conf), evidence,
        required, available, missing, "hard",
        "Maintenance", table[0] if table else None,
    )


def _detect_material_inventory(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    has_bom = dna.get("has_bom")
    has_inv = dna.get("has_inventory")
    if not (has_bom and has_inv):
        return None
    evidence = ["BOM and Inventory both detected"]
    bom_rows = _get_rows(normalized_tables, "BOM", sheet_mapping)
    inv_rows = _get_rows(normalized_tables, "Inventory", sheet_mapping)
    if _col_in_rows(bom_rows, "quantity_required"):
        evidence.append("quantity_required in BOM")
    if _col_in_rows(inv_rows, "opening_inventory"):
        evidence.append("opening_inventory in Inventory")
    required = ["component_id", "quantity_required", "opening_inventory"]
    available = []
    if _col_in_rows(bom_rows, "component_id"):
        available.append("component_id")
    if _col_in_rows(bom_rows, "quantity_required"):
        available.append("quantity_required")
    if _col_in_rows(inv_rows, "opening_inventory"):
        available.append("opening_inventory")
    missing = [f for f in required if f not in available]
    conf = 0.65 + 0.12 * len(available)
    table_b = _get_sheets_for_role(sheet_mapping, "BOM")
    return _make_candidate(
        "material_inventory", min(1.0, conf), evidence,
        required, available, missing, "soft",
        "BOM", table_b[0] if table_b else None,
    )


def _detect_material_receipts(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not _has_role(sheet_mapping, "Material_Receipts"):
        return None
    rows = _get_rows(normalized_tables, "Material_Receipts", sheet_mapping)
    evidence = ["Material_Receipts table detected"]
    required = ["item_id", "receipt_date", "receipt_qty"]
    available, missing = _available_fields(required, rows, column_mapping, "Material_Receipts", sheet_mapping)
    for f in available:
        evidence.append(f"{f} present")
    conf = 0.65 + 0.12 * len(available)
    table = _get_sheets_for_role(sheet_mapping, "Material_Receipts")
    return _make_candidate(
        "material_receipts", min(1.0, conf), evidence,
        required, available, missing, "soft",
        "Material_Receipts", table[0] if table else None,
    )


def _detect_shelf_life_freshness(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    sku_rows = _get_rows(normalized_tables, "SKU_Master", sheet_mapping)
    evidence = []
    shelf_cols = ["shelf_life_days", "shelf_life_hours"]
    found = [c for c in shelf_cols if _col_in_rows(sku_rows, c)]
    if not found:
        return None
    for f in found:
        evidence.append(f"{f} in SKU_Master")
    required = ["shelf_life_days"]
    available = found
    missing = [f for f in required if f not in available]
    conf = 0.85
    table = _get_sheets_for_role(sheet_mapping, "SKU_Master")
    return _make_candidate(
        "shelf_life_freshness", conf, evidence,
        required, available, missing, "hard",
        "SKU_Master", table[0] if table else None,
    )


def _detect_labor_shift_capacity(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_labor"):
        return None
    rows = _get_rows(normalized_tables, "Labor_Shifts", sheet_mapping)
    evidence = ["Labor_Shifts table detected"]
    required = ["skill", "available_count"]
    available, missing = _available_fields(required, rows, column_mapping, "Labor_Shifts", sheet_mapping)
    for f in available:
        evidence.append(f"{f} present")
    conf = 0.65 + 0.15 * len(available)
    table = _get_sheets_for_role(sheet_mapping, "Labor_Shifts")
    return _make_candidate(
        "labor_shift_capacity", min(1.0, conf), evidence,
        required, available, missing, "soft",
        "Labor_Shifts", table[0] if table else None,
    )


def _detect_overtime_capacity(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_overtime"):
        return None
    evidence = ["overtime-related fields detected"]
    required = ["overtime_minutes"]
    available: list[str] = []
    missing = ["overtime_minutes"]
    conf = 0.65
    return _make_candidate(
        "overtime_capacity", conf, evidence,
        required, available, missing, "soft",
        "Labor_Shifts", None,
    )


def _detect_cost_objective_terms(
    normalized_tables: dict, sheet_mapping: dict,
    column_mapping: dict, dna: dict,
) -> dict | None:
    if not dna.get("has_costs"):
        return None
    evidence = []
    cost_terms = []
    mm_rows = _get_rows(normalized_tables, "Machine_Master", sheet_mapping)
    if _col_in_rows(mm_rows, "hourly_cost"):
        evidence.append("hourly_cost in Machine_Master")
        cost_terms.append("machine_hourly_cost")
    sku_rows = _get_rows(normalized_tables, "SKU_Master", sheet_mapping)
    if _col_in_rows(sku_rows, "holding_cost_per_unit_per_day"):
        evidence.append("holding_cost in SKU_Master")
        cost_terms.append("holding_cost")
    if _col_in_rows(sku_rows, "selling_price_per_unit"):
        evidence.append("selling_price in SKU_Master")
        cost_terms.append("selling_price")
    do_rows = _get_rows(normalized_tables, "Demand_Orders", sheet_mapping)
    if _col_in_rows(do_rows, "late_penalty_per_unit_per_day"):
        evidence.append("late_penalty in Demand_Orders")
        cost_terms.append("tardiness_penalty")
    sc_rows = _get_rows(normalized_tables, "Setup_Changeover", sheet_mapping)
    if _col_in_rows(sc_rows, "setup_cost") or _col_in_rows(sc_rows, "cleaning_cost"):
        evidence.append("setup/cleaning cost in Setup_Changeover")
        cost_terms.append("setup_cost")
    if not evidence:
        return None
    conf = 0.70 + 0.05 * len(cost_terms)
    return _make_candidate(
        "cost_objective_terms", min(1.0, conf), evidence,
        cost_terms, cost_terms, [], "soft",
        "Multiple", None,
    )


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

DETECTORS = [
    _detect_demand_fulfillment,
    _detect_operation_precedence,
    _detect_machine_capacity_no_overlap,
    _detect_machine_eligibility,
    _detect_processing_time,
    _detect_due_date_tardiness,
    _detect_priority_weighting,
    _detect_batch_size_rules,
    _detect_setup_changeover,
    _detect_cleaning_changeover,
    _detect_wait_between_operations,
    _detect_quality_hold_release,
    _detect_machine_calendar_availability,
    _detect_maintenance_downtime,
    _detect_material_inventory,
    _detect_material_receipts,
    _detect_shelf_life_freshness,
    _detect_labor_shift_capacity,
    _detect_overtime_capacity,
    _detect_cost_objective_terms,
]


def discover_constraint_candidates(
    normalized_tables: dict,
    sheet_mapping: dict[str, str],
    column_mapping: dict[str, dict[str, str]],
    manufacturing_dna: dict,
) -> dict:
    """
    Discover constraint candidates from the manufacturing dataset.

    Input:
        normalized_tables: {sheet_name: [row_dict, ...]}
        sheet_mapping: {raw_sheet: canonical_role}
        column_mapping: {raw_sheet: {raw_col: canonical_col}}
        manufacturing_dna: output of detect_manufacturing_dna()["manufacturing_dna"]

    Output: {
        "constraint_candidates": [...],
        "errors": [...],
        "warnings": [...]
    }

    NOTE: Candidates are NOT enforced. They are proposals for review.
    """
    errors: list[str] = []
    warnings: list[str] = []
    candidates: list[dict] = []

    dna = manufacturing_dna if isinstance(manufacturing_dna, dict) else {}

    for detector in DETECTORS:
        try:
            result = detector(normalized_tables, sheet_mapping, column_mapping, dna)
            if result is not None:
                candidates.append(result)
        except Exception as exc:
            errors.append(f"Constraint detector '{detector.__name__}' failed: {exc}")

    # Sort by confidence descending
    candidates.sort(key=lambda c: -c["confidence"])

    if not candidates:
        warnings.append(
            "No constraint candidates were discovered. "
            "Ensure the dataset has at least Demand_Orders, Routing, and Machine_Master."
        )

    return {
        "constraint_candidates": candidates,
        "errors": errors,
        "warnings": warnings,
    }
