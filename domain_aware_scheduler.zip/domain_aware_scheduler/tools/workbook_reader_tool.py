from __future__ import annotations

import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def _json_safe(value: Any) -> Any:
    """Convert a single value to a JSON-serializable Python type."""
    if value is None:
        return None
    # pandas NA / NaT check (safe for all types)
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    # numpy scalars
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        f = float(value)
        return None if (math.isnan(f) or math.isinf(f)) else f
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, np.ndarray):
        return [_json_safe(v) for v in value.tolist()]
    # pandas Timestamp
    if isinstance(value, pd.Timestamp):
        return None if pd.isna(value) else value.isoformat()
    # stdlib datetime / date
    from datetime import datetime, date
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    # plain float
    if isinstance(value, float):
        return None if (math.isnan(value) or math.isinf(value)) else value
    # bytes
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def _dataframe_profile(df: pd.DataFrame, sample_size: int = 5) -> dict:
    """Return a JSON-serializable profile dict for a DataFrame. Never returns DataFrame."""
    columns = [str(c) for c in df.columns]
    row_count = len(df)
    dtypes = {str(c): str(t) for c, t in df.dtypes.items()}

    sample_rows = []
    for _, row in df.head(sample_size).iterrows():
        sample_rows.append({str(k): _json_safe(v) for k, v in row.items()})

    return {
        "columns": columns,
        "row_count": row_count,
        "sample_rows": sample_rows,
        "dtypes": dtypes,
    }


def read_workbook(file_path: str, sample_size: int = 5) -> dict:
    """
    Read an uploaded Excel (.xlsx / .xls) or CSV file.

    Returns a JSON-serializable dict:
    {
        "file_path": str,
        "file_type": "xlsx" | "xls" | "csv" | None,
        "sheets": { sheet_name: { columns, row_count, sample_rows, dtypes } },
        "sheet_names": [str],
        "errors": [str],
        "warnings": [str]
    }
    """
    errors: list[str] = []
    warnings: list[str] = []

    def _empty(extra_errors: list[str]) -> dict:
        return {
            "file_path": file_path,
            "file_type": None,
            "sheets": {},
            "sheet_names": [],
            "errors": extra_errors,
            "warnings": warnings,
        }

    if not file_path:
        return _empty(["file_path is required."])

    path = Path(file_path)
    if not path.exists():
        return _empty([f"File not found: {file_path}"])

    ext = path.suffix.lower().lstrip(".")
    if ext not in ("xlsx", "xls", "csv"):
        return _empty([f"Unsupported file type: .{ext}. Supported: .xlsx, .xls, .csv"])

    sheets: dict = {}
    sheet_names: list[str] = []

    if ext in ("xlsx", "xls"):
        try:
            excel_file = pd.ExcelFile(str(path))
        except Exception as exc:
            return {
                "file_path": file_path,
                "file_type": ext,
                "sheets": {},
                "sheet_names": [],
                "errors": [f"Could not open Excel file: {exc}"],
                "warnings": warnings,
            }

        for raw_name in excel_file.sheet_names:
            try:
                df = pd.read_excel(excel_file, sheet_name=raw_name, header=0)
                df = df.dropna(how="all")
                name = str(raw_name)
                sheets[name] = _dataframe_profile(df, sample_size)
                sheet_names.append(name)
            except Exception as exc:
                warnings.append(f"Could not read sheet '{raw_name}': {exc}")

    else:  # csv
        try:
            df = pd.read_csv(str(path), header=0)
            df = df.dropna(how="all")
            sheets["CSV_Data"] = _dataframe_profile(df, sample_size)
            sheet_names.append("CSV_Data")
        except Exception as exc:
            return {
                "file_path": file_path,
                "file_type": ext,
                "sheets": {},
                "sheet_names": [],
                "errors": [f"Could not read CSV file: {exc}"],
                "warnings": warnings,
            }

    if not sheets:
        errors.append("No sheets could be successfully read from the file.")

    return {
        "file_path": str(file_path),
        "file_type": ext,
        "sheets": sheets,
        "sheet_names": sheet_names,
        "errors": errors,
        "warnings": warnings,
    }
