from __future__ import annotations

import re
from typing import Optional

# ---------------------------------------------------------------------------
# Canonical sheet roles and their deterministic aliases
# ---------------------------------------------------------------------------

SHEET_ROLE_ALIASES: dict[str, list[str]] = {
    "Demand_Orders": [
        "demand_orders", "orders", "order", "customer_orders", "sales_orders",
        "order_data", "orders_data", "demand", "demand_forecast",
    ],
    "SKU_Master": [
        "sku_master", "sku", "skus", "products", "product_info",
        "product_master", "items", "item_master",
    ],
    "Inventory": [
        "inventory", "stock", "current_stock", "raw_inventory",
        "material_inventory",
    ],
    "BOM": [
        "bom", "bill_of_materials", "recipe", "formula", "formulas",
        "ingredients", "material_recipe",
    ],
    "Routing": [
        "routing", "route", "process_flow", "operations", "operation_master",
        "process", "process_plan",
    ],
    "Machine_Master": [
        "machine_master", "machines", "machine", "equipment",
        "equipment_list", "resources", "resource_master",
    ],
    "Machine_Calendar": [
        "machine_calendar", "calendar", "shift_calendar", "working_calendar",
        "availability", "machine_availability",
    ],
    "Setup_Changeover": [
        "setup_changeover", "changeover", "setup", "cleaning_matrix",
        "setup_matrix", "changeover_matrix",
    ],
    "Maintenance": [
        "maintenance", "downtime", "planned_downtime", "machine_downtime",
    ],
    "Labor_Shifts": [
        "labor_shifts", "shifts", "labor", "workforce", "operators",
    ],
    "Cost_Parameters": [
        "cost_parameters", "costs", "cost", "pricing", "financials",
    ],
    "Business_Rules": [
        "business_rules", "rules", "constraints", "policies",
    ],
    "Material_Receipts": [
        "material_receipts", "receipts", "incoming_materials",
        "purchase_orders", "inbound_materials",
    ],
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize_name(name: str) -> str:
    """Lowercase, replace spaces/hyphens with underscores, strip punctuation."""
    if not name:
        return ""
    text = str(name).lower().strip()
    text = re.sub(r"[\s\-]+", "_", text)
    text = re.sub(r"[^a-z0-9_]", "", text)
    return text


def _simple_similarity(a: str, b: str) -> float:
    """
    Character bigram overlap (Jaccard) similarity between two strings.
    Returns 0.0–1.0.
    """
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0

    def bigrams(s: str) -> set[str]:
        return {s[i : i + 2] for i in range(len(s) - 1)}

    bg_a = bigrams(a)
    bg_b = bigrams(b)
    if not bg_a or not bg_b:
        return 0.0

    intersection = bg_a & bg_b
    union = bg_a | bg_b
    return len(intersection) / len(union)


def _best_role_match(sheet_name: str) -> tuple[Optional[str], float, str]:
    """
    Match a raw sheet name to the best canonical role.
    Returns (role | None, confidence, method).

    Priority:
      1. Exact alias match       → confidence 1.0,  method "alias"
      2. Substring alias match   → confidence 0.85, method "substring"
      3. Bigram similarity ≥0.70 → confidence sim,  method "similarity"
      4. No match                → None, 0.0, "none"
    """
    norm = _normalize_name(sheet_name)

    # 1. Exact alias
    for role, aliases in SHEET_ROLE_ALIASES.items():
        if norm in aliases:
            return role, 1.0, "alias"

    # 2. Substring
    for role, aliases in SHEET_ROLE_ALIASES.items():
        for alias in aliases:
            if alias and (alias in norm or norm in alias):
                return role, 0.85, "substring"

    # 3. Similarity
    best_role: Optional[str] = None
    best_sim = 0.0
    for role, aliases in SHEET_ROLE_ALIASES.items():
        for alias in aliases:
            sim = _simple_similarity(norm, alias)
            if sim > best_sim:
                best_sim = sim
                best_role = role

    if best_sim >= 0.70:
        return best_role, round(best_sim, 4), "similarity"

    return None, 0.0, "none"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect_sheet_mapping(
    workbook_profile: dict,
    domain_profile: Optional[dict] = None,
) -> dict:
    """
    Map raw workbook sheet names to canonical sheet roles.

    Returns:
    {
        "sheet_mapping":   { raw_name: canonical_role },
        "confidence":      { raw_name: float },
        "method":          { raw_name: "alias" | "substring" | "similarity" },
        "unmapped_sheets": [str],
        "errors":          [str],
        "warnings":        [str]
    }
    """
    errors: list[str] = []
    warnings: list[str] = []
    sheet_mapping: dict[str, str] = {}
    confidence: dict[str, float] = {}
    method: dict[str, str] = {}
    unmapped_sheets: list[str] = []

    sheet_names: list[str] = workbook_profile.get("sheet_names", [])
    if not sheet_names:
        warnings.append("No sheet names found in workbook_profile.")
        return {
            "sheet_mapping": {},
            "confidence": {},
            "method": {},
            "unmapped_sheets": [],
            "errors": errors,
            "warnings": warnings,
        }

    for raw_name in sheet_names:
        role, conf, match_method = _best_role_match(raw_name)
        if role:
            sheet_mapping[raw_name] = role
            confidence[raw_name] = conf
            method[raw_name] = match_method
        else:
            unmapped_sheets.append(raw_name)
            warnings.append(
                f"Sheet '{raw_name}' could not be mapped to a canonical role."
            )

    return {
        "sheet_mapping": sheet_mapping,
        "confidence": confidence,
        "method": method,
        "unmapped_sheets": unmapped_sheets,
        "errors": errors,
        "warnings": warnings,
    }
