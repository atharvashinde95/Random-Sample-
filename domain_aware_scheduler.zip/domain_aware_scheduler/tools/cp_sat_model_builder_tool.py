from __future__ import annotations

from datetime import datetime
from typing import Any

from ortools.sat.python import cp_model


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _parse_dt(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(str(value))


def _dt_to_minutes(dt: datetime, reference: datetime, clamp_to_zero: bool = False) -> int:
    """Convert dt to minutes offset from reference. Negative for past timestamps."""
    delta = dt - reference
    minutes = int(delta.total_seconds() // 60)
    return max(0, minutes) if clamp_to_zero else minutes


def _build_availability_intervals(
    machine_id: str,
    calendars: list[dict],
    reference: datetime,
    horizon_minutes: int,
) -> list[tuple[int, int]]:
    """Return sorted list of (start_min, end_min) available windows for a machine."""
    windows: list[tuple[int, int]] = []
    for cal in calendars:
        if cal.get("machine_id") != machine_id:
            continue
        if not cal.get("available", True):
            continue
        s = max(0, _dt_to_minutes(_parse_dt(cal["start"]), reference))
        e = min(horizon_minutes, _dt_to_minutes(_parse_dt(cal["end"]), reference))
        if e > s:
            windows.append((s, e))
    if not windows:
        windows.append((0, horizon_minutes))
    windows.sort()
    return windows


def _merge_availability(windows: list[tuple[int, int]]) -> list[tuple[int, int]]:
    merged: list[tuple[int, int]] = []
    for s, e in sorted(windows):
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))
    return merged


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_cp_sat_model(
    payload: dict,
    solve_config: dict | None = None,
) -> dict:
    """
    Translate a canonical SolverPayload dict into an OR-Tools CP-SAT model.

    Returns:
    {
        "model":             CpModel instance or None on validation failure,
        "vars":              { job_id: { op_idx: { "start", "end", "interval",
                                                    "machine_assignments": {machine_id: BoolVar} } } },
        "horizon_minutes":   int,
        "reference":         datetime,
        "job_order":         [job_id, ...],
        "machine_intervals": { machine_id: [IntervalVar, ...] },
        "machine_demands":   { machine_id: [int, ...] },
        "objective_terms":   [LinearExpr, ...],
        "errors":            [str],
        "warnings":          [str],
        "debug":             {},
    }
    """
    errors: list[str] = []
    warnings: list[str] = []

    # FIX 2 — validate payload with Pydantic before touching it
    try:
        from schemas.canonical_schema import SolverPayload as _SP
        payload_model = _SP(**payload)
        payload = payload_model.model_dump(mode="json")
    except Exception as exc:
        return {
            "model": None,
            "vars": {},
            "horizon_minutes": 0,
            "reference": None,
            "job_order": [],
            "machine_intervals": {},
            "machine_demands": {},
            "objective_terms": [],
            "errors": [f"SolverPayload validation failed before CP-SAT build: {exc}"],
            "warnings": [],
            "debug": {},
        }

    cfg = solve_config or {}
    reference = _parse_dt(payload["reference_time"])
    horizon_seconds = int(payload.get("horizon_seconds", 86400 * 14))
    horizon_minutes = max(1, horizon_seconds // 60)

    jobs: list[dict] = payload.get("jobs", [])
    machines: list[dict] = payload.get("machines", [])
    calendars: list[dict] = payload.get("calendars", [])
    setup_rules: list[dict] = payload.get("setup_rules", [])
    cleaning_rules: list[dict] = payload.get("cleaning_rules", [])
    wait_rules: list[dict] = payload.get("wait_rules", [])
    quality_rules: list[dict] = payload.get("quality_rules", [])
    shared_resources: list[dict] = payload.get("shared_resources", [])
    obj_w: dict = payload.get("objective_weights", {})

    machine_ids = {m["machine_id"] for m in machines}
    machine_capacity = {m["machine_id"]: int(m.get("capacity", 1)) for m in machines}
    machines_map = {m["machine_id"]: m for m in machines}

    model = cp_model.CpModel()

    job_vars: dict[str, dict] = {}
    machine_intervals: dict[str, list] = {mid: [] for mid in machine_ids}
    machine_demands: dict[str, list[int]] = {mid: [] for mid in machine_ids}
    objective_terms: list = []

    # -----------------------------------------------------------------------
    # Weights (scaled to integer; CP-SAT requires integer objectives)
    # -----------------------------------------------------------------------
    SCALE = 100
    tard_w = max(0, int(float(obj_w.get("tardiness_weight", 1.0)) * SCALE))
    setup_w = max(0, int(float(obj_w.get("setup_weight", 1.0)) * SCALE))
    clean_w = max(0, int(float(obj_w.get("cleaning_weight", 1.0)) * SCALE))

    # -----------------------------------------------------------------------
    # Per-job, per-operation variables
    # -----------------------------------------------------------------------
    job_order: list[str] = []
    completion_vars: list = []  # last-op end vars for makespan objective

    for job in jobs:
        job_id: str = job["job_id"]
        job_order.append(job_id)

        # FIX 1 — allow negative due_minutes for backlog jobs
        due_dt = _parse_dt(job["due_at"])
        due_minutes = _dt_to_minutes(due_dt, reference, clamp_to_zero=False)
        if due_minutes < 0:
            warnings.append(
                f"Job {job_id} due date is before reference_time; "
                "treated as backlog/late risk."
            )

        ops = sorted(job.get("operations", []), key=lambda o: int(o.get("sequence", 1)))

        job_vars[job_id] = {}
        prev_end_var = None
        prev_op = None

        for op_idx, op in enumerate(ops):
            dur = int(op["duration_minutes"])
            eligible = [m for m in op.get("eligible_machines", []) if m in machine_ids]
            if not eligible:
                errors.append(
                    f"Job {job_id} op {op.get('op_id')}: no eligible machines in model."
                )
                continue

            start_var = model.NewIntVar(0, horizon_minutes, f"s_{job_id}_{op_idx}")
            end_var = model.NewIntVar(0, horizon_minutes, f"e_{job_id}_{op_idx}")
            interval_var = model.NewIntervalVar(
                start_var, dur, end_var, f"iv_{job_id}_{op_idx}"
            )

            machine_assignments: dict[str, Any] = {}

            for mid in eligible:
                b = model.NewBoolVar(f"b_{job_id}_{op_idx}_{mid}")
                machine_assignments[mid] = b
                opt_iv = model.NewOptionalIntervalVar(
                    start_var, dur, end_var, b, f"oiv_{job_id}_{op_idx}_{mid}"
                )
                machine_intervals[mid].append(opt_iv)
                machine_demands[mid].append(int(op.get("demand_load", 1)))

                # Exact machine running cost in objective (no scaling).
                # 1 unit = INR 1 of machine cost. Total range 4M-13M units.
                # Makespan ~15K units. Machine cost dominates 300:1 ->
                # solver always picks cheapest eligible machine -> max profit.
                hourly = float(machines_map.get(mid, {}).get("hourly_cost", 0.0))
                if hourly > 0:
                    cost_unit = int(dur * hourly / 60)
                    if cost_unit > 0:
                        objective_terms.append(b * cost_unit)

            model.AddExactlyOne(machine_assignments[mid] for mid in eligible)

            # Availability windows
            for mid in eligible:
                avail = _merge_availability(
                    _build_availability_intervals(mid, calendars, reference, horizon_minutes)
                )
                if len(avail) == 1 and avail[0] == (0, horizon_minutes):
                    pass  # full horizon available — no extra constraints
                else:
                    b = machine_assignments[mid]
                    window_choices = []
                    for ws, we in avail:
                        if we - ws >= dur:
                            wc = model.NewBoolVar(f"wc_{job_id}_{op_idx}_{mid}_{ws}")
                            model.Add(start_var >= ws).OnlyEnforceIf(wc)
                            model.Add(end_var <= we).OnlyEnforceIf(wc)
                            window_choices.append(wc)
                    if window_choices:
                        model.AddBoolOr(window_choices).OnlyEnforceIf(b)
                    else:
                        model.Add(machine_assignments[mid] == 0)
                        warnings.append(
                            f"Job {job_id} op {op.get('op_id')}: no available window "
                            f"fits duration {dur}m on machine {mid}."
                        )

            # Intra-job sequencing
            if prev_end_var is not None:
                min_gap = 0
                max_gap = None
                if prev_op is not None:
                    mw = prev_op.get("min_wait_to_next_minutes")
                    xw = prev_op.get("max_wait_to_next_minutes")
                    if mw is not None:
                        min_gap = int(mw)
                    if xw is not None:
                        max_gap = int(xw)
                model.Add(start_var >= prev_end_var + min_gap)
                if max_gap is not None:
                    model.Add(start_var <= prev_end_var + max_gap)

            job_vars[job_id][op_idx] = {
                "start": start_var,
                "end": end_var,
                "interval": interval_var,
                "machine_assignments": machine_assignments,
                "op": op,
            }
            prev_end_var = end_var
            prev_op = op

        # Tardiness + shelf life per job
        if job_vars.get(job_id):
            last_idx = max(job_vars[job_id].keys())
            last_end = job_vars[job_id][last_idx]["end"]
            completion_vars.append(last_end)

            # --- Tardiness (late penalty) ---
            # tard_var upper bound must cover backlog offset
            tard_ub = horizon_minutes - min(0, due_minutes)
            tard_var = model.NewIntVar(0, tard_ub, f"tard_{job_id}")
            model.AddMaxEquality(tard_var, [0, last_end - due_minutes])

            if tard_w > 0:
                pw = max(1, int(float(job.get("priority_weight", 1.0)) * SCALE))
                weight = (tard_w * pw) // SCALE
                if weight > 0:
                    objective_terms.append(tard_var * weight)

            # --- Shelf life: soft freshness penalty ---
            # A hard lower-bound on last_end can make the model infeasible when many
            # jobs compete for the same machines near their due dates.  Instead we
            # add a soft penalty: every minute the job completes before the freshness
            # window (due_at - shelf_life) costs the same as a tardiness minute.
            slm = job.get("shelf_life_minutes")
            if slm and slm > 0 and due_minutes > 0:
                freshness_lb = max(0, due_minutes - slm)
                if freshness_lb > 0 and tard_w > 0:
                    fresh_viol = model.NewIntVar(0, freshness_lb, f"fresh_{job_id}")
                    model.AddMaxEquality(fresh_viol, [0, freshness_lb - last_end])
                    pw = max(1, int(float(job.get("priority_weight", 1.0)) * SCALE))
                    weight = (tard_w * pw) // SCALE
                    if weight > 0:
                        objective_terms.append(fresh_viol * weight)

    # -----------------------------------------------------------------------
    # No-overlap / cumulative per machine
    # -----------------------------------------------------------------------
    for mid in machine_ids:
        if not machine_intervals[mid]:
            continue
        cap = machine_capacity.get(mid, 1)
        if cap == 1:
            model.AddNoOverlap(machine_intervals[mid])
        else:
            model.AddCumulative(machine_intervals[mid], machine_demands[mid], cap)

    # -----------------------------------------------------------------------
    # Shared resources
    # -----------------------------------------------------------------------
    for res in shared_resources:
        res_cap = int(res.get("capacity", 1))
        applicable_families = set(res.get("applicable_operation_families", []))
        res_intervals: list = []
        res_demands: list[int] = []
        for jid, op_map in job_vars.items():
            for op_idx, ov in op_map.items():
                op = ov["op"]
                if op.get("operation_family") in applicable_families:
                    res_intervals.append(ov["interval"])
                    res_demands.append(int(op.get("demand_load", 1)))
        if res_intervals:
            model.AddCumulative(res_intervals, res_demands, res_cap)

    # -----------------------------------------------------------------------
    # Wait rules (intra-job, matched by operation family)
    # -----------------------------------------------------------------------
    for rule in wait_rules:
        if not rule.get("hard", True):
            continue
        from_fam = rule.get("from_operation_family", "")
        to_fam = rule.get("to_operation_family", "")
        min_w = int(rule.get("min_wait_minutes") or 0)
        max_w = rule.get("max_wait_minutes")

        for jid, op_map in job_vars.items():
            job_from = [
                ov["end"]
                for ov in op_map.values()
                if ov["op"].get("operation_family") == from_fam
            ]
            job_to = [
                ov["start"]
                for ov in op_map.values()
                if ov["op"].get("operation_family") == to_fam
            ]
            for fe in job_from:
                for ts in job_to:
                    model.Add(ts >= fe + min_w)
                    if max_w is not None:
                        model.Add(ts <= fe + int(max_w))

    # -----------------------------------------------------------------------
    # Setup / cleaning rules (sequence-dependent, same machine)
    # -----------------------------------------------------------------------
    combined_transition_rules = [
        (r, setup_w, "setup") for r in setup_rules
    ] + [
        (r, clean_w, "clean") for r in cleaning_rules
    ]

    machine_op_list: dict[str, list] = {mid: [] for mid in machine_ids}
    for jid, op_map in job_vars.items():
        for op_idx, ov in op_map.items():
            fam = ov["op"].get("operation_family", "")
            for mid, b in ov["machine_assignments"].items():
                machine_op_list[mid].append(
                    (jid, op_idx, fam, ov["start"], ov["end"], b)
                )

    for rule, weight, kind in combined_transition_rules:
        from_fam = rule.get("from_family", "")
        to_fam = rule.get("to_family", "")
        gap_min = int(
            rule.get("setup_minutes", 0) if kind == "setup"
            else rule.get("cleaning_minutes", 0)
        )
        if rule.get("machine_id"):
            target_mids: list[str] = [rule["machine_id"]]
        elif rule.get("machine_type"):
            target_mids = [
                m["machine_id"]
                for m in machines
                if m.get("machine_type") == rule["machine_type"]
            ]
        else:
            target_mids = list(machine_ids)

        for mid in target_mids:
            ops_on_mid = machine_op_list.get(mid, [])
            for i, (jid_a, oi_a, fam_a, s_a, e_a, b_a) in enumerate(ops_on_mid):
                for jid_b, oi_b, fam_b, s_b, e_b, b_b in ops_on_mid[i + 1:]:
                    if jid_a == jid_b:
                        continue
                    if fam_a != from_fam or fam_b != to_fam:
                        continue
                    both_on_mid = model.NewBoolVar(
                        f"both_{mid}_{jid_a}_{oi_a}_{jid_b}_{oi_b}"
                    )
                    model.AddBoolAnd([b_a, b_b]).OnlyEnforceIf(both_on_mid)
                    model.AddBoolOr([b_a.Not(), b_b.Not()]).OnlyEnforceIf(both_on_mid.Not())

                    a_before_b = model.NewBoolVar(
                        f"ord_{mid}_{jid_a}_{oi_a}_{jid_b}_{oi_b}"
                    )
                    model.Add(s_b >= e_a + gap_min).OnlyEnforceIf([both_on_mid, a_before_b])
                    model.Add(s_a >= e_b + gap_min).OnlyEnforceIf(
                        [both_on_mid, a_before_b.Not()]
                    )

    # -----------------------------------------------------------------------
    # Quality hold rules (within job)
    # hard=True  → hard constraint; hard=False → soft penalty in objective.
    # REQUIRED: operation_family must be set so the hold applies only after the
    # relevant operation (e.g., QC, QA_RELEASE).  Rules without operation_family
    # would apply between ALL consecutive operations and make the model intractable.
    # -----------------------------------------------------------------------
    for rule in quality_rules:
        hold = int(rule.get("hold_minutes", 0))
        if hold <= 0:
            continue
        target_fam = rule.get("operation_family")
        if not target_fam:
            # Skip: no operation family means the hold would apply everywhere — too broad.
            continue
        is_hard = bool(rule.get("hard", False))
        target_prod = rule.get("product_id")
        target_pfam = rule.get("product_family")

        for job in jobs:
            if target_prod and job.get("product_id") != target_prod:
                continue
            if target_pfam and job.get("product_family") != target_pfam:
                continue
            jid = job["job_id"]
            ops_sorted = sorted(
                job.get("operations", []), key=lambda o: int(o.get("sequence", 1))
            )
            for op_idx, op in enumerate(ops_sorted):
                if target_fam and op.get("operation_family") != target_fam:
                    continue
                if op_idx + 1 < len(ops_sorted):
                    next_idx = op_idx + 1
                    if next_idx in job_vars.get(jid, {}):
                        ov_cur = job_vars[jid][op_idx]
                        ov_next = job_vars[jid][next_idx]
                        if is_hard:
                            model.Add(ov_next["start"] >= ov_cur["end"] + hold)
                        else:
                            # Soft: penalise QA hold violations in objective
                            viol = model.NewIntVar(
                                0, horizon_minutes,
                                f"qa_viol_{jid}_{op_idx}"
                            )
                            model.Add(viol >= ov_cur["end"] + hold - ov_next["start"])
                            objective_terms.append(viol * tard_w)

    # -----------------------------------------------------------------------
    # Objective: minimize total cost (tardiness + machine + setup).
    # When cost terms exist, DO NOT add makespan — makespan conflicts with
    # cost minimization (packing jobs tightly uses expensive machines).
    # Makespan is only a fallback when no cost terms are present.
    # -----------------------------------------------------------------------
    makespan_var = model.NewIntVar(0, horizon_minutes, "makespan")
    if completion_vars:
        model.AddMaxEquality(makespan_var, completion_vars)
    else:
        model.Add(makespan_var == 0)

    if objective_terms:
        # Primary: exact machine cost + makespan as urgency signal.
        # Machine cost range 4M-13M units vs makespan ~15K min.
        # Machine cost dominates 300:1 — solver picks cheapest machines.
        # Makespan as secondary keeps solver finding feasible solutions fast.
        model.Minimize(cp_model.LinearExpr.Sum(objective_terms) + makespan_var)
    else:
        model.Minimize(makespan_var)

    return {
        "model": model,
        "vars": job_vars,
        "horizon_minutes": horizon_minutes,
        "reference": reference,
        "job_order": job_order,
        "machine_intervals": machine_intervals,
        "machine_demands": machine_demands,
        "objective_terms": objective_terms,
        "errors": errors,
        "warnings": warnings,
        "debug": {"num_jobs": len(jobs), "num_machines": len(machines)},
    }
