from __future__ import annotations

import math
import re
from datetime import datetime, date, timedelta
from typing import Any, Optional

import pandas as pd

PRIORITY_MAP: dict[str, int] = {"VIP": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _json_safe(value: Any) -> Any:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, (datetime, date)):
        return value.isoformat() if isinstance(value, datetime) else datetime(value.year, value.month, value.day).isoformat()
    if isinstance(value, float):
        return None if (math.isnan(value) or math.isinf(value)) else value
    return value


def _parse_datetime(value: Any) -> Optional[datetime]:
    """Parse any date-like value to a timezone-naive datetime, or None."""
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, datetime):
        return value.replace(tzinfo=None)
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day, 0, 0, 0)
    try:
        ts = pd.to_datetime(value)
        if pd.isna(ts):
            return None
        dt = ts.to_pydatetime().replace(tzinfo=None)
        return dt
    except Exception:
        return None


def _parse_reference_time(
    current_date: str, reference_date: Optional[str] = None
) -> tuple[Optional[datetime], Optional[str]]:
    """
    Parse reference_time from current_date or reference_date.
    Never calls datetime.now().
    Returns (datetime_obj, iso_string) or (None, None) on failure.
    """
    target = reference_date if reference_date else current_date
    if not target:
        return None, None
    try:
        ts = pd.to_datetime(str(target))
        if pd.isna(ts):
            return None, None
        dt = ts.to_pydatetime().replace(tzinfo=None)
        # If only a date was given (no time component), set to midnight
        if "T" not in str(target) and ":" not in str(target):
            dt = dt.replace(hour=0, minute=0, second=0, microsecond=0)
        return dt, dt.isoformat()
    except Exception:
        return None, None


def _to_float(value: Any, default: float = 0.0) -> float:
    if value is None:
        return default
    try:
        f = float(value)
        return default if (math.isnan(f) or math.isinf(f)) else f
    except (ValueError, TypeError):
        return default


def _to_int(value: Any, default: int = 0) -> int:
    if value is None:
        return default
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return default


def _clean_id(value: Any) -> Optional[str]:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    sv = str(value).strip()
    return sv if sv and sv.lower() not in ("none", "nan", "null") else None


def _build_lookup(rows: list[dict], key: str) -> dict[str, dict]:
    result: dict[str, dict] = {}
    for row in rows:
        k = _clean_id(row.get(key))
        if k:
            result[k] = row
    return result


def _parse_machine_list(value: Any) -> list[str]:
    """Parse comma/semicolon/pipe-separated machine IDs into a list."""
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if v is not None and str(v).strip()]
    sv = str(value).strip()
    if not sv or sv.lower() in ("none", "nan", "null"):
        return []
    parts = re.split(r"[,;|]+", sv)
    return [p.strip() for p in parts if p.strip()]


def _machine_ids_by_type(machines: list[dict]) -> dict[str, list[str]]:
    """Return {machine_type: [machine_id, ...]} from a machines list."""
    result: dict[str, list[str]] = {}
    for m in machines:
        mt = _clean_id(m.get("machine_type"))
        mid = _clean_id(m.get("machine_id"))
        if mt and mid:
            result.setdefault(mt, []).append(mid)
    return result


def _normalize_operation_family(value: Any) -> str:
    if not value:
        return "PROCESS"
    text = str(value).strip().upper()
    text = re.sub(r"[\s\-]+", "_", text)
    text = re.sub(r"[^A-Z0-9_]", "", text)
    return text or "PROCESS"


def _calculate_horizon_seconds(reference_time: datetime, jobs: list[dict]) -> int:
    max_due = reference_time
    for job in jobs:
        due_dt = _parse_datetime(job.get("due_at"))
        if due_dt and due_dt > max_due:
            max_due = due_dt
    horizon_end = max(max_due, reference_time) + timedelta(days=14)
    return max(86400, int((horizon_end - reference_time).total_seconds()))


def _error_result(errors: list[str], warnings: Optional[list[str]] = None) -> dict:
    w = warnings or []
    return {
        "canonical_solver_payload": None,
        "build_report": {
            "num_jobs": 0, "num_operations": 0, "num_machines": 0,
            "reference_time": None, "errors": errors, "warnings": w,
        },
        "errors": errors,
        "warnings": w,
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_canonical_payload(
    normalized_tables: dict,
    constraint_rules: dict,
    domain_result: dict,
    current_date: str,
    reference_date: Optional[str] = None,
) -> dict:
    """
    Build a SolverPayload-compatible dict from normalized tables and mapped
    constraints. Never calls datetime.now().

    Returns:
    {
        "canonical_solver_payload": dict | None,
        "build_report": { num_jobs, num_operations, num_machines,
                          reference_time, errors, warnings },
        "errors": [str],
        "warnings": [str]
    }
    """
    errors: list[str] = []
    warnings: list[str] = []

    # Unwrap if full tool results were passed
    if "normalized_tables" in normalized_tables:
        tables: dict = normalized_tables["normalized_tables"]
    else:
        tables = normalized_tables

    # ------------------------------------------------------------------ A
    # Reference time — never datetime.now()
    # ------------------------------------------------------------------
    ref_dt, ref_iso = _parse_reference_time(current_date, reference_date)
    if ref_dt is None:
        return _error_result(
            ["current_date or reference_date is required and must be a valid date."]
        )

    # ------------------------------------------------------------------ B
    # Machines
    # ------------------------------------------------------------------
    machine_table = tables.get("Machine_Master", [])
    if not machine_table:
        return _error_result(
            ["Machine_Master table is required to build SolverPayload."]
        )

    machines: list[dict] = []
    machine_id_set: set[str] = set()

    for i, row in enumerate(machine_table):
        mid = _clean_id(row.get("machine_id"))
        if not mid:
            warnings.append(f"Machine_Master row {i}: machine_id missing, skipping.")
            continue
        if mid in machine_id_set:
            warnings.append(f"Machine_Master: duplicate machine_id '{mid}', skipping duplicate.")
            continue
        machine_id_set.add(mid)

        mtype = _clean_id(row.get("machine_type"))
        if not mtype:
            mtype = mid
            warnings.append(
                f"Machine_Master row {i}: machine_type missing for '{mid}', "
                "using machine_id as type."
            )

        machines.append({
            "machine_id": mid,
            "machine_name": _clean_id(row.get("machine_name")),
            "machine_type": mtype,
            "capacity": max(1, _to_int(row.get("capacity"), default=1)),
            "hourly_cost": max(0.0, _to_float(row.get("hourly_cost"), default=0.0)),
        })

    if not machines:
        return _error_result(
            ["No valid machines could be extracted from Machine_Master."]
        )

    machines_by_type = _machine_ids_by_type(machines)

    # ------------------------------------------------------------------ C
    # Required tables check
    # ------------------------------------------------------------------
    demand_table = tables.get("Demand_Orders", [])
    if not demand_table:
        return _error_result(["Demand_Orders table is required to build SolverPayload."])

    routing_table = tables.get("Routing", [])
    if not routing_table:
        return _error_result(["Routing table is required to build SolverPayload."])

    # ------------------------------------------------------------------ D
    # Lookup tables
    # ------------------------------------------------------------------
    sku_table = tables.get("SKU_Master", [])
    sku_lookup = _build_lookup(sku_table, "product_id")
    if not sku_table:
        warnings.append("SKU_Master missing; job cost/family enrichment skipped.")

    # Group routing by product_id
    routing_by_product: dict[str, list[dict]] = {}
    for row in routing_table:
        pid = _clean_id(row.get("product_id"))
        if pid:
            routing_by_product.setdefault(pid, []).append(row)

    # ------------------------------------------------------------------ E
    # Build jobs + operations
    # ------------------------------------------------------------------
    def _seq_key(r: dict) -> int:
        try:
            return int(float(r.get("stage_sequence") or 9999))
        except (TypeError, ValueError):
            return 9999

    jobs: list[dict] = []

    for i, order in enumerate(demand_table):
        order_id = _clean_id(order.get("order_id"))
        if not order_id:
            order_id = f"ORDER_{i:04d}"
            warnings.append(
                f"Demand_Orders row {i}: order_id missing, generated '{order_id}'."
            )

        product_id = _clean_id(order.get("product_id"))
        if not product_id:
            errors.append(f"Demand_Orders row {i}: product_id missing, skipping order.")
            continue

        quantity = _to_float(order.get("quantity"))
        if quantity <= 0:
            errors.append(
                f"Demand_Orders row {i} (order_id={order_id}): "
                "quantity missing or <= 0, skipping."
            )
            continue

        due_dt = _parse_datetime(order.get("due_date"))
        if due_dt is None:
            due_dt = ref_dt + timedelta(days=7)
            warnings.append(
                f"Order {order_id}: due_date missing, defaulting to reference_time + 7 days."
            )

        priority_class = str(order.get("priority_class") or "MEDIUM").strip().upper()
        pw_raw = order.get("priority_weight")
        priority_weight = (
            max(0.0, _to_float(pw_raw))
            if pw_raw is not None
            else float(PRIORITY_MAP.get(priority_class, 1))
        )

        late_ppu = _to_float(order.get("late_penalty_per_unit_per_day"))
        late_penalty_per_minute = (late_ppu * quantity / 1440.0) if late_ppu > 0 else 0.0

        sku = sku_lookup.get(product_id, {})
        hold_cpu = _to_float(sku.get("holding_cost_per_unit_per_day"))
        holding_cost_per_minute = (hold_cpu * quantity / 1440.0) if hold_cpu > 0 else 0.0
        selling_price = _to_float(sku.get("selling_price_per_unit"))
        production_cost = _to_float(sku.get("unit_production_cost"))
        product_family = _clean_id(sku.get("product_family"))

        # Shelf life: how many minutes after manufacture until the product expires.
        # Constraint: job must complete no earlier than (due_at - shelf_life_minutes)
        # so the product is still fresh when it reaches the customer.
        shelf_life_hours_raw = _to_float(sku.get("shelf_life_hours"))
        shelf_life_minutes: Optional[int] = None
        if shelf_life_hours_raw > 0:
            slm = int(shelf_life_hours_raw * 60)
            # Only enforce when shelf life is shorter than the planning window.
            # If shelf_life > (due_date - ref_dt), the constraint is trivially met.
            due_offset_minutes = int((due_dt - ref_dt).total_seconds() / 60) if due_dt else 0
            if slm < due_offset_minutes:
                shelf_life_minutes = slm

        # Operations
        routing_rows = routing_by_product.get(product_id, [])
        if not routing_rows:
            errors.append(
                f"No routing found for product_id '{product_id}'; "
                f"skipping job for order '{order_id}'."
            )
            continue

        sorted_routing = sorted(routing_rows, key=_seq_key)
        operations: list[dict] = []
        op_error = False

        for j, rrow in enumerate(sorted_routing):
            seq = _to_int(rrow.get("stage_sequence"), default=j + 1)
            raw_op_id = _clean_id(rrow.get("operation_id"))
            op_id = raw_op_id or f"{product_id}_OP_{seq:02d}"

            op_family = _normalize_operation_family(
                rrow.get("operation_family") or rrow.get("operation_name") or op_id
            )
            op_name = _clean_id(rrow.get("operation_name"))

            duration = _to_int(rrow.get("runtime_minutes_per_batch"), default=0)
            if duration <= 0:
                errors.append(
                    f"Routing product='{product_id}' op='{op_id}': "
                    "duration_minutes <= 0, skipping job."
                )
                op_error = True
                break

            # Resolve eligible machines
            em_raw = rrow.get("eligible_machines")
            mid_raw = _clean_id(rrow.get("machine_id"))
            mtype_raw = _clean_id(rrow.get("machine_type"))

            eligible: list[str] = []
            if em_raw is not None:
                eligible = _parse_machine_list(em_raw)
            elif mid_raw:
                eligible = [mid_raw]
            elif mtype_raw:
                eligible = machines_by_type.get(mtype_raw, [])
                if not eligible:
                    errors.append(
                        f"Routing product='{product_id}' op='{op_id}': "
                        f"no machines found for machine_type='{mtype_raw}'."
                    )
                    op_error = True
                    break

            if not eligible:
                errors.append(
                    f"Routing product='{product_id}' op='{op_id}': "
                    "no eligible_machines could be determined."
                )
                op_error = True
                break

            invalid = [m for m in eligible if m not in machine_id_set]
            if invalid:
                errors.append(
                    f"Routing product='{product_id}' op='{op_id}': "
                    f"eligible_machines {invalid} not found in Machine_Master."
                )
                op_error = True
                break

            # Wait to next (only for non-last operation)
            if j < len(sorted_routing) - 1:
                min_w = _to_int(rrow.get("min_wait_minutes"), 0)
                max_w = _to_int(rrow.get("max_wait_minutes"), 0)
                min_wait_next: Optional[int] = min_w if min_w > 0 else None
                max_wait_next: Optional[int] = max_w if max_w > 0 else None
            else:
                min_wait_next = None
                max_wait_next = None

            operations.append({
                "op_id": op_id,
                "operation_family": op_family,
                "operation_name": op_name,
                "sequence": seq,
                "duration_minutes": duration,
                "eligible_machines": eligible,
                "demand_load": 1,
                "min_wait_to_next_minutes": min_wait_next,
                "max_wait_to_next_minutes": max_wait_next,
            })

        if op_error or not operations:
            continue

        jobs.append({
            "job_id": order_id,
            "order_id": order_id,
            "product_id": product_id,
            "product_family": product_family,
            "quantity": quantity,
            "due_at": due_dt.isoformat(),
            "priority_class": priority_class,
            "priority_weight": priority_weight,
            "late_penalty_per_minute": late_penalty_per_minute,
            "holding_cost_per_minute": holding_cost_per_minute,
            "selling_price_per_unit": selling_price,
            "unit_production_cost": production_cost,
            "shelf_life_minutes": shelf_life_minutes,
            "operations": operations,
        })

    if not jobs:
        return _error_result(
            errors + ["No valid jobs could be built from Demand_Orders and Routing."],
            warnings,
        )

    # ------------------------------------------------------------------ F
    # Horizon
    # ------------------------------------------------------------------
    horizon_seconds = _calculate_horizon_seconds(ref_dt, jobs)

    # ------------------------------------------------------------------ G
    # Calendars (default if Machine_Calendar missing)
    # ------------------------------------------------------------------
    calendar_table = tables.get("Machine_Calendar", [])
    calendars: list[dict] = []

    if calendar_table:
        for i, row in enumerate(calendar_table):
            mid = _clean_id(row.get("machine_id"))
            if not mid:
                warnings.append(f"Machine_Calendar row {i}: machine_id missing, skipping.")
                continue
            if mid not in machine_id_set:
                warnings.append(
                    f"Machine_Calendar row {i}: machine_id '{mid}' "
                    "not in Machine_Master, skipping."
                )
                continue
            start_dt = _parse_datetime(row.get("start"))
            end_dt = _parse_datetime(row.get("end"))
            if not start_dt or not end_dt:
                warnings.append(f"Machine_Calendar row {i}: invalid start/end, skipping.")
                continue
            if end_dt <= start_dt:
                warnings.append(f"Machine_Calendar row {i}: end <= start, skipping.")
                continue
            available = True
            av_raw = row.get("available")
            if av_raw is not None:
                av_str = str(av_raw).strip().lower()
                available = av_str not in ("false", "0", "no", "n")
            calendars.append({
                "machine_id": mid,
                "start": start_dt.isoformat(),
                "end": end_dt.isoformat(),
                "available": available,
            })
    else:
        horizon_end = ref_dt + timedelta(seconds=horizon_seconds)
        for m in machines:
            calendars.append({
                "machine_id": m["machine_id"],
                "start": ref_dt.isoformat(),
                "end": horizon_end.isoformat(),
                "available": True,
            })
        warnings.append(
            "Machine_Calendar missing; default full-horizon availability created."
        )

    # ------------------------------------------------------------------ H
    # Materials
    # ------------------------------------------------------------------
    materials: list[dict] = []
    for i, row in enumerate(tables.get("Inventory", [])):
        item_id = _clean_id(row.get("item_id"))
        if not item_id:
            continue
        materials.append({
            "material_id": item_id,
            "material_name": item_id,
            "unit": str(row.get("unit") or "unit").strip() or "unit",
            "available_quantity": max(0.0, _to_float(row.get("opening_inventory"))),
            "safety_stock": max(0.0, _to_float(row.get("safety_stock"))),
            "receipt_date": None,
        })

    receipt_table = tables.get("Material_Receipts", [])
    if receipt_table:
        if any(r.get("receipt_status") == "future_receipt" for r in receipt_table):
            warnings.append(
                "Future material receipts detected; "
                "time-phased material availability will be modeled later."
            )

    # ------------------------------------------------------------------ I
    # Copy constraint rules
    # ------------------------------------------------------------------
    setup_rules = constraint_rules.get("setup_rules", [])
    cleaning_rules = constraint_rules.get("cleaning_rules", [])
    wait_rules = constraint_rules.get("wait_rules", [])
    batch_rules = constraint_rules.get("batch_rules", [])
    quality_rules = constraint_rules.get("quality_rules", [])
    shared_resources = constraint_rules.get("shared_resources", [])
    generic_constraints = constraint_rules.get("constraints", [])

    # ------------------------------------------------------------------ I2
    # Batch rule pre-validation: warn when an order quantity violates batch
    # constraints.  The CP-SAT model treats quantity as fixed (splitting not
    # modeled), so violations here indicate the schedule may differ from the
    # shop floor reality. These are warnings, not errors.
    # ------------------------------------------------------------------
    batch_rule_by_product: dict[str, dict] = {}
    batch_rule_by_family: dict[str, dict] = {}
    for br in batch_rules:
        if br.get("product_id"):
            batch_rule_by_product[br["product_id"]] = br
        elif br.get("product_family"):
            batch_rule_by_family[br["product_family"]] = br

    for job in jobs:
        pid = job["product_id"]
        pfam = job.get("product_family") or ""
        qty = job["quantity"]
        br = batch_rule_by_product.get(pid) or batch_rule_by_family.get(pfam)
        if not br:
            # Fall back to SKU_Master batch constraints
            sku = sku_lookup.get(pid, {})
            min_b = _to_float(sku.get("min_batch_size"))
            max_b = _to_float(sku.get("max_batch_size"))
            mult  = _to_float(sku.get("batch_multiple"))
        else:
            min_b = _to_float(br.get("min_batch_size"))
            max_b = _to_float(br.get("max_batch_size"))
            mult  = _to_float(br.get("batch_multiple"))

        order_id = job["job_id"]
        if min_b > 0 and qty < min_b:
            warnings.append(
                f"Order {order_id} qty={qty:.0f} is below min_batch_size={min_b:.0f} "
                f"for product '{pid}'. Schedule will proceed but may require splitting on the floor."
            )
        if max_b > 0 and qty > max_b:
            warnings.append(
                f"Order {order_id} qty={qty:.0f} exceeds max_batch_size={max_b:.0f} "
                f"for product '{pid}'. Schedule will proceed but order may need to be split."
            )
        if mult > 0 and qty % mult > 1e-6:
            warnings.append(
                f"Order {order_id} qty={qty:.0f} is not a multiple of batch_multiple={mult:.0f} "
                f"for product '{pid}'."
            )

    # ------------------------------------------------------------------ J
    # Objective weights (defaults; Cost_Parameters not yet wired)
    # ------------------------------------------------------------------
    objective_weights = {
        "tardiness_weight": 1.0,
        "holding_weight": 1.0,
        "setup_weight": 1.0,
        "cleaning_weight": 1.0,
        "machine_cost_weight": 1.0,
        "overtime_weight": 1.0,
        "freshness_waste_weight": 1.0,
    }

    # ------------------------------------------------------------------ K
    # Domain info + metadata
    # ------------------------------------------------------------------
    domain_profile_id = domain_result.get("domain_profile_id", "generic_manufacturing.v1")
    domain_confidence = domain_result.get("confidence", 0.0)

    metadata: dict = {
        "current_date": current_date,
        "current_date_source": "user_selected",
        "domain_profile_id": domain_profile_id,
        "domain_confidence": domain_confidence,
        "num_orders": len(demand_table),
        "num_routing_rows": len(routing_table),
        "num_valid_jobs": len(jobs),
        "num_machines": len(machines),
    }

    provenance = [{
        "step": "canonical_payload_builder_tool",
        "domain_profile_id": domain_profile_id,
        "num_jobs": len(jobs),
        "num_machines": len(machines),
        "reference_time": ref_iso,
    }]

    # ------------------------------------------------------------------ L
    # Assemble payload dict
    # ------------------------------------------------------------------
    payload: dict = {
        "reference_time": ref_iso,
        "domain_profile_id": domain_profile_id,
        "metadata": metadata,
        "jobs": jobs,
        "machines": machines,
        "calendars": calendars,
        "materials": materials,
        "setup_rules": setup_rules,
        "cleaning_rules": cleaning_rules,
        "wait_rules": wait_rules,
        "batch_rules": batch_rules,
        "quality_rules": quality_rules,
        "shared_resources": shared_resources,
        "objective_weights": objective_weights,
        "constraints": generic_constraints,
        "provenance": provenance,
        "horizon_seconds": horizon_seconds,
    }

    # ------------------------------------------------------------------ M
    # Pre-validate with Pydantic (errors do not block returning payload)
    # ------------------------------------------------------------------
    try:
        from schemas.canonical_schema import SolverPayload
        SolverPayload(**payload)
    except Exception as exc:
        errors.append(f"SolverPayload pre-validation failed: {exc}")

    num_ops = sum(len(j["operations"]) for j in jobs)
    build_report = {
        "num_jobs": len(jobs),
        "num_operations": num_ops,
        "num_machines": len(machines),
        "reference_time": ref_iso,
        "errors": errors[:],
        "warnings": warnings[:],
    }

    return {
        "canonical_solver_payload": payload,
        "build_report": build_report,
        "errors": errors,
        "warnings": warnings,
    }
