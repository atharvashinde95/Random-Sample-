from __future__ import annotations

import re
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Canonical columns per sheet role and their raw-column aliases
# ---------------------------------------------------------------------------
# Rules:
#  - Avoid single-word aliases that cause false-positive substring matches.
#  - Each entry maps a raw column alias to ONE canonical column.

COLUMN_ALIASES_BY_ROLE: dict[str, dict[str, list[str]]] = {
    "Demand_Orders": {
        "order_id": [
            "order id", "order_id", "order no", "order number",
            "sales order", "order_no", "orderid", "orderno",
            "sales_order_id",
        ],
        "product_id": [
            "sku", "sku code", "sku_id", "sku id", "product id", "product_id",
            "item code", "item_id", "sku_code", "itemcode", "skuid",
        ],
        "quantity": [
            "qty", "quantity", "demand qty", "order qty", "required quantity",
            "demand_qty", "order_qty", "required_quantity",
            "order_quantity", "requested qty", "requested_qty",
        ],
        "order_date": [
            "order date", "order_date", "orderdate",
            "created date", "created_date",
        ],
        "due_date": [
            "due date", "due_dt", "due", "customer due", "deadline",
            "delivery date", "due_date", "duedate", "deliverydate",
            "customer due date", "required date", "required_date",
            "promise date", "promise_date", "ship date", "ship_date",
        ],
        "priority_class": [
            "priority", "priority class", "priority_class",
            "urgency", "priority_label",
            "order priority", "order_priority",
        ],
        "priority_weight": [
            "priority weight", "priority_weight", "weight", "importance",
        ],
        "late_penalty_per_unit_per_day": [
            "late penalty", "late_penalty", "lateness penalty",
            "late penalty per unit per day", "late_penalty_per_unit_per_day",
            "tardiness penalty",
        ],
        "customer_id": [
            "customer id", "customer_id", "client_id", "client",
        ],
    },
    "SKU_Master": {
        "product_id": [
            "product id", "product_id", "sku", "sku code", "sku_id",
            "item code", "item_id", "sku_code",
        ],
        "product_name": [
            "product name", "product_name", "sku name",
            "item name", "item_name",
        ],
        "product_family": [
            "product family", "product_family", "category",
            "product category", "product_category", "family",
        ],
        "batch_size": [
            "batch size", "batch_size", "standard batch", "default batch",
        ],
        "min_batch_size": [
            "min batch", "min_batch_size", "minimum batch", "minimum_batch",
            "min batch qty", "min_batch_qty",
        ],
        "max_batch_size": [
            "max batch", "max_batch_size", "maximum batch", "maximum_batch",
            "max batch qty", "max_batch_qty",
        ],
        "batch_multiple": [
            "batch multiple", "batch_multiple", "increment", "batch increment",
        ],
        "holding_cost_per_unit_per_day": [
            "holding cost", "holding_cost", "inventory cost", "storage cost",
            "holding cost per unit per day", "holding_cost_per_unit_per_day",
        ],
        "selling_price_per_unit": [
            "selling price", "selling_price", "unit price", "unit_price",
            "selling price per unit", "selling_price_per_unit",
        ],
        "unit_production_cost": [
            "production cost", "unit cost", "unit_cost", "manufacturing cost",
            "unit production cost", "unit_production_cost",
        ],
        "shelf_life_days": [
            "shelf life", "shelf_life", "expiry days", "shelf_life_days",
        ],
        "shelf_life_hours": [
            "shelf life hours", "shelf_life_hours",
        ],
        "qa_release_hours": [
            "qa release", "qa_release", "qc release", "release time", "hold time",
            "qa release hours", "qa_release_hours",
        ],
    },
    "Routing": {
        "product_id": [
            "product id", "product_id", "sku", "sku code", "sku_id", "sku id",
        ],
        "operation_id": [
            "operation id", "operation_id", "op id", "op_id", "step id",
            "operation_code", "op_code",
        ],
        "operation_name": [
            "operation name", "operation_name", "op name", "step name",
            "process name", "process_name",
        ],
        "operation_family": [
            "operation family", "operation_family", "op type",
            "operation type", "process type",
        ],
        "stage_sequence": [
            "sequence", "stage", "stage_sequence", "step", "step no",
            "step number", "seq", "op sequence",
            "operation seq", "operation_seq", "step_no",
        ],
        "machine_type": [
            "machine type", "machine_type", "resource type", "equipment type",
            "machine group", "machine_group",
        ],
        "eligible_machines": [
            "eligible machines", "machines", "machine ids", "eligible line",
            "eligible_lines", "eligible_machines", "machine_ids",
            "compatible machines", "compatible_machines",
        ],
        "runtime_minutes_per_batch": [
            "runtime", "run time", "runtime minutes", "process time",
            "processing time", "duration", "duration min",
            "runtime_minutes", "run_time_min", "process_time_min",
            "run min per batch", "run_min_per_batch",
            "run min", "run minutes", "run_min",
            "cycle time min", "cycle_time_min",
            "runtime min per batch", "runtime_min_per_batch",
            "operation time", "operation_time",
        ],
        "setup_time_minutes": [
            "setup time", "setup_time", "setup minutes",
            "changeover time", "changeover_time",
        ],
        "batch_capacity": [
            "batch capacity", "batch_capacity", "batch qty", "lot size",
        ],
        "min_wait_minutes": [
            "min wait", "min_wait", "minimum wait", "min_wait_minutes",
        ],
        "max_wait_minutes": [
            "max wait", "max_wait", "maximum wait", "max_wait_minutes",
        ],
    },
    "Machine_Master": {
        "machine_id": [
            "machine id", "machine_id", "equipment id", "resource id",
            "machine_id", "equipment_id", "resource_id", "machineid",
        ],
        "machine_name": [
            "machine name", "machine_name", "equipment name", "line name",
        ],
        "machine_type": [
            "machine type", "machine_type", "equipment type", "resource type",
            "machine group", "machine_group",
            "equipment group", "equipment_group",
            "resource group", "resource_group",
            "line group", "line_group",
        ],
        "capacity": [
            "capacity", "parallel capacity", "lanes", "units",
        ],
        "available_from": [
            "available from", "available_from", "shift start", "start time",
        ],
        "available_to": [
            "available to", "available_to", "shift end", "end time",
        ],
        "hourly_cost": [
            "hourly cost", "hourly_cost", "cost per hour", "rate", "machine rate",
            "hourly run cost", "hourly_run_cost", "run cost per hour",
        ],
    },
    "BOM": {
        "product_id": [
            "product id", "product_id", "sku", "sku code", "sku_id",
            "finished good",
        ],
        "component_id": [
            "component id", "component_id", "material id", "material_id",
            "ingredient", "raw material",
        ],
        "quantity_required": [
            "quantity required", "quantity_required",
            "amount", "required qty", "qty per batch", "qty_per_batch",
        ],
        "unit": ["unit", "uom", "unit of measure", "measure"],
    },
    "Inventory": {
        "item_id": [
            "item id", "item_id", "material id", "sku", "component id",
            "material_id", "sku_id",
        ],
        "item_type": ["item type", "item_type", "material type", "type"],
        "opening_inventory": [
            "opening inventory", "opening_inventory", "opening stock",
            "current stock", "on hand", "quantity on hand",
            "opening finished goods", "opening_finished_goods",
        ],
        "safety_stock": [
            "safety stock", "safety_stock", "minimum stock", "reorder level",
            "safety_stock_qty",
        ],
        "unit": ["unit", "uom", "unit of measure"],
    },
    "Business_Rules": {
        "rule_id": ["rule id", "rule_id", "rule no"],
        "rule_text": [
            "rule text", "rule_text", "description", "constraint",
            "rule description", "rule_description",
        ],
        "rule_type": ["rule type", "rule_type", "type"],
        "hard": ["hard", "is_hard", "mandatory", "required"],
        "penalty": ["penalty", "violation cost", "soft_penalty"],
    },
    "Material_Receipts": {
        "item_id": [
            "item id", "item_id", "material id", "sku", "component",
        ],
        "receipt_qty": [
            "receipt qty", "receipt_qty", "quantity", "qty", "incoming qty",
        ],
        "receipt_date": [
            "receipt date", "receipt_date", "arrival date",
            "delivery date", "expected date",
        ],
        "unit": ["unit", "uom"],
    },
    "Machine_Calendar": {
        "machine_id": [
            "machine id", "machine_id", "resource id", "equipment id",
        ],
        "start": [
            "start", "start_time", "start time", "from", "window_start",
        ],
        "end": ["end", "end_time", "end time", "to", "window_end"],
        "available": [
            "available", "is_available", "flag",
            "is_working_day", "is working day", "working_day",
            "availability_flag",
        ],
        "work_date": [
            "work date", "work_date", "calendar_date",
            "shift_date", "calendar_day", "work_day",
        ],
        "shift_start": [
            "shift start", "shift_start", "shift_start_time",
            "start_hour", "shift_from",
        ],
        "shift_end": [
            "shift end", "shift_end", "shift_end_time",
            "end_hour", "shift_to",
        ],
        "available_minutes": [
            "available minutes", "available_minutes",
            "regular available min", "regular_available_min",
            "available_min", "shift_duration_min", "shift duration min",
            "base available min per shift", "base_available_min_per_shift",
        ],
    },
    "Maintenance": {
        "machine_id": [
            "machine id", "machine_id", "resource id", "equipment id",
        ],
        "downtime_start": [
            "downtime start", "downtime_start", "start", "start_time", "from",
        ],
        "downtime_end": [
            "downtime end", "downtime_end", "end", "end_time", "to",
        ],
        "reason": ["reason", "description", "type", "downtime reason"],
    },
    "Setup_Changeover": {
        "from_family": [
            "from family", "from_family", "from product", "from sku", "product from",
            "from cleaning family", "from_cleaning_family",
            "from group", "from_group", "source family",
        ],
        "to_family": [
            "to family", "to_family", "to product", "to sku", "product to",
            "to cleaning family", "to_cleaning_family",
            "to group", "to_group", "target family",
        ],
        "machine_id": [
            "machine id", "machine_id", "machine", "equipment id",
        ],
        "machine_type": ["machine type", "machine_type", "equipment type"],
        "setup_minutes": [
            "setup minutes", "setup_minutes", "setup time", "setup_time",
            "changeover minutes", "changeover_minutes", "changeover_min",
        ],
        "setup_cost": [
            "setup cost", "setup_cost", "changeover cost", "changeover_cost",
        ],
        "cleaning_minutes": [
            "cleaning minutes", "cleaning_minutes", "cleaning time", "wash time",
            "cleaning_min",
        ],
        "cleaning_cost": ["cleaning cost", "cleaning_cost"],
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize_name(name: str) -> str:
    if not name:
        return ""
    text = str(name).lower().strip()
    text = re.sub(r"[\s_\-]+", " ", text)
    text = re.sub(r"[^a-z0-9 ]", "", text)
    return text.strip()


def _simple_similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0

    def bigrams(s: str) -> set[str]:
        return {s[i : i + 2] for i in range(len(s) - 1)}

    bg_a = bigrams(a)
    bg_b = bigrams(b)
    if not bg_a or not bg_b:
        return 0.0
    return len(bg_a & bg_b) / len(bg_a | bg_b)


def _best_column_match(
    raw_column: str, role: str
) -> tuple[Optional[str], float, str]:
    """
    Match a raw column name to the best canonical column for a given role.
    Returns (canonical_column | None, confidence, method).
    Priority: exact alias (1.0) > substring (0.85) > similarity (0.70-0.99).
    """
    canonical_fields = COLUMN_ALIASES_BY_ROLE.get(role, {})
    if not canonical_fields:
        return None, 0.0, "none"

    norm_raw = _normalize_name(raw_column)

    # 1. Exact alias
    for canon, aliases in canonical_fields.items():
        if norm_raw in [_normalize_name(a) for a in aliases]:
            return canon, 1.0, "alias"

    # 2. Substring — only match when the alias is at least 4 chars to avoid
    #    false positives from very short words (e.g. "id", "no").
    for canon, aliases in canonical_fields.items():
        for alias in aliases:
            norm_alias = _normalize_name(alias)
            if len(norm_alias) >= 4 and (norm_alias in norm_raw or norm_raw in norm_alias):
                return canon, 0.85, "substring"

    # 3. Similarity
    best_canon: Optional[str] = None
    best_sim = 0.0
    for canon, aliases in canonical_fields.items():
        for alias in aliases:
            sim = _simple_similarity(norm_raw, _normalize_name(alias))
            if sim > best_sim:
                best_sim = sim
                best_canon = canon

    if best_sim >= 0.70:
        return best_canon, round(best_sim, 4), "similarity"

    return None, 0.0, "none"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect_column_mapping(
    workbook_profile: dict,
    sheet_mapping: dict,
    domain_profile: Optional[dict] = None,
) -> dict:
    """
    Map raw columns in each mapped sheet to canonical column names.
    Returns a column_mapping_report alongside the flat column_mapping for
    backward compatibility.

    Returns:
    {
        "column_mapping":        { raw_sheet: { raw_col: canonical_col } },
        "mapping_details":       [ { sheet, canonical_role, raw_column,
                                      canonical_column, confidence, method } ],
        "column_mapping_report": { raw_sheet: { raw_col: {canonical_column,
                                      confidence, reason, alternatives} } },
        "unmapped_columns":      [ { sheet, column } ],
        "errors":                [str],
        "warnings":              [str]
    }
    """
    errors: list[str] = []
    warnings: list[str] = []
    column_mapping: dict[str, dict[str, str]] = {}
    mapping_details: list[dict[str, Any]] = []
    mapping_report: dict[str, dict[str, Any]] = {}
    unmapped_columns: list[dict[str, str]] = []

    role_map: dict[str, str] = sheet_mapping.get("sheet_mapping", sheet_mapping)
    sheets_data: dict = workbook_profile.get("sheets", {})

    for raw_sheet, canonical_role in role_map.items():
        sheet_data = sheets_data.get(raw_sheet)
        if sheet_data is None:
            warnings.append(
                f"Sheet '{raw_sheet}' not found in workbook_profile; "
                "skipping column mapping."
            )
            continue

        raw_columns: list[str] = sheet_data.get("columns", [])
        column_mapping[raw_sheet] = {}
        mapping_report[raw_sheet] = {}

        for raw_col in raw_columns:
            canon_col, conf, match_method = _best_column_match(raw_col, canonical_role)
            if canon_col:
                column_mapping[raw_sheet][raw_col] = canon_col
                mapping_details.append({
                    "sheet": raw_sheet,
                    "canonical_role": canonical_role,
                    "raw_column": raw_col,
                    "canonical_column": canon_col,
                    "confidence": conf,
                    "method": match_method,
                })
                mapping_report[raw_sheet][raw_col] = {
                    "canonical_column": canon_col,
                    "confidence": conf,
                    "reason": match_method,
                    "alternatives": [],
                }
            else:
                unmapped_columns.append({"sheet": raw_sheet, "column": raw_col})
                mapping_report[raw_sheet][raw_col] = {
                    "canonical_column": None,
                    "confidence": 0.0,
                    "reason": "none",
                    "alternatives": [],
                }

    return {
        "column_mapping": column_mapping,
        "mapping_details": mapping_details,
        "column_mapping_report": mapping_report,
        "unmapped_columns": unmapped_columns,
        "errors": errors,
        "warnings": warnings,
    }
