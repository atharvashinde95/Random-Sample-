from __future__ import annotations

from typing import Any

from pydantic import ValidationError

from schemas.canonical_schema import SolverPayload


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _format_pydantic_error(exc: ValidationError) -> list[str]:
    """Convert a Pydantic ValidationError into a flat list of human-readable strings."""
    lines: list[str] = []
    for e in exc.errors():
        loc = " -> ".join(str(part) for part in e.get("loc", []))
        msg = e.get("msg", "Unknown error")
        lines.append(f"[{loc}] {msg}" if loc else msg)
    return lines


def _collect_reference_warnings(model: SolverPayload) -> tuple[list[str], list[str]]:
    """
    Run additional checks beyond Pydantic field-level validation.
    Returns (errors, warnings).
    """
    errors: list[str] = []
    warnings: list[str] = []

    # Metadata completeness
    meta = model.metadata or {}
    if "current_date" not in meta:
        warnings.append(
            "metadata.current_date is missing; planning date traceability reduced."
        )
    if "current_date_source" not in meta:
        warnings.append("metadata.current_date_source is missing.")

    # Duplicate job_ids
    job_ids = [j.job_id for j in model.jobs]
    if len(job_ids) != len(set(job_ids)):
        errors.append("Duplicate job_id values found in jobs list.")

    # Duplicate machine_ids
    machine_ids = [m.machine_id for m in model.machines]
    if len(machine_ids) != len(set(machine_ids)):
        errors.append("Duplicate machine_id values found in machines list.")

    # Duplicate op_ids within each job
    for job in model.jobs:
        op_ids = [op.op_id for op in job.operations]
        if len(op_ids) != len(set(op_ids)):
            errors.append(f"Duplicate op_id within job '{job.job_id}'.")

    # Backlog / past due dates — warning only, not error
    for job in model.jobs:
        if job.due_at < model.reference_time:
            warnings.append(
                f"Order {job.job_id} due before reference_time; "
                "treated as backlog/late risk."
            )

    # Hard setup rules must have from_family + to_family
    for rule in model.setup_rules:
        if rule.hard and (not rule.from_family or not rule.to_family):
            errors.append(
                f"Hard setup rule '{rule.rule_id}' missing from_family or to_family."
            )

    # Hard cleaning rules must have from_family + to_family
    for rule in model.cleaning_rules:
        if rule.hard and (not rule.from_family or not rule.to_family):
            errors.append(
                f"Hard cleaning rule '{rule.rule_id}' missing from_family or to_family."
            )

    # Hard wait rules must have from/to operation family
    for rule in model.wait_rules:
        if rule.hard and (
            not rule.from_operation_family or not rule.to_operation_family
        ):
            errors.append(
                f"Hard wait rule '{rule.rule_id}' missing from/to operation family."
            )

    return errors, warnings


def _json_safe_dump_model(model: SolverPayload) -> dict:
    """Return the model as a JSON-serializable dict using Pydantic v2 mode='json'."""
    return model.model_dump(mode="json")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def validate_canonical_payload(payload: Any) -> dict:
    """
    Validate a SolverPayload dict using Pydantic v2 and additional reference checks.

    Returns:
    {
        "is_valid":          bool,
        "errors":            [str],
        "warnings":          [str],
        "validated_payload": dict | None
    }
    """
    errors: list[str] = []
    warnings: list[str] = []

    # Basic type check
    if not payload or not isinstance(payload, dict):
        return {
            "is_valid": False,
            "errors": ["payload must be a non-empty dict."],
            "warnings": [],
            "validated_payload": None,
        }

    # Pydantic validation
    validated_model: SolverPayload | None = None
    try:
        validated_model = SolverPayload(**payload)
    except ValidationError as exc:
        errors.extend(_format_pydantic_error(exc))
    except Exception as exc:
        errors.append(f"Unexpected error during Pydantic validation: {exc}")

    if errors:
        return {
            "is_valid": False,
            "errors": errors,
            "warnings": warnings,
            "validated_payload": None,
        }

    # Additional reference / cross-field checks
    assert validated_model is not None
    extra_errors, extra_warnings = _collect_reference_warnings(validated_model)
    errors.extend(extra_errors)
    warnings.extend(extra_warnings)

    if errors:
        return {
            "is_valid": False,
            "errors": errors,
            "warnings": warnings,
            "validated_payload": None,
        }

    return {
        "is_valid": True,
        "errors": [],
        "warnings": warnings,
        "validated_payload": _json_safe_dump_model(validated_model),
    }
