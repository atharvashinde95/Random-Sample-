"""
Manufacturing DNA detection tool.

Summarizes the workbook as a manufacturing scheduling problem
without assigning a domain name label.
"""
from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

BASIC_SCHEDULING_REQUIREMENTS = [
    "demand_orders",
    "routing",
    "machines",
    "product_id",
    "quantity",
    "due_date",
    "stage_sequence",
    "runtime_or_duration",
    "machine_eligibility",
]

ADVANCED_FEATURES = [
    "bom",
    "inventory",
    "material_receipts",
    "setup_changeover",
    "cleaning",
    "quality_hold",
    "shelf_life",
    "maintenance",
    "labor_shifts",
    "overtime",
    "cost_fields",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _has_role(sheet_mapping: dict[str, str], role: str) -> bool:
    """Return True if any sheet maps to the given role."""
    return role in sheet_mapping.values()


def _get_sheets_for_role(sheet_mapping: dict[str, str], role: str) -> list[str]:
    return [s for s, r in sheet_mapping.items() if r == role]


def _has_canonical_col(
    column_mapping: dict[str, dict[str, str]],
    role: str,
    sheet_mapping: dict[str, str],
    canonical_col: str,
) -> bool:
    """Return True if any sheet of the given role has the canonical column mapped."""
    for raw_sheet in _get_sheets_for_role(sheet_mapping, role):
        if canonical_col in column_mapping.get(raw_sheet, {}).values():
            return True
    return False


def _has_any_canonical_col(
    column_mapping: dict[str, dict[str, str]],
    role: str,
    sheet_mapping: dict[str, str],
    canonical_cols: list[str],
) -> bool:
    for col in canonical_cols:
        if _has_canonical_col(column_mapping, role, sheet_mapping, col):
            return True
    return False


def _get_table_rows(normalized_tables: dict, role: str, sheet_mapping: dict) -> list[dict]:
    """Collect all rows from tables with the given role."""
    rows: list[dict] = []
    for raw_sheet in _get_sheets_for_role(sheet_mapping, role):
        rows.extend(normalized_tables.get(raw_sheet, []))
    return rows


def _has_col_in_table(rows: list[dict], col_name: str) -> bool:
    """Return True if the column exists and has at least one non-null value."""
    return any(row.get(col_name) is not None for row in rows)


def _has_multiple_operations_per_product(
    routing_rows: list[dict],
) -> bool:
    """Return True if at least one product has more than one routing step."""
    from collections import Counter
    product_counts: Counter = Counter()
    for row in routing_rows:
        pid = row.get("product_id")
        if pid is not None:
            product_counts[pid] += 1
    return any(c > 1 for c in product_counts.values())


# ---------------------------------------------------------------------------
# Feature detection functions
# ---------------------------------------------------------------------------

def _detect_has_demand(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    if not _has_role(sheet_mapping, "Demand_Orders"):
        return False, []
    rows = _get_table_rows(normalized_tables, "Demand_Orders", sheet_mapping)
    evidence = ["Demand_Orders sheet detected"]
    if _has_col_in_table(rows, "quantity"):
        evidence.append("quantity column present")
    if _has_col_in_table(rows, "due_date"):
        evidence.append("due_date column present")
    return True, evidence


def _detect_has_products(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    has_sku = _has_role(sheet_mapping, "SKU_Master")
    has_demand_products = _has_canonical_col(column_mapping, "Demand_Orders", sheet_mapping, "product_id")
    has_routing_products = _has_canonical_col(column_mapping, "Routing", sheet_mapping, "product_id")
    if has_sku or has_demand_products or has_routing_products:
        ev = []
        if has_sku:
            ev.append("SKU_Master sheet detected")
        if has_demand_products:
            ev.append("product_id in Demand_Orders")
        if has_routing_products:
            ev.append("product_id in Routing")
        return True, ev
    return False, []


def _detect_has_routing(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    if not _has_role(sheet_mapping, "Routing"):
        return False, []
    rows = _get_table_rows(normalized_tables, "Routing", sheet_mapping)
    evidence = ["Routing sheet detected"]
    if _has_col_in_table(rows, "stage_sequence"):
        evidence.append("stage_sequence column present")
    if _has_col_in_table(rows, "runtime_minutes_per_batch"):
        evidence.append("runtime_minutes_per_batch column present")
    return True, evidence


def _detect_has_machines(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    if not _has_role(sheet_mapping, "Machine_Master"):
        return False, []
    rows = _get_table_rows(normalized_tables, "Machine_Master", sheet_mapping)
    evidence = ["Machine_Master sheet detected"]
    if _has_col_in_table(rows, "machine_id"):
        evidence.append("machine_id column present")
    return True, evidence


def _detect_has_machine_capacity(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    rows = _get_table_rows(normalized_tables, "Machine_Master", sheet_mapping)
    if _has_col_in_table(rows, "capacity"):
        return True, ["capacity column in Machine_Master"]
    return False, []


def _detect_has_processing_times(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    rows = _get_table_rows(normalized_tables, "Routing", sheet_mapping)
    if _has_col_in_table(rows, "runtime_minutes_per_batch"):
        return True, ["runtime_minutes_per_batch in Routing"]
    return False, []


def _detect_has_due_dates(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    rows = _get_table_rows(normalized_tables, "Demand_Orders", sheet_mapping)
    if _has_col_in_table(rows, "due_date"):
        return True, ["due_date column in Demand_Orders"]
    return False, []


def _detect_has_priorities(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    rows = _get_table_rows(normalized_tables, "Demand_Orders", sheet_mapping)
    has_class = _has_col_in_table(rows, "priority_class")
    has_weight = _has_col_in_table(rows, "priority_weight")
    if has_class or has_weight:
        ev = []
        if has_class:
            ev.append("priority_class in Demand_Orders")
        if has_weight:
            ev.append("priority_weight in Demand_Orders")
        return True, ev
    return False, []


def _detect_has_bom(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    if _has_role(sheet_mapping, "BOM"):
        return True, ["BOM sheet detected"]
    return False, []


def _detect_has_inventory(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    if _has_role(sheet_mapping, "Inventory"):
        return True, ["Inventory sheet detected"]
    return False, []


def _detect_has_setup_changeover(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    if _has_role(sheet_mapping, "Setup_Changeover"):
        rows = _get_table_rows(normalized_tables, "Setup_Changeover", sheet_mapping)
        ev = ["Setup_Changeover sheet detected"]
        if _has_col_in_table(rows, "setup_minutes"):
            ev.append("setup_minutes present")
        if _has_col_in_table(rows, "cleaning_minutes"):
            ev.append("cleaning_minutes present")
        return True, ev
    return False, []


def _detect_has_quality_hold(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    rows = _get_table_rows(normalized_tables, "SKU_Master", sheet_mapping)
    if _has_col_in_table(rows, "qa_release_hours"):
        return True, ["qa_release_hours in SKU_Master"]
    return False, []


def _detect_has_calendar(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    if _has_role(sheet_mapping, "Machine_Calendar"):
        return True, ["Machine_Calendar sheet detected"]
    return False, []


def _detect_has_labor(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    if _has_role(sheet_mapping, "Labor_Shifts"):
        return True, ["Labor_Shifts sheet detected"]
    return False, []


def _detect_has_maintenance(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    if _has_role(sheet_mapping, "Maintenance"):
        return True, ["Maintenance sheet detected"]
    return False, []


def _detect_has_overtime(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    # Check for overtime fields in any table
    for role in ("Cost_Parameters", "Labor_Shifts", "Machine_Calendar"):
        for raw_sheet in _get_sheets_for_role(sheet_mapping, role):
            rows = normalized_tables.get(raw_sheet, [])
            if _has_col_in_table(rows, "overtime") or _has_col_in_table(rows, "overtime_minutes"):
                return True, [f"overtime field found in {role}"]
    return False, []


def _detect_has_costs(
    sheet_mapping: dict, column_mapping: dict, normalized_tables: dict
) -> tuple[bool, list[str]]:
    evidence = []
    rows_mm = _get_table_rows(normalized_tables, "Machine_Master", sheet_mapping)
    if _has_col_in_table(rows_mm, "hourly_cost"):
        evidence.append("hourly_cost in Machine_Master")
    rows_sku = _get_table_rows(normalized_tables, "SKU_Master", sheet_mapping)
    if _has_col_in_table(rows_sku, "holding_cost_per_unit_per_day"):
        evidence.append("holding_cost in SKU_Master")
    if _has_col_in_table(rows_sku, "selling_price_per_unit"):
        evidence.append("selling_price in SKU_Master")
    rows_do = _get_table_rows(normalized_tables, "Demand_Orders", sheet_mapping)
    if _has_col_in_table(rows_do, "late_penalty_per_unit_per_day"):
        evidence.append("late_penalty in Demand_Orders")
    if _has_role(sheet_mapping, "Cost_Parameters"):
        evidence.append("Cost_Parameters sheet detected")
    rows_sc = _get_table_rows(normalized_tables, "Setup_Changeover", sheet_mapping)
    if _has_col_in_table(rows_sc, "setup_cost"):
        evidence.append("setup_cost in Setup_Changeover")
    return bool(evidence), evidence


# ---------------------------------------------------------------------------
# Production model inference
# ---------------------------------------------------------------------------

def _infer_production_model(
    has_demand: bool,
    has_routing: bool,
    has_machines: bool,
    routing_rows: list[dict],
    has_bom: bool,
) -> str:
    if has_demand and has_routing and has_machines:
        has_batch_fields = _has_col_in_table(routing_rows, "batch_capacity")
        if has_batch_fields or has_bom:
            return "multi_step_batch_manufacturing"
        return "multi_step_job_shop_or_batch_scheduling"
    if has_demand and has_machines and not has_routing:
        return "single_step_capacity_scheduling_candidate"
    if has_demand and not has_machines and not has_routing:
        return "planning_only_not_schedulable"
    return "unknown_scheduling_structure"


# ---------------------------------------------------------------------------
# Missing fields analysis
# ---------------------------------------------------------------------------

def _find_missing_basic(dna: dict) -> list[str]:
    missing = []
    if not dna["has_demand"]:
        missing.append("No demand/order table found")
    if not dna["has_routing"]:
        missing.append("No routing/process steps table found")
    if not dna["has_machines"]:
        missing.append("No machine/resource master found")
    if not dna["has_processing_times"]:
        missing.append("No processing time/duration column found")
    if not dna["has_due_dates"]:
        missing.append("No due_date column found in orders")
    if dna["has_routing"] and not dna.get("_has_stage_sequence"):
        missing.append("No stage_sequence column found in routing")
    if dna["has_routing"] and not dna.get("_has_machine_eligibility"):
        missing.append("No machine eligibility (eligible_machines or machine_type) in routing")
    return missing


def _find_missing_advanced(dna: dict) -> list[str]:
    missing = []
    if not dna["has_bom"]:
        missing.append("BOM/recipe table not found")
    if not dna["has_inventory"]:
        missing.append("Inventory/stock table not found")
    if not dna["has_setup_changeover"]:
        missing.append("Setup/changeover matrix not found")
    if not dna["has_quality_hold"]:
        missing.append("QA release hold (qa_release_hours) not found")
    if not dna["has_calendar"]:
        missing.append("Machine calendar/availability not found")
    if not dna["has_labor"]:
        missing.append("Labor capacity not found")
    if not dna["has_overtime"]:
        missing.append("Overtime capacity not found")
    return missing


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def detect_manufacturing_dna(
    normalized_tables: dict,
    sheet_mapping: dict[str, str],
    column_mapping: dict[str, dict[str, str]],
) -> dict:
    """
    Build a manufacturing DNA summary describing what scheduling structures exist.

    Input:
        normalized_tables: {sheet_name: [row_dict, ...]}
        sheet_mapping: {raw_sheet: canonical_role}
        column_mapping: {raw_sheet: {raw_col: canonical_col}}

    Output: {
        "manufacturing_dna": {...},
        "evidence": {...},
        "missing_for_basic_scheduling": [...],
        "missing_for_advanced_scheduling": [...],
        "errors": [...],
        "warnings": [...]
    }
    """
    errors: list[str] = []
    warnings: list[str] = []

    detectors = [
        ("has_demand",           _detect_has_demand),
        ("has_products",         _detect_has_products),
        ("has_routing",          _detect_has_routing),
        ("has_machines",         _detect_has_machines),
        ("has_machine_capacity", _detect_has_machine_capacity),
        ("has_processing_times", _detect_has_processing_times),
        ("has_due_dates",        _detect_has_due_dates),
        ("has_priorities",       _detect_has_priorities),
        ("has_bom",              _detect_has_bom),
        ("has_inventory",        _detect_has_inventory),
        ("has_setup_changeover", _detect_has_setup_changeover),
        ("has_quality_hold",     _detect_has_quality_hold),
        ("has_calendar",         _detect_has_calendar),
        ("has_labor",            _detect_has_labor),
        ("has_maintenance",      _detect_has_maintenance),
        ("has_overtime",         _detect_has_overtime),
        ("has_costs",            _detect_has_costs),
    ]

    dna: dict[str, Any] = {}
    evidence: dict[str, list[str]] = {}

    for key, detector in detectors:
        try:
            flag, ev = detector(sheet_mapping, column_mapping, normalized_tables)
        except Exception as exc:
            errors.append(f"DNA detector '{key}' failed: {exc}")
            flag, ev = False, []
        dna[key] = flag
        if ev:
            evidence[key] = ev

    # Internal flags for missing analysis
    routing_rows = _get_table_rows(normalized_tables, "Routing", sheet_mapping)
    dna["_has_stage_sequence"] = _has_col_in_table(routing_rows, "stage_sequence")
    dna["_has_machine_eligibility"] = (
        _has_col_in_table(routing_rows, "eligible_machines")
        or _has_col_in_table(routing_rows, "machine_type")
    )

    # Infer production model
    dna["production_model"] = _infer_production_model(
        dna.get("has_demand", False),
        dna.get("has_routing", False),
        dna.get("has_machines", False),
        routing_rows,
        dna.get("has_bom", False),
    )

    missing_basic = _find_missing_basic(dna)
    missing_advanced = _find_missing_advanced(dna)

    if missing_basic:
        warnings.append(
            f"Basic scheduling is incomplete. Missing: {', '.join(missing_basic)}"
        )

    # Clean internal flags from public output
    public_dna = {k: v for k, v in dna.items() if not k.startswith("_")}

    return {
        "manufacturing_dna": public_dna,
        "evidence": evidence,
        "missing_for_basic_scheduling": missing_basic,
        "missing_for_advanced_scheduling": missing_advanced,
        "errors": errors,
        "warnings": warnings,
    }
