"""
Solver capability verifier tool.

Separates detected constraint candidates into:
  - verified_constraints   (status=enforced, all required fields present, solver supports)
  - partial_constraints    (status=detected_partial or needs_user_review)
  - unsupported_constraints (status=detected_not_enforced or unsupported)
  - constraint_enforcement_matrix (full picture of every constraint type)

Only verified_constraints should ever enter the CP-SAT solver payload.

DETECTED ≠ ENFORCED.  This module makes that separation explicit.
"""
from __future__ import annotations

import math
from typing import Any

# ---------------------------------------------------------------------------
# Solver capability registry
# ---------------------------------------------------------------------------

SUPPORTED_SOLVER_CONSTRAINTS: dict[str, dict] = {
    # --- Core scheduling constraints (fully supported) ---
    "demand_fulfillment": {
        "supported": True,
        "solver_mechanism": "Job intervals created for each order",
        "required_fields": ["product_id", "quantity", "due_date"],
    },
    "operation_precedence": {
        "supported": True,
        "solver_mechanism": "AddEndBeforeStart() between consecutive operation intervals",
        "required_fields": ["product_id", "stage_sequence", "runtime_minutes_per_batch"],
    },
    "machine_capacity_no_overlap": {
        "supported": True,
        "solver_mechanism": "AddNoOverlap() or AddCumulative() per machine",
        "required_fields": ["machine_id"],
    },
    "machine_eligibility": {
        "supported": True,
        "solver_mechanism": "NewOptionalIntervalVar per eligible machine + OnlyEnforceIf",
        "required_fields": ["eligible_machines"],
    },
    "processing_time": {
        "supported": True,
        "solver_mechanism": "IntervalVar size = duration_minutes",
        "required_fields": ["runtime_minutes_per_batch"],
    },
    "due_date_tardiness": {
        "supported": True,
        "solver_mechanism": "Tardiness term in objective: max(0, end - due_at)",
        "required_fields": ["due_date"],
    },
    "priority_weighting": {
        "supported": True,
        "solver_mechanism": "priority_weight multiplied into objective tardiness term",
        "required_fields": ["priority_weight"],
    },
    "machine_calendar_availability": {
        "supported": True,
        "solver_mechanism": "CalendarWindow intervals forbidden via AddNoOverlap",
        "required_fields": ["machine_id", "start", "end"],
    },
    "setup_changeover": {
        "supported": True,
        "solver_mechanism": "Sequence-dependent setup arcs in circuit/setup model",
        "required_fields": ["from_family", "to_family", "setup_minutes"],
    },
    "cleaning_changeover": {
        "supported": True,
        "solver_mechanism": "Sequence-dependent cleaning arcs added to setup model",
        "required_fields": ["from_family", "to_family", "cleaning_minutes"],
    },
    "wait_between_operations": {
        "supported": True,
        "solver_mechanism": "min/max gap constraints between consecutive op intervals",
        "required_fields": ["from_operation_family", "to_operation_family"],
    },
    "quality_hold_release": {
        "supported": True,
        "solver_mechanism": "QA hold modeled as extra wait interval after last operation",
        "required_fields": ["qa_release_hours"],
    },
    # --- Domain-specific constraints that MAP to supported solver constraints ---
    "proof_to_bake_max_wait": {
        "supported": True,
        "maps_to": "wait_between_operations",
        "solver_mechanism": "max_wait gap constraint between PROOF and BAKE intervals",
        "required_fields": ["from_operation_family", "to_operation_family", "max_wait_minutes"],
    },
    "cool_to_pack_max_wait": {
        "supported": True,
        "maps_to": "wait_between_operations",
        "solver_mechanism": "max_wait gap constraint between COOL and PACK intervals",
        "required_fields": ["from_operation_family", "to_operation_family", "max_wait_minutes"],
    },
    "allergen_cleaning": {
        "supported": True,
        "maps_to": "cleaning_changeover",
        "solver_mechanism": "Sequence-dependent cleaning arcs for allergen transitions",
        "required_fields": ["from_family", "to_family", "cleaning_minutes"],
    },
    "bulk_mix_to_fill_max_wait": {
        "supported": True,
        "maps_to": "wait_between_operations",
        "solver_mechanism": "max_wait gap constraint between MIX and FILL intervals",
        "required_fields": ["from_operation_family", "to_operation_family", "max_wait_minutes"],
    },
    "fragrance_changeover_cleaning": {
        "supported": True,
        "maps_to": "cleaning_changeover",
        "solver_mechanism": "Sequence-dependent cleaning arcs for fragrance transitions",
        "required_fields": ["from_family", "to_family", "cleaning_minutes"],
    },
    "color_changeover_cleaning": {
        "supported": True,
        "maps_to": "cleaning_changeover",
        "solver_mechanism": "Sequence-dependent cleaning arcs for color transitions",
        "required_fields": ["from_family", "to_family", "cleaning_minutes"],
    },
    "GMP_QC_release_hold": {
        "supported": True,
        "maps_to": "quality_hold_release",
        "solver_mechanism": "QA hold modeled as mandatory wait after last operation",
        "required_fields": ["qa_release_hours"],
    },
    "grade_changeover": {
        "supported": True,
        "maps_to": "setup_changeover",
        "solver_mechanism": "Sequence-dependent setup arcs for grade transitions",
        "required_fields": ["from_family", "to_family", "setup_minutes"],
    },
    "thickness_changeover": {
        "supported": True,
        "maps_to": "setup_changeover",
        "solver_mechanism": "Sequence-dependent setup arcs for thickness transitions",
        "required_fields": ["from_family", "to_family", "setup_minutes"],
    },
    "dye_color_changeover": {
        "supported": True,
        "maps_to": "setup_changeover",
        "solver_mechanism": "Sequence-dependent setup/cleaning arcs for dye transitions",
        "required_fields": ["from_family", "to_family", "setup_minutes"],
    },
    "mold_changeover": {
        "supported": True,
        "maps_to": "setup_changeover",
        "solver_mechanism": "Sequence-dependent setup arcs for mold changeover",
        "required_fields": ["from_family", "to_family", "setup_minutes"],
    },
    "print_plate_changeover": {
        "supported": True,
        "maps_to": "setup_changeover",
        "solver_mechanism": "Sequence-dependent setup arcs for print plate change",
        "required_fields": ["from_family", "to_family", "setup_minutes"],
    },
    "carton_size_changeover": {
        "supported": True,
        "maps_to": "setup_changeover",
        "solver_mechanism": "Sequence-dependent setup arcs for carton size change",
        "required_fields": ["from_family", "to_family", "setup_minutes"],
    },
    "part_family_changeover": {
        "supported": True,
        "maps_to": "setup_changeover",
        "solver_mechanism": "Sequence-dependent setup arcs for part family change",
        "required_fields": ["from_family", "to_family", "setup_minutes"],
    },
    "paint_curing_wait": {
        "supported": True,
        "maps_to": "wait_between_operations",
        "solver_mechanism": "min_wait gap constraint between PAINT and CURE intervals",
        "required_fields": ["from_operation_family", "to_operation_family", "min_wait_minutes"],
    },
    "validated_cleaning_changeover": {
        "supported": True,
        "maps_to": "cleaning_changeover",
        "solver_mechanism": "Sequence-dependent cleaning arcs for validated GMP cleaning",
        "required_fields": ["from_family", "to_family", "cleaning_minutes"],
    },
    "heat_treatment_sequence": {
        "supported": True,
        "maps_to": "operation_precedence",
        "solver_mechanism": "Precedence constraints for heat treatment stages",
        "required_fields": ["product_id", "stage_sequence"],
    },
    "cooling_wait_time": {
        "supported": True,
        "maps_to": "wait_between_operations",
        "solver_mechanism": "min_wait gap constraint after cooling operation",
        "required_fields": ["from_operation_family", "to_operation_family"],
    },
    "wash_to_dry_wait": {
        "supported": True,
        "maps_to": "wait_between_operations",
        "solver_mechanism": "max_wait gap constraint between WASH and DRY intervals",
        "required_fields": ["from_operation_family", "to_operation_family", "max_wait_minutes"],
    },
    # --- Constraints detected but NOT enforced by current solver ---
    "material_inventory": {
        "supported": False,
        "reason": "Detected but time-phased material consumption is not fully modeled by current CP-SAT solver",
    },
    "material_time_phased_inventory": {
        "supported": False,
        "reason": "Detected but not enforced — requires time-indexed material flow variables",
    },
    "shelf_life_freshness": {
        "supported": False,
        "reason": "Detected but shelf-life windows are not fully enforced by current solver",
    },
    "freshness_or_shelf_life": {
        "supported": False,
        "reason": "Detected but shelf-life/freshness windows are not fully modeled",
    },
    "expiry_window": {
        "supported": False,
        "reason": "Detected but expiry window enforcement requires time-indexed variables",
    },
    "labor_shift_capacity": {
        "supported": False,
        "reason": "Detected but labor cumulative resource constraints are not fully modeled",
    },
    "overtime_capacity": {
        "supported": False,
        "reason": "Detected but optional overtime capacity is not fully modeled",
    },
    "component_reel_availability": {
        "supported": False,
        "reason": "Detected but component-level time-phased availability is not modeled",
    },
    "fixture_availability": {
        "supported": False,
        "reason": "Detected but fixture/jig resource sharing is not fully modeled",
    },
    "rework_loop_candidate": {
        "supported": False,
        "reason": "Detected but rework loops require conditional scheduling not yet implemented",
    },
    "active_ingredient_material_availability": {
        "supported": False,
        "reason": "Detected but API-level material availability is not fully modeled",
    },
    "cleanroom_class_constraint": {
        "supported": False,
        "reason": "Detected but cleanroom class resource constraints are not yet implemented",
    },
    "furnace_batch_capacity": {
        "supported": False,
        "reason": "Detected but furnace batch-mode scheduling is not fully modeled",
    },
    "rolling_mill_capacity": {
        "supported": False,
        "reason": "Detected — mapped to machine_capacity_no_overlap if machine_id present",
    },
    "loom_setup": {
        "supported": False,
        "reason": "Detected — mapped to setup_changeover if setup_minutes present",
    },
    "fabric_roll_length": {
        "supported": False,
        "reason": "Detected but roll-length batching is not fully modeled",
    },
    "drying_capacity": {
        "supported": False,
        "reason": "Detected — mapped to machine_capacity_no_overlap if capacity present",
    },
    "test_stage_capacity": {
        "supported": False,
        "reason": "Detected — mapped to machine_capacity_no_overlap if capacity present",
    },
    "SMT_line_setup": {
        "supported": False,
        "reason": "Detected — mapped to setup_changeover if setup data present",
    },
    "tool_availability": {
        "supported": False,
        "reason": "Detected but tool/die resource sharing is not fully modeled",
    },
    "assembly_station_capacity": {
        "supported": False,
        "reason": "Detected — mapped to machine_capacity_no_overlap if capacity present",
    },
    "batch_size_rules": {
        "supported": False,
        "reason": "Detected but batch splitting/merging is not fully modeled",
    },
    "quarantine_hold": {
        "supported": True,
        "maps_to": "quality_hold_release",
        "solver_mechanism": "QA hold modeled as mandatory wait after last operation",
        "required_fields": ["qa_release_hours"],
    },
    "batch_release_hold": {
        "supported": True,
        "maps_to": "quality_hold_release",
        "solver_mechanism": "QA hold modeled as mandatory wait after last operation",
        "required_fields": ["qa_release_hours"],
    },
    "material_receipts": {
        "supported": False,
        "reason": "Detected but time-phased receipt planning is not fully modeled",
    },
    "maintenance_downtime": {
        "supported": True,
        "solver_mechanism": "Maintenance windows modeled as forbidden intervals per machine",
        "required_fields": ["machine_id", "start", "end"],
    },
    "priority_weighting": {
        "supported": True,
        "solver_mechanism": "priority_weight multiplied into objective tardiness term",
        "required_fields": ["priority_weight"],
    },
}

# ---------------------------------------------------------------------------
# Allowed status values
# ---------------------------------------------------------------------------

STATUS_ENFORCED = "enforced"
STATUS_PARTIAL = "detected_partial"
STATUS_NOT_ENFORCED = "detected_not_enforced"
STATUS_NEEDS_REVIEW = "needs_user_review"
STATUS_UNSUPPORTED = "unsupported"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize_priority_weighting_candidate(candidate: dict) -> dict:
    """
    Before required-field validation, allow priority_weight to be derived
    from priority_class deterministically, so the constraint can be enforced.
    """
    if candidate.get("constraint_type") != "priority_weighting":
        return candidate
    available = set(candidate.get("available_fields") or [])
    data = dict(candidate.get("data") or {})
    if "priority_weight" in available:
        data["priority_weight_source"] = "priority_weight"
    elif "priority_class" in available:
        available.add("priority_weight")
        data["priority_weight_source"] = "derived_from_priority_class"
        data["priority_weight_derivation"] = {"VIP": 4, "HIGH": 3, "MEDIUM": 2, "NORMAL": 1, "LOW": 1}
        evidence = list(candidate.get("evidence") or [])
        evidence.append("priority_weight can be deterministically derived from priority_class")
        candidate = {**candidate, "evidence": evidence}
    return {**candidate, "available_fields": list(available), "data": data}


def _dedupe_enforcement_matrix(matrix: list[dict]) -> list[dict]:
    """Keep only the highest-status row per constraint type. Merges evidence."""
    status_rank = {
        "enforced": 5, "detected_partial": 4,
        "needs_user_review": 3, "detected_not_enforced": 2, "unsupported": 1,
    }
    best: dict[str, dict] = {}
    for row in matrix:
        ctype = row.get("constraint", "")
        rank = status_rank.get(row.get("status", ""), 0)
        existing = best.get(ctype)
        if existing is None:
            best[ctype] = dict(row)
        elif rank > status_rank.get(existing.get("status", ""), 0):
            # Merge evidence then replace
            merged_ev = list(existing.get("evidence") or []) + list(row.get("evidence") or [])
            best[ctype] = {**row, "evidence": merged_ev[:4]}
    return list(best.values())


def _to_float_safe(v):
    if v is None:
        return None
    try:
        f = float(v)
        return None if (math.isnan(f) or math.isinf(f)) else f
    except (TypeError, ValueError):
        return None


def _has_valid_value(candidate: dict, field: str) -> bool:
    """Check if a field has a non-null valid value in candidate data."""
    data = candidate.get("data") or {}
    val = data.get(field)
    if val is not None:
        fv = _to_float_safe(val) if isinstance(val, (int, float)) else val
        return fv is not None
    return field in (candidate.get("available_fields") or [])


# ---------------------------------------------------------------------------
# Core verification
# ---------------------------------------------------------------------------

def _verify_one(candidate: dict) -> dict:
    """
    Verify a single candidate against the solver capability registry.
    Returns an updated candidate dict with:
      - status updated
      - solver_supported set
      - enforced set
      - verification_reason set
    """
    ctype = candidate.get("constraint_type", "")
    # Normalize priority_weighting before field check (allow derived from priority_class)
    candidate = _normalize_priority_weighting_candidate(candidate)
    cap = SUPPORTED_SOLVER_CONSTRAINTS.get(ctype)

    if cap is None:
        return {
            **candidate,
            "status": STATUS_UNSUPPORTED,
            "solver_supported": False,
            "enforced": False,
            "verification_reason": f"Constraint type '{ctype}' not in solver capability registry",
        }

    if not cap.get("supported", False):
        return {
            **candidate,
            "status": STATUS_NOT_ENFORCED,
            "solver_supported": False,
            "enforced": False,
            "verification_reason": cap.get("reason", "Not supported by current CP-SAT solver"),
        }

    # Solver supports this constraint type — check required fields.
    required = cap.get("required_fields", [])
    available = set(candidate.get("available_fields") or [])
    missing = [f for f in required if f not in available and
               not _has_valid_value(candidate, f)]

    # If candidate was already flagged as needs_user_review, respect that
    if candidate.get("status") == STATUS_NEEDS_REVIEW:
        return {
            **candidate,
            "solver_supported": True,
            "enforced": False,
            "verification_reason": f"Solver supports this constraint but required values are missing: {missing or 'see missing_fields'}",
        }

    if missing:
        return {
            **candidate,
            "status": STATUS_PARTIAL,
            "solver_supported": True,
            "enforced": False,
            "missing_fields": list(set((candidate.get("missing_fields") or []) + missing)),
            "verification_reason": f"Solver supports this but required fields missing: {missing}",
        }

    # All fields present and solver supports it → enforced
    return {
        **candidate,
        "status": STATUS_ENFORCED,
        "solver_supported": True,
        "enforced": True,
        "verification_reason": (
            cap.get("solver_mechanism", "Supported by solver")
            + (f" → maps to {cap['maps_to']}" if "maps_to" in cap else "")
        ),
    }


def verify_constraint_candidates(
    constraint_candidates: list[dict],
    normalized_tables: dict | None = None,
    manufacturing_dna: dict | None = None,
) -> dict:
    """
    Verify a list of constraint candidates against solver capabilities.

    Input:
        constraint_candidates: list of candidate dicts (from discovery or pack runner)
        normalized_tables: optional, used for field-level validation
        manufacturing_dna: optional metadata

    Output: {
        "verified_constraints": [...],       # status=enforced
        "partial_constraints": [...],        # status=detected_partial or needs_user_review
        "unsupported_constraints": [...],    # status=detected_not_enforced or unsupported
        "constraint_enforcement_matrix": [...],
        "errors": [...],
        "warnings": [...]
    }
    """
    errors: list[str] = []
    warnings: list[str] = []

    verified: list[dict] = []
    partial: list[dict] = []
    unsupported: list[dict] = []

    # Table → constraint type mapping for field augmentation
    _TABLE_FOR_CONSTRAINT: dict[str, str] = {
        "machine_calendar_availability": "Machine_Calendar",
        "maintenance_downtime": "Machine_Calendar",
    }

    for candidate in constraint_candidates:
        # Augment available_fields from normalized table columns before verification.
        # This prevents false PARTIAL when fields exist in the table but not in
        # the candidate dict (e.g., machine_calendar_availability start/end).
        ctype_local = candidate.get("constraint_type", "")
        _extra_table = _TABLE_FOR_CONSTRAINT.get(ctype_local)
        if _extra_table and normalized_tables:
            rows = normalized_tables.get(_extra_table) or []
            if rows:
                existing = set(candidate.get("available_fields") or [])
                existing.update(rows[0].keys())
                candidate = {**candidate, "available_fields": list(existing)}

        try:
            result = _verify_one(candidate)
        except Exception as exc:
            errors.append(
                f"Verification failed for '{candidate.get('constraint_type', '?')}': {exc}"
            )
            result = {
                **candidate,
                "status": STATUS_UNSUPPORTED,
                "solver_supported": False,
                "enforced": False,
                "verification_reason": f"Verification error: {exc}",
            }

        status = result.get("status", STATUS_UNSUPPORTED)
        if status == STATUS_ENFORCED:
            verified.append(result)
        elif status in (STATUS_PARTIAL, STATUS_NEEDS_REVIEW):
            partial.append(result)
        else:
            unsupported.append(result)

    # Build enforcement matrix covering all detected + registry-known types
    matrix = _build_enforcement_matrix(
        verified, partial, unsupported, constraint_candidates
    )
    matrix = _dedupe_enforcement_matrix(matrix)

    if not verified:
        warnings.append(
            "No constraints passed verification. "
            "Check that required fields are present in the dataset."
        )

    return {
        "verified_constraints": verified,
        "partial_constraints": partial,
        "unsupported_constraints": unsupported,
        "constraint_enforcement_matrix": matrix,
        "errors": errors,
        "warnings": warnings,
    }


def _build_enforcement_matrix(
    verified: list[dict],
    partial: list[dict],
    unsupported: list[dict],
    all_candidates: list[dict],
) -> list[dict]:
    """Build the constraint enforcement matrix."""
    # Collect all detected constraint types
    detected_types = {c["constraint_type"] for c in all_candidates}
    verified_types = {c["constraint_type"] for c in verified}
    partial_types = {c["constraint_type"] for c in partial}

    # Build index by constraint_type for fast lookup
    candidate_by_type: dict[str, dict] = {}
    for c in (verified + partial + unsupported):
        ctype = c["constraint_type"]
        if ctype not in candidate_by_type:
            candidate_by_type[ctype] = c

    matrix: list[dict] = []

    # Matrix rows for ALL detected constraints
    for ctype in sorted(detected_types):
        cap = SUPPORTED_SOLVER_CONSTRAINTS.get(ctype, {})
        c = candidate_by_type.get(ctype, {})
        is_enforced = ctype in verified_types
        is_partial = ctype in partial_types
        solver_sup = cap.get("supported", False) if cap else False
        status = c.get("status", STATUS_UNSUPPORTED)
        reason = c.get("verification_reason") or cap.get("reason") or \
                 cap.get("solver_mechanism", "Unknown")

        row: dict = {
            "constraint": ctype,
            "detected": True,
            "verified": is_enforced,
            "solver_supported": solver_sup,
            "enforced": is_enforced,
            "status": status,
            "reason": reason,
            "evidence": c.get("evidence", [])[:3],
        }
        if "maps_to" in cap:
            row["maps_to"] = cap["maps_to"]
        matrix.append(row)

    return matrix


# ---------------------------------------------------------------------------
# Compile verified constraints → canonical rule structures
# ---------------------------------------------------------------------------

def compile_verified_constraints(
    verified_constraints: list[dict],
    normalized_tables: dict | None = None,
) -> dict:
    """
    Convert verified constraints into canonical rule structures for the CP-SAT payload.

    Only verified (status=enforced) constraints should be passed here.
    Missing values result in the constraint being skipped with a warning.

    Output: {
        "setup_rules": [...],
        "cleaning_rules": [...],
        "wait_rules": [...],
        "quality_rules": [...],
        "batch_rules": [],
        "shared_resources": [],
        "warnings": [...]
    }
    """
    setup_rules: list[dict] = []
    cleaning_rules: list[dict] = []
    wait_rules: list[dict] = []
    quality_rules: list[dict] = []
    warnings: list[str] = []

    setup_idx = 0
    cleaning_idx = 0
    wait_idx = 0
    quality_idx = 0

    tables = normalized_tables or {}

    # Constraint type → rule category
    SETUP_TYPES = {
        "setup_changeover", "grade_changeover", "thickness_changeover",
        "dye_color_changeover", "mold_changeover", "print_plate_changeover",
        "carton_size_changeover", "part_family_changeover",
    }
    CLEANING_TYPES = {
        "cleaning_changeover", "allergen_cleaning", "fragrance_changeover_cleaning",
        "color_changeover_cleaning", "validated_cleaning_changeover",
    }
    WAIT_TYPES = {
        "proof_to_bake_max_wait", "cool_to_pack_max_wait", "bulk_mix_to_fill_max_wait",
        "wait_between_operations", "paint_curing_wait", "cooling_wait_time",
        "wash_to_dry_wait",
    }
    QUALITY_TYPES = {
        "quality_hold_release", "GMP_QC_release_hold", "quarantine_hold",
        "batch_release_hold",
    }

    for constraint in verified_constraints:
        if constraint.get("status") != STATUS_ENFORCED:
            warnings.append(
                f"Skipping non-enforced constraint '{constraint.get('constraint_type')}' "
                f"(status={constraint.get('status')})."
            )
            continue

        ctype = constraint.get("constraint_type", "")
        source_pack = constraint.get("source_pack", "unknown")
        data = constraint.get("data") or {}

        # -----------------------------------------------------------------------
        # Setup rules
        # -----------------------------------------------------------------------
        if ctype in SETUP_TYPES:
            rules_from_table = _compile_from_table_rows(
                tables, "Setup_Changeover", "setup", source_pack, setup_idx
            )
            if rules_from_table:
                setup_rules.extend(rules_from_table)
                setup_idx += len(rules_from_table)
            elif data.get("from_family") and data.get("to_family") and data.get("setup_minutes") is not None:
                setup_idx += 1
                setup_rules.append({
                    "rule_id": f"PACK_SETUP_{setup_idx:03d}",
                    "constraint_type": "sequence_dependent_setup",
                    "machine_id": data.get("machine_id"),
                    "machine_type": data.get("machine_type"),
                    "from_family": str(data["from_family"]),
                    "to_family": str(data["to_family"]),
                    "setup_minutes": int(float(data["setup_minutes"])),
                    "setup_cost": float(data.get("setup_cost", 0.0)),
                    "hard": bool(data.get("hard", True)),
                    "source": {"source_pack": source_pack, "constraint_type": ctype},
                })
            else:
                warnings.append(
                    f"Cannot compile '{ctype}': Setup_Changeover table missing or "
                    "from_family/to_family/setup_minutes not in data."
                )

        # -----------------------------------------------------------------------
        # Cleaning rules
        # -----------------------------------------------------------------------
        elif ctype in CLEANING_TYPES:
            rules_from_table = _compile_from_table_rows(
                tables, "Setup_Changeover", "cleaning", source_pack, cleaning_idx
            )
            if rules_from_table:
                cleaning_rules.extend(rules_from_table)
                cleaning_idx += len(rules_from_table)
            elif data.get("from_family") and data.get("to_family") and data.get("cleaning_minutes") is not None:
                cleaning_idx += 1
                cleaning_rules.append({
                    "rule_id": f"PACK_CLEAN_{cleaning_idx:03d}",
                    "constraint_type": "sequence_dependent_cleaning",
                    "machine_id": data.get("machine_id"),
                    "machine_type": data.get("machine_type"),
                    "from_family": str(data["from_family"]),
                    "to_family": str(data["to_family"]),
                    "cleaning_minutes": int(float(data["cleaning_minutes"])),
                    "cleaning_cost": float(data.get("cleaning_cost", 0.0)),
                    "hard": bool(data.get("hard", True)),
                    "source": {"source_pack": source_pack, "constraint_type": ctype},
                })
            else:
                warnings.append(
                    f"Cannot compile '{ctype}': from_family/to_family/cleaning_minutes "
                    "not available in data or Setup_Changeover table."
                )

        # -----------------------------------------------------------------------
        # Wait rules
        # -----------------------------------------------------------------------
        elif ctype in WAIT_TYPES:
            from_fam = data.get("from_operation_family")
            to_fam = data.get("to_operation_family")

            if from_fam is None or to_fam is None:
                warnings.append(
                    f"Cannot compile '{ctype}': from_operation_family or "
                    "to_operation_family missing from candidate data."
                )
                continue

            min_wait = _to_int_safe(data.get("min_wait_minutes"))
            max_wait = _to_int_safe(data.get("max_wait_minutes"))
            hard = bool(data.get("hard", True))

            # Infer constraint_type for the wait rule
            if max_wait is not None:
                wait_constraint_type = "max_wait_between_operations"
            elif min_wait is not None:
                wait_constraint_type = "min_wait_between_operations"
            else:
                wait_constraint_type = "min_wait_between_operations"
                warnings.append(
                    f"'{ctype}': no min or max wait value in data; "
                    "compiling as structural wait rule without numeric bound."
                )

            wait_idx += 1
            prefix = _ctype_to_prefix(ctype)
            wait_rules.append({
                "rule_id": f"PACK_{prefix}_{wait_idx:03d}",
                "constraint_type": wait_constraint_type,
                "from_operation_family": str(from_fam).upper(),
                "to_operation_family": str(to_fam).upper(),
                "min_wait_minutes": min_wait,
                "max_wait_minutes": max_wait,
                "hard": hard,
                "penalty_per_minute": float(data.get("penalty_per_minute", 0.0)),
                "source": {"source_pack": source_pack, "constraint_type": ctype},
            })

        # -----------------------------------------------------------------------
        # Quality rules
        # -----------------------------------------------------------------------
        elif ctype in QUALITY_TYPES:
            # Two sources for QA hold time:
            # 1. candidate "data" dict: qa_release_hours is in RAW HOURS (not normalized),
            #    qa_release_minutes is in minutes if present.
            # 2. normalized SKU_Master table: both qa_release_hours and qa_release_minutes
            #    are in MINUTES (normalization already converted hours→minutes).
            hold_minutes: int | None = None

            if data.get("qa_release_minutes") is not None:
                hold_minutes = int(float(data["qa_release_minutes"]))
            elif data.get("qa_release_hours") is not None:
                hold_minutes = int(float(data["qa_release_hours"]) * 60)  # raw hours → minutes
            else:
                # Fall back to normalized SKU_Master (values already in minutes)
                sku_rows = tables.get("SKU_Master", [])
                for row in sku_rows:
                    v = row.get("qa_release_minutes") or row.get("qa_release_hours")
                    if v is not None:
                        hold_minutes = int(float(v))  # already minutes in normalized table
                        break

            if hold_minutes is None:
                warnings.append(
                    f"Cannot compile '{ctype}': qa_release_hours/minutes not in candidate data. "
                    "Per-product QA hold from SKU_Master is not used as hard/soft constraint "
                    "because long holds (72-96h) with tight due dates risk infeasibility. "
                    "Provide explicit qa_release_hours in constraint candidate data to enforce."
                )
                continue

            quality_idx += 1
            quality_rules.append({
                "rule_id": f"PACK_QUALITY_{quality_idx:03d}",
                "constraint_type": "quality_release_hold",
                "product_id": data.get("product_id"),
                "product_family": data.get("product_family"),
                "operation_family": data.get("operation_family"),
                "hold_minutes": hold_minutes,
                # Quality holds are soft: violations incur penalty but don't block feasibility.
                # Long QA holds (e.g., 72h) would make datasets with tight due dates infeasible
                # as hard constraints. Making them soft is architecturally correct — real
                # manufacturing can bypass QA holds under emergency approval.
                "hard": False,
                "source": {"source_pack": source_pack, "constraint_type": ctype},
            })

        else:
            # Structural constraints (demand_fulfillment, operation_precedence, etc.)
            # have no explicit rule to compile — they are enforced by solver structure.
            pass

    return {
        "setup_rules": setup_rules,
        "cleaning_rules": cleaning_rules,
        "wait_rules": wait_rules,
        "quality_rules": quality_rules,
        "batch_rules": [],
        "shared_resources": [],
        "warnings": warnings,
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _to_int_safe(v: Any) -> int | None:
    if v is None:
        return None
    try:
        f = float(v)
        return None if (math.isnan(f) or math.isinf(f)) else int(f)
    except (TypeError, ValueError):
        return None


def _ctype_to_prefix(ctype: str) -> str:
    return ctype.upper().replace("_", "_")[:30]


def _compile_from_table_rows(
    tables: dict,
    table_name: str,
    rule_kind: str,  # "setup" or "cleaning"
    source_pack: str,
    start_idx: int,
) -> list[dict]:
    """Compile setup or cleaning rules from Setup_Changeover table rows."""
    rows = tables.get(table_name, [])
    if not rows:
        return []

    results: list[dict] = []
    idx = start_idx

    for row in rows:
        from_fam = row.get("from_family")
        to_fam = row.get("to_family")

        if rule_kind == "setup":
            value = _to_int_safe(row.get("setup_minutes"))
            if from_fam is None or to_fam is None or value is None:
                continue
            idx += 1
            results.append({
                "rule_id": f"PACK_SETUP_{idx:03d}",
                "constraint_type": "sequence_dependent_setup",
                "machine_id": row.get("machine_id"),
                "machine_type": row.get("machine_type"),
                "from_family": str(from_fam),
                "to_family": str(to_fam),
                "setup_minutes": value,
                "setup_cost": float(row.get("setup_cost") or 0.0),
                "hard": True,
                "source": {"source_pack": source_pack, "table": table_name},
            })

        elif rule_kind == "cleaning":
            value = _to_int_safe(row.get("cleaning_minutes"))
            if from_fam is None or to_fam is None or value is None:
                continue
            idx += 1
            results.append({
                "rule_id": f"PACK_CLEAN_{idx:03d}",
                "constraint_type": "sequence_dependent_cleaning",
                "machine_id": row.get("machine_id"),
                "machine_type": row.get("machine_type"),
                "from_family": str(from_fam),
                "to_family": str(to_fam),
                "cleaning_minutes": value,
                "cleaning_cost": float(row.get("cleaning_cost") or 0.0),
                "hard": True,
                "source": {"source_pack": source_pack, "table": table_name},
            })

    return results