from __future__ import annotations

import math
import re
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _to_bool(value: Any, default: bool = True) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(int(value))
    sv = str(value).strip().lower()
    if sv in ("true", "yes", "1", "y"):
        return True
    if sv in ("false", "no", "0", "n", ""):
        return False
    return default


def _to_float(value: Any, default: float = 0.0) -> float:
    if value is None:
        return default
    try:
        f = float(value)
        return default if (math.isnan(f) or math.isinf(f)) else f
    except (ValueError, TypeError):
        return default


def _to_int(value: Any, default: int = 0) -> int:
    if value is None:
        return default
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return default


def _is_present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, float) and math.isnan(value):
        return False
    sv = str(value).strip().lower()
    return bool(sv) and sv not in ("none", "nan", "null", "")


def _make_rule_id(prefix: str, index: int) -> str:
    return f"{prefix}_{index:03d}"


def _sort_routing_rows(rows: list[dict]) -> list[dict]:
    def _key(r: dict) -> int:
        try:
            return int(float(r.get("stage_sequence") or 9999))
        except (TypeError, ValueError):
            return 9999
    return sorted(rows, key=_key)


def _group_by(rows: list[dict], key: str) -> dict[str, list[dict]]:
    result: dict[str, list[dict]] = {}
    for row in rows:
        k = str(row.get(key) or "__UNKNOWN__")
        result.setdefault(k, []).append(row)
    return result


def _append_mapped_constraint(
    mapped_constraints: list,
    rule_id: str,
    constraint_type: str,
    source: str,
    hard: bool,
) -> None:
    mapped_constraints.append(
        {"rule_id": rule_id, "constraint_type": constraint_type,
         "source": source, "hard": hard}
    )


# ---------------------------------------------------------------------------
# Business Rules — deterministic BR-xxx pattern mapping
# ---------------------------------------------------------------------------
# Known BR patterns are treated as "mapped" (fully handled by solver) or
# "warning" (partially handled).  Only truly unrecognized hard rules block
# the pipeline via errors[].
#
# treatment values:
#   "mapped"   — the constraint is fully represented in the CP-SAT model
#   "warning"  — partially enforced; pipeline continues, warning added

_KNOWN_BR: dict[str, tuple[str, str]] = {
    "BR-001": ("mapped",  "demand balance is represented by Demand_Orders jobs"),
    "BR-002": ("mapped",  "no-overlap is enforced by CP-SAT AddNoOverlap"),
    "BR-003": ("mapped",  "precedence is enforced by operation sequence constraints"),
    "BR-004": ("warning", "material inventory balance is detected; time-phased enforcement is pending"),
    "BR-005": ("mapped",  "batch constraints are mapped via SKU_Master batch fields"),
    "BR-006": ("mapped",  "setup/cleaning are mapped via Setup_Changeover table"),
    "BR-007": ("mapped",  "QA release hold is mapped via SKU_Master QA fields"),
    "BR-008": ("mapped",  "machine eligibility is handled by Routing eligible_machines/machine_type"),
    "BR-009": ("warning", "shelf-life earliest start window is not fully enforced in current solver"),
    "BR-010": ("mapped",  "holding cost is included in objective when SKU_Master fields are present"),
    "BR-011": ("mapped",  "tardiness objective variables are always created by the solver"),
    "BR-012": ("mapped",  "revenue and profit are computed in cost_summary report"),
    "BR-013": ("warning", "overtime optional capacity is not fully modeled in current solver"),
}

# Constraint_Area values → canonical BR key (lower-case normalised)
_KNOWN_CONSTRAINT_AREAS: dict[str, str] = {
    "demand": "BR-001", "demand balance": "BR-001",
    "capacity": "BR-002", "no-overlap": "BR-002", "no overlap": "BR-002",
    "interval no-overlap": "BR-002",
    "routing": "BR-003", "precedence": "BR-003",
    "material": "BR-004", "inventory": "BR-004", "material balance": "BR-004",
    "batch": "BR-005", "batching": "BR-005", "integer batch": "BR-005",
    "setup": "BR-006", "changeover": "BR-006", "sequence dependent setup": "BR-006",
    "qa": "BR-007", "qa release": "BR-007", "quality release": "BR-007",
    "quality hold": "BR-007", "gmp": "BR-008",
    "eligibility": "BR-008", "machine eligibility": "BR-008",
    "shelf life": "BR-009", "freshness": "BR-009",
    "holding": "BR-010", "holding cost": "BR-010",
    "tardiness": "BR-011", "lateness": "BR-011",
    "profit": "BR-012", "revenue": "BR-012", "profit objective": "BR-012",
    "overtime": "BR-013", "overtime capacity": "BR-013",
}


def _normalize_br_id(raw_id: str) -> str:
    """Normalise BR-001, BR001, br_001 → 'BR-001'; return upper-cased original otherwise."""
    m = re.match(r"BR[\s\-_]?(\d+)", str(raw_id).strip(), re.IGNORECASE)
    return f"BR-{int(m.group(1)):03d}" if m else str(raw_id).strip().upper()


def _parse_hard_field(row: dict) -> bool:
    """
    Determine whether a Business_Rule row is hard.
    Handles the canonical 'hard' column AND raw__ variants that appear when
    the dataset uses non-standard column names such as 'Hard_or_Soft'.
    """
    v = row.get("hard")
    if v is not None:
        return _to_bool(v, default=True)
    for key in (
        "raw__Hard_or_Soft", "raw__hard_or_soft", "raw__Hard",
        "raw__is_hard", "raw__mandatory", "raw__Hard_Or_Soft",
    ):
        v = row.get(key)
        if v is not None:
            sv = str(v).strip().lower()
            if sv in ("hard", "yes", "true", "1", "y", "mandatory", "h"):
                return True
            if sv in ("soft", "no", "false", "0", "n", "optional", "s"):
                return False
    return True  # conservative default: treat unknown as hard


def _get_constraint_area(row: dict) -> str:
    """Return the normalised constraint_area string, or '' if absent."""
    for key in (
        "raw__Constraint_Area", "raw__constraint_area",
        "raw__ConstraintArea", "constraint_area",
    ):
        v = row.get(key)
        if v is not None:
            return str(v).strip().lower()
    return ""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def map_constraints(
    normalized_tables: dict,
    domain_profile: dict,
) -> dict:
    """
    Read normalized canonical tables and domain profile rules, then produce
    structured constraint rule lists ready to be inserted into SolverPayload.

    Accepts either the raw {role: records} dict or the full normalize_tables
    result (with a "normalized_tables" wrapper key).
    Accepts either a raw profile dict or the full detect_domain result
    (with a "profile" wrapper key).

    Returns:
    {
        "setup_rules", "cleaning_rules", "wait_rules", "batch_rules",
        "quality_rules", "shared_resources", "constraints",
        "mapped_constraints", "unsupported_rules", "errors", "warnings"
    }
    """
    errors: list[str] = []
    warnings: list[str] = []
    setup_rules: list[dict] = []
    cleaning_rules: list[dict] = []
    wait_rules: list[dict] = []
    batch_rules: list[dict] = []
    quality_rules: list[dict] = []
    shared_resources: list[dict] = []
    generic_constraints: list[dict] = []
    mapped_constraints: list[dict] = []
    unsupported_rules: list[dict] = []

    # Unwrap if full tool results were passed
    if "normalized_tables" in normalized_tables:
        tables: dict = normalized_tables["normalized_tables"]
    else:
        tables = normalized_tables

    if "profile" in domain_profile and "domain_profile_id" in domain_profile:
        profile: dict = domain_profile["profile"]
    else:
        profile = domain_profile

    domain_name = str(profile.get("domain_name") or "").lower()
    domain_rules: dict = profile.get("domain_rules") or {}

    setup_idx = 0
    clean_idx = 0

    # ------------------------------------------------------------------ A/B
    # Setup and Cleaning rules from Setup_Changeover
    # ------------------------------------------------------------------
    for i, row in enumerate(tables.get("Setup_Changeover", [])):
        from_family = row.get("from_family")
        to_family = row.get("to_family")

        if not _is_present(from_family) or not _is_present(to_family):
            warnings.append(
                f"Setup_Changeover row {i}: missing from_family or to_family, skipping."
            )
            continue

        from_family = str(from_family).strip()
        to_family = str(to_family).strip()
        machine_id = str(row["machine_id"]).strip() if _is_present(row.get("machine_id")) else None
        machine_type = str(row["machine_type"]).strip() if _is_present(row.get("machine_type")) else None
        hard = _to_bool(row.get("hard"), default=True)
        source_ref = {"table": "Setup_Changeover", "row_index": i}

        # A — Setup rule
        setup_min_raw = row.get("setup_minutes")
        if not _is_present(setup_min_raw):
            setup_minutes = 0
            warnings.append(
                f"Setup_Changeover row {i}: setup_minutes missing, defaulting to 0."
            )
        else:
            setup_minutes = max(0, _to_int(setup_min_raw))

        setup_cost = max(0.0, _to_float(row.get("setup_cost")))
        setup_idx += 1
        rule_id = _make_rule_id("SETUP", setup_idx)
        setup_rule: dict = {
            "rule_id": rule_id,
            "constraint_type": "sequence_dependent_setup",
            "machine_id": machine_id,
            "machine_type": machine_type,
            "from_family": from_family,
            "to_family": to_family,
            "setup_minutes": setup_minutes,
            "setup_cost": setup_cost,
            "hard": hard,
            "source": source_ref,
        }
        setup_rules.append(setup_rule)
        _append_mapped_constraint(
            mapped_constraints, rule_id, "sequence_dependent_setup",
            "Setup_Changeover", hard
        )

        # B — Cleaning rule (only if cleaning_minutes is present)
        if _is_present(row.get("cleaning_minutes")):
            cleaning_minutes = max(0, _to_int(row["cleaning_minutes"]))
            cleaning_cost = max(0.0, _to_float(row.get("cleaning_cost")))
            clean_idx += 1
            c_rule_id = _make_rule_id("CLEAN", clean_idx)
            cleaning_rule: dict = {
                "rule_id": c_rule_id,
                "constraint_type": "sequence_dependent_cleaning",
                "machine_id": machine_id,
                "machine_type": machine_type,
                "from_family": from_family,
                "to_family": to_family,
                "cleaning_minutes": cleaning_minutes,
                "cleaning_cost": cleaning_cost,
                "hard": hard,
                "source": source_ref,
            }
            cleaning_rules.append(cleaning_rule)
            _append_mapped_constraint(
                mapped_constraints, c_rule_id, "sequence_dependent_cleaning",
                "Setup_Changeover", hard
            )

    # ------------------------------------------------------------------ C
    # Wait rules from Routing (consecutive ops per product)
    # ------------------------------------------------------------------
    routing_rows = tables.get("Routing", [])
    if routing_rows:
        for product_id, rows in _group_by(routing_rows, "product_id").items():
            sorted_rows = _sort_routing_rows(rows)
            for j in range(len(sorted_rows) - 1):
                curr = sorted_rows[j]
                nxt = sorted_rows[j + 1]

                curr_fam = curr.get("operation_family")
                nxt_fam = nxt.get("operation_family")
                if not _is_present(curr_fam) or not _is_present(nxt_fam):
                    continue

                curr_fam = str(curr_fam).strip()
                nxt_fam = str(nxt_fam).strip()

                min_w = _to_int(curr.get("min_wait_minutes"), 0) if _is_present(curr.get("min_wait_minutes")) else 0
                max_w = _to_int(curr.get("max_wait_minutes"), 0) if _is_present(curr.get("max_wait_minutes")) else 0

                has_min = min_w > 0
                has_max = max_w > 0
                if not has_min and not has_max:
                    continue

                if has_min and has_max:
                    ctype = "max_wait_between_operations"
                elif has_min:
                    ctype = "min_wait_between_operations"
                else:
                    ctype = "max_wait_between_operations"

                w_rule_id = f"WAIT_{product_id}_{curr_fam}_{nxt_fam}"
                wait_rule: dict = {
                    "rule_id": w_rule_id,
                    "constraint_type": ctype,
                    "from_operation_family": curr_fam,
                    "to_operation_family": nxt_fam,
                    "min_wait_minutes": min_w if has_min else None,
                    "max_wait_minutes": max_w if has_max else None,
                    "hard": True,
                    "penalty_per_minute": 0.0,
                    "source": {"table": "Routing", "product_id": product_id},
                }
                wait_rules.append(wait_rule)
                _append_mapped_constraint(
                    mapped_constraints, w_rule_id, ctype, "Routing", True
                )

    # ------------------------------------------------------------------ D/E
    # Quality and Batch rules from SKU_Master
    # ------------------------------------------------------------------
    for i, row in enumerate(tables.get("SKU_Master", [])):
        product_id = row.get("product_id")
        if not _is_present(product_id):
            continue
        product_id = str(product_id).strip()
        product_family = str(row["product_family"]).strip() if _is_present(row.get("product_family")) else None

        # D — Quality rule
        # qa_release_minutes is already in minutes (normalization converts hours→min).
        # qa_release_hours from normalized tables is also in minutes (same conversion).
        qa_min = row.get("qa_release_minutes")
        qa_hr = row.get("qa_release_hours")
        hold_minutes: Optional[int] = None
        if _is_present(qa_min):
            hold_minutes = max(0, _to_int(qa_min))   # already minutes
        elif _is_present(qa_hr):
            hold_minutes = max(0, _to_int(qa_hr))    # also already minutes after normalization

        if hold_minutes is not None:
            q_rule_id = f"QUALITY_{product_id}"
            quality_rules.append({
                "rule_id": q_rule_id,
                "product_id": product_id,
                "product_family": product_family,
                "operation_family": "QC",
                "hold_minutes": hold_minutes,
                "hard": True,
                "source": {"table": "SKU_Master", "row_index": i},
            })
            _append_mapped_constraint(
                mapped_constraints, q_rule_id, "quality_release_hold",
                "SKU_Master", True
            )

        # E — Batch rule
        batch_size = row.get("batch_size")
        min_b_raw = row.get("min_batch_size")
        max_b_raw = row.get("max_batch_size")
        mult_raw = row.get("batch_multiple")

        has_batch = any(
            _is_present(v) for v in [batch_size, min_b_raw, max_b_raw, mult_raw]
        )
        if has_batch:
            b_rule_id = f"BATCH_{product_id}"
            min_b: Optional[float] = None
            max_b: Optional[float] = None
            mult_b: Optional[float] = None

            if _is_present(batch_size) and not _is_present(min_b_raw) and not _is_present(max_b_raw):
                bs = _to_float(batch_size)
                if bs > 0:
                    min_b = bs
                    max_b = bs
                    warnings.append(
                        f"SKU_Master product_id={product_id}: "
                        f"fixed batch_size={bs} inferred as min/max batch."
                    )
            else:
                if _is_present(min_b_raw):
                    v = _to_float(min_b_raw)
                    min_b = v if v > 0 else None
                if _is_present(max_b_raw):
                    v = _to_float(max_b_raw)
                    max_b = v if v > 0 else None

            if _is_present(mult_raw):
                v = _to_float(mult_raw)
                mult_b = v if v > 0 else None

            batch_rules.append({
                "rule_id": b_rule_id,
                "product_id": product_id,
                "product_family": product_family,
                "min_batch_size": min_b,
                "max_batch_size": max_b,
                "batch_multiple": mult_b,
                "split_allowed": False,
                "source": {"table": "SKU_Master", "row_index": i},
            })
            _append_mapped_constraint(
                mapped_constraints, b_rule_id, "batch_rule", "SKU_Master", False
            )

    # ------------------------------------------------------------------ F
    # Domain defaults — cosmetics
    # ------------------------------------------------------------------
    if domain_name == "cosmetics":
        if "bulk_mix_to_fill_max_wait_minutes" in domain_rules:
            r_id = "COS_BULK_MIX_TO_FILL_MAX_WAIT"
            wait_rules.append({
                "rule_id": r_id,
                "constraint_type": "max_wait_between_operations",
                "from_operation_family": "MIX",
                "to_operation_family": "FILL",
                "min_wait_minutes": None,
                "max_wait_minutes": _to_int(domain_rules["bulk_mix_to_fill_max_wait_minutes"]),
                "hard": True,
                "penalty_per_minute": 0.0,
                "source": {"profile_rule": "bulk_mix_to_fill_max_wait_minutes"},
            })
            _append_mapped_constraint(
                mapped_constraints, r_id, "max_wait_between_operations", "domain_profile", True
            )

        if "qc_release_default_minutes" in domain_rules:
            r_id = "COS_QC_RELEASE_DEFAULT"
            quality_rules.append({
                "rule_id": r_id,
                "product_id": None,
                "product_family": None,
                "operation_family": "QC",
                "hold_minutes": _to_int(domain_rules["qc_release_default_minutes"]),
                "hard": True,
                "source": {"profile_rule": "qc_release_default_minutes"},
            })
            _append_mapped_constraint(
                mapped_constraints, r_id, "quality_release_hold", "domain_profile", True
            )

        if "fragrance_changeover_cleaning_minutes" in domain_rules:
            r_id = "COS_FRAGRANCE_CHANGEOVER_DEFAULT"
            cleaning_rules.append({
                "rule_id": r_id,
                "constraint_type": "sequence_dependent_cleaning",
                "machine_id": None,
                "machine_type": None,
                "from_family": "FRAGRANCE_A",
                "to_family": "FRAGRANCE_B",
                "cleaning_minutes": _to_int(domain_rules["fragrance_changeover_cleaning_minutes"]),
                "cleaning_cost": 0.0,
                "hard": True,
                "source": {"profile_rule": "fragrance_changeover_cleaning_minutes"},
            })
            _append_mapped_constraint(
                mapped_constraints, r_id, "sequence_dependent_cleaning", "domain_profile", True
            )
            warnings.append(
                "Generic cosmetics fragrance cleaning rule created from domain profile; "
                "exact product-family mapping will depend on SKU_Master.product_family."
            )

        if "color_changeover_cleaning_minutes" in domain_rules:
            r_id = "COS_COLOR_CHANGEOVER_DEFAULT"
            cleaning_rules.append({
                "rule_id": r_id,
                "constraint_type": "sequence_dependent_cleaning",
                "machine_id": None,
                "machine_type": None,
                "from_family": "COLOR_A",
                "to_family": "COLOR_B",
                "cleaning_minutes": _to_int(domain_rules["color_changeover_cleaning_minutes"]),
                "cleaning_cost": 0.0,
                "hard": True,
                "source": {"profile_rule": "color_changeover_cleaning_minutes"},
            })
            _append_mapped_constraint(
                mapped_constraints, r_id, "sequence_dependent_cleaning", "domain_profile", True
            )
            warnings.append(
                "Generic cosmetics color cleaning rule created from domain profile; "
                "exact product-family mapping will depend on SKU_Master.product_family."
            )

    # ------------------------------------------------------------------ G
    # Domain defaults — bakery
    # ------------------------------------------------------------------
    elif domain_name == "bakery":
        if "proof_to_bake_max_wait_minutes" in domain_rules:
            r_id = "BAKERY_PROOF_TO_BAKE_MAX_WAIT"
            wait_rules.append({
                "rule_id": r_id,
                "constraint_type": "max_wait_between_operations",
                "from_operation_family": "PROOF",
                "to_operation_family": "BAKE",
                "min_wait_minutes": None,
                "max_wait_minutes": _to_int(domain_rules["proof_to_bake_max_wait_minutes"]),
                "hard": True,
                "penalty_per_minute": 0.0,
                "source": {"profile_rule": "proof_to_bake_max_wait_minutes"},
            })
            _append_mapped_constraint(
                mapped_constraints, r_id, "max_wait_between_operations", "domain_profile", True
            )

        if "cooling_to_pack_max_wait_minutes" in domain_rules:
            r_id = "BAKERY_COOL_TO_PACK_MAX_WAIT"
            wait_rules.append({
                "rule_id": r_id,
                "constraint_type": "max_wait_between_operations",
                "from_operation_family": "COOL",
                "to_operation_family": "PACK",
                "min_wait_minutes": None,
                "max_wait_minutes": _to_int(domain_rules["cooling_to_pack_max_wait_minutes"]),
                "hard": True,
                "penalty_per_minute": 0.0,
                "source": {"profile_rule": "cooling_to_pack_max_wait_minutes"},
            })
            _append_mapped_constraint(
                mapped_constraints, r_id, "max_wait_between_operations", "domain_profile", True
            )

        if "allergen_cleaning_minutes" in domain_rules:
            r_id = "BAKERY_ALLERGEN_CLEANING_DEFAULT"
            cleaning_rules.append({
                "rule_id": r_id,
                "constraint_type": "sequence_dependent_cleaning",
                "machine_id": None,
                "machine_type": None,
                "from_family": "ALLERGEN",
                "to_family": "NON_ALLERGEN",
                "cleaning_minutes": _to_int(domain_rules["allergen_cleaning_minutes"]),
                "cleaning_cost": 0.0,
                "hard": True,
                "source": {"profile_rule": "allergen_cleaning_minutes"},
            })
            _append_mapped_constraint(
                mapped_constraints, r_id, "sequence_dependent_cleaning", "domain_profile", True
            )

    # ------------------------------------------------------------------ H
    # Business Rules — deterministic mapping for known BR-xxx patterns
    # ------------------------------------------------------------------
    # Known BR-001…BR-013 are mapped (fully or partially) without errors.
    # Legacy rule_type strings (max_wait, setup, …) continue to work.
    # Only truly unrecognized hard rules add to errors[] and block the payload.

    SUPPORTED_RULE_TYPES = {"max_wait", "min_wait", "cleaning", "setup", "quality_hold", "batch"}

    for i, row in enumerate(tables.get("Business_Rules", [])):
        r_id_raw = str(row.get("rule_id") or f"BR_{i:03d}").strip()
        rule_text = str(row.get("rule_text") or "").strip()
        rule_type = str(row.get("rule_type") or "").strip().lower()
        hard = _parse_hard_field(row)
        constraint_area = _get_constraint_area(row)

        entry = {
            "rule_id": r_id_raw,
            "rule_type": rule_type,
            "rule_text": rule_text,
            "hard": hard,
            "constraint_area": constraint_area,
            "source": {"table": "Business_Rules", "row_index": i},
        }

        # ---- 1. Legacy rule_type strings (backward compatible) ----
        if rule_type in SUPPORTED_RULE_TYPES:
            generic_constraints.append(entry)
            _append_mapped_constraint(
                mapped_constraints, r_id_raw, rule_type, "Business_Rules", hard
            )
            continue

        # ---- 2. Known BR-xxx pattern matching ----
        br_key = _normalize_br_id(r_id_raw)
        treatment_tuple = _KNOWN_BR.get(br_key)

        # ---- 3. Fallback: match by Constraint_Area ----
        if treatment_tuple is None and constraint_area:
            mapped_br = _KNOWN_CONSTRAINT_AREAS.get(constraint_area)
            if mapped_br:
                treatment_tuple = _KNOWN_BR.get(mapped_br)
                br_key = mapped_br

        if treatment_tuple is not None:
            treatment, description = treatment_tuple
            if treatment == "mapped":
                generic_constraints.append(entry)
                _append_mapped_constraint(
                    mapped_constraints, r_id_raw, br_key, "Business_Rules", hard
                )
            else:  # "warning" — partial enforcement
                unsupported_rules.append({**entry, "reason": "partial_enforcement"})
                warnings.append(
                    f"{r_id_raw} ({constraint_area or br_key}): {description}."
                )
                # Still register as mapped so the report shows it was recognised
                _append_mapped_constraint(
                    mapped_constraints, r_id_raw, br_key, "Business_Rules", hard
                )
        else:
            # ---- 4. Truly unrecognized rule ----
            unsupported_rules.append({**entry, "reason": "unrecognized_rule_type"})
            if hard:
                errors.append(
                    f"Unsupported hard business rule {r_id_raw}: "
                    "rule type is not recognized and cannot be mapped deterministically."
                )
            else:
                warnings.append(
                    f"Unsupported soft business rule {r_id_raw}: will be skipped."
                )

    return {
        "setup_rules": setup_rules,
        "cleaning_rules": cleaning_rules,
        "wait_rules": wait_rules,
        "batch_rules": batch_rules,
        "quality_rules": quality_rules,
        "shared_resources": shared_resources,
        "constraints": generic_constraints,
        "mapped_constraints": mapped_constraints,
        "unsupported_rules": unsupported_rules,
        "errors": errors,
        "warnings": warnings,
    }
