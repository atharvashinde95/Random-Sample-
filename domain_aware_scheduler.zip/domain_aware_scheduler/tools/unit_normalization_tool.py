from __future__ import annotations

import math
import re
from datetime import date, datetime
from pathlib import Path
from typing import Any, Optional

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Column category sets
# ---------------------------------------------------------------------------

DATE_COLUMNS: frozenset[str] = frozenset({
    "order_date", "due_date", "available_from", "available_to",
    "start", "end", "receipt_date", "downtime_start", "downtime_end",
    "work_date",
})

NUMERIC_COLUMNS: frozenset[str] = frozenset({
    "quantity", "priority_weight", "late_penalty_per_unit_per_day",
    "batch_size", "min_batch_size", "max_batch_size", "batch_multiple",
    "holding_cost_per_unit_per_day", "selling_price_per_unit",
    "unit_production_cost", "runtime_minutes_per_batch", "setup_time_minutes",
    "batch_capacity", "capacity", "hourly_cost", "quantity_required",
    "opening_inventory", "safety_stock", "receipt_qty", "penalty",
    "setup_minutes", "setup_cost", "cleaning_minutes", "cleaning_cost",
})

DURATION_COLUMNS: frozenset[str] = frozenset({
    "runtime_minutes_per_batch", "setup_time_minutes",
    "min_wait_minutes", "max_wait_minutes",
    "setup_minutes", "cleaning_minutes",
    "qa_release_hours", "shelf_life_days",
})

_PRIORITY_MAP: dict[str, int] = {"VIP": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}

# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _json_safe(value: Any) -> Any:
    """Convert a single value to a JSON-serializable Python type."""
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        f = float(value)
        return None if (math.isnan(f) or math.isinf(f)) else f
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, np.ndarray):
        return [_json_safe(v) for v in value.tolist()]
    if isinstance(value, pd.Timestamp):
        return None if pd.isna(value) else value.isoformat()
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day).isoformat()
    if isinstance(value, float):
        return None if (math.isnan(value) or math.isinf(value)) else value
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def _parse_datetime(value: Any, column_name: str = "") -> Optional[str]:
    """
    Parse a value to ISO datetime string, or None.

    Handles:
    - ISO strings, pandas Timestamp, datetime/date objects
    - Excel serial date numbers (int/float in range 20 000–60 000)
      These are stored as days-since-1899-12-30 by Excel and must NOT be
      passed to pd.to_datetime(value) without a unit, which would interpret
      them as nanoseconds since 1970 (producing 1970-01-01T00:00:00.000046).
    """
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, pd.Timestamp):
        return None if pd.isna(value) else value.isoformat()
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day).isoformat()

    # Excel serial date detection — integers/floats in the plausible date range
    # (~1954-01-01 = 19723 to ~2063-12-31 = 59579) on known date columns.
    if isinstance(value, (int, float, np.integer, np.floating)):
        n = float(value)
        if math.isnan(n) or math.isinf(n):
            return None
        if 20000 <= n <= 60000:
            try:
                ts = pd.to_datetime(n, unit="D", origin="1899-12-30")
                return ts.normalize().isoformat()
            except Exception:
                pass
        # Small integers (IDs, counts) are not dates
        return None

    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        try:
            ts = pd.to_datetime(s, dayfirst=False)
            return None if pd.isna(ts) else ts.isoformat()
        except Exception:
            try:
                ts = pd.to_datetime(s, dayfirst=True)
                return None if pd.isna(ts) else ts.isoformat()
            except Exception:
                return None

    # Last resort
    try:
        ts = pd.to_datetime(value)
        return None if pd.isna(ts) else ts.isoformat()
    except Exception:
        return None


def _parse_number(value: Any) -> Optional[float]:
    """Parse a value to float, or None."""
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, (int, float, np.integer, np.floating)):
        f = float(value)
        return None if (math.isnan(f) or math.isinf(f)) else f
    if isinstance(value, str):
        cleaned = re.sub(r"[^\d.\-]", "", value.strip())
        try:
            return float(cleaned) if cleaned else None
        except ValueError:
            return None
    return None


def _parse_duration_to_minutes(value: Any, column_name: str) -> Optional[float]:
    """
    Parse a duration value to minutes.

    String patterns handled: "2 hours", "1.5 hr", "30 min", "2h", "30m", "1d", etc.
    Bare numerics: unit inferred from column_name suffix (hours/days/seconds → min).
    Default bare numeric unit: minutes.
    """
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass

    is_string = isinstance(value, str)
    str_val = str(value).strip().lower() if is_string else None

    if str_val is not None:
        patterns = [
            (r"([\d.]+)\s*(?:hours?|hrs?|h)\b", 60.0),
            (r"([\d.]+)\s*(?:days?|d)\b", 1440.0),
            (r"([\d.]+)\s*(?:minutes?|mins?|m)\b", 1.0),
            (r"([\d.]+)\s*(?:seconds?|secs?|s)\b", 1.0 / 60.0),
        ]
        for pattern, multiplier in patterns:
            m = re.search(pattern, str_val)
            if m:
                try:
                    return float(m.group(1)) * multiplier
                except ValueError:
                    return None
        # Bare numeric string
        try:
            num = float(str_val)
        except ValueError:
            return None
    else:
        num = float(value)  # type: ignore[arg-type]
        if math.isnan(num) or math.isinf(num):
            return None

    # Infer unit from column name
    col_lower = column_name.lower()
    if any(t in col_lower for t in ("hour", "_hr", "hrs")):
        return num * 60.0
    if any(t in col_lower for t in ("day", "_day")):
        return num * 1440.0
    if any(t in col_lower for t in ("second", "_sec")):
        return num / 60.0
    # Default: already in minutes
    return num


def _clean_id(value: Any) -> Optional[str]:
    """Strip whitespace and return as string ID, or None."""
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    return str(value).strip() or None


def _normalize_priority(row: dict) -> dict:
    """
    Normalize priority_class to uppercase and assign priority_weight
    from PRIORITY_MAP if priority_weight is absent.
    """
    row = dict(row)
    pc = row.get("priority_class")
    pw = row.get("priority_weight")

    if pc is not None:
        pc_norm = str(pc).strip().upper()
        row["priority_class"] = pc_norm
        if (pw is None) and (pc_norm in _PRIORITY_MAP):
            row["priority_weight"] = _PRIORITY_MAP[pc_norm]

    return row


def _records_from_df(df: pd.DataFrame) -> list[dict]:
    """Convert a DataFrame to a list of JSON-safe dicts. Never returns DataFrame."""
    return [{str(k): _json_safe(v) for k, v in row.items()} for _, row in df.iterrows()]


def aggregate_warnings(warnings: list[str]) -> list[str]:
    """
    Aggregate repetitive row-level warnings into grouped summaries.

    Example: 365 "Machine_Calendar row N: invalid start/end" messages
    collapse to: "Machine_Calendar: 365 rows — invalid start/end, skipping."
    """
    import re
    from collections import defaultdict

    ROW_PATTERN = re.compile(
        r"^([\w_]+)\s+row\s+\d+\s*[:\-]\s*(.{1,120})$", re.IGNORECASE
    )
    groups: defaultdict[str, int] = defaultdict(int)
    ungrouped: list[str] = []

    for w in warnings:
        m = ROW_PATTERN.match(w.strip())
        if m:
            table = m.group(1)
            # Normalise the message: remove quoted IDs to group similar messages
            msg_root = re.sub(r"'[^']{1,60}'", "'...'", m.group(2)).strip()[:80]
            key = f"{table}|||{msg_root}"
            groups[key] += 1
        else:
            ungrouped.append(w)

    result = list(ungrouped)
    for key, count in sorted(groups.items()):
        table, msg_root = key.split("|||", 1)
        if count == 1:
            result.append(f"{table} (1 row): {msg_root}")
        else:
            result.append(f"{table} ({count} rows): {msg_root}")
    return result


def _synthesize_calendar_intervals(
    records: list[dict],
    warnings: list[str],
) -> list[dict]:
    """
    Build start/end datetime strings from alternative Machine_Calendar patterns.

    Pattern A — direct: record already has 'start' + 'end'.
    Pattern B — shift times: 'work_date' + 'shift_start' + 'shift_end'.
    Pattern C — duration: 'work_date' + 'available_minutes'.
    Pattern D — date only: 'work_date' alone (default 8-hour working day).
    """
    from datetime import timedelta as _td

    result: list[dict] = []
    skipped = 0

    def _parse_avail(r: dict) -> bool:
        """Return True if this row represents an available/working slot."""
        v = r.get("available")
        if v is None:
            return True
        sv = str(v).strip().lower()
        return sv not in ("false", "0", "no", "n", "0.0", "unavailable")

    def _parse_time_str(s: Any) -> Optional[str]:
        """Normalise a time value to 'HH:MM:SS' string or None."""
        if s is None:
            return None
        sv = str(s).strip()
        if not sv or sv.lower() in ("none", "nan", "null"):
            return None
        # Already looks like a time
        if re.match(r"^\d{1,2}:\d{2}", sv):
            return sv
        # Excel fraction: 0.333… → 8h
        try:
            f = float(sv)
            if 0.0 <= f < 1.0:
                total_secs = int(round(f * 86400))
                h, rem = divmod(total_secs, 3600)
                m, s2 = divmod(rem, 60)
                return f"{h:02d}:{m:02d}:{s2:02d}"
        except (ValueError, TypeError):
            pass
        return sv

    for r in records:
        # Pattern A: already complete
        if r.get("start") and r.get("end"):
            result.append(r)
            continue

        work_date_raw = r.get("work_date")
        if not work_date_raw:
            skipped += 1
            continue

        try:
            work_dt = pd.to_datetime(work_date_raw)
        except Exception:
            skipped += 1
            continue

        available = _parse_avail(r)
        machine_id = r.get("machine_id")

        # Pattern B: shift times
        shift_s = _parse_time_str(r.get("shift_start"))
        shift_e = _parse_time_str(r.get("shift_end"))
        if shift_s and shift_e:
            try:
                start_dt = pd.to_datetime(f"{work_dt.date()} {shift_s}")
                end_dt = pd.to_datetime(f"{work_dt.date()} {shift_e}")
                if end_dt <= start_dt:
                    end_dt = end_dt + pd.Timedelta(days=1)
                new_r = {**r,
                         "start": start_dt.isoformat(),
                         "end": end_dt.isoformat(),
                         "available": available,
                         "machine_id": machine_id}
                result.append(new_r)
                continue
            except Exception:
                pass

        # Pattern C: available minutes
        avail_min = r.get("available_minutes")
        if avail_min is not None:
            try:
                avail_min_f = float(avail_min)
                if avail_min_f > 0:
                    start_dt = work_dt.replace(hour=0, minute=0, second=0, microsecond=0)
                    end_dt = start_dt + pd.Timedelta(minutes=avail_min_f)
                    new_r = {**r,
                             "start": start_dt.isoformat(),
                             "end": end_dt.isoformat(),
                             "available": available,
                             "machine_id": machine_id}
                    result.append(new_r)
                    continue
            except (ValueError, TypeError):
                pass

        # Pattern D: date only → default 8-hour day (only if available)
        if available:
            start_dt = work_dt.replace(hour=0, minute=0, second=0, microsecond=0)
            end_dt = start_dt + pd.Timedelta(hours=8)
            new_r = {**r,
                     "start": start_dt.isoformat(),
                     "end": end_dt.isoformat(),
                     "available": True,
                     "machine_id": machine_id}
            result.append(new_r)
        # not available → don't add (machine not working that day)

    if skipped:
        warnings.append(
            f"Machine_Calendar: {skipped} rows skipped — missing work_date field."
        )
    return result


def _read_all_tables(file_path: str) -> dict:
    """
    Read all sheets from an Excel or CSV file.
    Returns {"tables": {sheet_name: DataFrame}, "errors": [str]}.
    DataFrames are for internal use only — never returned to callers.
    """
    path = Path(file_path)
    ext = path.suffix.lower().lstrip(".")
    tables: dict[str, pd.DataFrame] = {}
    errors: list[str] = []

    if ext in ("xlsx", "xls"):
        try:
            xf = pd.ExcelFile(str(path))
            for sheet_name in xf.sheet_names:
                try:
                    df = pd.read_excel(xf, sheet_name=sheet_name)
                    tables[str(sheet_name)] = df.dropna(how="all")
                except Exception as exc:
                    errors.append(f"Could not read sheet '{sheet_name}': {exc}")
        except Exception as exc:
            errors.append(f"Could not open Excel file: {exc}")

    elif ext == "csv":
        try:
            df = pd.read_csv(str(path))
            tables["CSV_Data"] = df.dropna(how="all")
        except Exception as exc:
            errors.append(f"Could not read CSV: {exc}")

    else:
        errors.append(f"Unsupported file type: .{ext}")

    return {"tables": tables, "errors": errors}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def normalize_tables(
    file_path: str,
    sheet_mapping: dict,
    column_mapping: dict,
    current_date: Optional[str] = None,
) -> dict:
    """
    Read the workbook, apply sheet/column mappings, normalize all values,
    and return canonical table records keyed by canonical role.

    Returns:
    {
        "normalized_tables":   { canonical_role: [ {record}, ... ] },
        "normalization_report": {
            "rows_loaded":         { canonical_role: int },
            "converted_columns":   [ { table, column, conversion } ],
            "duplicate_warnings":  [str],
            "errors":              [str],
            "warnings":            [str]
        },
        "errors":   [str],
        "warnings": [str]
    }
    """
    errors: list[str] = []
    warnings: list[str] = []
    normalized_tables: dict[str, list[dict]] = {}
    report: dict[str, Any] = {
        "rows_loaded": {},
        "converted_columns": [],
        "duplicate_warnings": [],
        "errors": [],
        "warnings": [],
    }

    # --- Input validation ---
    if not file_path:
        errors.append("file_path is required.")
        report["errors"] = errors[:]
        return {
            "normalized_tables": {},
            "normalization_report": report,
            "errors": errors,
            "warnings": warnings,
        }

    if not Path(file_path).exists():
        errors.append(f"File not found: {file_path}")
        report["errors"] = errors[:]
        return {
            "normalized_tables": {},
            "normalization_report": report,
            "errors": errors,
            "warnings": warnings,
        }

    # --- Read raw tables (DataFrames, internal only) ---
    read_result = _read_all_tables(file_path)
    raw_tables: dict[str, pd.DataFrame] = read_result["tables"]
    errors.extend(read_result["errors"])

    if not raw_tables:
        errors.append("No tables could be read from the file.")
        report["errors"] = errors[:]
        return {
            "normalized_tables": {},
            "normalization_report": report,
            "errors": errors,
            "warnings": warnings,
        }

    # Accept either full detect_sheet_mapping result or plain {raw: role} dict
    role_map: dict[str, str] = sheet_mapping.get("sheet_mapping", sheet_mapping)
    # Accept either full detect_column_mapping result or plain {sheet: {raw: canon}} dict
    raw_col_map: dict[str, dict[str, str]] = column_mapping.get(
        "column_mapping", column_mapping
    )

    # Parse current_date once
    current_dt: Optional[pd.Timestamp] = None
    if current_date:
        try:
            current_dt = pd.to_datetime(current_date)
        except Exception:
            warnings.append(
                f"Could not parse current_date '{current_date}'; "
                "skipping receipt_status computation."
            )

    # --- Process each mapped sheet ---
    for raw_sheet, canonical_role in role_map.items():
        df = raw_tables.get(raw_sheet)
        if df is None:
            warnings.append(f"Sheet '{raw_sheet}' not found in raw tables; skipping.")
            continue

        df = df.copy()

        # Rename mapped columns; prefix unmapped with "raw__".
        # Duplicate canonical names are resolved by confidence (best wins).
        # This prevents duplicate DataFrame columns which corrupt .apply() calls.
        col_map_for_sheet: dict[str, str] = raw_col_map.get(raw_sheet, {})

        # Build confidence lookup from mapping_details if available
        _details = (
            column_mapping.get("mapping_details", [])
            if isinstance(column_mapping, dict)
            else []
        )
        _conf_lookup: dict[str, dict[str, float]] = {}
        for _d in _details:
            _s = _d.get("sheet", "")
            _rc = _d.get("raw_column", "")
            _conf_lookup.setdefault(_s, {})[_rc] = float(_d.get("confidence", 0.5))

        rename_map: dict[str, str] = {}
        used_canonical: dict[str, tuple[str, float]] = {}  # canon->(raw_col, conf)
        dup_notes: list[str] = []

        for raw_col in df.columns:
            raw_col_str = str(raw_col)
            if raw_col_str in col_map_for_sheet:
                canon = col_map_for_sheet[raw_col_str]
                this_conf = _conf_lookup.get(raw_sheet, {}).get(raw_col_str, 0.5)
                if canon not in used_canonical:
                    rename_map[raw_col_str] = canon
                    used_canonical[canon] = (raw_col_str, this_conf)
                else:
                    prev_col, prev_conf = used_canonical[canon]
                    if this_conf > prev_conf:
                        # Current column is better — demote the previous one
                        rename_map[prev_col] = f"raw__{prev_col}"
                        rename_map[raw_col_str] = canon
                        used_canonical[canon] = (raw_col_str, this_conf)
                        dup_notes.append(
                            f"kept {raw_col_str!r} (conf={this_conf:.2f}), "
                            f"moved {prev_col!r} to raw__{prev_col}"
                        )
                    else:
                        rename_map[raw_col_str] = f"raw__{raw_col_str}"
                        dup_notes.append(
                            f"kept {prev_col!r} (conf={prev_conf:.2f}), "
                            f"moved {raw_col_str!r} to raw__{raw_col_str}"
                        )
            else:
                rename_map[raw_col_str] = f"raw__{raw_col_str}"

        if dup_notes:
            n = len(dup_notes)
            examples = "; ".join(dup_notes[:3])
            warnings.append(
                f"Sheet '{raw_sheet}': {n} duplicate column mapping(s) resolved "
                f"by confidence. {examples}{'...' if n > 3 else ''}."
            )

        df = df.rename(columns=rename_map)
        df = df.dropna(how="all")

        converted_cols: list[dict] = []
        date_col_lower = {c.lower() for c in DATE_COLUMNS}
        duration_col_lower = {c.lower() for c in DURATION_COLUMNS}
        numeric_col_lower = {c.lower() for c in NUMERIC_COLUMNS}
        id_cols = {
            "order_id", "product_id", "machine_id", "operation_id",
            "item_id", "material_id", "component_id", "resource_id",
            "rule_id", "from_family", "to_family",
        }

        for col in list(df.columns):
            col_lower = col.lower()

            if col in DURATION_COLUMNS or col_lower in duration_col_lower:
                df[col] = df[col].apply(
                    lambda v, c=col: _parse_duration_to_minutes(v, c)
                )
                converted_cols.append({
                    "table": canonical_role, "column": col,
                    "conversion": "parsed_duration_to_minutes",
                })
                # Derived minute columns for hour/day duration fields
                if col == "qa_release_hours":
                    df["qa_release_minutes"] = df[col]
                    converted_cols.append({
                        "table": canonical_role, "column": "qa_release_minutes",
                        "conversion": "derived_from_qa_release_hours",
                    })
                elif col == "shelf_life_days":
                    df["shelf_life_minutes"] = df[col]
                    converted_cols.append({
                        "table": canonical_role, "column": "shelf_life_minutes",
                        "conversion": "derived_from_shelf_life_days",
                    })

            elif col in DATE_COLUMNS or col_lower in date_col_lower:
                df[col] = df[col].apply(lambda v, c=col: _parse_datetime(v, c))
                converted_cols.append({
                    "table": canonical_role, "column": col,
                    "conversion": "parsed_datetime",
                })

            elif col in NUMERIC_COLUMNS or col_lower in numeric_col_lower:
                df[col] = df[col].apply(_parse_number)
                converted_cols.append({
                    "table": canonical_role, "column": col,
                    "conversion": "parsed_numeric",
                })

        # Clean ID columns
        for col in id_cols:
            if col in df.columns:
                df[col] = df[col].apply(_clean_id)

        # Convert to records (no DataFrames from here on)
        records: list[dict] = _records_from_df(df)

        # Priority normalization (record-level)
        if any(col in df.columns for col in ("priority_class", "priority_weight")):
            records = [_normalize_priority(r) for r in records]

        # Material receipt status (record-level, after date conversion)
        if (
            canonical_role == "Material_Receipts"
            and current_dt is not None
            and "receipt_date" in df.columns
        ):
            current_date_str = current_dt.date().isoformat()
            future_found = False
            for r in records:
                rd = r.get("receipt_date")
                if rd:
                    try:
                        rd_date_str = rd[:10]  # "YYYY-MM-DD"
                        if rd_date_str <= current_date_str:
                            r["receipt_status"] = "available_now"
                        else:
                            r["receipt_status"] = "future_receipt"
                            future_found = True
                    except Exception:
                        r["receipt_status"] = None
                else:
                    r["receipt_status"] = None

            if future_found:
                msg = (
                    "Future material receipts detected; time-phased material "
                    "constraints will be handled in later solver phase."
                )
                warnings.append(msg)

        # Machine_Calendar: synthesise start/end from shift patterns
        if canonical_role == "Machine_Calendar":
            records = _synthesize_calendar_intervals(records, warnings)

        # Collision guard: when two raw sheets map to the same canonical role,
        # keep whichever has more canonical (non-raw__) columns.
        # SKU_Master is excluded here intentionally: loading real SKU data
        # activates per-product QA hold constraints (qa_release_hours) in
        # constraint_mapping_tool.py which can make the CP-SAT model INFEASIBLE.
        # SKU_Master financial data is recovered via _patch_job_pricing() in
        # smart_constraint_mapping_agent.py (TECH DEBT #1 — see agent comments).
        _COLLISION_GUARD_EXCLUDED = {"SKU_Master"}
        if canonical_role not in _COLLISION_GUARD_EXCLUDED:
            _existing = normalized_tables.get(canonical_role)
            if _existing is not None:
                _existing_canon = sum(
                    1 for k in (_existing[0] if _existing else {})
                    if not k.startswith("raw__")
                )
                _new_canon = sum(
                    1 for k in (records[0] if records else {})
                    if not k.startswith("raw__")
                )
                if _new_canon <= _existing_canon:
                    warnings.append(
                        f"Normalization collision: sheet '{raw_sheet}' maps to "
                        f"'{canonical_role}' but has fewer canonical columns "
                        f"({_new_canon}) than existing data ({_existing_canon}); "
                        "keeping existing data."
                    )
                    continue

        report["converted_columns"].extend(converted_cols)
        report["rows_loaded"][canonical_role] = len(records)
        normalized_tables[canonical_role] = records

        # --- Duplicate detection ---
        dup_id_checks: dict[str, list[str]] = {
            "Demand_Orders": ["order_id"],
            "SKU_Master": ["product_id"],
            "Machine_Master": ["machine_id"],
            "Routing": ["operation_id"],
        }
        if canonical_role in dup_id_checks:
            for id_col in dup_id_checks[canonical_role]:
                if id_col in df.columns:
                    vals = [r[id_col] for r in records if r.get(id_col) is not None]
                    if len(vals) != len(set(vals)):
                        msg = (
                            f"Duplicate '{id_col}' values found in {canonical_role}."
                        )
                        report["duplicate_warnings"].append(msg)
                        warnings.append(msg)

        if canonical_role == "BOM":
            pairs = [
                (r.get("product_id"), r.get("component_id"))
                for r in records
                if r.get("product_id") is not None and r.get("component_id") is not None
            ]
            if len(pairs) != len(set(pairs)):
                msg = "Duplicate product_id/component_id combinations found in BOM."
                report["duplicate_warnings"].append(msg)
                warnings.append(msg)

    report["errors"] = errors[:]
    report["warnings"] = warnings[:]

    return {
        "normalized_tables": normalized_tables,
        "normalization_report": report,
        "errors": errors,
        "warnings": warnings,
    }
