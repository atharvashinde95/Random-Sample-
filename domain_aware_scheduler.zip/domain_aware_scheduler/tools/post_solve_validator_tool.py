from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

from tools.cp_sat_model_builder_tool import _parse_dt


def validate_schedule(payload: dict, solver_result: dict) -> dict:
    """
    Post-solve validation: checks that the solver result is internally consistent
    with the original payload constraints.

    Returns:
    {
        "is_valid":  bool,
        "errors":    [str],
        "warnings":  [str],
        "stats":     { num_tasks, num_late, num_overlap_violations, ... }
    }
    """
    errors: list[str] = []
    warnings: list[str] = []

    # FIX 6 — non-solved statuses are not post-solve failures; solver status explains them
    status = solver_result.get("solver_status", "UNKNOWN")
    if status not in ("OPTIMAL", "FEASIBLE"):
        return {
            "is_valid": True,
            "errors": [],
            "warnings": [
                f"No schedule validation performed because solver status is {status}."
            ],
            "stats": {},
        }

    schedule: list[dict] = solver_result.get("schedule_table", [])
    if not schedule:
        return {
            "is_valid": False,
            "errors": ["schedule_table is empty."],
            "warnings": [],
            "stats": {},
        }

    reference = _parse_dt(payload["reference_time"])
    horizon_seconds = int(payload.get("horizon_seconds", 86400 * 14))
    horizon_end = reference + timedelta(seconds=horizon_seconds)

    machines_map = {m["machine_id"]: m for m in payload.get("machines", [])}
    jobs_map = {j["job_id"]: j for j in payload.get("jobs", [])}
    machine_capacity = {m["machine_id"]: int(m.get("capacity", 1)) for m in payload.get("machines", [])}
    calendars = payload.get("calendars", [])

    num_overlap = 0
    num_horizon_violations = 0
    num_sequence_violations = 0
    num_duration_violations = 0
    num_availability_violations = 0

    # -----------------------------------------------------------------------
    # Per-task basic checks
    # -----------------------------------------------------------------------
    for task in schedule:
        start_dt = _parse_dt(task["start"])
        end_dt = _parse_dt(task["end"])
        dur = int(task.get("duration_minutes", 0))

        # Duration match
        actual_dur = int((end_dt - start_dt).total_seconds() // 60)
        if actual_dur != dur:
            errors.append(
                f"Job {task['job_id']} op {task['operation_id']}: "
                f"duration mismatch: expected {dur}m, got {actual_dur}m."
            )
            num_duration_violations += 1

        # Horizon bounds
        if start_dt < reference:
            errors.append(
                f"Job {task['job_id']} op {task['operation_id']}: "
                f"starts before reference_time ({start_dt.isoformat()} < {reference.isoformat()})."
            )
            num_horizon_violations += 1
        if end_dt > horizon_end:
            warnings.append(
                f"Job {task['job_id']} op {task['operation_id']}: "
                f"ends after horizon ({end_dt.isoformat()})."
            )
            num_horizon_violations += 1

        # Machine existence
        mid = task.get("machine_id")
        if mid not in machines_map:
            errors.append(
                f"Job {task['job_id']} op {task['operation_id']}: "
                f"assigned machine '{mid}' not in machines list."
            )

        # Machine availability
        if mid in machines_map and calendars:
            machine_cals = [
                c for c in calendars
                if c.get("machine_id") == mid and c.get("available", True)
            ]
            if machine_cals:
                fits = any(
                    _parse_dt(c["start"]) <= start_dt and end_dt <= _parse_dt(c["end"])
                    for c in machine_cals
                )
                if not fits:
                    warnings.append(
                        f"Job {task['job_id']} op {task['operation_id']}: "
                        f"scheduled outside known availability windows for machine '{mid}'."
                    )
                    num_availability_violations += 1

    # -----------------------------------------------------------------------
    # Sequence checks: within each job, operations must not overlap
    # -----------------------------------------------------------------------
    job_tasks: dict[str, list[dict]] = {}
    for task in schedule:
        job_tasks.setdefault(task["job_id"], []).append(task)

    for job_id, tasks in job_tasks.items():
        job = jobs_map.get(job_id, {})
        ops = sorted(job.get("operations", []), key=lambda o: int(o.get("sequence", 1)))
        op_id_to_seq = {op["op_id"]: op.get("sequence", 0) for op in ops}

        tasks_sorted = sorted(
            tasks,
            key=lambda t: op_id_to_seq.get(t["operation_id"], 9999),
        )
        for i in range(len(tasks_sorted) - 1):
            a = tasks_sorted[i]
            b = tasks_sorted[i + 1]
            end_a = _parse_dt(a["end"])
            start_b = _parse_dt(b["start"])
            if end_a > start_b:
                errors.append(
                    f"Job {job_id}: op {a['operation_id']} ends {end_a.isoformat()} "
                    f"but op {b['operation_id']} starts {start_b.isoformat()} (overlap)."
                )
                num_sequence_violations += 1

    # -----------------------------------------------------------------------
    # Machine overlap checks (capacity-aware)
    # -----------------------------------------------------------------------
    machine_tasks: dict[str, list[dict]] = {}
    for task in schedule:
        machine_tasks.setdefault(task["machine_id"], []).append(task)

    for mid, tasks in machine_tasks.items():
        cap = machine_capacity.get(mid, 1)
        tasks_sorted = sorted(tasks, key=lambda t: _parse_dt(t["start"]))
        # Sweep-line: count concurrent tasks
        events: list[tuple[datetime, int, str]] = []
        for t in tasks_sorted:
            events.append((_parse_dt(t["start"]), +1, t["job_id"]))
            events.append((_parse_dt(t["end"]), -1, t["job_id"]))
        events.sort(key=lambda x: (x[0], x[1]))
        concurrent = 0
        for ts, delta, jid in events:
            concurrent += delta
            if concurrent > cap:
                errors.append(
                    f"Machine {mid}: concurrent load {concurrent} exceeds capacity {cap} "
                    f"at {ts.isoformat()}."
                )
                num_overlap += 1
                break  # one error per machine to avoid flooding

    # -----------------------------------------------------------------------
    # Wait rule checks
    # -----------------------------------------------------------------------
    for rule in payload.get("wait_rules", []):
        if not rule.get("hard", True):
            continue
        min_w = int(rule.get("min_wait_minutes") or 0)
        max_w = rule.get("max_wait_minutes")
        from_fam = rule.get("from_operation_family", "")
        to_fam = rule.get("to_operation_family", "")

        for job_id, tasks in job_tasks.items():
            from_ends = [
                _parse_dt(t["end"])
                for t in tasks
                if t.get("operation_family") == from_fam
            ]
            to_starts = [
                _parse_dt(t["start"])
                for t in tasks
                if t.get("operation_family") == to_fam
            ]
            for fe in from_ends:
                for ts in to_starts:
                    gap = int((ts - fe).total_seconds() // 60)
                    if gap < min_w:
                        errors.append(
                            f"Job {job_id}: wait rule {rule.get('rule_id')} violated "
                            f"(gap {gap}m < min {min_w}m)."
                        )
                    if max_w is not None and gap > int(max_w):
                        errors.append(
                            f"Job {job_id}: wait rule {rule.get('rule_id')} violated "
                            f"(gap {gap}m > max {max_w}m)."
                        )

    # -----------------------------------------------------------------------
    # Material availability check (post-solve advisory)
    # Computes total BOM consumption for scheduled jobs and flags shortfalls.
    # This is a warning, not an error — the CP-SAT model cannot yet enforce
    # time-phased material constraints, so violations here are advisory.
    # -----------------------------------------------------------------------
    materials_map: dict[str, dict] = {
        m["material_id"]: m for m in payload.get("materials", [])
    }
    bom_table: list[dict] = payload.get("metadata", {}).get("bom_rows", [])

    if materials_map and bom_table:
        # Aggregate total consumption per material across all scheduled jobs
        scheduled_job_ids = {t["job_id"] for t in schedule}
        consumption: dict[str, float] = {}
        for bom_row in bom_table:
            pid = bom_row.get("product_id", "")
            mat_id = bom_row.get("material_id", "")
            qty_per_batch = float(bom_row.get("quantity_required") or 0.0)
            if not pid or not mat_id or qty_per_batch <= 0:
                continue
            for job in payload.get("jobs", []):
                if job["job_id"] not in scheduled_job_ids:
                    continue
                if job["product_id"] != pid:
                    continue
                batches = job["quantity"] / max(1, float(bom_row.get("batch_size") or 1))
                consumption[mat_id] = consumption.get(mat_id, 0.0) + qty_per_batch * batches

        for mat_id, consumed in consumption.items():
            mat = materials_map.get(mat_id, {})
            available = float(mat.get("available_quantity") or 0.0)
            safety = float(mat.get("safety_stock") or 0.0)
            usable = max(0.0, available - safety)
            if consumed > usable:
                shortfall = consumed - usable
                warnings.append(
                    f"Material '{mat_id}': schedule requires {consumed:.1f} units but only "
                    f"{usable:.1f} usable (available={available:.1f}, safety_stock={safety:.1f}). "
                    f"Shortfall: {shortfall:.1f} units. "
                    "Replenishment or order splitting is needed."
                )

    is_valid = len(errors) == 0
    stats: dict[str, Any] = {
        "num_tasks": len(schedule),
        "num_jobs": len(job_tasks),
        "num_late": sum(1 for t in schedule if t.get("is_late")),
        "num_overlap_violations": num_overlap,
        "num_horizon_violations": num_horizon_violations,
        "num_sequence_violations": num_sequence_violations,
        "num_duration_violations": num_duration_violations,
        "num_availability_violations": num_availability_violations,
    }

    return {
        "is_valid": is_valid,
        "errors": errors,
        "warnings": warnings,
        "stats": stats,
    }
