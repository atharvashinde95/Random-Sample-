"""
Domain-free manufacturing structure discovery tool.

Detects what each workbook sheet/table represents WITHOUT using domain YAML profiles.
Uses manufacturing structure signatures and weighted scoring.
"""
from __future__ import annotations

import re
from typing import Any

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ALL_ROLES = [
    "Demand_Orders", "SKU_Master", "Routing", "Machine_Master",
    "BOM", "Inventory", "Machine_Calendar", "Setup_Changeover",
    "Maintenance", "Labor_Shifts", "Cost_Parameters", "Business_Rules",
    "Material_Receipts", "Unknown",
]

CONFIDENCE_STRONG = 0.85
CONFIDENCE_MEDIUM = 0.60

# ---------------------------------------------------------------------------
# Role signatures
# Each role has:
#   required: list of token-sets  → +3 per matched required signal
#   optional: list of token-sets  → +1 per matched optional signal
#   dtype_hints: list of (token_set, expected_dtype) → +2 per confirmed dtype
#   value_patterns: list of (description, check_fn) → +2 per matched pattern
#   name_tokens: normalized sheet names that strongly indicate this role → +1
# ---------------------------------------------------------------------------

ROLE_SIGNATURES: dict[str, dict] = {
    "Demand_Orders": {
        "required": [
            {"sku", "product", "item", "part", "material", "article"},
            {"qty", "quantity", "demand", "volume", "amount", "units", "required"},
            {"due", "promise", "delivery", "ship", "deadline"},
        ],
        "optional": [
            {"order", "sales", "customer", "po", "so"},
            {"customer", "client", "buyer"},
            {"priority", "urgency", "vip", "critical"},
            {"penalty", "tardiness", "late"},
        ],
        "name_tokens": {
            "customer_plan", "orders", "demand", "sales_plan", "dispatch_plan",
            "customer_orders", "order_data", "demand_orders", "demand_forecast",
            "sales_orders", "order",
        },
        "dtype_hints": [
            ({"due", "promise", "delivery", "ship", "date"}, "date"),
            ({"qty", "quantity", "demand", "volume", "amount"}, "numeric"),
        ],
        "value_patterns": [
            ("order_id_pattern", lambda vals: any(
                isinstance(v, str) and bool(re.match(
                    r"(ORD|SO|PO|ORDER|DO|WO)[-_]?\d+", str(v).strip(), re.IGNORECASE
                ))
                for v in vals
            )),
        ],
    },
    "SKU_Master": {
        "required": [
            {"sku", "product", "item", "article", "material", "part"},
            {"name", "description", "label", "title"},
        ],
        "optional": [
            {"family", "category", "group", "type", "class"},
            {"batch", "lot"},
            {"cost", "price"},
            {"shelf", "expiry", "expire", "life"},
        ],
        "name_tokens": {
            "sku_master", "products", "item_master", "product_catalog",
            "finished_goods", "product_master", "skus", "items",
        },
        "dtype_hints": [
            ({"cost", "price", "value"}, "numeric"),
        ],
        "value_patterns": [],
    },
    "Routing": {
        "required": [
            {"sku", "product", "item", "part"},
            {"step", "sequence", "seq", "stage", "operation", "op"},
            {"runtime", "run", "duration", "cycle", "minutes", "min"},
        ],
        "optional": [
            {"machine", "equipment", "workcenter", "resource", "line"},
            {"operation", "process", "name"},
            {"wait"},
        ],
        "name_tokens": {
            "processdata", "routing", "operations", "process_flow",
            "work_instructions", "route_master", "process_plan",
            "operation_master", "process",
        },
        "dtype_hints": [
            ({"runtime", "run", "duration", "minutes", "min"}, "numeric"),
            ({"seq", "sequence", "step", "stage", "no"}, "numeric"),
        ],
        "value_patterns": [
            ("operation_name_pattern", lambda vals: any(
                isinstance(v, str) and any(
                    kw in str(v).lower()
                    for kw in ["mix", "cut", "fill", "pack", "bake", "coat",
                               "blend", "weigh", "inspect", "clean", "grind",
                               "press", "heat", "cool", "dry", "label"]
                )
                for v in vals
            )),
            ("workcenter_id_pattern", lambda vals: any(
                isinstance(v, str) and bool(re.match(r"[A-Z]{2,6}[-_]?\d+", str(v).strip()))
                for v in vals
            )),
        ],
    },
    "Machine_Master": {
        "required": [
            {"machine", "equipment", "resource", "workcenter"},
            {"group", "type", "class", "category"},
        ],
        "optional": [
            {"capacity", "parallel", "units", "lanes"},
            {"cost", "rate", "hourly"},
            {"location", "area", "line"},
        ],
        "name_tokens": {
            "equipmentlist", "machines", "resources", "workcenters",
            "machine_master", "equipment_list", "resource_master",
        },
        "dtype_hints": [
            ({"capacity"}, "numeric"),
            ({"cost", "rate", "hourly"}, "numeric"),
        ],
        "value_patterns": [
            ("machine_id_pattern", lambda vals: any(
                isinstance(v, str) and bool(re.match(r"[A-Z]{1,6}[-_]?\d+", str(v).strip()))
                for v in vals
            )),
        ],
    },
    "BOM": {
        "required": [
            {"product", "sku", "item", "finished", "parent"},
            {"component", "material", "ingredient", "raw"},
            {"qty", "quantity", "amount"},
        ],
        "optional": [
            {"unit", "uom"},
        ],
        "name_tokens": {
            "recipe", "bom", "ingredients", "formula", "bill_of_materials",
            "material_requirements", "formulas",
        },
        "dtype_hints": [
            ({"qty", "quantity", "amount"}, "numeric"),
        ],
        "value_patterns": [],
    },
    "Inventory": {
        "required": [
            {"item", "material", "sku", "component", "product"},
            {"stock", "inventory", "hand", "available", "opening"},
        ],
        "optional": [
            {"safety", "minimum", "reorder"},
            {"unit", "uom"},
            {"warehouse", "location"},
        ],
        "name_tokens": {
            "stock_on_hand", "inventory", "material_inventory", "current_stock",
            "raw_inventory",
        },
        "dtype_hints": [
            ({"stock", "inventory", "quantity", "hand", "opening"}, "numeric"),
            ({"safety"}, "numeric"),
        ],
        "value_patterns": [],
    },
    "Machine_Calendar": {
        "required": [
            {"machine", "resource", "equipment"},
            {"available", "working"},
        ],
        "optional": [
            {"date", "shift"},
            {"minutes", "hours"},
        ],
        "name_tokens": {
            "machine_calendar", "availability", "shift_calendar",
            "working_calendar", "calendar", "machine_availability",
        },
        "dtype_hints": [
            ({"date", "start", "end"}, "date"),
            ({"minutes", "hours"}, "numeric"),
        ],
        "value_patterns": [],
    },
    "Setup_Changeover": {
        "required": [
            {"from", "source"},
            {"to", "target"},
            {"setup", "changeover", "cleaning", "transition"},
        ],
        "optional": [
            {"machine", "equipment"},
            {"cost"},
            {"hard", "soft"},
        ],
        "name_tokens": {
            "setup_changeover", "changeover_matrix", "setup_matrix",
            "cleaning_matrix", "transition_matrix",
        },
        "dtype_hints": [
            ({"setup", "changeover", "cleaning", "minutes", "min"}, "numeric"),
        ],
        "value_patterns": [],
    },
    "Maintenance": {
        "required": [
            {"machine", "equipment", "resource"},
            {"downtime", "maintenance", "unavailable"},
        ],
        "optional": [
            {"start", "end"},
            {"reason", "description", "type"},
        ],
        "name_tokens": {
            "maintenance", "downtime", "planned_downtime", "machine_downtime",
        },
        "dtype_hints": [
            ({"start", "end", "date"}, "date"),
        ],
        "value_patterns": [],
    },
    "Labor_Shifts": {
        "required": [
            {"operator", "crew", "team", "labor", "skill"},
            {"capacity", "available", "count", "headcount"},
        ],
        "optional": [
            {"shift", "start", "end"},
            {"hours", "minutes"},
        ],
        "name_tokens": {
            "labor_shifts", "shifts", "labor", "workforce", "operators",
        },
        "dtype_hints": [
            ({"start", "end"}, "date"),
            ({"capacity", "available", "count"}, "numeric"),
        ],
        "value_patterns": [],
    },
    "Cost_Parameters": {
        "required": [
            {"cost", "price", "penalty", "rate"},
            {"parameter", "name", "type", "value"},
        ],
        "optional": [
            {"holding", "tardiness", "overtime", "setup"},
        ],
        "name_tokens": {
            "cost_parameters", "costs", "pricing", "financials",
        },
        "dtype_hints": [
            ({"cost", "price", "value"}, "numeric"),
        ],
        "value_patterns": [],
    },
    "Business_Rules": {
        "required": [
            {"rule", "constraint", "policy"},
            {"text", "description", "type", "area"},
        ],
        "optional": [
            {"hard", "soft", "mandatory"},
            {"penalty"},
        ],
        "name_tokens": {
            "business_rules", "rules", "constraints", "policies",
        },
        "dtype_hints": [],
        "value_patterns": [],
    },
    "Material_Receipts": {
        "required": [
            {"material", "item", "sku", "component"},
            {"receipt", "arrival", "incoming"},
            {"qty", "quantity"},
        ],
        "optional": [
            {"supplier"},
            {"date", "expected"},
        ],
        "name_tokens": {
            "material_receipts", "receipts", "incoming_materials",
            "purchase_orders", "inbound_materials",
        },
        "dtype_hints": [
            ({"date", "receipt", "arrival"}, "date"),
            ({"qty", "quantity"}, "numeric"),
        ],
        "value_patterns": [],
    },
}


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------

def normalize_text(value: Any) -> str:
    """Lowercase, remove special characters, collapse whitespace."""
    if value is None:
        return ""
    t = str(value).lower().strip()
    t = re.sub(r"[^a-z0-9 ]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def tokenize_text(text: Any) -> set[str]:
    """Split into lowercase tokens, handling camelCase and underscores."""
    t = str(text)
    t = re.sub(r"([a-z])([A-Z])", r"\1 \2", t)
    t = t.lower()
    tokens = set(re.sub(r"[^a-z0-9]+", " ", t).split())
    return tokens


def normalize_column_name(name: str) -> str:
    """Return lowercased, underscore-normalized column name."""
    t = str(name).lower().strip()
    return re.sub(r"[^a-z0-9_]", "_", re.sub(r"[\s\-]+", "_", t))


# ---------------------------------------------------------------------------
# Type inference helpers
# ---------------------------------------------------------------------------

_DATE_PATTERN = re.compile(
    r"\d{4}[-/]\d{1,2}[-/]\d{1,2}"     # YYYY-MM-DD or YYYY/MM/DD
    r"|\d{1,2}[-/]\d{1,2}[-/]\d{4}"    # DD/MM/YYYY
    r"|\d{4}-\d{2}-\d{2}T\d{2}"        # ISO datetime
)
_DATE_MONTH_TOKENS = frozenset(
    ["jan", "feb", "mar", "apr", "may", "jun",
     "jul", "aug", "sep", "oct", "nov", "dec"]
)


def is_date_like_values(values: list) -> bool:
    """Return True if the majority of non-null values resemble dates."""
    non_null = [v for v in values if v is not None]
    if not non_null:
        return False
    hits = 0
    for v in non_null:
        sv = str(v)
        if _DATE_PATTERN.search(sv):
            hits += 1
        elif any(m in sv.lower() for m in _DATE_MONTH_TOKENS):
            hits += 1
    return (hits / len(non_null)) >= 0.5


def is_numeric_like_values(values: list) -> bool:
    """Return True if the majority of non-null values are numeric."""
    non_null = [v for v in values if v is not None]
    if not non_null:
        return False
    hits = 0
    for v in non_null:
        try:
            float(str(v).replace(",", ""))
            hits += 1
        except (ValueError, TypeError):
            pass
    return (hits / len(non_null)) >= 0.5


def is_id_like_values(values: list) -> bool:
    """Return True if values look like alphanumeric identifiers."""
    non_null = [v for v in values if v is not None]
    if not non_null:
        return False
    id_pat = re.compile(r"^[A-Za-z]{1,8}[-_]?\d+$")
    hits = sum(1 for v in non_null if id_pat.match(str(v).strip()))
    return (hits / len(non_null)) >= 0.4


def is_duration_like_column(name: str, values: list) -> bool:
    """Return True if the column looks like a duration/time column."""
    if tokenize_text(name) & {"runtime", "run", "duration", "time", "minutes", "min", "cycle"}:
        return is_numeric_like_values(values)
    return False


def is_cost_like_column(name: str, values: list) -> bool:
    """Return True if the column looks like a cost/price column."""
    if tokenize_text(name) & {"cost", "price", "rate", "penalty", "value"}:
        return is_numeric_like_values(values)
    return False


def infer_sample_type(col_name: str, sample_rows: list[dict]) -> str:
    """Infer column type from sample values: 'date', 'numeric', 'id', or 'text'."""
    vals = [row.get(col_name) for row in sample_rows if row.get(col_name) is not None]
    if not vals:
        return "text"
    if is_date_like_values(vals):
        return "date"
    if is_numeric_like_values(vals):
        return "numeric"
    if is_id_like_values(vals):
        return "id"
    return "text"


# ---------------------------------------------------------------------------
# Signal matching
# ---------------------------------------------------------------------------

def _column_matches_signal(col_name: str, signal_tokens: set[str]) -> bool:
    """
    Check if a column name matches a signal token set.
    Uses exact word-token match and substring match for tokens ≥5 chars.
    """
    col_tokens = tokenize_text(col_name)
    clean = re.sub(r"[^a-z0-9]", "", col_name.lower())
    for token in signal_tokens:
        if token in col_tokens:
            return True
        if len(token) >= 5 and token in clean:
            return True
    return False


# ---------------------------------------------------------------------------
# Core scoring
# ---------------------------------------------------------------------------

def score_sheet_against_role(
    sheet_name: str,
    sheet_profile: dict,
    role_signature: dict,
) -> tuple[int, int, list[str]]:
    """
    Score a sheet against one role signature.

    Returns (raw_score, max_score, evidence_list).
    Scoring rules:
      Required signal match: +3
      Optional signal match: +1
      Dtype match:           +2
      Value pattern match:   +2
      Sheet name match:      +1
    """
    columns: list[str] = sheet_profile.get("columns", [])
    sample_rows: list[dict] = sheet_profile.get("sample_rows", [])

    required_signals: list[set] = role_signature.get("required", [])
    optional_signals: list[set] = role_signature.get("optional", [])
    dtype_hints: list[tuple] = role_signature.get("dtype_hints", [])
    value_patterns: list[tuple] = role_signature.get("value_patterns", [])
    name_tokens_set: set = role_signature.get("name_tokens", set())

    evidence: list[str] = []
    raw_score = 0
    max_score = 0

    # Required signals
    for sig_tokens in required_signals:
        max_score += 3
        for col in columns:
            if _column_matches_signal(col, sig_tokens):
                raw_score += 3
                evidence.append(f"required signal {sig_tokens} matched by column '{col}'")
                break

    # Optional signals
    for sig_tokens in optional_signals:
        max_score += 1
        for col in columns:
            if _column_matches_signal(col, sig_tokens):
                raw_score += 1
                evidence.append(f"optional signal {sig_tokens} matched by column '{col}'")
                break

    # Dtype hints
    for token_set, expected_dtype in dtype_hints:
        max_score += 2
        for col in columns:
            if _column_matches_signal(col, token_set):
                vals = [row.get(col) for row in sample_rows]
                confirmed = False
                if expected_dtype == "date" and is_date_like_values(vals):
                    confirmed = True
                elif expected_dtype == "numeric" and is_numeric_like_values(vals):
                    confirmed = True
                elif expected_dtype == "id" and is_id_like_values(vals):
                    confirmed = True
                if confirmed:
                    raw_score += 2
                    evidence.append(f"dtype '{expected_dtype}' confirmed for column '{col}'")
                break

    # Value patterns
    all_vals = [v for row in sample_rows for v in row.values()]
    for pattern_desc, check_fn in value_patterns:
        max_score += 2
        try:
            if check_fn(all_vals):
                raw_score += 2
                evidence.append(f"value pattern matched: {pattern_desc}")
        except Exception:
            pass

    # Sheet name match (+1, one-time)
    max_score += 1
    norm_sname = re.sub(r"[^a-z0-9]+", "_", sheet_name.lower()).strip("_")
    name_matched = False
    if norm_sname in name_tokens_set:
        name_matched = True
        evidence.append(f"sheet name '{sheet_name}' matches known role pattern")
    else:
        sname_tokens = tokenize_text(sheet_name)
        for nt in name_tokens_set:
            nt_tokens = set(nt.split("_"))
            if sname_tokens & nt_tokens:
                name_matched = True
                evidence.append(f"sheet name tokens overlap with '{nt}'")
                break
    if name_matched:
        raw_score += 1

    return raw_score, max_score, evidence


# ---------------------------------------------------------------------------
# Cross-table reference detection
# ---------------------------------------------------------------------------

def _extract_column_sample_values(
    sheet_name: str, col_keywords: set[str], workbook_profile: dict
) -> set[str]:
    """Collect sample values from columns matching col_keywords in the given sheet."""
    sheet_data = workbook_profile.get("sheets", {}).get(sheet_name, {})
    columns = sheet_data.get("columns", [])
    sample_rows = sheet_data.get("sample_rows", [])
    vals: set[str] = set()
    for col in columns:
        if _column_matches_signal(col, col_keywords):
            for row in sample_rows:
                v = row.get(col)
                if v is not None:
                    vals.add(str(v).strip())
    return vals


def _detect_cross_table_refs(
    candidate_mapping: dict[str, str],
    workbook_profile: dict,
) -> dict[str, int]:
    """
    Count cross-table reference overlaps.
    Returns {sheet_name: bonus_points}.
    Max +3 per sheet.
    """
    _PRODUCT_TOKENS = {"sku", "product", "item", "part", "material", "article"}
    _MACHINE_TOKENS = {"machine", "equipment", "resource", "workcenter"}

    bonuses: dict[str, int] = {s: 0 for s in candidate_mapping}

    # Collect product ID values from Demand_Orders and Routing
    demand_sheets = [s for s, r in candidate_mapping.items() if r == "Demand_Orders"]
    routing_sheets = [s for s, r in candidate_mapping.items() if r == "Routing"]
    sku_sheets = [s for s, r in candidate_mapping.items() if r == "SKU_Master"]
    machine_sheets = [s for s, r in candidate_mapping.items() if r == "Machine_Master"]
    bom_sheets = [s for s, r in candidate_mapping.items() if r == "BOM"]
    inventory_sheets = [s for s, r in candidate_mapping.items() if r == "Inventory"]

    demand_products: set[str] = set()
    for s in demand_sheets:
        demand_products |= _extract_column_sample_values(s, _PRODUCT_TOKENS, workbook_profile)

    routing_products: set[str] = set()
    for s in routing_sheets:
        routing_products |= _extract_column_sample_values(s, _PRODUCT_TOKENS, workbook_profile)

    sku_products: set[str] = set()
    for s in sku_sheets:
        sku_products |= _extract_column_sample_values(s, _PRODUCT_TOKENS, workbook_profile)

    routing_machines: set[str] = set()
    for s in routing_sheets:
        routing_machines |= _extract_column_sample_values(s, _MACHINE_TOKENS, workbook_profile)

    machine_ids: set[str] = set()
    for s in machine_sheets:
        machine_ids |= _extract_column_sample_values(s, _MACHINE_TOKENS, workbook_profile)

    bom_products: set[str] = set()
    for s in bom_sheets:
        bom_products |= _extract_column_sample_values(s, _PRODUCT_TOKENS, workbook_profile)

    inventory_items: set[str] = set()
    for s in inventory_sheets:
        inventory_items |= _extract_column_sample_values(s, _PRODUCT_TOKENS, workbook_profile)

    def _add_bonus(sheets: list[str], bonus: int) -> None:
        for s in sheets:
            bonuses[s] = min(3, bonuses.get(s, 0) + bonus)

    # Product IDs overlap between demand and routing
    if demand_products and routing_products and (demand_products & routing_products):
        _add_bonus(demand_sheets, 3)
        _add_bonus(routing_sheets, 3)

    # Product IDs overlap between demand/routing and SKU_Master
    if sku_products and (demand_products | routing_products) & sku_products:
        _add_bonus(sku_sheets, 3)

    # Machine IDs overlap between routing and machine_master
    if routing_machines and machine_ids and (routing_machines & machine_ids):
        _add_bonus(routing_sheets, 3)
        _add_bonus(machine_sheets, 3)

    # BOM and Inventory overlap
    if bom_products and inventory_items and (bom_products & inventory_items):
        _add_bonus(bom_sheets, 3)
        _add_bonus(inventory_sheets, 3)

    return bonuses


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def discover_manufacturing_structure(workbook_profile: dict) -> dict:
    """
    Detect manufacturing table roles for each sheet in the workbook.

    Input: workbook_profile as returned by workbook_reader_tool.read_workbook()
    Output: {
        "table_role_candidates": [...],
        "selected_sheet_mapping": {...},
        "unknown_sheets": [...],
        "requires_user_review": bool,
        "errors": [...],
        "warnings": [...]
    }
    """
    errors: list[str] = []
    warnings: list[str] = []

    sheets_data: dict = workbook_profile.get("sheets", {})
    sheet_names: list[str] = workbook_profile.get("sheet_names", [])

    if not sheet_names:
        warnings.append("No sheets found in workbook_profile.")
        return {
            "table_role_candidates": [],
            "selected_sheet_mapping": {},
            "unknown_sheets": [],
            "requires_user_review": False,
            "errors": errors,
            "warnings": warnings,
        }

    # --- First pass: score every sheet against every role ---
    first_pass: dict[str, dict[str, tuple]] = {}  # sheet → {role: (raw, max, evidence)}
    for sname in sheet_names:
        profile = sheets_data.get(sname, {})
        first_pass[sname] = {}
        for role, sig in ROLE_SIGNATURES.items():
            if role == "Unknown":
                continue
            raw, max_s, ev = score_sheet_against_role(sname, profile, sig)
            first_pass[sname][role] = (raw, max_s, ev)

    # --- Determine best candidate role per sheet (before cross-ref) ---
    pre_mapping: dict[str, str] = {}
    for sname in sheet_names:
        best_role = "Unknown"
        best_conf = 0.0
        for role, (raw, max_s, _) in first_pass[sname].items():
            conf = (raw / max_s) if max_s > 0 else 0.0
            if conf > best_conf:
                best_conf = conf
                best_role = role
        if best_conf >= CONFIDENCE_MEDIUM:
            pre_mapping[sname] = best_role

    # --- Cross-table reference pass ---
    cross_bonuses = _detect_cross_table_refs(pre_mapping, workbook_profile)

    # --- Build final candidates ---
    table_role_candidates: list[dict] = []
    selected_sheet_mapping: dict[str, str] = {}
    unknown_sheets: list[str] = []
    requires_user_review = False

    for sname in sheet_names:
        profile = sheets_data.get(sname, {})
        role_scores: list[tuple[str, float, list[str]]] = []

        for role, (raw, max_s, ev) in first_pass[sname].items():
            bonus = cross_bonuses.get(sname, 0) if pre_mapping.get(sname) == role else 0
            total_raw = raw + bonus
            conf = min(1.0, total_raw / max_s) if max_s > 0 else 0.0
            role_scores.append((role, round(conf, 4), ev[:]))

        role_scores.sort(key=lambda x: -x[1])

        # ── Identity name override ────────────────────────────────────────
        # When a sheet's normalized name exactly matches a canonical role
        # name or is listed in that role's known name_tokens, apply a +0.35
        # confidence boost so the correct role always beats accidental false
        # positives (e.g. a "cost" column in Machine_Master causing
        # Cost_Parameters to outscore the correct role due to having a lower
        # max_score denominator).
        #
        # Affected cases that triggered this fix:
        #   Machine_Master   → was wrongly assigned Cost_Parameters (80 %)
        #   Setup_Changeover → was wrongly assigned Cost_Parameters (80 %)
        #   Material_Inventory → was wrongly assigned Cost_Parameters (80 %)
        _norm_sname_id = re.sub(r"[^a-z0-9]+", "_", sname.lower()).strip("_")
        for _id_role, _id_sig in ROLE_SIGNATURES.items():
            _norm_role_id = re.sub(r"[^a-z0-9]+", "_", _id_role.lower()).strip("_")
            _exact = _norm_sname_id == _norm_role_id
            _token = _norm_sname_id in _id_sig.get("name_tokens", set())
            if _exact or _token:
                _boost_ev = [
                    f"Sheet name '{sname}' "
                    f"{'exactly matches' if _exact else 'is a known alias for'} "
                    f"role '{_id_role}' — identity override applied"
                ]
                _boosted = False
                for _i, (_r, _c, _ev) in enumerate(role_scores):
                    if _r == _id_role:
                        role_scores[_i] = (_r, min(1.0, _c + 0.35), _ev + _boost_ev)
                        _boosted = True
                        break
                if not _boosted:
                    role_scores.append((_id_role, CONFIDENCE_STRONG, _boost_ev))
                role_scores.sort(key=lambda x: -x[1])
                break  # apply at most one identity boost per sheet
        # ─────────────────────────────────────────────────────────────────

        best_role, best_conf, best_ev = role_scores[0]
        alt_roles = [
            {"role": r, "confidence": c, "reason": f"score={c:.2f}"}
            for r, c, _ in role_scores[1:4]
            if c >= 0.15
        ]

        if best_conf < CONFIDENCE_MEDIUM:
            best_role = "Unknown"
            best_conf = 0.0
            unknown_sheets.append(sname)
            warnings.append(
                f"Sheet '{sname}' could not be mapped to any known manufacturing role "
                f"(best confidence={role_scores[0][1]:.2f})."
            )
        elif best_conf < CONFIDENCE_STRONG:
            warnings.append(
                f"Sheet '{sname}' → '{best_role}' with medium confidence ({best_conf:.2f}). "
                "Consider review."
            )
            requires_user_review = True

        candidate: dict = {
            "raw_sheet": sname,
            "selected_role": best_role,
            "confidence": best_conf,
            "evidence": best_ev,
            "alternative_roles": alt_roles,
        }
        table_role_candidates.append(candidate)

        if best_role != "Unknown":
            selected_sheet_mapping[sname] = best_role

    if requires_user_review:
        warnings.insert(0, "Some sheets have medium confidence — user review recommended.")

    return {
        "table_role_candidates": table_role_candidates,
        "selected_sheet_mapping": selected_sheet_mapping,
        "unknown_sheets": unknown_sheets,
        "requires_user_review": requires_user_review,
        "errors": errors,
        "warnings": warnings,
    }