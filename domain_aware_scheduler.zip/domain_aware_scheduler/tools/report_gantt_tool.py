from __future__ import annotations

import html
import os
import re
from typing import Any

import pandas as pd


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ensure_output_dir(output_dir: str) -> str:
    os.makedirs(output_dir, exist_ok=True)
    return output_dir


def _safe_filename(value: str) -> str:
    """Replace non-alphanumeric characters with underscores."""
    return re.sub(r"[^a-zA-Z0-9_\-]", "_", str(value))


def _html_escape(value: Any) -> str:
    if value is None:
        return ""
    return html.escape(str(value))


def _dict_to_html_table(data: dict) -> str:
    if not data:
        return "<p><em>No data.</em></p>"
    rows = "".join(
        f"<tr><td class='kv-key'>{_html_escape(k)}</td>"
        f"<td>{_html_escape(v)}</td></tr>"
        for k, v in data.items()
    )
    return f"<table class='kv-table'><tbody>{rows}</tbody></table>"


def _records_to_html_table(records: list[dict], limit: int = 100) -> str:
    if not records:
        return "<p><em>No records.</em></p>"
    displayed = records[:limit]
    headers = list(displayed[0].keys())
    header_cells = "".join(f"<th>{_html_escape(h)}</th>" for h in headers)
    row_html = ""
    for r in displayed:
        cells = "".join(f"<td>{_html_escape(r.get(h, ''))}</td>" for h in headers)
        row_html += f"<tr>{cells}</tr>\n"
    suffix = (
        f"<tr><td colspan='{len(headers)}' style='text-align:center;color:#888'>"
        f"... and {len(records) - limit} more rows.</td></tr>"
        if len(records) > limit else ""
    )
    return (
        f"<table><thead><tr>{header_cells}</tr></thead>"
        f"<tbody>{row_html}{suffix}</tbody></table>"
    )


def _list_to_html_ul(items: list[str], css_class: str = "") -> str:
    if not items:
        return "<p><em>None.</em></p>"
    class_attr = f" class='{css_class}'" if css_class else ""
    lis = "".join(f"<li>{_html_escape(i)}</li>" for i in items)
    return f"<ul{class_attr}>{lis}</ul>"


# ---------------------------------------------------------------------------
# Summary enrichment
# ---------------------------------------------------------------------------

def _enrich_info_summary(
    payload: dict,
    solver_result: dict,
    mapping_report: dict | None,
) -> dict:
    info = dict(solver_result.get("info_summary") or {})
    reference_time = str(payload.get("reference_time") or "")
    domain_profile_id = str(payload.get("domain_profile_id") or "")
    meta = payload.get("metadata") or {}
    current_date = str(meta.get("current_date") or reference_time[:10] or "")

    jobs = payload.get("jobs") or []
    total_ops = sum(len(j.get("operations") or []) for j in jobs)
    schedule_table = solver_result.get("schedule_table") or []
    late_orders = solver_result.get("late_orders") or []
    unscheduled = solver_result.get("unscheduled_orders") or []

    info.update({
        "current_date": current_date,
        "reference_time": reference_time,
        "domain_profile_id": domain_profile_id,
        "solver_status": solver_result.get("solver_status") or "UNKNOWN",
        "total_jobs": len(jobs),
        "total_operations": total_ops,
        "scheduled_operations": len(schedule_table),
        "late_orders_count": len(late_orders),
        "unscheduled_orders_count": len(unscheduled),
    })
    return info


def _enrich_cost_summary(
    cost_summary: dict,
    payload: dict,
    schedule_table: list[dict],
    warnings: list[str],
) -> dict:
    cs = dict(cost_summary)
    defaults: dict[str, Any] = {
        "total_tardiness_minutes": 0,
        "total_tardiness_cost": 0.0,
        "total_holding_cost": 0.0,
        "total_machine_cost": 0.0,
        "total_setup_cleaning_cost": 0.0,
        "total_cost": 0.0,
        "estimated_revenue": 0.0,
        "estimated_production_cost": 0.0,
        "estimated_profit": 0.0,
        "objective_value": None,
    }
    for k, v in defaults.items():
        cs.setdefault(k, v)

    # Compute revenue/profit from payload if selling prices are present
    jobs = payload.get("jobs") or []
    scheduled_ids = {t.get("job_id") for t in schedule_table}
    revenue = 0.0
    prod_cost = 0.0
    for job in jobs:
        if job.get("job_id") in scheduled_ids:
            qty = float(job.get("quantity") or 0)
            revenue += qty * float(job.get("selling_price_per_unit") or 0)
            prod_cost += qty * float(job.get("unit_production_cost") or 0)

    if revenue > 0:
        cs["estimated_revenue"] = round(revenue, 2)
        cs["estimated_production_cost"] = round(prod_cost, 2)
        total_cost = float(cs.get("total_cost") or 0)
        cs["estimated_profit"] = round(revenue - prod_cost - total_cost, 2)

    return cs


# ---------------------------------------------------------------------------
# File writers
# ---------------------------------------------------------------------------

_SCHEDULE_COLUMNS = [
    "job_id", "order_id", "product_id", "operation_id", "operation_family",
    "machine_id", "start", "end", "duration_minutes", "due_at",
    "is_late", "tardiness_minutes", "priority_class",
]


def _write_csv(schedule_table: list[dict], path: str) -> None:
    if schedule_table:
        df = pd.DataFrame(schedule_table)
        for col in _SCHEDULE_COLUMNS:
            if col not in df.columns:
                df[col] = None
        df[_SCHEDULE_COLUMNS].to_csv(path, index=False)
    else:
        pd.DataFrame(columns=_SCHEDULE_COLUMNS).to_csv(path, index=False)


def _write_excel(
    solver_result: dict,
    info_summary: dict,
    cost_summary: dict,
    output_path: str,
    mapping_report: dict | None = None,
) -> None:
    schedule_table = solver_result.get("schedule_table") or []
    machine_util = solver_result.get("machine_utilization") or []
    late_orders = solver_result.get("late_orders") or []
    bottlenecks = solver_result.get("bottlenecks") or []
    warnings_list = solver_result.get("warnings") or []
    errors_list = solver_result.get("errors") or []

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        # Sheet 1: Schedule
        if schedule_table:
            df = pd.DataFrame(schedule_table)
            for col in _SCHEDULE_COLUMNS:
                if col not in df.columns:
                    df[col] = None
            df[_SCHEDULE_COLUMNS].to_excel(writer, sheet_name="Schedule", index=False)
        else:
            pd.DataFrame(columns=_SCHEDULE_COLUMNS).to_excel(
                writer, sheet_name="Schedule", index=False
            )

        # Sheet 2: Cost_Summary
        pd.DataFrame([cost_summary]).to_excel(
            writer, sheet_name="Cost_Summary", index=False
        )

        # Sheet 3: Info_Summary
        pd.DataFrame([info_summary]).to_excel(
            writer, sheet_name="Info_Summary", index=False
        )

        # Sheet 4: Machine_Utilization
        if machine_util:
            pd.DataFrame(machine_util).to_excel(
                writer, sheet_name="Machine_Utilization", index=False
            )
        else:
            pd.DataFrame(columns=["machine_id", "utilization_pct"]).to_excel(
                writer, sheet_name="Machine_Utilization", index=False
            )

        # Sheet 5: Late_Orders
        if late_orders:
            pd.DataFrame(late_orders).to_excel(
                writer, sheet_name="Late_Orders", index=False
            )
        else:
            pd.DataFrame(columns=["job_id", "tardiness_minutes"]).to_excel(
                writer, sheet_name="Late_Orders", index=False
            )

        # Sheet 6: Bottlenecks
        if bottlenecks:
            pd.DataFrame(bottlenecks).to_excel(
                writer, sheet_name="Bottlenecks", index=False
            )
        else:
            pd.DataFrame(columns=["machine_id", "utilization_pct"]).to_excel(
                writer, sheet_name="Bottlenecks", index=False
            )

        # Sheet 7: Warnings
        pd.DataFrame({"warning": warnings_list}).to_excel(
            writer, sheet_name="Warnings", index=False
        )

        # Sheet 8: Errors
        pd.DataFrame({"error": errors_list}).to_excel(
            writer, sheet_name="Errors", index=False
        )

        # Phase 4 — new intelligence sheets (safe: skip if data missing)
        mr = mapping_report or {}

        # Sheet 9: Manufacturing_DNA
        try:
            dna = mr.get("manufacturing_dna") or {}
            if dna:
                dna_rows = [{"Capability": label, "Detected": str(dna.get(key, False))}
                            for key, label in _DNA_LABELS.items()]
                dna_rows.insert(0, {"Capability": "Production Model",
                                    "Detected": str(dna.get("production_model", ""))})
                pd.DataFrame(dna_rows).to_excel(
                    writer, sheet_name="Manufacturing_DNA", index=False
                )
        except Exception:
            pass

        # Sheet 10: Constraint_Enforcement
        try:
            matrix = mr.get("constraint_enforcement_matrix") or []
            if matrix:
                mat_rows = [
                    {
                        "Constraint": r.get("constraint", ""),
                        "Detected": r.get("detected", False),
                        "Verified": r.get("verified", False),
                        "Solver_Supported": r.get("solver_supported", False),
                        "Enforced": r.get("enforced", False),
                        "Status": r.get("status", ""),
                        "Reason": str(r.get("reason", ""))[:200],
                    }
                    for r in matrix
                ]
                pd.DataFrame(mat_rows).to_excel(
                    writer, sheet_name="Constraint_Enforcement", index=False
                )
        except Exception:
            pass

        # Sheet 11: Table_Role_Mapping
        try:
            candidates = (mr.get("table_role_report") or {}).get("table_role_candidates") or []
            sheet_src = mr.get("sheet_mapping_source") or {}
            if candidates:
                role_rows = [
                    {
                        "Raw_Sheet": c.get("raw_sheet", ""),
                        "Detected_Role": c.get("selected_role", ""),
                        "Confidence": round(float(c.get("confidence", 0)), 4),
                        "Source": sheet_src.get(c.get("raw_sheet", ""), ""),
                        "Evidence": "; ".join(str(e) for e in (c.get("evidence") or [])[:3]),
                    }
                    for c in candidates
                ]
                pd.DataFrame(role_rows).to_excel(
                    writer, sheet_name="Table_Role_Mapping", index=False
                )
        except Exception:
            pass

        # Sheet 12: Constraint_Packs
        try:
            pack_cands = mr.get("constraint_pack_candidates") or []
            if pack_cands:
                pack_rows = [
                    {
                        "Constraint_Type": c.get("constraint_type", ""),
                        "Source_Pack": c.get("source_pack", ""),
                        "Confidence": round(float(c.get("confidence", 0)), 4),
                        "Status": c.get("status", ""),
                        "Evidence": "; ".join(str(e) for e in (c.get("evidence") or [])[:3]),
                        "Missing_Fields": ", ".join(c.get("missing_fields") or []),
                    }
                    for c in pack_cands
                ]
                pd.DataFrame(pack_rows).to_excel(
                    writer, sheet_name="Constraint_Packs", index=False
                )
        except Exception:
            pass


def _write_gantt_html(
    schedule_table: list[dict],
    output_path: str,
    warnings: list[str],
) -> None:
    if not schedule_table:
        _write_fallback_gantt_html([], output_path, "No schedule data to display.")
        return

    try:
        import plotly.express as px
        import plotly.io as pio

        df = pd.DataFrame(schedule_table)
        df["start"] = pd.to_datetime(df["start"], errors="coerce")
        df["end"] = pd.to_datetime(df["end"], errors="coerce")
        df = df.dropna(subset=["start", "end", "machine_id"])

        if df.empty:
            _write_fallback_gantt_html(schedule_table, output_path, "No valid rows after parsing dates.")
            warnings.append("Gantt: all rows had unparseable start/end — using fallback table.")
            return

        # Ensure color column exists
        color_col = "operation_family" if "operation_family" in df.columns else "product_id"
        if color_col not in df.columns:
            df["_color"] = "Task"
            color_col = "_color"
        df[color_col] = df[color_col].fillna("Unknown")

        hover_cols = [
            c for c in [
                "job_id", "order_id", "product_id", "operation_id",
                "duration_minutes", "due_at", "is_late", "tardiness_minutes",
            ]
            if c in df.columns
        ]

        fig = px.timeline(
            df,
            x_start="start",
            x_end="end",
            y="machine_id",
            color=color_col,
            hover_data=hover_cols,
            title="Production Schedule — Gantt Chart",
            labels={"machine_id": "Machine", color_col: "Operation Family"},
        )
        fig.update_yaxes(autorange="reversed")
        fig.update_layout(
            xaxis_title="Time",
            yaxis_title="Machine",
            legend_title="Operation Family",
            height=max(400, 60 * df["machine_id"].nunique() + 120),
        )

        html_str = pio.to_html(fig, full_html=True, include_plotlyjs="cdn")
        with open(output_path, "w", encoding="utf-8") as fh:
            fh.write(html_str)

    except Exception as exc:
        warnings.append(f"Gantt plotly rendering failed ({exc}); using fallback table.")
        _write_fallback_gantt_html(schedule_table, output_path, str(exc))


def _write_fallback_gantt_html(
    schedule_table: list[dict],
    output_path: str,
    reason: str = "",
) -> None:
    table_html = _records_to_html_table(schedule_table, limit=200)
    reason_html = f"<p style='color:#c0392b'><strong>Note:</strong> {_html_escape(reason)}</p>" if reason else ""
    content = (
        f"<!DOCTYPE html><html><head><meta charset='utf-8'>"
        f"<title>Schedule Table</title>{_HTML_STYLE}</head><body>"
        f"<h1>Production Schedule — Table View</h1>"
        f"{reason_html}"
        f"<div class='section'>{table_html}</div>"
        f"</body></html>"
    )
    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write(content)


def _write_report_html(
    payload: dict,
    solver_result: dict,
    mapping_report: dict | None,
    info_summary: dict,
    cost_summary: dict,
    output_path: str,
) -> None:
    solver_status = solver_result.get("solver_status") or "UNKNOWN"
    schedule_table = solver_result.get("schedule_table") or []
    machine_util = solver_result.get("machine_utilization") or []
    bottlenecks = solver_result.get("bottlenecks") or []
    late_orders = solver_result.get("late_orders") or []
    unscheduled = solver_result.get("unscheduled_orders") or []
    warnings_list = solver_result.get("warnings") or []
    errors_list = solver_result.get("errors") or []
    solver_debug = solver_result.get("solver_debug") or {}
    post_val = solver_result.get("post_solve_validation_report") or {}

    status_badge_cls = "badge-ok" if solver_status in ("OPTIMAL", "FEASIBLE") else "badge-error"
    mr = mapping_report or {}

    # -- Domain section --
    domain_data = {
        "domain_profile_id": info_summary.get("domain_profile_id", ""),
        "current_date": info_summary.get("current_date", ""),
        "reference_time": info_summary.get("reference_time", ""),
        "solver_status": solver_status,
    }
    if mr:
        domain_data["domain_confidence"] = mr.get("domain_confidence", "")
        domain_data["domain_reason"] = mr.get("domain_reason", "")

    # -- Schedule summary section --
    summary_data = {
        "total_jobs": info_summary.get("total_jobs", ""),
        "total_operations": info_summary.get("total_operations", ""),
        "scheduled_operations": info_summary.get("scheduled_operations", ""),
        "late_orders_count": info_summary.get("late_orders_count", ""),
        "unscheduled_orders_count": info_summary.get("unscheduled_orders_count", ""),
        "horizon_minutes": info_summary.get("horizon_minutes", ""),
        "num_scheduled_jobs": info_summary.get("num_scheduled_jobs", ""),
    }

    # -- Mapping summary --
    mapped_c = mr.get("mapped_constraints") or []
    unsupported_r = mr.get("unsupported_rules") or []
    sheet_map = mr.get("sheet_mapping") or {}
    col_map = mr.get("column_mapping") or {}

    parts: list[str] = [
        "<!DOCTYPE html><html><head><meta charset='utf-8'>",
        "<title>Production Scheduling Copilot Report</title>",
        _HTML_STYLE,
        "</head><body>",
        "<h1>Production Scheduling Copilot Report</h1>",

        # 1. Planning date
        "<div class='section'><h2>1. Planning Date &amp; Reference Time</h2>",
        _dict_to_html_table({
            "Current Planning Date": info_summary.get("current_date", "N/A"),
            "Reference Time (time-zero)": info_summary.get("reference_time", "N/A"),
        }),
        "</div>",

        # 2. Optional domain metadata (not the scheduling source of truth)
        "<div class='section'><h2>2. Optional Domain Metadata</h2>",
        "<p style='color:#888;font-size:12px'>The optional domain guess is retained for "
        "backward compatibility only. Solver constraints are selected from discovered "
        "manufacturing structure and verified constraint evidence.</p>",
        _dict_to_html_table({
            "Optional Domain Guess": domain_data.get("domain_profile_id", ""),
            "Guess Confidence": domain_data.get("domain_confidence", ""),
            "Legacy Domain Reason": domain_data.get("domain_reason", ""),
            "Current Date": domain_data.get("current_date", ""),
            "Reference Time": domain_data.get("reference_time", ""),
            "Solver Status": domain_data.get("solver_status", ""),
        }),
        "</div>",

        # 3. Solver status
        "<div class='section'><h2>3. Solver Status</h2>",
        f"<p>Status: <span class='{status_badge_cls}'>{_html_escape(solver_status)}</span></p>",
        _dict_to_html_table(solver_debug),
        "</div>",

        # 4. Schedule summary
        "<div class='section'><h2>4. Schedule Summary</h2>",
        _dict_to_html_table(summary_data),
        "</div>",

        # 5. Cost / profit
        "<div class='section'><h2>5. Cost / Profit Summary</h2>",
        _build_cost_section_html(cost_summary),
        "</div>",

        # 6. Machine utilization
        "<div class='section'><h2>6. Machine Utilization</h2>",
        _records_to_html_table(machine_util),
        "</div>",

        # 7. Bottlenecks
        "<div class='section'><h2>7. Bottleneck Machines (≥80% utilization)</h2>",
        _records_to_html_table(bottlenecks) if bottlenecks else "<p><em>No bottlenecks detected.</em></p>",
        "</div>",

        # 8. Late orders
        "<div class='section'><h2>8. Late Orders</h2>",
        _records_to_html_table(late_orders) if late_orders else "<p><em>All orders on time.</em></p>",
        "</div>",

        # 9. Unscheduled orders
        "<div class='section'><h2>9. Unscheduled Orders</h2>",
        _records_to_html_table(unscheduled) if unscheduled else "<p><em>All orders scheduled.</em></p>",
        "</div>",

        # 10. Schedule table (sample)
        "<div class='section'><h2>10. Schedule Table (first 50 rows)</h2>",
        _records_to_html_table(schedule_table, limit=50),
        "</div>",

        # 11. Warnings
        "<div class='section'><h2>11. Warnings</h2>",
        _list_to_html_ul(warnings_list, "warn-list") if warnings_list else "<p><em>None.</em></p>",
        "</div>",

        # 12. Errors
        "<div class='section'><h2>12. Errors</h2>",
        _list_to_html_ul(errors_list, "error-list") if errors_list else "<p><em>None.</em></p>",
        "</div>",

        # 13. Mapping summary
        "<div class='section'><h2>13. Mapping Summary</h2>",
        "<h3>Sheet Mapping</h3>",
        _dict_to_html_table(sheet_map),
        "<h3>Mapped Constraints</h3>",
        _records_to_html_table(mapped_c) if mapped_c else "<p><em>None.</em></p>",
        "<h3>Unsupported Rules</h3>",
        _records_to_html_table(unsupported_r) if unsupported_r else "<p><em>None.</em></p>",
        "</div>",

        # 14. Manufacturing Structure Discovery (Phase 4)
        _build_dna_section_html(mr),

        # 15. Constraint Enforcement Matrix (Phase 4)
        _build_enforcement_matrix_html(mr),

        # 16. Evidence-Based Constraint Pack Detection (Phase 4)
        _build_pack_detection_html(mr),

        # 17. Post-solve validation
        "<div class='section'><h2>17. Post-Solve Validation</h2>",
        _dict_to_html_table(post_val.get("stats") or {}) if post_val else "<p><em>Not available.</em></p>",
        "</div>",

        # 18. Solver debug
        "<div class='section'><h2>18. Solver Debug</h2>",
        _dict_to_html_table(solver_debug),
        "</div>",

        "</body></html>",
    ]

    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(parts))


# ---------------------------------------------------------------------------
# Shared CSS
# ---------------------------------------------------------------------------

_HTML_STYLE = """
<style>
  body{font-family:Arial,sans-serif;margin:20px;background:#f8f9fa;color:#333}
  h1{color:#2c3e50;border-bottom:2px solid #3498db;padding-bottom:8px}
  h2{color:#2980b9;margin-top:24px}
  h3{color:#555;margin-top:16px}
  table{border-collapse:collapse;width:100%;margin-bottom:16px;font-size:13px}
  th{background:#3498db;color:white;padding:7px 10px;text-align:left}
  td{padding:5px 10px;border:1px solid #ddd}
  tr:nth-child(even){background:#f2f7fc}
  .section{background:white;padding:16px;margin-bottom:20px;border-radius:4px;box-shadow:0 1px 3px rgba(0,0,0,.1)}
  .badge-ok{background:#27ae60;color:white;padding:2px 10px;border-radius:3px;font-weight:bold}
  .badge-warn{background:#e67e22;color:white;padding:2px 10px;border-radius:3px;font-weight:bold}
  .badge-error{background:#c0392b;color:white;padding:2px 10px;border-radius:3px;font-weight:bold}
  .badge-info{background:#2980b9;color:white;padding:2px 10px;border-radius:3px;font-weight:bold}
  .kv-table td{border:1px solid #ddd;padding:5px 10px}
  .kv-key{font-weight:bold;background:#eaf2fb;width:220px}
  .warn-list li{color:#e67e22}
  .error-list li{color:#c0392b}
  ul{padding-left:20px}
  .note{background:#fef9e7;border-left:4px solid #f39c12;padding:8px 12px;margin:8px 0;font-size:12px}
  .info-note{background:#eaf2fb;border-left:4px solid #3498db;padding:8px 12px;margin:8px 0;font-size:12px}
  .enforced{color:#27ae60;font-weight:bold}
  .partial{color:#e67e22}
  .not-enforced{color:#c0392b}
  .needs-review{color:#8e44ad}
  .unsupported{color:#7f8c8d}
</style>
"""


# ---------------------------------------------------------------------------
# Phase 4 — Manufacturing intelligence HTML builders
# ---------------------------------------------------------------------------

_DNA_LABELS: dict[str, str] = {
    "has_demand":           "Demand Orders",
    "has_products":         "Products / SKUs",
    "has_routing":          "Routing / Operations",
    "has_machines":         "Machine / Resource Master",
    "has_machine_capacity": "Machine Capacity",
    "has_processing_times": "Processing Times",
    "has_due_dates":        "Due Dates",
    "has_priorities":       "Priorities",
    "has_bom":              "BOM / Recipe",
    "has_inventory":        "Inventory / Stock",
    "has_setup_changeover": "Setup / Changeover",
    "has_quality_hold":     "Quality Hold (QA Release)",
    "has_calendar":         "Machine Calendar",
    "has_labor":            "Labor Shifts",
    "has_maintenance":      "Maintenance Downtime",
    "has_overtime":         "Overtime Capacity",
    "has_costs":            "Cost Parameters",
}

_STATUS_HTML: dict[str, str] = {
    "enforced":              "<span class='enforced'>&#10003; Enforced</span>",
    "detected_partial":      "<span class='partial'>&#9651; Detected (partial)</span>",
    "detected_not_enforced": "<span class='not-enforced'>&#10007; Detected &mdash; not enforced</span>",
    "needs_user_review":     "<span class='needs-review'>? Needs user review</span>",
    "unsupported":           "<span class='unsupported'>&#9899; Unsupported</span>",
}


def _is_partial_cost_summary(cost: dict) -> bool:
    revenue = float(cost.get("estimated_revenue") or 0)
    prod_cost = float(cost.get("estimated_production_cost") or 0)
    total = float(cost.get("total_machine_cost") or cost.get("total_business_cost") or cost.get("total_cost") or 0)
    return total > 0 and (revenue == 0 or prod_cost == 0)


def _build_cost_section_html(cost: dict) -> str:
    parts = []
    if _is_partial_cost_summary(cost):
        parts.append(
            "<div class='note'><strong>Partial Business Cost Estimate.</strong> "
            "Machine/tardiness/setup costs may be computed, but revenue or unit production "
            "cost is missing/zero in the dataset. Estimated profit is therefore partial and "
            "should not be treated as final financial profit.</div>"
        )
    parts.append(_dict_to_html_table(cost))
    return "\n".join(parts)


def _build_dna_section_html(mr: dict) -> str:
    """Build Manufacturing Structure Discovery HTML section."""
    dna = mr.get("manufacturing_dna") or {}
    dna_report = mr.get("manufacturing_dna_report") or {}
    table_role_report = mr.get("table_role_report") or {}
    mapping_mode = mr.get("mapping_mode") or ""
    optional_domain = mr.get("optional_domain_guess") or {}
    sheet_src = mr.get("sheet_mapping_source") or {}

    if not dna and not mapping_mode:
        return ""

    parts = ["<div class='section'><h2>14. Manufacturing Structure Discovery</h2>"]

    # Mapping mode
    if mapping_mode:
        mode_map = {
            "domain_free_mapping":    ("badge-ok", "Domain-Free Mapping (no YAML profiles required)"),
            "mixed_mapping":          ("badge-warn", "Mixed Mapping (domain-free + legacy fallback)"),
            "legacy_fallback_mapping":("badge-warn", "Legacy Fallback Mapping"),
        }
        cls, label = mode_map.get(mapping_mode, ("badge-info", mapping_mode))
        parts.append(f"<p><strong>Mapping Mode:</strong> <span class='{cls}'>{_html_escape(label)}</span></p>")

    # Optional domain guess
    if optional_domain.get("domain_profile_id"):
        domain_id = optional_domain.get("domain_profile_id", "")
        domain_conf = float(optional_domain.get("confidence") or 0)
        parts.append(
            f"<div class='info-note'><strong>Optional Domain Guess:</strong> "
            f"{_html_escape(domain_id)} (confidence: {domain_conf:.0%}). "
            "This is metadata only &mdash; scheduling is based on discovered manufacturing "
            "structure and verified constraints, not on the domain label.</div>"
        )

    # Production model
    prod_model = dna.get("production_model", "")
    if prod_model:
        parts.append(f"<p><strong>Production Model:</strong> <code>{_html_escape(prod_model)}</code></p>")

    # DNA checklist
    if dna:
        enforcement_matrix = mr.get("constraint_enforcement_matrix") or []
        no_overlap_enforced = any(
            r.get("constraint") == "machine_capacity_no_overlap" and r.get("enforced")
            for r in enforcement_matrix
        )
        parts.append("<h3>Manufacturing Capability Checklist</h3>")
        rows = ""
        for key, label in _DNA_LABELS.items():
            val = dna.get(key)
            if key == "has_machine_capacity" and not val and no_overlap_enforced:
                icon = "&#9888; Explicit capacity not found; default capacity=1 assumed and no-overlap enforced"
                style = "color:#e67e22"
            elif val:
                icon = "&#10003; Detected"
                style = "color:#27ae60"
            else:
                icon = "&#10007; Not found"
                style = "color:#c0392b"
            rows += (
                f"<tr><td>{_html_escape(label)}</td>"
                f"<td style='{style}'><strong>{icon}</strong></td></tr>"
            )
        parts.append(
            f"<table><thead><tr><th>Capability</th><th>Status</th></tr></thead>"
            f"<tbody>{rows}</tbody></table>"
        )

    # Missing requirements
    missing_basic = dna_report.get("missing_for_basic_scheduling") or []
    missing_adv = dna_report.get("missing_for_advanced_scheduling") or []
    if missing_basic:
        items = "; ".join(_html_escape(m) for m in missing_basic)
        parts.append(f"<div class='note'><strong>Missing for basic scheduling:</strong> {items}</div>")
    if missing_adv:
        items = "; ".join(_html_escape(m) for m in missing_adv[:6])
        suffix = "..." if len(missing_adv) > 6 else ""
        parts.append(
            f"<div class='info-note'><strong>Missing for advanced scheduling (optional):</strong> "
            f"{items}{suffix}</div>"
        )

    # Table role mapping
    candidates = table_role_report.get("table_role_candidates") or []
    if candidates:
        parts.append("<h3>Detected Sheet Roles</h3>")
        header = "<tr><th>Raw Sheet</th><th>Detected Role</th><th>Confidence</th><th>Source</th><th>Evidence</th></tr>"
        rows = ""
        for c in candidates:
            conf = c.get("confidence", 0.0)
            conf_label = "High" if conf >= 0.85 else ("Medium" if conf >= 0.60 else "Low")
            ev = c.get("evidence") or []
            ev_short = "; ".join(str(e) for e in ev[:2])
            if len(ev) > 2:
                ev_short += "..."
            src = sheet_src.get(c.get("raw_sheet", ""), "")
            rows += (
                f"<tr><td>{_html_escape(c.get('raw_sheet',''))}</td>"
                f"<td><strong>{_html_escape(c.get('selected_role','Unknown'))}</strong></td>"
                f"<td>{_html_escape(f'{conf:.0%}')} ({_html_escape(conf_label)})</td>"
                f"<td>{_html_escape(src)}</td>"
                f"<td>{_html_escape(ev_short)}</td></tr>"
            )
        parts.append(f"<table><thead>{header}</thead><tbody>{rows}</tbody></table>")

    parts.append("</div>")
    return "\n".join(parts)


def _build_enforcement_matrix_html(mr: dict) -> str:
    """Build Constraint Enforcement Matrix HTML section."""
    matrix = mr.get("constraint_enforcement_matrix") or []
    partial_list = mr.get("partial_constraints") or []
    unsup_list = mr.get("unsupported_constraints") or []

    if not matrix:
        return ""

    n_enforced = sum(1 for r in matrix if r.get("enforced"))
    n_partial = len(partial_list)
    n_unsup = len(unsup_list)

    parts = ["<div class='section'><h2>15. Constraint Enforcement Matrix</h2>"]
    parts.append(
        f"<p><strong>Enforced:</strong> {n_enforced} &nbsp; "
        f"<strong>Partial / Review:</strong> {n_partial} &nbsp; "
        f"<strong>Detected (not enforced):</strong> {n_unsup}</p>"
    )

    if n_partial:
        parts.append(
            "<div class='note'>Some constraints were detected but only partially supported. "
            "They were NOT sent to CP-SAT as hard constraints. "
            "Check Missing Fields to understand what data is needed.</div>"
        )
    if n_unsup:
        parts.append(
            "<div class='note'>Some constraints were detected from the dataset but are NOT "
            "enforced by the current solver (e.g., material inventory, shelf life, "
            "overtime). These are shown as information only.</div>"
        )

    header = (
        "<tr><th>Constraint</th><th>Detected</th><th>Verified</th>"
        "<th>Solver Supported</th><th>Enforced</th><th>Status</th><th>Reason</th></tr>"
    )
    rows = ""
    for r in matrix:
        status_raw = r.get("status", "")
        status_html = _STATUS_HTML.get(status_raw, _html_escape(status_raw))
        det = "&#10003;" if r.get("detected") else "&#10007;"
        ver = "&#10003;" if r.get("verified") else "&mdash;"
        sup = "&#10003;" if r.get("solver_supported") else "&#10007;"
        enf = "&#10003;" if r.get("enforced") else "&#10007;"
        reason_short = str(r.get("reason", ""))[:120]
        rows += (
            f"<tr><td><strong>{_html_escape(r.get('constraint',''))}</strong></td>"
            f"<td>{det}</td><td>{ver}</td><td>{sup}</td><td>{enf}</td>"
            f"<td>{status_html}</td>"
            f"<td style='font-size:11px'>{_html_escape(reason_short)}</td></tr>"
        )

    parts.append(f"<table><thead>{header}</thead><tbody>{rows}</tbody></table>")
    parts.append("</div>")
    return "\n".join(parts)


def _build_pack_detection_html(mr: dict) -> str:
    """Build Evidence-Based Constraint Pack Detection HTML section."""
    activated_packs = mr.get("activated_constraint_packs") or []
    pack_candidates = mr.get("constraint_pack_candidates") or []

    if not activated_packs and not pack_candidates:
        return ""

    _STATUS_HTML_MAP: dict[str, str] = {
        "enforced":              "&#10003; Enforced",
        "detected_partial":      "&#9651; Partial",
        "detected_not_enforced": "&#10007; Not enforced",
        "needs_user_review":     "? Needs review",
        "candidate":             "&#9670; Candidate",
        "needs_user_review":     "? Review",
        "unsupported":           "&#9899; Unsupported",
    }

    parts = [
        "<div class='section'><h2>16. Evidence-Based Constraint Pack Detection</h2>",
        "<div class='info-note'>These are <strong>not domain classifications</strong>. "
        "They are constraint-family detectors that activate when matching "
        "evidence appears in the workbook.</div>",
    ]

    if activated_packs:
        parts.append("<h3>Pack Activation Summary</h3>")
        header = "<tr><th>Pack</th><th>Activated</th><th>Candidates</th><th>Avg Confidence</th><th>Reason</th></tr>"
        rows = ""
        for p in activated_packs:
            activated = "&#10003; Yes" if p.get("activated") else "&#10007; No"
            rows += (
                f"<tr><td>{_html_escape(p.get('pack_name',''))}</td>"
                f"<td>{activated}</td>"
                f"<td>{p.get('num_candidates', 0)}</td>"
                f"<td>{float(p.get('confidence') or 0):.0%}</td>"
                f"<td style='font-size:11px'>{_html_escape(str(p.get('reason',''))[:100])}</td></tr>"
            )
        parts.append(f"<table><thead>{header}</thead><tbody>{rows}</tbody></table>")

    if pack_candidates:
        parts.append(f"<h3>Pack Candidates ({len(pack_candidates)})</h3>")
        header = (
            "<tr><th>Constraint Type</th><th>Source Pack</th><th>Confidence</th>"
            "<th>Status</th><th>Evidence</th><th>Missing Fields</th></tr>"
        )
        rows = ""
        for c in pack_candidates[:50]:
            status_raw = c.get("status", "")
            status_disp = _STATUS_HTML_MAP.get(status_raw, status_raw)
            ev = c.get("evidence") or []
            ev_short = "; ".join(str(e) for e in ev[:2])
            missing = ", ".join(c.get("missing_fields") or []) or "&mdash;"
            rows += (
                f"<tr><td>{_html_escape(c.get('constraint_type',''))}</td>"
                f"<td>{_html_escape(c.get('source_pack',''))}</td>"
                f"<td>{float(c.get('confidence') or 0):.0%}</td>"
                f"<td>{status_disp}</td>"
                f"<td style='font-size:11px'>{_html_escape(ev_short)}</td>"
                f"<td>{_html_escape(missing)}</td></tr>"
            )
        if len(pack_candidates) > 50:
            rows += (
                f"<tr><td colspan='6' style='text-align:center;color:#888'>"
                f"... and {len(pack_candidates)-50} more candidates in debug JSON.</td></tr>"
            )
        parts.append(f"<table><thead>{header}</thead><tbody>{rows}</tbody></table>")

    parts.append("</div>")
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_report(
    payload: dict,
    solver_result: dict,
    mapping_report: dict | None = None,
    output_dir: str = "outputs",
) -> dict:
    """
    Generate schedule.csv, schedule.xlsx, gantt.html, and report.html
    from an existing solved schedule. Never reruns the solver.

    Returns:
    {
        "output_files": { "schedule_csv", "schedule_xlsx", "report_html", "gantt_html" },
        "gantt_chart_path": str,
        "info_summary": dict,
        "cost_summary": dict,
        "errors": [str],
        "warnings": [str],
    }
    """
    errors: list[str] = []
    warnings: list[str] = []

    output_dir = _ensure_output_dir(output_dir)

    schedule_table: list[dict] = solver_result.get("schedule_table") or []
    if not schedule_table:
        warnings.append("schedule_table is empty; output files will be generated with no schedule rows.")

    info_summary = _enrich_info_summary(payload, solver_result, mapping_report)
    cost_summary = _enrich_cost_summary(
        dict(solver_result.get("cost_summary") or {}),
        payload,
        schedule_table,
        warnings,
    )

    # Deterministic file-name prefix — no datetime.now()
    reference_time = str(payload.get("reference_time") or "")
    ts = _safe_filename(reference_time[:10]) if reference_time else "nodate"
    domain_safe = _safe_filename(str(payload.get("domain_profile_id") or "unknown"))[:30]
    prefix = f"{ts}_{domain_safe}"

    csv_path = os.path.join(output_dir, f"schedule_{prefix}.csv")
    xlsx_path = os.path.join(output_dir, f"schedule_{prefix}.xlsx")
    gantt_path = os.path.join(output_dir, f"gantt_{prefix}.html")
    report_path = os.path.join(output_dir, f"report_{prefix}.html")

    # Write files — each is guarded individually so one failure doesn't abort others
    try:
        _write_csv(schedule_table, csv_path)
    except Exception as exc:
        errors.append(f"CSV write failed: {exc}")
        csv_path = ""

    try:
        _write_excel(solver_result, info_summary, cost_summary, xlsx_path, mapping_report)
    except Exception as exc:
        errors.append(f"Excel write failed: {exc}")
        xlsx_path = ""

    try:
        _write_gantt_html(schedule_table, gantt_path, warnings)
    except Exception as exc:
        errors.append(f"Gantt HTML write failed: {exc}")
        gantt_path = ""

    try:
        _write_report_html(
            payload, solver_result, mapping_report,
            info_summary, cost_summary, report_path,
        )
    except Exception as exc:
        errors.append(f"Report HTML write failed: {exc}")
        report_path = ""

    info_summary["gantt_chart_path"] = gantt_path

    output_files = {
        "schedule_csv": csv_path,
        "schedule_xlsx": xlsx_path,
        "report_html": report_path,
        "gantt_html": gantt_path,
    }

    return {
        "output_files": output_files,
        "gantt_chart_path": gantt_path,
        "info_summary": info_summary,
        "cost_summary": cost_summary,
        "errors": errors,
        "warnings": warnings,
    }