"""
Semantic column classifier tool.

Maps raw columns to canonical columns using:
- Detected table role (from manufacturing_structure_discovery_tool)
- Column name tokens
- Sample values and data types
- Null percentage and uniqueness ratio
- Value patterns

Does NOT use domain YAML profiles.
"""
from __future__ import annotations

import re
from typing import Any

# ---------------------------------------------------------------------------
# Canonical column aliases by role
# Each entry: canonical_column -> list of raw aliases (normalized match)
# ---------------------------------------------------------------------------

CANONICAL_ALIASES_BY_ROLE: dict[str, dict[str, list[str]]] = {
    "Demand_Orders": {
        "order_id": [
            "order_id", "order_no", "order_number", "orderno", "orderid",
            "sales_order", "sales_order_id", "so_no", "so_number", "so_id",
            "po_number", "po_no", "dispatch_no", "work_order", "wo_no",
        ],
        "product_id": [
            "sku", "sku_code", "sku_id", "product_id", "product_code",
            "item_code", "item_id", "article", "material_code", "part_no",
        ],
        "quantity": [
            "qty", "quantity", "demand_qty", "order_qty", "required_qty",
            "demand_quantity", "order_quantity", "required_quantity",
            "requested_qty", "volume", "units", "amount",
        ],
        "order_date": [
            "order_date", "orderdate", "order_creation_date",
            "created_date", "creation_date",
        ],
        "due_date": [
            "due_date", "due_dt", "duedate", "due",
            "promise_date", "promisedate", "delivery_date", "deliverydate",
            "ship_date", "shipdate", "required_date", "deadline",
            "customer_due_date", "need_date",
        ],
        "priority_class": [
            "priority", "priority_class", "priority_label",
            "urgency", "order_priority", "priority_level",
        ],
        "priority_weight": [
            "priority_weight", "weight", "importance",
        ],
        "late_penalty_per_unit_per_day": [
            "late_penalty", "penalty", "tardiness_penalty",
            "late_penalty_per_unit_per_day", "lateness_penalty",
        ],
        "customer_id": [
            "customer_id", "customer", "client_id", "client", "account_id",
        ],
    },
    "SKU_Master": {
        "product_id": [
            "sku", "sku_code", "sku_id", "product_id", "product_code",
            "item_code", "item_id", "article", "material_code",
        ],
        "product_name": [
            "product_name", "sku_name", "item_name", "description",
            "product_description", "item_description",
        ],
        "product_family": [
            "product_family", "family", "category", "product_category",
            "cleaning_family", "group", "product_group",
        ],
        "batch_size": [
            "batch_size", "standard_batch", "default_batch", "lot_size",
        ],
        "min_batch_size": [
            "min_batch_size", "min_batch", "minimum_batch", "min_batch_qty",
        ],
        "max_batch_size": [
            "max_batch_size", "max_batch", "maximum_batch", "max_batch_qty",
        ],
        "batch_multiple": [
            "batch_multiple", "increment", "batch_increment",
        ],
        "holding_cost_per_unit_per_day": [
            "holding_cost", "holding_cost_per_unit_per_day",
            "inventory_cost", "storage_cost",
        ],
        "selling_price_per_unit": [
            "selling_price", "selling_price_per_unit", "unit_price", "price",
        ],
        "unit_production_cost": [
            "unit_production_cost", "production_cost", "unit_cost",
            "manufacturing_cost",
        ],
        "shelf_life_days": [
            "shelf_life_days", "shelf_life", "expiry_days",
        ],
        "shelf_life_hours": [
            "shelf_life_hours",
        ],
        "qa_release_hours": [
            "qa_release_hours", "qa_release", "qc_release",
            "release_time", "hold_time", "qc_hold_hours",
        ],
    },
    "Routing": {
        "product_id": [
            "sku", "sku_code", "sku_id", "product_id", "product_code", "item_code",
        ],
        "operation_id": [
            "operation_id", "op_id", "step_id", "operation_code", "op_code",
        ],
        "operation_name": [
            "operation_name", "op_name", "step_name", "process_name",
            "operation_description",
        ],
        "operation_family": [
            "operation_family", "op_type", "operation_type", "process_type",
        ],
        "stage_sequence": [
            "stage_sequence", "sequence", "seq", "step_no", "step_number",
            "operation_seq", "operation_sequence", "op_seq", "stage", "step",
        ],
        "machine_type": [
            "machine_type", "machine_group", "resource_type", "equipment_type",
            "workcenter_type",
        ],
        "eligible_machines": [
            "eligible_machines", "machine_ids", "compatible_machines",
            "eligible_lines", "machines",
        ],
        "runtime_minutes_per_batch": [
            "runtime_minutes_per_batch", "runtime_min_per_batch",
            "run_min", "run_minutes", "run_min_per_batch",
            "runtime", "runtime_minutes", "run_time_min",
            "process_time", "process_time_min", "process_time_minutes",
            "duration", "duration_min", "duration_minutes",
            "cycle_time", "cycle_time_min",
            "operation_time", "operation_time_min",
        ],
        "batch_capacity": [
            "batch_capacity", "batch_qty", "lot_size", "units_per_run",
        ],
        "min_wait_minutes": [
            "min_wait_minutes", "min_wait", "minimum_wait",
        ],
        "max_wait_minutes": [
            "max_wait_minutes", "max_wait", "maximum_wait",
        ],
    },
    "Machine_Master": {
        "machine_id": [
            "machine_id", "resource_id", "equipment_id", "workcenter_id",
            "machine_code", "resource_code",
        ],
        "machine_name": [
            "machine_name", "equipment_name", "resource_name", "line_name",
        ],
        "machine_type": [
            "machine_type", "machine_group", "resource_type", "equipment_type",
            "resource_group", "equipment_group", "line_group",
        ],
        "capacity": [
            "capacity", "parallel_capacity", "lanes", "units",
        ],
        "hourly_cost": [
            "hourly_cost", "hourly_run_cost", "cost_per_hour",
            "machine_rate", "run_cost_per_hour", "rate",
        ],
    },
    "BOM": {
        "product_id": [
            "product_id", "sku", "sku_code", "finished_good", "parent",
            "parent_sku", "item_id",
        ],
        "component_id": [
            "component_id", "material_id", "ingredient", "raw_material",
            "component_code", "material_code",
        ],
        "quantity_required": [
            "quantity_required", "qty_per_batch", "required_qty",
            "amount", "quantity", "qty",
        ],
        "unit": [
            "unit", "uom", "unit_of_measure", "measure",
        ],
    },
    "Inventory": {
        "item_id": [
            "item_id", "material_id", "sku", "component_id", "sku_id",
        ],
        "opening_inventory": [
            "opening_inventory", "opening_stock", "on_hand",
            "quantity_on_hand", "current_stock", "available_qty",
            "opening_finished_goods",
        ],
        "safety_stock": [
            "safety_stock", "safety_stock_qty", "minimum_stock", "reorder_level",
        ],
        "unit": [
            "unit", "uom", "unit_of_measure",
        ],
    },
    "Machine_Calendar": {
        "machine_id": [
            "machine_id", "resource_id", "equipment_id",
        ],
        "start": [
            "start", "start_time", "from", "window_start", "shift_start",
            "shift_start_time",
        ],
        "end": [
            "end", "end_time", "to", "window_end", "shift_end", "shift_end_time",
        ],
        "work_date": [
            "work_date", "calendar_date", "shift_date", "calendar_day", "work_day",
            "date",
        ],
        "available": [
            "available", "is_available", "flag", "is_working_day",
            "working_day", "availability_flag",
        ],
        "available_minutes": [
            "available_minutes", "available_min", "shift_duration_min",
            "regular_available_min", "base_available_min_per_shift",
        ],
    },
    "Setup_Changeover": {
        "from_family": [
            "from_family", "from_product", "from_sku", "from_state",
            "from_grade", "from_color", "from_cleaning_family", "from_group",
            "source_family", "product_from",
        ],
        "to_family": [
            "to_family", "to_product", "to_sku", "to_state",
            "to_grade", "to_color", "to_cleaning_family", "to_group",
            "target_family", "product_to",
        ],
        "setup_minutes": [
            "setup_minutes", "setup_time", "setup_min",
            "changeover_minutes", "changeover_min", "changeover_time",
        ],
        "setup_cost": [
            "setup_cost", "changeover_cost",
        ],
        "cleaning_minutes": [
            "cleaning_minutes", "cleaning_time", "cleaning_min",
            "wash_time",
        ],
        "cleaning_cost": [
            "cleaning_cost",
        ],
        "hard": [
            "hard", "is_hard", "mandatory", "required",
        ],
    },
    "Maintenance": {
        "machine_id": [
            "machine_id", "resource_id", "equipment_id",
        ],
        "start": [
            "start", "start_time", "downtime_start", "maintenance_start", "from",
        ],
        "end": [
            "end", "end_time", "downtime_end", "maintenance_end", "to",
        ],
        "reason": [
            "reason", "description", "type", "downtime_reason", "maintenance_type",
        ],
    },
    "Labor_Shifts": {
        "shift_id": [
            "shift_id", "shift_name", "shift",
        ],
        "skill": [
            "skill", "skill_type", "operator_type", "crew_type",
        ],
        "available_count": [
            "available_count", "capacity", "headcount", "operators",
        ],
        "start": [
            "start", "shift_start", "start_time",
        ],
        "end": [
            "end", "shift_end", "end_time",
        ],
    },
    "Cost_Parameters": {
        "parameter_name": [
            "parameter_name", "name", "cost_name", "parameter",
        ],
        "parameter_value": [
            "parameter_value", "value", "cost_value",
        ],
        "unit": [
            "unit", "uom",
        ],
    },
    "Business_Rules": {
        "rule_id": [
            "rule_id", "rule_no", "rule_number",
        ],
        "rule_type": [
            "rule_type", "type", "constraint_type",
        ],
        "rule_text": [
            "rule_text", "description", "constraint", "rule_description",
        ],
        "constraint_area": [
            "constraint_area", "area", "category",
        ],
        "hard": [
            "hard", "is_hard", "mandatory", "required",
        ],
    },
    "Material_Receipts": {
        "item_id": [
            "item_id", "material_id", "sku", "component",
        ],
        "receipt_date": [
            "receipt_date", "arrival_date", "delivery_date", "expected_date",
        ],
        "receipt_qty": [
            "receipt_qty", "quantity", "qty", "incoming_qty",
        ],
        "unit": [
            "unit", "uom",
        ],
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize_alias(text: str) -> str:
    """Lowercase, underscore-normalize for alias matching."""
    t = str(text).lower().strip()
    t = re.sub(r"([a-z])([A-Z])", r"\1_\2", t)  # camelCase
    t = re.sub(r"[\s\-]+", "_", t)
    t = re.sub(r"[^a-z0-9_]", "", t)
    return t


def _tokenize(text: str) -> set[str]:
    t = str(text)
    t = re.sub(r"([a-z])([A-Z])", r"\1 \2", t)
    t = t.lower()
    return set(re.sub(r"[^a-z0-9]+", " ", t).split())


def compute_null_ratio(col_name: str, sample_rows: list[dict]) -> float:
    """Fraction of sample rows where the column is null/empty."""
    if not sample_rows:
        return 0.0
    null_count = sum(
        1 for row in sample_rows
        if row.get(col_name) is None or str(row.get(col_name, "")).strip() in ("", "nan", "None")
    )
    return null_count / len(sample_rows)


def compute_uniqueness_ratio(col_name: str, sample_rows: list[dict]) -> float:
    """Fraction of unique values among non-null sample values."""
    vals = [row.get(col_name) for row in sample_rows if row.get(col_name) is not None]
    if not vals:
        return 0.0
    return len(set(str(v) for v in vals)) / len(vals)


def _is_date_like_values(values: list) -> bool:
    _DATE_PAT = re.compile(
        r"\d{4}[-/]\d{1,2}[-/]\d{1,2}"
        r"|\d{1,2}[-/]\d{1,2}[-/]\d{4}"
        r"|\d{4}-\d{2}-\d{2}T\d{2}"
    )
    non_null = [v for v in values if v is not None]
    if not non_null:
        return False
    hits = sum(1 for v in non_null if _DATE_PAT.search(str(v)))
    return (hits / len(non_null)) >= 0.5


def _is_numeric_like_values(values: list) -> bool:
    non_null = [v for v in values if v is not None]
    if not non_null:
        return False
    hits = 0
    for v in non_null:
        try:
            float(str(v).replace(",", ""))
            hits += 1
        except (ValueError, TypeError):
            pass
    return (hits / len(non_null)) >= 0.5


def _is_comma_list_values(values: list) -> bool:
    """Check if values are comma-separated lists (e.g., 'M1,M2,M3')."""
    non_null = [v for v in values if v is not None]
    if not non_null:
        return False
    hits = sum(1 for v in non_null if "," in str(v))
    return (hits / len(non_null)) >= 0.4


# ---------------------------------------------------------------------------
# Column classification per role
# ---------------------------------------------------------------------------

def detect_column_semantics(
    role: str, col_name: str, values: list
) -> tuple[str | None, float, list[str]]:
    """
    Classify a single column into its canonical name for a given role.

    Returns (canonical_column or None, confidence, evidence_list).
    """
    aliases = CANONICAL_ALIASES_BY_ROLE.get(role, {})
    if not aliases:
        return None, 0.0, []

    norm = _normalize_alias(col_name)
    col_tokens = _tokenize(col_name)
    clean = re.sub(r"[^a-z0-9]", "", col_name.lower())

    best_canon: str | None = None
    best_conf = 0.0
    best_ev: list[str] = []

    for canon, alias_list in aliases.items():
        for alias in alias_list:
            norm_alias = _normalize_alias(alias)

            # 1. Exact match
            if norm == norm_alias:
                return canon, 1.0, [f"exact alias match: '{alias}'"]

            # 2. Token exact match
            alias_tokens = _tokenize(alias)
            if col_tokens == alias_tokens and col_tokens:
                return canon, 0.97, [f"token-exact match: '{alias}'"]

            # 3. Substring (alias in col or col in alias) for aliases ≥4 chars
            if len(norm_alias) >= 4:
                if norm_alias in norm or norm in norm_alias:
                    conf = 0.87
                    if conf > best_conf:
                        best_conf = conf
                        best_canon = canon
                        best_ev = [f"substring match with alias '{alias}'"]

            # 4. Significant token overlap
            if alias_tokens and col_tokens:
                overlap = len(col_tokens & alias_tokens) / len(alias_tokens)
                if overlap >= 0.6:
                    conf = round(0.70 + overlap * 0.15, 4)
                    if conf > best_conf:
                        best_conf = conf
                        best_canon = canon
                        best_ev = [f"token overlap ({overlap:.0%}) with alias '{alias}'"]

    if best_canon is None or best_conf < 0.60:
        return None, 0.0, []

    # Boost based on sample value type confirming the expected semantic
    if best_canon in ("due_date", "order_date", "receipt_date", "start", "end", "work_date"):
        if _is_date_like_values(values):
            best_conf = min(1.0, best_conf + 0.05)
            best_ev.append("date-like values confirm date column")

    elif best_canon in ("quantity", "runtime_minutes_per_batch", "capacity",
                        "setup_minutes", "cleaning_minutes", "opening_inventory",
                        "safety_stock", "qty_per_batch", "quantity_required",
                        "available_minutes", "receipt_qty", "hourly_cost",
                        "holding_cost_per_unit_per_day", "selling_price_per_unit",
                        "unit_production_cost", "batch_size", "min_batch_size",
                        "max_batch_size", "batch_capacity"):
        if _is_numeric_like_values(values):
            best_conf = min(1.0, best_conf + 0.05)
            best_ev.append("numeric values confirm numeric column")

    elif best_canon == "eligible_machines":
        if _is_comma_list_values(values):
            best_conf = min(1.0, best_conf + 0.05)
            best_ev.append("comma-separated values confirm eligible_machines list")

    return best_canon, round(best_conf, 4), best_ev


def classify_column_for_role(
    role: str, column_name: str, sample_values: list
) -> tuple[str | None, float, list[str]]:
    """Public interface: classify one column for a given role."""
    return detect_column_semantics(role, column_name, sample_values)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def classify_columns_semantically(
    workbook_profile: dict,
    selected_sheet_mapping: dict[str, str],
) -> dict:
    """
    Classify raw columns to canonical columns for each mapped sheet.

    Input:
        workbook_profile: output of workbook_reader_tool.read_workbook()
        selected_sheet_mapping: {raw_sheet_name: canonical_role}

    Output: {
        "column_mapping": {sheet: {raw_col: canonical_col}},
        "column_mapping_report": {sheet: {raw_col: {canonical_column, confidence, evidence}}},
        "ambiguous_columns": [{sheet, column, candidates}],
        "errors": [...],
        "warnings": [...]
    }
    """
    errors: list[str] = []
    warnings: list[str] = []
    column_mapping: dict[str, dict[str, str]] = {}
    column_mapping_report: dict[str, dict[str, Any]] = {}
    ambiguous_columns: list[dict] = []

    sheets_data: dict = workbook_profile.get("sheets", {})

    for raw_sheet, role in selected_sheet_mapping.items():
        sheet_data = sheets_data.get(raw_sheet)
        if sheet_data is None:
            warnings.append(f"Sheet '{raw_sheet}' not found in workbook_profile.")
            continue

        raw_columns: list[str] = sheet_data.get("columns", [])
        sample_rows: list[dict] = sheet_data.get("sample_rows", [])

        column_mapping[raw_sheet] = {}
        column_mapping_report[raw_sheet] = {}

        # Detect potential conflicts: same canonical col claimed by multiple raw cols
        canon_to_cols: dict[str, list[str]] = {}

        for col in raw_columns:
            vals = [row.get(col) for row in sample_rows if row.get(col) is not None]
            canon, conf, evidence = detect_column_semantics(role, col, vals)

            column_mapping_report[raw_sheet][col] = {
                "canonical_column": canon,
                "confidence": conf,
                "evidence": evidence,
            }

            if canon is not None and conf >= 0.85:
                column_mapping[raw_sheet][col] = canon
                canon_to_cols.setdefault(canon, []).append(col)
            elif canon is not None and conf >= 0.60:
                column_mapping[raw_sheet][col] = canon
                canon_to_cols.setdefault(canon, []).append(col)
                warnings.append(
                    f"Sheet '{raw_sheet}', column '{col}' → '{canon}' "
                    f"with low confidence ({conf:.2f}). Review recommended."
                )
            else:
                ambiguous_columns.append({
                    "sheet": raw_sheet,
                    "column": col,
                    "best_candidate": canon,
                    "confidence": conf,
                })

        # Warn about conflicts (two raw cols mapping to same canonical)
        for canon_col, raw_list in canon_to_cols.items():
            if len(raw_list) > 1:
                warnings.append(
                    f"Sheet '{raw_sheet}': multiple columns map to '{canon_col}': "
                    f"{raw_list}. Keeping first: '{raw_list[0]}'."
                )
                # Keep only first
                for dup in raw_list[1:]:
                    column_mapping[raw_sheet].pop(dup, None)
                    if raw_sheet in column_mapping_report and dup in column_mapping_report[raw_sheet]:
                        column_mapping_report[raw_sheet][dup]["canonical_column"] = None
                        column_mapping_report[raw_sheet][dup]["confidence"] = 0.0

    return {
        "column_mapping": column_mapping,
        "column_mapping_report": column_mapping_report,
        "ambiguous_columns": ambiguous_columns,
        "errors": errors,
        "warnings": warnings,
    }
