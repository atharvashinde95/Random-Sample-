from __future__ import annotations

import math
from datetime import datetime, timedelta
from typing import Any

from ortools.sat.python import cp_model

from tools.cp_sat_model_builder_tool import build_cp_sat_model, _parse_dt

_STATUS_MAP = {
    cp_model.OPTIMAL: "OPTIMAL",
    cp_model.FEASIBLE: "FEASIBLE",
    cp_model.INFEASIBLE: "INFEASIBLE",
    cp_model.MODEL_INVALID: "MODEL_INVALID",
    cp_model.UNKNOWN: "UNKNOWN",
}

_STATUS_EXPLANATION: dict[str, str] = {
    "OPTIMAL": "Globally optimal schedule found.",
    "FEASIBLE": (
        "Valid feasible schedule found; global optimality was not proven "
        "within the configured time limit."
    ),
    "INFEASIBLE": "No valid schedule exists under the current constraints.",
    "MODEL_INVALID": "Input or model validation failed before solving.",
    "UNKNOWN": "Solver stopped before proving feasibility or optimality.",
    "ERROR": "An internal error occurred during scheduling.",
    "POST_SOLVE_INVALID": "A schedule was found but failed post-solve constraint checks.",
}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _minutes_to_dt(minutes: int, reference: datetime) -> datetime:
    return reference + timedelta(minutes=minutes)


def _compute_job_completion_summary(
    payload: dict,
    schedule_table: list[dict],
) -> dict:
    """
    Compute job-level completion times and tardiness.

    Each job is late only when its FINAL operation completes after due_at.
    This avoids over-counting tardiness across operations of the same job.

    Returns:
      {
        "job_completion_table":            [per-job dict],
        "late_orders":                     [per-late-job dict],
        "job_level_total_tardiness_minutes": int,
        "num_late_orders":                 int,
      }
    """
    jobs_map: dict[str, dict] = {j["job_id"]: j for j in payload.get("jobs", [])}

    # Group schedule rows by job
    job_tasks: dict[str, list[dict]] = {}
    for task in schedule_table:
        jid = task.get("job_id")
        if jid:
            job_tasks.setdefault(jid, []).append(task)

    job_completion_table: list[dict] = []
    late_orders: list[dict] = []
    total_tardiness = 0
    num_late = 0

    for jid, job in jobs_map.items():
        tasks = job_tasks.get(jid)
        if not tasks:
            continue  # unscheduled — handled separately

        starts = [datetime.fromisoformat(t["start"]) for t in tasks]
        ends = [datetime.fromisoformat(t["end"]) for t in tasks]
        due_dt = _parse_dt(job.get("due_at"))

        final_start = min(starts)
        final_completion = max(ends)

        tardiness_minutes = max(
            0, int((final_completion - due_dt).total_seconds() // 60)
        )
        early_minutes = (
            max(0, int((due_dt - final_completion).total_seconds() // 60))
            if final_completion < due_dt
            else 0
        )
        is_late = tardiness_minutes > 0

        entry = {
            "job_id": jid,
            "order_id": job.get("order_id", jid),
            "product_id": job.get("product_id", ""),
            "product_family": job.get("product_family"),
            "quantity": job.get("quantity", 0),
            "priority_class": job.get("priority_class", "MEDIUM"),
            "priority_weight": job.get("priority_weight", 1.0),
            "start": final_start.isoformat(),
            "completion_at": final_completion.isoformat(),
            "due_at": due_dt.isoformat(),
            "is_late": is_late,
            "tardiness_minutes": tardiness_minutes,
            "early_minutes": early_minutes,
            # late_penalty_per_minute is a job-level rupee penalty per minute,
            # derived in the payload builder as:
            #   late_penalty_per_unit_per_day * quantity / 1440
            "late_penalty_per_minute": float(job.get("late_penalty_per_minute") or 0.0),
            "holding_cost_per_minute": float(job.get("holding_cost_per_minute") or 0.0),
        }
        job_completion_table.append(entry)

        if is_late:
            late_orders.append({
                "job_id": jid,
                "order_id": job.get("order_id", jid),
                "product_id": job.get("product_id", ""),
                "tardiness_minutes": tardiness_minutes,
                "due_at": due_dt.isoformat(),
                "completion_at": final_completion.isoformat(),
            })
            num_late += 1

        total_tardiness += tardiness_minutes

    return {
        "job_completion_table": job_completion_table,
        "late_orders": late_orders,
        "job_level_total_tardiness_minutes": total_tardiness,
        "num_late_orders": num_late,
    }


def _transition_matches(
    rule: dict,
    machine_id: str,
    machine_type: str,
    from_fam: str,
    to_fam: str,
) -> bool:
    """True if a setup/cleaning rule applies to this (from_fam → to_fam) transition."""
    if rule.get("from_family") != from_fam or rule.get("to_family") != to_fam:
        return False
    rule_mid = rule.get("machine_id")
    rule_mtype = rule.get("machine_type")
    if rule_mid:
        return rule_mid == machine_id
    if rule_mtype:
        return rule_mtype == machine_type
    return True  # rule applies to all machines


def _compute_business_cost_summary(
    payload: dict,
    schedule_table: list[dict],
    job_completion_table: list[dict],
    objective_value: float | None,
    unscheduled: list[dict],
) -> dict:
    """
    Compute deterministic business cost from the solved schedule.

    Cost formula:
    - Tardiness cost:  tardiness_minutes * late_penalty_per_minute (job-level)
    - Holding cost:    early_minutes * holding_cost_per_minute (job-level)
    - Machine cost:    (duration_minutes / 60) * machine.hourly_cost per operation
    - Setup/cleaning:  matched rule costs for consecutive family transitions per machine

    late_penalty_per_minute is treated as a job-level rupee penalty per minute.
    priority_weight is NOT applied to rupee cost (it is a scheduling preference only).
    """
    machines_map: dict[str, dict] = {
        m["machine_id"]: m for m in payload.get("machines", [])
    }
    setup_rules: list[dict] = payload.get("setup_rules", [])
    cleaning_rules: list[dict] = payload.get("cleaning_rules", [])
    notes: list[str] = []

    # A. Job-level tardiness cost
    total_tardiness_cost = sum(
        jct["tardiness_minutes"] * jct["late_penalty_per_minute"]
        for jct in job_completion_table
        if jct["is_late"]
    )

    # B. Holding cost (early completion only)
    total_holding_cost = sum(
        jct["early_minutes"] * jct["holding_cost_per_minute"]
        for jct in job_completion_table
        if not jct["is_late"] and jct["early_minutes"] > 0
    )

    # C. Machine running cost
    total_machine_cost = 0.0
    any_machine_zero_cost = False
    for task in schedule_table:
        mid = task.get("machine_id")
        machine = machines_map.get(mid, {})
        hourly_cost = float(machine.get("hourly_cost") or 0.0)
        if mid and mid in machines_map and hourly_cost == 0.0:
            any_machine_zero_cost = True
        dur_min = int(task.get("duration_minutes") or 0)
        total_machine_cost += (dur_min / 60.0) * hourly_cost
    if any_machine_zero_cost:
        notes.append(
            "One or more machines have hourly_cost=0; machine running cost may be understated."
        )

    # D. Setup / cleaning cost from actual scheduled sequence per machine
    # Families are matched using operation_family, consistent with the CP-SAT model.
    total_setup_cleaning_cost = 0.0
    machine_tasks: dict[str, list[dict]] = {}
    for task in schedule_table:
        mid = task.get("machine_id")
        if mid:
            machine_tasks.setdefault(mid, []).append(task)

    for mid, tasks in machine_tasks.items():
        tasks_sorted = sorted(tasks, key=lambda t: t["start"])
        mtype = machines_map.get(mid, {}).get("machine_type", "")
        for i in range(len(tasks_sorted) - 1):
            prev = tasks_sorted[i]
            curr = tasks_sorted[i + 1]
            from_fam = prev.get("operation_family", "")
            to_fam = curr.get("operation_family", "")
            if not from_fam or not to_fam:
                continue
            for rule in setup_rules:
                if _transition_matches(rule, mid, mtype, from_fam, to_fam):
                    total_setup_cleaning_cost += float(rule.get("setup_cost") or 0.0)
                    break
            for rule in cleaning_rules:
                if _transition_matches(rule, mid, mtype, from_fam, to_fam):
                    total_setup_cleaning_cost += float(rule.get("cleaning_cost") or 0.0)
                    break

    # E. Revenue and production cost from scheduled jobs
    jobs_map = {j["job_id"]: j for j in payload.get("jobs", [])}
    scheduled_job_ids = {t.get("job_id") for t in schedule_table}
    estimated_revenue = 0.0
    estimated_production_cost = 0.0
    for jid in scheduled_job_ids:
        job = jobs_map.get(jid, {})
        qty = float(job.get("quantity") or 0)
        estimated_revenue += qty * float(job.get("selling_price_per_unit") or 0.0)
        estimated_production_cost += qty * float(job.get("unit_production_cost") or 0.0)

    # F. Totals
    total_business_cost = (
        total_tardiness_cost
        + total_holding_cost
        + total_machine_cost
        + total_setup_cleaning_cost
    )
    estimated_profit = estimated_revenue - estimated_production_cost - total_business_cost

    job_level_tardiness = sum(jct["tardiness_minutes"] for jct in job_completion_table)
    op_row_tardiness = sum(t.get("tardiness_minutes", 0) for t in schedule_table)

    return {
        "solver_objective_score": objective_value,
        "objective_value": objective_value,            # backward-compat alias
        "total_tardiness_minutes": job_level_tardiness,
        "operation_row_tardiness_minutes": op_row_tardiness,
        "num_late_orders": sum(1 for jct in job_completion_table if jct["is_late"]),
        "num_unscheduled": len(unscheduled),
        "total_tardiness_cost": round(total_tardiness_cost, 2),
        "total_holding_cost": round(total_holding_cost, 2),
        "total_machine_cost": round(total_machine_cost, 2),
        "total_setup_cleaning_cost": round(total_setup_cleaning_cost, 2),
        "total_business_cost": round(total_business_cost, 2),
        "total_cost": round(total_business_cost, 2),   # backward-compat alias
        "estimated_revenue": round(estimated_revenue, 2),
        "estimated_production_cost": round(estimated_production_cost, 2),
        "estimated_profit": round(estimated_profit, 2),
        "cost_summary_computed": True,
        "cost_summary_notes": notes,
    }


def _empty_result() -> dict:
    return {
        "solver_status": "UNKNOWN",
        "objective_value": None,
        "schedule_table": [],
        "late_orders": [],
        "unscheduled_orders": [],
        "machine_utilization": [],
        "bottlenecks": [],
        "cost_summary": {
            "solver_objective_score": None,
            "objective_value": None,
            "total_tardiness_minutes": 0,
            "num_late_orders": 0,
            "num_unscheduled": 0,
            "cost_summary_computed": False,
        },
        "info_summary": {},
        "solver_debug": {},
        "post_solve_validation_report": {},
        "errors": [],
        "warnings": [],
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def solve_cp_sat(
    payload: dict,
    solve_config: dict | None = None,
) -> dict:
    """
    Build and solve a CP-SAT model from a canonical SolverPayload dict.

    Uses payload["reference_time"] as time-zero. Never calls datetime.now().
    Returns job-level tardiness and a fully computed business cost summary.
    """
    errors: list[str] = []
    warnings: list[str] = []
    cfg = solve_config or {}

    # SOLVER CONFIGURATION — large industrial JSP (200+ jobs, 1500+ ops):
    #
    # num_search_workers=4:  CP-SAT needs multiple workers to find the first
    #   feasible solution within the time budget.  A single worker cannot
    #   traverse the search space fast enough for problems of this size.
    #   4 workers is the minimum for reliable FEASIBLE results; 8 increases
    #   variance.  4 is the best balance of speed and consistency.
    #
    # random_seed=42:  Each worker is seeded deterministically from this base
    #   seed, which stabilises results run-over-run far more than no seed.
    #
    # relative_gap_limit=0.02:  Once the solver proves it is within 2% of
    #   the true optimum it stops immediately, so runs that find a good
    #   solution early don't waste time on marginal improvements that shift
    #   the objective value (and therefore the reported profit) between runs.
    #
    # CP-SAT multi-worker search is NOT bit-for-bit deterministic even with a
    # fixed seed (workers communicate bounds asynchronously).  The gap limit
    # ensures all runs converge to within ±2% of each other.
    _defaults = {
        "max_time_seconds":    300,   # 5 min; sufficient with 4 workers
        "random_seed":         42,
        "num_search_workers":  4,     # minimum for feasibility on large problems
        "relative_gap_limit":  0.02,  # stop within 2% of proven optimal
        "absolute_gap_limit":  None,
        "log_search_progress": False,
    }
    _defaults.update(solve_config or {})
    cfg = _defaults

    # Build model
    build_result = build_cp_sat_model(payload, cfg)
    if build_result.get("model") is None:
        return {
            **_empty_result(),
            "solver_status": "MODEL_INVALID",
            "errors": errors + build_result.get("errors", []),
            "warnings": warnings + build_result.get("warnings", []),
            "solver_debug": build_result.get("debug", {}),
        }

    errors.extend(build_result.get("errors", []))
    warnings.extend(build_result.get("warnings", []))

    model: cp_model.CpModel = build_result["model"]
    job_vars: dict = build_result["vars"]
    horizon_minutes: int = build_result["horizon_minutes"]
    reference: datetime = build_result["reference"]
    job_order: list[str] = build_result["job_order"]

    # Solve
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = float(cfg["max_time_seconds"])
    _seed = int(cfg["random_seed"])
    if _seed:
        solver.parameters.random_seed = _seed
    solver.parameters.num_workers = int(cfg["num_search_workers"])
    solver.parameters.log_search_progress = bool(cfg["log_search_progress"])
    # Gap tolerance: stop as soon as the solver proves it is within X% of optimal.
    # This avoids burning the full time budget once quality is good enough.
    if cfg.get("relative_gap_limit") is not None:
        solver.parameters.relative_gap_limit = float(cfg["relative_gap_limit"])
    if cfg.get("absolute_gap_limit") is not None:
        solver.parameters.absolute_gap_limit = float(cfg["absolute_gap_limit"])

    status_int = solver.Solve(model)
    status_str = _STATUS_MAP.get(status_int, "UNKNOWN")

    if status_int not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return {
            **_empty_result(),
            "solver_status": status_str,
            "errors": errors,
            "warnings": warnings,
            "solver_debug": {
                "status_int": status_int,
                "wall_time": solver.WallTime(),
                "num_branches": solver.NumBranches(),
                "num_conflicts": solver.NumConflicts(),
            },
        }

    obj_value: float | None = None
    try:
        obj_value = float(solver.ObjectiveValue())
    except Exception:
        pass

    best_bound: float | None = None
    try:
        best_bound = float(solver.BestObjectiveBound())
    except Exception:
        pass

    # Optimality gap: how far is the best feasible solution from proven optimal?
    # 0% = OPTIMAL. >0% = solver stopped before proof (time or gap limit).
    gap_pct: float | None = None
    if obj_value is not None and best_bound is not None and abs(obj_value) > 1e-9:
        gap_pct = round(abs(obj_value - best_bound) / abs(obj_value) * 100.0, 2)

    # -----------------------------------------------------------------------
    # Extract operation-level schedule
    # -----------------------------------------------------------------------
    jobs_map: dict[str, dict] = {j["job_id"]: j for j in payload.get("jobs", [])}
    machines_map: dict[str, dict] = {
        m["machine_id"]: m for m in payload.get("machines", [])
    }

    schedule_table: list[dict] = []
    unscheduled: list[dict] = []
    scheduled_job_ids: set[str] = set()

    for job_id in job_order:
        op_map = job_vars.get(job_id)
        if not op_map:
            unscheduled.append({"job_id": job_id, "reason": "no variables built"})
            continue

        job = jobs_map.get(job_id, {})
        job_scheduled = True

        for op_idx, ov in sorted(op_map.items()):
            op = ov["op"]
            s_min = solver.Value(ov["start"])
            e_min = solver.Value(ov["end"])
            assigned_machine: str | None = None
            for mid, b_var in ov["machine_assignments"].items():
                if solver.Value(b_var) == 1:
                    assigned_machine = mid
                    break

            if assigned_machine is None:
                job_scheduled = False
                warnings.append(
                    f"Job {job_id} op {op.get('op_id')}: no machine assigned in solution."
                )
                continue

            start_dt = _minutes_to_dt(s_min, reference)
            end_dt = _minutes_to_dt(e_min, reference)
            due_dt = _parse_dt(job.get("due_at", reference.isoformat()))
            is_late = end_dt > due_dt
            # operation-level tardiness — kept for Gantt hover/diagnostic use only.
            # Use job_level_total_tardiness_minutes from cost_summary for KPI reporting.
            op_tardiness = max(0, int((end_dt - due_dt).total_seconds() // 60)) if is_late else 0

            schedule_table.append({
                "job_id": job_id,
                "order_id": job.get("order_id", job_id),
                "product_id": job.get("product_id", ""),
                "product_family": job.get("product_family"),
                "operation_id": op.get("op_id", f"{job_id}_op{op_idx}"),
                "operation_family": op.get("operation_family", ""),
                "machine_id": assigned_machine,
                "start": start_dt.isoformat(),
                "end": end_dt.isoformat(),
                "duration_minutes": int(op.get("duration_minutes", 0)),
                "due_at": due_dt.isoformat(),
                "is_late": is_late,
                "tardiness_minutes": op_tardiness,           # operation-level
                "operation_row_tardiness_minutes": op_tardiness,  # explicit alias
                "priority_class": job.get("priority_class", "MEDIUM"),
            })

        if job_scheduled:
            scheduled_job_ids.add(job_id)
        else:
            unscheduled.append({"job_id": job_id, "reason": "partial machine assignment"})

    # -----------------------------------------------------------------------
    # Job-level completion summary (fixes tardiness over-counting)
    # -----------------------------------------------------------------------
    job_summary = _compute_job_completion_summary(payload, schedule_table)
    late_orders = job_summary["late_orders"]          # one entry per late job
    job_level_tardiness = job_summary["job_level_total_tardiness_minutes"]

    # -----------------------------------------------------------------------
    # Machine utilization
    # -----------------------------------------------------------------------
    machine_busy: dict[str, int] = {mid: 0 for mid in machines_map}
    for task in schedule_table:
        mid = task["machine_id"]
        machine_busy[mid] = machine_busy.get(mid, 0) + task["duration_minutes"]

    machine_utilization: list[dict] = []
    for mid, m in machines_map.items():
        busy = machine_busy.get(mid, 0)
        util_pct = round(100.0 * busy / horizon_minutes, 2) if horizon_minutes > 0 else 0.0
        machine_utilization.append({
            "machine_id": mid,
            "machine_name": m.get("machine_name") or mid,
            "busy_minutes": busy,
            "horizon_minutes": horizon_minutes,
            "utilization_pct": util_pct,
        })

    bottlenecks = sorted(
        [m for m in machine_utilization if m["utilization_pct"] >= 80.0],
        key=lambda x: x["utilization_pct"],
        reverse=True,
    )

    # -----------------------------------------------------------------------
    # Business cost summary (deterministic, no fake zeros)
    # -----------------------------------------------------------------------
    cost_summary = _compute_business_cost_summary(
        payload, schedule_table,
        job_summary["job_completion_table"],
        obj_value,
        unscheduled,
    )

    info_summary: dict[str, Any] = {
        "solver_status": status_str,
        "solver_status_explanation": _STATUS_EXPLANATION.get(status_str, ""),
        "schedule_quality_label": (
            "Globally optimal"
            if status_str == "OPTIMAL"
            else "Feasible valid schedule, not proven globally optimal"
        ),
        "is_globally_optimal": status_str == "OPTIMAL",
        "optimality_gap_pct": gap_pct,
        "best_objective_bound": best_bound,
        "num_scheduled_jobs": len(scheduled_job_ids),
        "num_operations_scheduled": len(schedule_table),
        "reference_time": reference.isoformat(),
        "horizon_minutes": horizon_minutes,
    }

    solver_debug: dict[str, Any] = {
        "status_int": status_int,
        "wall_time": solver.WallTime(),
        "num_branches": solver.NumBranches(),
        "num_conflicts": solver.NumConflicts(),
        "objective_value": obj_value,
        "best_objective_bound": best_bound,
        "optimality_gap_pct": gap_pct,
        "solve_config": {
            "max_time_seconds":   cfg["max_time_seconds"],
            "random_seed":        cfg["random_seed"],
            "num_search_workers": cfg["num_search_workers"],
            "relative_gap_limit": cfg.get("relative_gap_limit"),
        },
        "reproducibility_note": (
            "4 workers + seed=42 + 2% gap tolerance. "
            "Gap limit ensures all runs converge within ±2% of each other. "
            "FEASIBLE = valid schedule found within time+gap budget. "
            "OPTIMAL = proven best possible. "
            "LLM does not affect mapping, constraints, or solver results."
        ),
    }

    return {
        "solver_status": status_str,
        "objective_value": obj_value,
        "schedule_table": schedule_table,
        "late_orders": late_orders,
        "unscheduled_orders": unscheduled,
        "machine_utilization": machine_utilization,
        "bottlenecks": bottlenecks,
        "cost_summary": cost_summary,
        "info_summary": info_summary,
        "solver_debug": solver_debug,
        "post_solve_validation_report": {},
        "errors": errors,
        "warnings": warnings,
    }
