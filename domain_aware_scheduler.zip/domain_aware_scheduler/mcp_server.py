"""
FastMCP server — exposes the deterministic scheduling tools via MCP protocol.

Transport: stdio (default).  Stdout is reserved for JSON-RPC.
All diagnostic logs go to stderr via _log().

Run manually:
    .venv/Scripts/python.exe mcp_server.py

This server is an integration layer only.  The Streamlit + LangGraph
pipeline continues to work via direct Python imports and is unaffected.
"""

import json
import sys
from typing import Any

from fastmcp import FastMCP

# Project-tool imports — DLL noise from OR-Tools goes to stderr, which is
# safe for stdio transport (stdout is reserved for JSON-RPC frames).
from tools.workbook_reader_tool import read_workbook
from tools.schema_detection_tool import detect_sheet_mapping
from tools.column_mapping_tool import detect_column_mapping
from tools.unit_normalization_tool import normalize_tables
from tools.constraint_mapping_tool import map_constraints
from tools.canonical_payload_builder_tool import build_canonical_payload
from tools.canonical_payload_validator_tool import validate_canonical_payload
from tools.cp_sat_solver_tool import solve_cp_sat
from tools.report_gantt_tool import generate_report

# ---------------------------------------------------------------------------
# Server instance
# ---------------------------------------------------------------------------
mcp = FastMCP(
    "domain-aware-production-scheduler",
    instructions=(
        "Deterministic tools for domain-aware production scheduling. "
        "Each tool accepts a JSON-encoded request string and returns a "
        "JSON-encoded result string."
    ),
)

# ---------------------------------------------------------------------------
# Helpers — stdout must never be written to directly
# ---------------------------------------------------------------------------

def _log(message: str) -> None:
    """Diagnostic output to stderr only (never stdout)."""
    print(message, file=sys.stderr, flush=True)


def _loads(request_json: str) -> dict:
    """Parse request_json; returns {'__parse_error__': ...} on failure."""
    try:
        if not request_json:
            return {}
        if isinstance(request_json, dict):
            return request_json
        return json.loads(request_json)
    except Exception as exc:
        return {"__parse_error__": str(exc)}


def _dumps(result: Any) -> str:
    """Serialize to JSON string; safe fallback on serialisation error."""
    try:
        return json.dumps(result, ensure_ascii=False, default=str)
    except Exception as exc:
        return json.dumps(
            {"errors": [f"JSON serialization failed: {exc}"], "warnings": []},
            ensure_ascii=False,
        )


def _error_response(message: str) -> str:
    return _dumps({"errors": [message], "warnings": []})


def _check_parse(req: dict, tool_name: str) -> str | None:
    """Return error-response string when parse failed, otherwise None."""
    if "__parse_error__" in req:
        msg = f"{tool_name}: request parse error — {req['__parse_error__']}"
        _log(msg)
        return _error_response(msg)
    return None


# ---------------------------------------------------------------------------
# MCP tool registrations
# ---------------------------------------------------------------------------

@mcp.tool()
def workbook_reader_tool(request_json: str) -> str:
    """
    Read an Excel or CSV file and return a JSON-serializable workbook profile.

    Request JSON: {"file_path": "...", "sample_size": 5}
    """
    req = _loads(request_json)
    if (err := _check_parse(req, "workbook_reader_tool")):
        return err
    try:
        result = read_workbook(
            file_path=req.get("file_path", ""),
            sample_size=int(req.get("sample_size", 5)),
        )
        return _dumps(result)
    except Exception as exc:
        _log(f"workbook_reader_tool exception: {exc}")
        return _error_response(str(exc))


@mcp.tool()
def schema_detection_tool(request_json: str) -> str:
    """
    Map raw workbook sheet names to canonical sheet roles.

    Request JSON: {"workbook_profile": {...}, "domain_profile": {...}}
    """
    req = _loads(request_json)
    if (err := _check_parse(req, "schema_detection_tool")):
        return err
    try:
        result = detect_sheet_mapping(
            workbook_profile=req.get("workbook_profile", {}),
            domain_profile=req.get("domain_profile"),
        )
        return _dumps(result)
    except Exception as exc:
        _log(f"schema_detection_tool exception: {exc}")
        return _error_response(str(exc))


@mcp.tool()
def column_mapping_tool(request_json: str) -> str:
    """
    Map raw column names to canonical column names per sheet role.

    Request JSON:
    {"workbook_profile": {...}, "sheet_mapping": {...}, "domain_profile": {...}}
    """
    req = _loads(request_json)
    if (err := _check_parse(req, "column_mapping_tool")):
        return err
    try:
        result = detect_column_mapping(
            workbook_profile=req.get("workbook_profile", {}),
            sheet_mapping=req.get("sheet_mapping", {}),
            domain_profile=req.get("domain_profile"),
        )
        return _dumps(result)
    except Exception as exc:
        _log(f"column_mapping_tool exception: {exc}")
        return _error_response(str(exc))


@mcp.tool()
def unit_normalization_tool(request_json: str) -> str:
    """
    Read a file, apply sheet/column mappings, and return normalized table records.

    Request JSON:
    {
      "file_path": "...",
      "sheet_mapping": {...},
      "column_mapping": {...},
      "current_date": "YYYY-MM-DD"
    }
    """
    req = _loads(request_json)
    if (err := _check_parse(req, "unit_normalization_tool")):
        return err
    try:
        result = normalize_tables(
            file_path=req.get("file_path", ""),
            sheet_mapping=req.get("sheet_mapping", {}),
            column_mapping=req.get("column_mapping", {}),
            current_date=req.get("current_date"),
        )
        return _dumps(result)
    except Exception as exc:
        _log(f"unit_normalization_tool exception: {exc}")
        return _error_response(str(exc))


@mcp.tool()
def constraint_mapping_tool(request_json: str) -> str:
    """
    Produce structured constraint rule lists from normalized tables + domain profile.

    Request JSON: {"normalized_tables": {...}, "domain_profile": {...}}
    """
    req = _loads(request_json)
    if (err := _check_parse(req, "constraint_mapping_tool")):
        return err
    try:
        result = map_constraints(
            normalized_tables=req.get("normalized_tables", {}),
            domain_profile=req.get("domain_profile", {}),
        )
        return _dumps(result)
    except Exception as exc:
        _log(f"constraint_mapping_tool exception: {exc}")
        return _error_response(str(exc))


@mcp.tool()
def canonical_payload_builder_tool(request_json: str) -> str:
    """
    Build a SolverPayload-compatible dict from normalized tables and constraints.

    Request JSON:
    {
      "normalized_tables": {...},
      "constraint_rules": {...},
      "domain_result": {...},
      "current_date": "YYYY-MM-DD",
      "reference_date": "YYYY-MM-DD"
    }
    """
    req = _loads(request_json)
    if (err := _check_parse(req, "canonical_payload_builder_tool")):
        return err
    try:
        result = build_canonical_payload(
            normalized_tables=req.get("normalized_tables", {}),
            constraint_rules=req.get("constraint_rules", {}),
            domain_result=req.get("domain_result", {}),
            current_date=req.get("current_date", ""),
            reference_date=req.get("reference_date"),
        )
        return _dumps(result)
    except Exception as exc:
        _log(f"canonical_payload_builder_tool exception: {exc}")
        return _error_response(str(exc))


@mcp.tool()
def canonical_payload_validator_tool(request_json: str) -> str:
    """
    Validate a SolverPayload dict using Pydantic.

    Request JSON: {"payload": {...}}
    """
    req = _loads(request_json)
    if (err := _check_parse(req, "canonical_payload_validator_tool")):
        return err
    try:
        result = validate_canonical_payload(req.get("payload", {}))
        return _dumps(result)
    except Exception as exc:
        _log(f"canonical_payload_validator_tool exception: {exc}")
        return _error_response(str(exc))


@mcp.tool()
def cp_sat_solver_tool(request_json: str) -> str:
    """
    Build and solve a CP-SAT scheduling model from a canonical SolverPayload.
    Returns truthful solver status. No hybrid modes, no greedy fallback.

    Request JSON:
    {
      "payload": {...},
      "solve_config": {"max_time_seconds": 120, "num_workers": 4}
    }
    """
    req = _loads(request_json)
    if (err := _check_parse(req, "cp_sat_solver_tool")):
        return err
    try:
        result = solve_cp_sat(
            payload=req.get("payload", {}),
            solve_config=req.get("solve_config") or {},
        )
        return _dumps(result)
    except Exception as exc:
        _log(f"cp_sat_solver_tool exception: {exc}")
        return _error_response(str(exc))


@mcp.tool()
def report_gantt_generator_tool(request_json: str) -> str:
    """
    Generate schedule.csv, schedule.xlsx, gantt.html, and report.html
    from an existing solved schedule. Never reruns the solver.

    Request JSON:
    {
      "payload": {...},
      "solver_result": {...},
      "mapping_report": {...},
      "output_dir": "outputs"
    }
    """
    req = _loads(request_json)
    if (err := _check_parse(req, "report_gantt_generator_tool")):
        return err
    try:
        result = generate_report(
            payload=req.get("payload", {}),
            solver_result=req.get("solver_result", {}),
            mapping_report=req.get("mapping_report"),
            output_dir=req.get("output_dir", "outputs"),
        )
        return _dumps(result)
    except Exception as exc:
        _log(f"report_gantt_generator_tool exception: {exc}")
        return _error_response(str(exc))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    _log('Starting MCP server "domain-aware-production-scheduler" (stdio transport) ...')
    mcp.run()   # transport=None → resolved to "stdio" inside run_async
