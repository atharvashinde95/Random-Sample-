"""
Build and write the production_scheduling_validation.ipynb notebook from scratch.
Run from: H:/HAS/notebook/  or any directory.
"""
import json


def code_cell(source_lines):
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": source_lines,
    }


def md_cell(source_lines):
    return {
        "cell_type": "markdown",
        "metadata": {},
        "source": source_lines,
    }


# ---------------------------------------------------------------------------
# Cell 0 - Title (markdown)
# ---------------------------------------------------------------------------
cell0 = md_cell([
    "# Production Scheduling Validation\n",
    "\n",
    "Validates whether an uploaded CSV/Excel workbook and a scheduling requirement\n",
    "are ready for a FUTURE CP-SAT solver. This notebook does NOT build or run the solver.\n",
    "\n",
    "| Step | What happens | Type |\n",
    "|------|-------------|------|\n",
    "| 0 | Setup & imports | - |\n",
    "| 1 | Data Profiling | Deterministic |\n",
    "| 2 | LLM Problem Understanding | LLM (1 call) |\n",
    "| 3 | Schema Mapping | LLM (1 call) |\n",
    "| 4 | Readiness Validation | Deterministic |\n",
    "| 5 | Final Summary | Deterministic |\n",
])

# ---------------------------------------------------------------------------
# Cell 1 - Setup & Imports
# ---------------------------------------------------------------------------
cell1 = code_cell([
    "import sys\n",
    "from pathlib import Path\n",
    "import pandas as pd\n",
    "from IPython.display import display, Markdown\n",
    "\n",
    "ROOT = Path('..').resolve()\n",
    "if str(ROOT) not in sys.path:\n",
    "    sys.path.insert(0, str(ROOT))\n",
    "\n",
    "from app.config import (\n",
    "    GROQ_MODEL, DATA_DIR,\n",
    "    SCHEDULING_CONCEPTS, SCHEDULING_RELATIONSHIPS,\n",
    "    CONCEPT_CHECK_REQUIREMENTS,\n",
    ")\n",
    "from app.tools import workbook_tools\n",
    "from app.llm import user_input_understanding\n",
    "from app.agents.schema_mapping_agent import SchemaMappingAgent\n",
    "from app.agents.readiness_validator import ReadinessValidator\n",
    "\n",
    "print(f'Groq model: {GROQ_MODEL}')\n",
    "print('All imports loaded successfully')\n",
])

# ---------------------------------------------------------------------------
# Cell 2 - Configuration
# ---------------------------------------------------------------------------
cell2 = code_cell([
    "# --- Model configuration ---\n",
    "print('Model configuration')\n",
    "print(f'  Model       : {GROQ_MODEL}')\n",
    "print(f'  Provider    : Groq')\n",
    "print(f'  Temperature : 0')\n",
    "print()\n",
    "\n",
    "# --- Ontology table ---\n",
    "rows = []\n",
    "for concept, description in SCHEDULING_CONCEPTS.items():\n",
    "    checks = CONCEPT_CHECK_REQUIREMENTS.get(concept, [])\n",
    "    rows.append({\n",
    "        'Concept': concept,\n",
    "        'Description': description,\n",
    "        'Data checks': ', '.join(checks) if checks else '(none)',\n",
    "    })\n",
    "ontology_df = pd.DataFrame(rows)\n",
    "display(Markdown('### Scheduling Ontology'))\n",
    "display(ontology_df)\n",
])

# ---------------------------------------------------------------------------
# Cell 3 - User Inputs
# ---------------------------------------------------------------------------
cell3 = code_cell([
    "USER_REQUIREMENT = (\n",
    "    \"Validate whether this electronics assembly workbook has enough customer build request, \"\n",
    "    \"assembly product, requested quantity, available stock, assembly processing time, \"\n",
    "    \"assembly station capacity, earliest start window, and customer commitment deadline \"\n",
    "    \"data for CP-SAT scheduling. The goal is to complete all assembly jobs as early \"\n",
    "    \"as possible across the available assembly stations.\"\n",
    ")\n",
    "\n",
    "SCHEMA_CONTEXT = \"\"\"\n",
    "AssemblyCatalog contains product master and stock data for electronics assemblies.\n",
    "assembly_sku is the assembly/product ID.\n",
    "assembly_name is the assembly product name.\n",
    "assembly_family is the product family or category.\n",
    "assembly_min_each is the assembly processing time per unit in minutes.\n",
    "stock_available_units is the current available stock quantity.\n",
    "changeover_group identifies similar assemblies for setup/changeover grouping.\n",
    "\n",
    "BuildRequests contains customer build request data.\n",
    "ticket_no is the build request or order ID.\n",
    "assembly_sku links each build request to AssemblyCatalog.assembly_sku.\n",
    "client_name is the customer name.\n",
    "units_requested is the quantity requested by the customer.\n",
    "\n",
    "BuildWindows contains scheduling time-window constraints for each build request.\n",
    "ticket_no links each timing record to BuildRequests.ticket_no.\n",
    "not_before_day is the earliest day assembly can start.\n",
    "not_before_min is the earliest start time within that day, in minutes.\n",
    "commit_day is the customer commitment deadline day.\n",
    "commit_cutoff_min is the deadline time within the commitment day, in minutes.\n",
    "\n",
    "AssemblyStations contains available assembly production resources.\n",
    "station_id is the assembly station or production line ID.\n",
    "station_name is the station name.\n",
    "shift_capacity_min is the available capacity per station per day.\n",
    "available_start_day is the first day the station is available.\n",
    "available_end_day is the last day the station is available.\n",
    "\n",
    "Relationships:\n",
    "BuildRequests.assembly_sku links to AssemblyCatalog.assembly_sku.\n",
    "BuildWindows.ticket_no links to BuildRequests.ticket_no.\n",
    "AssemblyStations are the available resources for assigning assembly jobs.\n",
    "\"\"\"\n",
    "\n",
    "# --- Auto-detect file path ---\n",
    "data_files = sorted(\n",
    "    p for p in DATA_DIR.iterdir()\n",
    "    if p.is_file() and p.suffix.lower() in ('.xlsx', '.xls', '.csv')\n",
    ")\n",
    "\n",
    "if len(data_files) == 1:\n",
    "    FILE_PATH = data_files[0]\n",
    "elif len(data_files) > 1:\n",
    "    print('Multiple files found:')\n",
    "    for i, f in enumerate(data_files):\n",
    "        print(f'  [{i}] {f.name}')\n",
    "    idx = int(input('Choose file number [0]: ') or '0')\n",
    "    FILE_PATH = data_files[idx]\n",
    "else:\n",
    "    raise FileNotFoundError(f'No CSV/Excel file found in {DATA_DIR}')\n",
    "\n",
    "print(f'File             : {FILE_PATH.name}')\n",
    "print(f'Requirement      : {USER_REQUIREMENT[:90]}...')\n",
    "print(f'Schema context   : {SCHEMA_CONTEXT[:80] if SCHEMA_CONTEXT else \"(none -- agent will infer)\"}')\n",
])

# ---------------------------------------------------------------------------
# Step 1 - Workbook Profiling
# ---------------------------------------------------------------------------
cell4 = code_cell([
    "display(Markdown('## Step 1 -- Workbook Profiling (Deterministic)'))\n",
    "\n",
    "workbook_tools.reset_cache()\n",
    "profile = workbook_tools.profile_workbook(FILE_PATH)\n",
    "\n",
    "if not profile.get('ok'):\n",
    "    print(f'ERROR: {profile.get(\"error\")}')\n",
    "else:\n",
    "    print(f'Sheets found: {list(profile[\"sheets\"].keys())}')\n",
    "    print(f'Sheet count : {profile[\"sheet_count\"]}')\n",
    "    print()\n",
    "    for sheet_name, info in profile['sheets'].items():\n",
    "        display(Markdown(f'### Sheet: {sheet_name} ({info[\"row_count\"]} rows)'))\n",
    "        cols_info = info.get('columns_info', {})\n",
    "        rows = []\n",
    "        for col in info['columns']:\n",
    "            dtype = info['dtypes'].get(col, '?')\n",
    "            nulls = info['null_counts'].get(col, 0)\n",
    "            unique = info['unique_counts'].get(col, 0)\n",
    "            col_detail = cols_info.get(col, {})\n",
    "            top_vals = list(col_detail.get('top_values', {}).keys())[:3]\n",
    "            hint = col_detail.get('pattern_hint', '')\n",
    "            neg = col_detail.get('negative_count', 0)\n",
    "            rows.append({\n",
    "                'Column': col,\n",
    "                'Type': dtype,\n",
    "                'Nulls': nulls,\n",
    "                'Unique': unique,\n",
    "                'Negatives': neg,\n",
    "                'Sample values': str(top_vals),\n",
    "                'Hint': hint,\n",
    "            })\n",
    "        display(pd.DataFrame(rows))\n",
])

# ---------------------------------------------------------------------------
# Step 2 - LLM Problem Understanding
# ---------------------------------------------------------------------------
cell5 = code_cell([
    "display(Markdown('## Step 2 -- LLM Problem Understanding (LLM)'))\n",
    "\n",
    "understanding = user_input_understanding.understand(USER_REQUIREMENT, profile)\n",
    "\n",
    "# --- Section 1: Problem Overview ---\n",
    "cv = understanding.get('constraint_validation', {})\n",
    "obj = understanding.get('objective', {})\n",
    "overview_rows = [\n",
    "    {'Field': 'Problem Type',        'Value': understanding.get('problem_type', '')},\n",
    "    {'Field': 'Objective',           'Value': obj.get('name', '') + ' -- ' + obj.get('description', '')},\n",
    "    {'Field': 'CP-SAT Compatible',   'Value': str(understanding.get('is_cpsat_compatible', ''))},\n",
    "    {'Field': 'Constraints valid',   'Value': str(cv.get('are_constraints_valid', ''))},\n",
    "    {'Field': 'Contradictions',      'Value': str(cv.get('has_contradictions', ''))},\n",
    "]\n",
    "display(Markdown('### Problem Overview'))\n",
    "display(pd.DataFrame(overview_rows))\n",
    "\n",
    "# --- Section 2: Constraints ---\n",
    "constraints = understanding.get('constraints', [])\n",
    "if constraints:\n",
    "    c_rows = []\n",
    "    for c in constraints:\n",
    "        valid_val = c.get('is_valid', c.get('valid', ''))\n",
    "        valid_str = 'YES' if valid_val is True else ('NO' if valid_val is False else str(valid_val))\n",
    "        reason = c.get('validity_reason', c.get('reason', c.get('note', '')))\n",
    "        label = valid_str\n",
    "        if reason:\n",
    "            label = valid_str + ' -- ' + str(reason)\n",
    "        c_rows.append({\n",
    "            'Name': c.get('name', ''),\n",
    "            'Type': c.get('type', ''),\n",
    "            'Description': c.get('description', ''),\n",
    "            'Concepts used': ', '.join(c.get('concepts_used', c.get('concepts', []))),\n",
    "            'Valid': label,\n",
    "        })\n",
    "    display(Markdown('### Constraints'))\n",
    "    display(pd.DataFrame(c_rows))\n",
    "else:\n",
    "    display(Markdown('### Constraints'))\n",
    "    print('No constraints identified.')\n",
    "\n",
    "# --- Section 3: Concept lists ---\n",
    "display(Markdown('### Required and Optional Concepts'))\n",
    "req_concepts = understanding.get('required_concepts', [])\n",
    "opt_concepts = understanding.get('optional_concepts', [])\n",
    "req_rels = understanding.get('required_relationships', [])\n",
    "\n",
    "req_rows = []\n",
    "for c in req_concepts:\n",
    "    desc = SCHEDULING_CONCEPTS.get(c, '(not in ontology)')\n",
    "    req_rows.append({'Concept': c, 'Description': desc, 'Category': 'Required'})\n",
    "for c in opt_concepts:\n",
    "    desc = SCHEDULING_CONCEPTS.get(c, '(not in ontology)')\n",
    "    req_rows.append({'Concept': c, 'Description': desc, 'Category': 'Optional'})\n",
    "if req_rows:\n",
    "    display(pd.DataFrame(req_rows))\n",
    "else:\n",
    "    print('No concepts identified.')\n",
    "\n",
    "if req_rels:\n",
    "    display(Markdown('**Required relationships:** ' + ', '.join(req_rels)))\n",
])

# ---------------------------------------------------------------------------
# Step 3 - Schema Mapping
# ---------------------------------------------------------------------------
cell6 = code_cell([
    "display(Markdown('## Step 3 -- Schema Mapping (LLM)'))\n",
    "\n",
    "schema_agent = SchemaMappingAgent(\n",
    "    file_path=FILE_PATH,\n",
    "    workbook_profile=profile,\n",
    "    user_requirement=understanding,\n",
    "    schema_context=SCHEMA_CONTEXT,\n",
    ")\n",
    "mapping_result = schema_agent.run()\n",
    "\n",
    "# --- Mappings table ---\n",
    "display(Markdown('### Mapping Results'))\n",
    "if mapping_result.mappings:\n",
    "    conf_report = mapping_result.confidence_report\n",
    "    status_by_concept = {p['concept']: p['status'] for p in conf_report.get('per_concept', [])}\n",
    "    m_rows = []\n",
    "    for m in mapping_result.mappings:\n",
    "        concept = m.get('concept', '')\n",
    "        m_rows.append({\n",
    "            'Concept': concept,\n",
    "            'Sheet': m.get('sheet', ''),\n",
    "            'Column': m.get('column', ''),\n",
    "            'Confidence': m.get('confidence', ''),\n",
    "            'Status': status_by_concept.get(concept, ''),\n",
    "            'Reasoning': m.get('reasoning', ''),\n",
    "        })\n",
    "    display(pd.DataFrame(m_rows))\n",
    "else:\n",
    "    print('No mappings produced.')\n",
    "\n",
    "# --- Relationships ---\n",
    "display(Markdown('### Detected Relationships'))\n",
    "if mapping_result.relationships:\n",
    "    r_rows = []\n",
    "    for r in mapping_result.relationships:\n",
    "        r_rows.append({\n",
    "            'Name': r.get('name', ''),\n",
    "            'From': r.get('from_sheet', '') + '.' + r.get('from_col', ''),\n",
    "            'To': r.get('to_sheet', '') + '.' + r.get('to_col', ''),\n",
    "            'Overlap verified': r.get('overlap_verified', ''),\n",
    "        })\n",
    "    display(pd.DataFrame(r_rows))\n",
    "else:\n",
    "    print('No relationships detected.')\n",
    "\n",
    "# --- Summary ---\n",
    "display(Markdown('### Mapping Status Summary'))\n",
    "cr = mapping_result.confidence_report\n",
    "print(f'  Mapping status : {cr.get(\"mapping_status\", \"\")}')\n",
    "print(f'  Total required : {cr.get(\"total_required\", 0)}')\n",
    "print(f'  Total mapped   : {cr.get(\"total_mapped\", 0)}')\n",
    "print(f'  Total unmapped : {cr.get(\"total_unmapped\", 0)}')\n",
    "print(f'  Accepted (>=80%): {cr.get(\"accepted_count\", 0)}')\n",
    "print(f'  Warned  (60-80%): {cr.get(\"warned_count\", 0)}')\n",
    "print(f'  Low conf (<60%) : {cr.get(\"low_confidence_count\", 0)}')\n",
    "if mapping_result.validation_warnings:\n",
    "    print()\n",
    "    print('Validation warnings:')\n",
    "    for w in mapping_result.validation_warnings:\n",
    "        print(f'  * {w}')\n",
])

# ---------------------------------------------------------------------------
# Step 4 - Readiness Validation
# ---------------------------------------------------------------------------
cell7 = code_cell([
    "display(Markdown('## Step 4 -- Readiness Validation (Deterministic)'))\n",
    "\n",
    "schema_mapping_dict = {\n",
    "    'mappings': mapping_result.mappings,\n",
    "    'relationships': mapping_result.relationships,\n",
    "}\n",
    "validator = ReadinessValidator(\n",
    "    file_path=FILE_PATH,\n",
    "    schema_mapping=schema_mapping_dict,\n",
    "    user_requirement=understanding,\n",
    "    workbook_profile=profile,\n",
    ")\n",
    "readiness_result = validator.run()\n",
    "\n",
    "# --- Per-concept table ---\n",
    "display(Markdown('### Concept Checks'))\n",
    "cc_rows = []\n",
    "for concept, v in readiness_result.concept_checks.items():\n",
    "    checks_run = ', '.join(CONCEPT_CHECK_REQUIREMENTS.get(concept, []))\n",
    "    sheet_col = ''\n",
    "    if v.get('mapped'):\n",
    "        sheet_col = v.get('sheet', '') + '.' + v.get('column', '')\n",
    "    is_numeric = v.get('is_numeric', '')\n",
    "    if is_numeric == '':\n",
    "        numeric_str = 'N/A'\n",
    "    else:\n",
    "        numeric_str = 'YES' if is_numeric else 'NO'\n",
    "    no_nulls = v.get('no_nulls', '')\n",
    "    if no_nulls == '':\n",
    "        nulls_str = 'N/A'\n",
    "    else:\n",
    "        nulls_str = 'YES' if no_nulls else 'NO'\n",
    "    no_neg = v.get('no_negatives', '')\n",
    "    if no_neg == '':\n",
    "        neg_str = 'N/A'\n",
    "    else:\n",
    "        neg_str = 'YES' if no_neg else 'NO'\n",
    "    ok_str = 'OK' if v.get('ok') else 'FAIL'\n",
    "    cc_rows.append({\n",
    "        'Concept': concept,\n",
    "        'Sheet.Column': sheet_col if sheet_col else '(unmapped)',\n",
    "        'Checks run': checks_run,\n",
    "        'Numeric': numeric_str,\n",
    "        'No Nulls': nulls_str,\n",
    "        'No Negatives': neg_str,\n",
    "        'OK': ok_str,\n",
    "    })\n",
    "display(pd.DataFrame(cc_rows))\n",
    "\n",
    "# --- Relationship checks ---\n",
    "display(Markdown('### Relationship Checks'))\n",
    "if readiness_result.relationship_checks:\n",
    "    rel_rows = []\n",
    "    for rel_name, v in readiness_result.relationship_checks.items():\n",
    "        rel_rows.append({\n",
    "            'Relationship': rel_name,\n",
    "            'From': v.get('from_sheet', '') + '.' + v.get('from_col', ''),\n",
    "            'To': v.get('to_sheet', '') + '.' + v.get('to_col', ''),\n",
    "            'Orphans': v.get('orphan_count', 0),\n",
    "            'OK': 'OK' if v.get('ok', False) else 'FAIL',\n",
    "        })\n",
    "    display(pd.DataFrame(rel_rows))\n",
    "else:\n",
    "    print('No relationship checks performed.')\n",
    "\n",
    "# --- Blocking issues ---\n",
    "display(Markdown('### Blocking Issues'))\n",
    "if readiness_result.blocking_issues:\n",
    "    for issue in readiness_result.blocking_issues:\n",
    "        print(f'  * {issue}')\n",
    "else:\n",
    "    print('No blocking issues.')\n",
])

# ---------------------------------------------------------------------------
# Step 5 - Final Summary
# ---------------------------------------------------------------------------
cell8 = code_cell([
    "display(Markdown('## Step 5 -- Final Summary (Deterministic)'))\n",
    "\n",
    "req_concepts = understanding.get('required_concepts', [])\n",
    "mapped_concepts = [m.get('concept') for m in mapping_result.mappings]\n",
    "cr = mapping_result.confidence_report\n",
    "obj = understanding.get('objective', {})\n",
    "\n",
    "summary_rows = [\n",
    "    {'Field': 'Problem Type',      'Value': understanding.get('problem_type', '')},\n",
    "    {'Field': 'Objective',         'Value': obj.get('name', '')},\n",
    "    {'Field': 'CP-SAT Compatible', 'Value': str(understanding.get('is_cpsat_compatible', ''))},\n",
    "    {'Field': 'Required Concepts', 'Value': str(len(req_concepts))},\n",
    "    {'Field': 'Mapped Concepts',   'Value': str(len(mapped_concepts))},\n",
    "    {'Field': 'Schema Mapping',    'Value': cr.get('mapping_status', '')},\n",
    "    {'Field': 'Readiness Status',  'Value': readiness_result.readiness_status},\n",
    "    {'Field': 'Ready for CP-SAT',  'Value': str(readiness_result.overall_ready)},\n",
    "]\n",
    "display(pd.DataFrame(summary_rows))\n",
    "\n",
    "print()\n",
    "if readiness_result.overall_ready:\n",
    "    display(Markdown('### READY -- All required concepts are mapped and validated.'))\n",
    "else:\n",
    "    display(Markdown('### NOT READY -- Blocking issues must be resolved before CP-SAT.'))\n",
    "    for issue in readiness_result.blocking_issues:\n",
    "        print(f'  * {issue}')\n",
])



# ---------------------------------------------------------------------------
# Assemble notebook
# ---------------------------------------------------------------------------
nb = {
    "nbformat": 4,
    "nbformat_minor": 5,
    "metadata": {
        "kernelspec": {
            "display_name": "Python 3",
            "language": "python",
            "name": "python3",
        },
        "language_info": {
            "name": "python",
            "version": "3.10.0",
        },
    },
    "cells": [cell0, cell1, cell2, cell3, cell4, cell5, cell6, cell7, cell8],
}

out_path = r'h:\files\notebook\production_scheduling_validation.ipynb'
with open(out_path, 'w', encoding='utf-8') as f:
    json.dump(nb, f, indent=1, ensure_ascii=False)

print(f'Written to {out_path}')

# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------
print()
print('=== Verification ===')

with open(out_path, 'r', encoding='utf-8') as f:
    raw = f.read()

# Check 1: json.load succeeds
try:
    loaded = json.loads(raw)
    print('OK  json.load succeeds')
except Exception as e:
    print(f'FAIL  json.load: {e}')

# Gather all cell source text
all_source = ''
for cell in loaded.get('cells', []):
    all_source += ''.join(cell.get('source', []))

# Check 2: All critical imports present
imports_to_check = [
    ('from app.config import', True),
    ('CONCEPT_CHECK_REQUIREMENTS', True),
    ('from app.tools import workbook_tools', True),
    ('from app.llm import user_input_understanding', True),
    ('from app.agents.schema_mapping_agent import SchemaMappingAgent', True),
    ('from app.agents.readiness_validator import ReadinessValidator', True),
]
for token, expected in imports_to_check:
    found = token in all_source
    status = 'OK' if found == expected else 'FAIL'
    print(f'{status}  import present: {token[:60]}')

# Check 3: ReadinessValidationAgent does NOT appear
if 'ReadinessValidationAgent' in all_source:
    print('FAIL  ReadinessValidationAgent appears (must not)')
else:
    print('OK  ReadinessValidationAgent does not appear')

# Check 4: ReadinessValidator DOES appear
if 'ReadinessValidator' in all_source:
    print('OK  ReadinessValidator appears')
else:
    print('FAIL  ReadinessValidator missing')

# Check 5: CONCEPT_CHECK_REQUIREMENTS DOES appear
if 'CONCEPT_CHECK_REQUIREMENTS' in all_source:
    print('OK  CONCEPT_CHECK_REQUIREMENTS appears')
else:
    print('FAIL  CONCEPT_CHECK_REQUIREMENTS missing')

# Check 6: Step 6 does NOT appear (removed)
if 'Step 6' in all_source:
    print('FAIL  Step 6 still appears (should be removed)')
else:
    print('OK  Step 6 removed')

# Check 7: No unicode above 127 in cell sources
bad_chars = [(i, c) for i, c in enumerate(all_source) if ord(c) > 127]
if bad_chars:
    print(f'FAIL  {len(bad_chars)} non-ASCII chars found in cell sources:')
    for pos, c in bad_chars[:10]:
        print(f'       pos={pos} char={repr(c)}')
else:
    print('OK  No unicode above 127 in cell sources')

# Check 8: No "Readiness Validation Agent" as section title
if 'Readiness Validation Agent' in all_source:
    print('FAIL  "Readiness Validation Agent" appears (must not)')
else:
    print('OK  "Readiness Validation Agent" does not appear')

# Check 9: All code cells have empty outputs
code_cells = [c for c in loaded.get('cells', []) if c.get('cell_type') == 'code']
all_empty = all(c.get('outputs', ['x']) == [] for c in code_cells)
if all_empty:
    print('OK  All code cell outputs are empty lists')
else:
    print('FAIL  Some code cells have non-empty outputs')

print()
print('Done.')
