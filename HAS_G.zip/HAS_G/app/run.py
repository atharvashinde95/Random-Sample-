import sys
from pathlib import Path

# Add the parent directory to sys.path so 'app.xxx' imports work
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.main import main

if __name__ == "__main__":
    main()
# We need to organize today’s production work for two identical machines. The team works one full 8-hour shift, and the goal is to finish all listed jobs as early as possible. Before moving to scheduling, please check whether the uploaded file has enough information about what to make, how much to make, how long it takes, customer demand, and available stock.