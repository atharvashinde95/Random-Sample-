"""
LangGraph workflow — smart schema-flexible scheduling validation.

Pipeline:
  START
    -> data_profiling_schema_summary_node  schema-agnostic workbook profile
    -> llm_problem_understanding_node      extract required canonical concepts
    -> schema_mapping_agent_node           map concepts -> actual columns (SchemaMappingAgent)
    -> readiness_validation_node           check data quality per mapped column (ReadinessValidator)
    -> final_summary_node
    -> END
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from langgraph.graph import END, START, StateGraph

from app.agents.schema_mapping_agent import SchemaMappingAgent
from app.agents.readiness_validator import ReadinessValidator
from app.graph.state import SchedulingGraphState
from app.llm import user_input_understanding
from app.tools import workbook_tools
from app.utils import logger
from app.utils.json_writer import write_json


# ---------------------------------------------------------------------------
# Node 1: Workbook profiler (no LLM)
# ---------------------------------------------------------------------------

def data_profiling_schema_summary_node(state: SchedulingGraphState) -> SchedulingGraphState:
    logger.graph("Node: data_profiling_schema_summary_node")
    logger.section("STEP 1: WORKBOOK PROFILING")

    workbook_tools.reset_cache()
    profile = workbook_tools.profile_workbook(state["file_path"])

    if profile.get("ok"):
        logger.workbook_profile_table(profile)
    else:
        logger.error("PROFILER", profile.get("error", "Profiling failed"))

    output_dir = Path(state["output_dir"])
    write_json(output_dir / "workbook_profile.json", profile)
    logger.saved(str(output_dir / "workbook_profile.json"))
    logger.graph("Node completed: data_profiling_schema_summary_node")

    return {**state, "workbook_profile": profile}


# ---------------------------------------------------------------------------
# Node 2: LLM problem understanding (concept extraction, no column names)
# ---------------------------------------------------------------------------

def llm_problem_understanding_node(state: SchedulingGraphState) -> SchedulingGraphState:
    logger.graph("Node: llm_problem_understanding_node")
    logger.section("STEP 2: LLM PROBLEM UNDERSTANDING (concept extraction)")

    user_req = user_input_understanding.understand(
        state["user_input"],
        state["workbook_profile"],
    )

    output_dir = Path(state["output_dir"])
    write_json(output_dir / "user_requirement.json", user_req)
    logger.saved(str(output_dir / "user_requirement.json"))
    logger.graph("Node completed: llm_problem_understanding_node")

    return {**state, "user_requirement": user_req}


# ---------------------------------------------------------------------------
# Node 3: Schema mapping agent
# ---------------------------------------------------------------------------

def schema_mapping_agent_node(state: SchedulingGraphState) -> SchedulingGraphState:
    logger.graph("Node: schema_mapping_agent_node")
    logger.section("STEP 3: SCHEMA MAPPING AGENT")

    schema_context = state.get("schema_context", "")
    if schema_context:
        logger.info("CONTEXT", "User-provided schema context will guide column mapping")

    agent = SchemaMappingAgent(
        file_path=state["file_path"],
        workbook_profile=state["workbook_profile"],
        user_requirement=state["user_requirement"],
        schema_context=schema_context,
    )
    result = agent.run()

    mapping_dict: dict[str, Any] = {
        "file_path": result.file_path,
        "mapping_ok": result.mapping_ok,
        "mappings": result.mappings,
        "unmapped_concepts": result.unmapped_concepts,
        "ambiguities": result.ambiguities,
        "relationships": result.relationships,
        "llm_raw_response": result.llm_raw_response,
        "confidence_report": result.confidence_report,
        "validation_warnings": result.validation_warnings,
    }

    logger.schema_mapping_summary(mapping_dict)

    output_dir = Path(state["output_dir"])
    write_json(output_dir / "schema_mapping.json", mapping_dict)
    write_json(output_dir / "mapping_confidence_report.json", result.confidence_report)
    logger.saved(str(output_dir / "schema_mapping.json"))
    logger.saved(str(output_dir / "mapping_confidence_report.json"))
    logger.graph("Node completed: schema_mapping_agent_node")

    return {
        **state,
        "schema_mapping": mapping_dict,
        "mapping_confidence_report": result.confidence_report,
    }


# ---------------------------------------------------------------------------
# Node 4: Readiness validation (deterministic — not an agent)
# ---------------------------------------------------------------------------

def readiness_validation_node(state: SchedulingGraphState) -> SchedulingGraphState:
    logger.graph("Node: readiness_validation_node")
    logger.section("STEP 4: READINESS VALIDATION (deterministic)")

    validator = ReadinessValidator(
        file_path=state["file_path"],
        schema_mapping=state["schema_mapping"],
        user_requirement=state["user_requirement"],
        workbook_profile=state.get("workbook_profile", {}),
    )
    result = validator.run()

    report: dict[str, Any] = {
        "file_path": result.file_path,
        "readiness_status": result.readiness_status,
        "overall_ready": result.overall_ready,
        "concept_checks": result.concept_checks,
        "relationship_checks": result.relationship_checks,
        "blocking_issues": result.blocking_issues,
        "warnings": result.warnings,
    }

    logger.readiness_report_table(report)

    output_dir = Path(state["output_dir"])
    write_json(output_dir / "readiness_report.json", report)
    logger.saved(str(output_dir / "readiness_report.json"))
    logger.graph("Node completed: readiness_validation_node")

    return {
        **state,
        "readiness_report": report,
        "readiness_status": result.readiness_status,
    }


# ---------------------------------------------------------------------------
# Node 5: Final summary
# ---------------------------------------------------------------------------

def final_summary_node(state: SchedulingGraphState) -> SchedulingGraphState:
    logger.graph("Node: final_summary_node")

    req = state.get("user_requirement", {})
    mapping = state.get("schema_mapping", {})
    report = state.get("readiness_report", {})
    confidence_report = state.get("mapping_confidence_report", {})

    required_concepts = req.get("required_concepts", [])
    all_mappings = mapping.get("mappings", [])
    mapped_concepts = {m["concept"] for m in all_mappings if "concept" in m}
    required_mapped = [c for c in required_concepts if c in mapped_concepts]
    optional_mapped = [m["concept"] for m in all_mappings if m.get("concept") not in required_concepts]

    final_summary: dict[str, Any] = {
        "problem_type": req.get("problem_type"),
        "is_cpsat_compatible": req.get("is_cpsat_compatible"),
        "cpsat_compatibility_reason": req.get("cpsat_compatibility_reason"),
        "objective": req.get("objective", {}).get("name"),
        "required_concepts_count": len(required_concepts),
        "required_mapped_count": len(required_mapped),
        "optional_mapped_count": len(optional_mapped),
        "unmapped_concepts": [c for c in required_concepts if c not in mapped_concepts],
        "constraints_valid": req.get("constraint_validation", {}).get("are_constraints_valid"),
        "contradictions_found": req.get("constraint_validation", {}).get("has_contradictions"),
        "readiness_status": state.get("readiness_status"),
        "overall_ready": report.get("overall_ready", False),
        "blocking_issues": report.get("blocking_issues", []),
        "schema_mapping_status": confidence_report.get("mapping_status", "UNKNOWN"),
        "next_step": "Build CP-SAT model. Not implemented in this MVP.",
    }

    logger.final_summary(final_summary)

    output_dir = Path(state["output_dir"])
    write_json(output_dir / "final_summary.json", final_summary)
    logger.saved(str(output_dir / "final_summary.json"))

    state_trace: dict[str, Any] = {
        "run_id": state.get("run_id"),
        "file_path": state.get("file_path"),
        "user_input": state.get("user_input"),
        "schema_context": state.get("schema_context", ""),
        "workbook_profile": state.get("workbook_profile"),
        "user_requirement": state.get("user_requirement"),
        "schema_mapping": state.get("schema_mapping"),
        "readiness_status": state.get("readiness_status"),
        "mapping_confidence_report": state.get("mapping_confidence_report"),
        "final_summary": final_summary,
        "errors": state.get("errors", []),
        "warnings": state.get("warnings", []),
    }
    write_json(output_dir / "langgraph_state_trace.json", state_trace)
    logger.saved(str(output_dir / "langgraph_state_trace.json"))

    logger.graph("END")

    return {**state, "final_summary": final_summary}


# ---------------------------------------------------------------------------
# Graph builder
# ---------------------------------------------------------------------------

def build_workflow():
    workflow = StateGraph(SchedulingGraphState)

    workflow.add_node("data_profiling_schema_summary_node", data_profiling_schema_summary_node)
    workflow.add_node("llm_problem_understanding_node", llm_problem_understanding_node)
    workflow.add_node("schema_mapping_agent_node", schema_mapping_agent_node)
    workflow.add_node("readiness_validation_node", readiness_validation_node)
    workflow.add_node("final_summary_node", final_summary_node)

    workflow.add_edge(START, "data_profiling_schema_summary_node")
    workflow.add_edge("data_profiling_schema_summary_node", "llm_problem_understanding_node")
    workflow.add_edge("llm_problem_understanding_node", "schema_mapping_agent_node")
    workflow.add_edge("schema_mapping_agent_node", "readiness_validation_node")
    workflow.add_edge("readiness_validation_node", "final_summary_node")
    workflow.add_edge("final_summary_node", END)

    return workflow.compile()
