"""
LangGraph state for the smart scheduling validation workflow.
"""
from __future__ import annotations
from typing import Any, TypedDict


class SchedulingGraphState(TypedDict, total=False):
    run_id: str
    file_path: str
    schema_context: str     # optional user description of columns/tables/relationships
    output_dir: str
    user_input: str

    # Node 1: workbook_profiler_node
    workbook_profile: dict[str, Any]

    # Node 2: llm_problem_understanding_node
    user_requirement: dict[str, Any]

    # Node 3: schema_mapping_agent_node
    schema_mapping_trace: list[dict[str, Any]]
    schema_mapping: dict[str, Any]
    mapping_confidence_report: dict[str, Any]

    # Node 4: readiness_validation_node
    readiness_trace: list[dict[str, Any]]
    readiness_report: dict[str, Any]
    readiness_status: str

    # Node 5: final_summary_node
    final_summary: dict[str, Any]

    errors: list[str]
    warnings: list[str]
