# Production Scheduling Validation

Validates whether an Excel/CSV workbook contains all the data required to build a CP-SAT production schedule using Google OR-Tools. Uses Groq (llama-3.3-70b-versatile) for LLM-powered concept extraction and schema mapping.

## What it does

Given a workbook with production data (orders, machines, products, timelines), the pipeline:

1. Profiles the workbook (sheet names, columns, data types, statistics)
2. Extracts which canonical scheduling concepts are required (from a natural-language user input)
3. Maps workbook columns to those canonical concepts (schema mapping)
4. Validates each mapped column for completeness and data quality (readiness validation)
5. Produces a final readiness report: READY or NOT_READY for CP-SAT

No CP-SAT solver is invoked. This is a pre-flight check only.

## Architecture (5-step pipeline)

```
START
  -> data_profiling_schema_summary_node   profile sheets, columns, types, stats
  -> llm_problem_understanding_node       LLM extracts required canonical concepts
  -> schema_mapping_agent_node            LLM ReAct agent maps columns to concepts (tool-calling loop)
  -> readiness_validation_node            deterministic data quality checks (no LLM)
  -> final_summary_node
END
```

Step 2 uses a single Groq call. Step 3 uses a ReAct tool-calling loop (up to 25 iterations). Validation is always deterministic.

## Install

```bash
pip install -r requirements.txt
```

Requires a Groq API key. Add it to a `.env` file in the project root:

```
GROQ_API_KEY=your_key_here
```

## Run

```bash
python -m app.main
```

Or pass a specific file and user input:

```bash
python -m app.main --file data/production_scheduling_sample.xlsx
```

## Input modes

- **file**: Real Excel/CSV file with actual data (default)
- **schema_context**: Optional free-text description of columns to guide schema mapping

## Output files

Written to `outputs/terminal_runs/<run_id>/`:

| File | Contents |
|---|---|
| `workbook_profile.json` | Sheet/column profile with representative samples |
| `user_requirement.json` | Extracted canonical concepts and constraints |
| `schema_mapping.json` | Concept-to-column mappings with confidence scores |
| `mapping_confidence_report.json` | Per-concept confidence status (VALID/PARTIAL/FAILED) |
| `readiness_report.json` | Per-column data quality check results |
| `final_summary.json` | Overall readiness verdict |
| `langgraph_state_trace.json` | Full pipeline state |

## Model

- **Model**: llama-3.3-70b-versatile
- **Provider**: Groq (cloud API)
- **Temperature**: 0
- **Max tokens**: 4096
