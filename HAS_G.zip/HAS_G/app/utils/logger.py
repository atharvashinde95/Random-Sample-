"""
Rich-based terminal logger. All output goes through here.
"""
from __future__ import annotations
from typing import Any
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


def banner() -> None:
    console.print(
        Panel.fit(
            "[bold cyan]PRODUCTION SCHEDULING VALIDATION MVP[/bold cyan]",
            border_style="cyan",
        )
    )


def section(title: str) -> None:
    console.print(f"\n[bold white]--- {title} ---[/bold white]")


def info(label: str, message: str) -> None:
    console.print(f"[bold green][{label}][/bold green]  {message}")


def warn(label: str, message: str) -> None:
    console.print(f"[bold yellow][{label}][/bold yellow]  {message}")


def error(label: str, message: str) -> None:
    console.print(f"[bold red][{label}][/bold red]  {message}")


def saved(path: str) -> None:
    console.print(f"[bold blue][SAVED][/bold blue]   {path}")


def graph(message: str) -> None:
    console.print(f"[bold magenta][GRAPH][/bold magenta] {message}")


def react_thought(text: str) -> None:
    console.print(f"[bold yellow][AGENT - THOUGHT][/bold yellow]       {text}")


def react_action(text: str) -> None:
    console.print(f"[bold cyan][AGENT - ACTION][/bold cyan]        {text}")


def react_observation(text: str) -> None:
    console.print(f"[bold white][AGENT - OBSERVATION][/bold white]\n  {text}")


def react_final(text: str) -> None:
    console.print(
        Panel(
            f"[bold green]{text}[/bold green]",
            title="[bold green]AGENT - FINAL ANSWER[/bold green]",
            border_style="green",
        )
    )


# ---------------------------------------------------------------------------
# Workbook profile display
# ---------------------------------------------------------------------------

def workbook_profile_table(profile: dict[str, Any]) -> None:
    if not profile.get("ok"):
        error("PROFILER", profile.get("error", "profiling failed"))
        return

    sheets = profile.get("sheets", {})
    for sheet_name, info in sheets.items():
        table = Table(
            title=f"Sheet: {sheet_name}  ({info['row_count']} rows)",
            border_style="cyan",
            title_style="bold cyan",
            show_lines=False,
        )
        table.add_column("#", style="dim", justify="right")
        table.add_column("Column", style="bold")
        table.add_column("Dtype", style="yellow")
        table.add_column("Nulls", style="dim")

        for idx, col in enumerate(info["columns"], start=1):
            dtype = info["dtypes"].get(col, "?")
            nulls = info["null_counts"].get(col, 0)
            null_display = f"[red]{nulls}[/red]" if nulls > 0 else str(nulls)
            table.add_row(str(idx), col, str(dtype), null_display)

        console.print(table)


# ---------------------------------------------------------------------------
# Schema mapping display
# ---------------------------------------------------------------------------

def schema_mapping_summary(mapping: dict[str, Any]) -> None:
    mappings = mapping.get("mappings", [])
    unmapped = mapping.get("unmapped_concepts", [])

    table = Table(
        title="SCHEMA MAPPING  (concept -> sheet.column)",
        border_style="green",
        title_style="bold green",
    )
    table.add_column("Concept", style="bold")
    table.add_column("Sheet", style="cyan")
    table.add_column("Column", style="cyan")
    table.add_column("Confidence", style="dim")
    table.add_column("Reasoning", style="dim", max_width=40)

    for m in mappings:
        if not isinstance(m, dict):
            continue
        conf = m.get("confidence", "?")
        conf_str = f"{conf:.2f}" if isinstance(conf, float) else str(conf)
        table.add_row(
            str(m.get("concept", "")),
            str(m.get("sheet", "")),
            str(m.get("column", "")),
            conf_str,
            str(m.get("reasoning", "")),
        )

    for concept in unmapped:
        table.add_row(f"[red]{concept}[/red]", "[red]UNMAPPED[/red]", "", "", "")

    console.print(table)

    rels = mapping.get("relationships", [])
    if rels:
        console.print("[bold]Detected relationships:[/bold]")
        for r in rels:
            verified = "[green]✓[/green]" if r.get("overlap_verified") else "[yellow]?[/yellow]"
            console.print(
                f"  {verified} {r.get('name', '?')}: "
                f"{r.get('from_sheet', '?')}.{r.get('from_col', '?')} -> "
                f"{r.get('to_sheet', '?')}.{r.get('to_col', '?')}"
            )


# ---------------------------------------------------------------------------
# Readiness report display
# ---------------------------------------------------------------------------

def readiness_report_table(report: dict[str, Any]) -> None:
    concept_checks = report.get("concept_checks", {})
    relationship_checks = report.get("relationship_checks", {})

    table = Table(
        title="READINESS REPORT  (per concept)",
        border_style="yellow" if not report.get("overall_ready") else "green",
        title_style="bold",
    )
    table.add_column("Concept", style="bold")
    table.add_column("Sheet.Column", style="cyan")
    table.add_column("Numeric", style="dim")
    table.add_column("No Nulls", style="dim")
    table.add_column("No Neg.", style="dim")
    table.add_column("OK", style="bold")

    def _tick(val: Any) -> str:
        if val is None:
            return "[dim]—[/dim]"
        return "[green]✓[/green]" if val else "[red]✗[/red]"

    for concept, v in concept_checks.items():
        if not v.get("mapped"):
            table.add_row(
                f"[red]{concept}[/red]",
                "[red]NOT MAPPED[/red]",
                "[dim]—[/dim]",
                "[dim]—[/dim]",
                "[dim]—[/dim]",
                "[red]✗[/red]",
            )
            continue
        loc = f"{v.get('sheet', '?')}.{v.get('column', '?')}"
        table.add_row(
            concept,
            loc,
            _tick(v.get("is_numeric")),
            _tick(v.get("no_nulls")),
            _tick(v.get("no_negatives")),
            "[green]✓[/green]" if v.get("ok") else "[red]✗[/red]",
        )

    console.print(table)

    if relationship_checks:
        console.print("[bold]Relationship checks:[/bold]")
        for rel_name, v in relationship_checks.items():
            ok_str = "[green]PASS[/green]" if v.get("ok") else f"[red]FAIL ({v.get('orphan_count', '?')} orphans)[/red]"
            console.print(f"  {rel_name}: {ok_str}")

    blocking = report.get("blocking_issues", [])
    if blocking:
        console.print("\n[bold red]Blocking issues:[/bold red]")
        for issue in blocking:
            console.print(f"  [red]• {issue}[/red]")


# ---------------------------------------------------------------------------
# CP-SAT solvability reasoning
# ---------------------------------------------------------------------------

def cpsat_reasoning(understanding: dict[str, Any]) -> None:
    is_compatible = bool(understanding.get("is_cpsat_compatible"))
    reason = understanding.get("cpsat_compatibility_reason") or "(no reason provided)"

    problem_type = understanding.get("problem_type") or "(empty)"
    objective = understanding.get("objective", {})
    obj_name = objective.get("name") if isinstance(objective, dict) else str(objective)
    req_concepts = understanding.get("required_concepts", []) or []
    opt_concepts = understanding.get("optional_concepts", []) or []
    constraints = understanding.get("constraints", []) or []
    req_rels = understanding.get("required_relationships", []) or []
    cv = understanding.get("constraint_validation", {}) or {}

    hard = sum(1 for c in constraints if isinstance(c, dict) and c.get("type") == "hard")
    soft = sum(1 for c in constraints if isinstance(c, dict) and c.get("type") == "soft")

    inputs_lines = [
        f"[bold]Problem type[/bold]         : {problem_type}",
        f"[bold]Objective[/bold]            : {obj_name or '(empty)'}",
        f"[bold]Constraints[/bold]          : {len(constraints)}  ({hard} hard, {soft} soft)",
        f"[bold]Required concepts[/bold]    : {req_concepts}",
        f"[bold]Optional concepts[/bold]    : {opt_concepts}",
        f"[bold]Required relationships[/bold]: {req_rels}",
        f"[bold]Constraints valid[/bold]    : {'YES' if cv.get('are_constraints_valid') else 'NO'}",
        f"[bold]Contradictions[/bold]       : {'YES' if cv.get('has_contradictions') else 'NO'}",
    ]

    if is_compatible:
        verdict = "[bold green]SOLVABLE BY CP-SAT  -  YES[/bold green]"
        border = "green"
    else:
        verdict = "[bold red]SOLVABLE BY CP-SAT  -  NO[/bold red]"
        border = "red"

    # Constraint detail lines
    constraint_lines: list[str] = []
    if constraints:
        constraint_lines.append("\n[bold underline]Constraint details[/bold underline]")
        for c in constraints:
            if not isinstance(c, dict):
                continue
            ctype = c.get("type", "?").upper()
            cname = c.get("name", "?")
            cdesc = c.get("description", "")
            concepts = c.get("concepts_needed", [])
            color = "red" if ctype == "HARD" else "yellow"
            constraint_lines.append(
                f"  [{color}][{ctype}][/{color}] [bold]{cname}[/bold]: {cdesc}"
            )
            if concepts:
                constraint_lines.append(f"        uses: {', '.join(concepts)}")

    body = (
        "[bold underline]Inputs considered[/bold underline]\n"
        + "\n".join(inputs_lines)
        + "\n".join(constraint_lines)
        + "\n\n"
        + verdict
        + f"\n[bold]Why[/bold]: {reason}"
    )

    console.print(
        Panel(body, title="[bold cyan]CP-SAT SOLVABILITY REASONING[/bold cyan]", border_style=border)
    )


# ---------------------------------------------------------------------------
# Final summary display
# ---------------------------------------------------------------------------

def final_summary(summary: dict[str, Any]) -> None:
    section("FINAL SUMMARY")

    ready = summary.get("overall_ready", False)
    status = summary.get("readiness_status", "?")
    schema_mapping_status = summary.get("schema_mapping_status", "UNKNOWN")

    lines = [
        ("Problem Type",            summary.get("problem_type", "?")),
        ("Objective",               summary.get("objective", "?")),
        ("CP-SAT Compatible",       "YES" if summary.get("is_cpsat_compatible") else "NO"),
        ("Required Concepts",       str(summary.get("required_concepts_count", "?"))),
        ("Required Mapped",         str(summary.get("required_mapped_count", "?"))),
        ("Optional Mapped",         str(summary.get("optional_mapped_count", 0))),
        ("Schema Mapping",          schema_mapping_status),
        ("Readiness Status",        status),
        ("Ready for CP-SAT",        "YES" if ready else "NO"),
    ]

    for label, value in lines:
        color = "green" if value in ("YES", "READY", "VALID") else (
            "red" if value in ("NO", "NOT_READY", "INVALID", "FAILED") else (
                "yellow" if value in ("PARTIAL", "UNKNOWN") else "white"
            )
        )
        console.print(f"[bold]{label:<24}[/bold][{color}]{value}[/{color}]")

    unmapped = summary.get("unmapped_concepts", [])
    if unmapped:
        console.print(f"\n[bold yellow]Unmapped required concepts:[/bold yellow] {unmapped}")

    blocking = summary.get("blocking_issues", [])
    if blocking:
        console.print("\n[bold red]Blocking issues:[/bold red]")
        for issue in blocking:
            console.print(f"  [red]• {issue}[/red]")

    reason = summary.get("cpsat_compatibility_reason")
    if reason:
        console.print(f"\n[bold]CP-SAT reasoning[/bold]: {reason}")


# ---------------------------------------------------------------------------
# CP-SAT variable preview (shown only when data is READY)
# ---------------------------------------------------------------------------

def cpsat_variable_preview(schema_mapping: dict[str, Any], user_requirement: dict[str, Any]) -> None:
    """Show what the CP-SAT model variables would look like using actual mapped column names."""
    mappings = {m["concept"]: m for m in schema_mapping.get("mappings", []) if "concept" in m}
    objective = user_requirement.get("objective", {})
    obj_name = objective.get("name", "minimize_makespan") if isinstance(objective, dict) else str(objective)

    def ref(concept: str) -> str:
        """Return Sheet.Column reference for a concept, or '?' if not mapped."""
        m = mappings.get(concept)
        return f"{m['sheet']}.{m['column']}" if m else "?"

    lines: list[str] = []

    # Index sets
    if "order_id" in mappings:
        lines.append(f"  j  ∈  {ref('order_id')}        (jobs / orders)")
    if "machine_id" in mappings:
        lines.append(f"  k  ∈  {ref('machine_id')}      (machines / production lines)")
    lines.append("")

    # Decision variables
    lines.append("[bold]Decision variables:[/bold]")
    if "order_id" in mappings:
        lines.append("  start[j]     integer  — minute at which job j begins")
        lines.append("  machine[j]   integer  — machine assigned to job j")
    lines.append("")

    # Derived
    lines.append("[bold]Derived:[/bold]")
    if "demand_quantity" in mappings and "processing_time_per_unit" in mappings:
        lines.append(
            f"  duration[j]  =  {ref('demand_quantity')}[j]"
            f"  ×  {ref('processing_time_per_unit')}[j]"
        )
    lines.append("")

    # Constraints
    lines.append("[bold]Constraints:[/bold]")
    if "earliest_start_day" in mappings:
        lines.append(f"  start[j]  ≥  {ref('earliest_start_day')}[j]  (respect earliest start)")
    if "due_day" in mappings:
        due_ref = ref("due_day")
        time_ref = ref("due_time_minutes") if "due_time_minutes" in mappings else ""
        deadline = f"{due_ref}[j] × capacity + {time_ref}[j]" if time_ref else f"{due_ref}[j]"
        lines.append(f"  start[j] + duration[j]  ≤  {deadline}  (meet deadline)")
    if "machine_capacity_minutes_per_day" in mappings:
        lines.append(
            f"  Σ duration[j assigned to k]  ≤  {ref('machine_capacity_minutes_per_day')}[k]  (capacity)"
        )
    if "current_inventory" in mappings and "demand_quantity" in mappings:
        lines.append(
            f"  net_production[j]  =  max(0,  {ref('demand_quantity')}[j]"
            f"  −  {ref('current_inventory')}[j])  (use stock first)"
        )
    lines.append("")

    # Objective
    lines.append("[bold]Objective:[/bold]")
    if obj_name == "minimize_makespan":
        lines.append("  minimize  max( start[j] + duration[j]  for all j )")
    elif obj_name == "minimize_tardiness":
        lines.append("  minimize  Σ max(0,  start[j] + duration[j] − deadline[j])")
    else:
        lines.append(f"  {obj_name}")

    body = "\n".join(lines)
    console.print(
        Panel(
            body,
            title="[bold cyan]CP-SAT MODEL VARIABLES  (based on your mapped data)[/bold cyan]",
            border_style="cyan",
        )
    )
