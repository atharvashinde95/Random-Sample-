"""
LangChain tools for the SchemaMappingAgent ReAct loop.

These wrap workbook_tools functions so the LLM agent can explore
the workbook autonomously. All data comes from the in-memory cache
populated by Node 1 (workbook profiling) — no file re-reading.
"""
from __future__ import annotations

import json
from typing import Any

from langchain_core.tools import tool

from app.tools import workbook_tools


# ---------------------------------------------------------------------------
# Module-level state — set by SchemaMappingAgent before the loop starts
# ---------------------------------------------------------------------------
_file_path: str = ""
_workbook_profile: dict[str, Any] = {}


def configure(file_path: str, workbook_profile: dict[str, Any]) -> None:
    """Called by SchemaMappingAgent.run() to inject context before the loop."""
    global _file_path, _workbook_profile
    _file_path = file_path
    _workbook_profile = workbook_profile


# ---------------------------------------------------------------------------
# Tool 1: list_sheets
# ---------------------------------------------------------------------------
@tool
def list_sheets() -> str:
    """List all sheet names in the workbook. Call this first to see what data is available."""
    sheets = _workbook_profile.get("sheets", {})
    result = {
        "sheet_count": len(sheets),
        "sheets": [
            {"name": name, "row_count": info.get("row_count", 0), "column_count": len(info.get("columns", []))}
            for name, info in sheets.items()
        ],
    }
    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# Tool 2: get_sheet_info
# ---------------------------------------------------------------------------
@tool
def get_sheet_info(sheet_name: str) -> str:
    """Get all columns, their data types, null counts, and row count for a specific sheet.
    Use this to understand what data a sheet contains before mapping concepts."""
    sheets = _workbook_profile.get("sheets", {})
    if sheet_name not in sheets:
        return json.dumps({"error": f"Sheet '{sheet_name}' not found. Available: {list(sheets.keys())}"})
    info = sheets[sheet_name]
    result = {
        "sheet": sheet_name,
        "row_count": info.get("row_count", 0),
        "columns": [],
    }
    cols_info = info.get("columns_info", {})
    for col in info.get("columns", []):
        col_detail = cols_info.get(col, {})
        result["columns"].append({
            "name": col,
            "dtype": info.get("dtypes", {}).get(col, "?"),
            "nulls": info.get("null_counts", {}).get(col, 0),
            "unique": info.get("unique_counts", {}).get(col, 0),
            "pattern_hint": col_detail.get("pattern_hint", ""),
        })
    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# Tool 3: get_column_details
# ---------------------------------------------------------------------------
@tool
def get_column_details(sheet_name: str, column_name: str) -> str:
    """Get detailed info for a specific column: sample values, min/max, nulls, pattern.
    Use this to verify that a column matches a scheduling concept."""
    sheets = _workbook_profile.get("sheets", {})
    if sheet_name not in sheets:
        return json.dumps({"error": f"Sheet '{sheet_name}' not found"})
    info = sheets[sheet_name]
    if column_name not in info.get("columns", []):
        return json.dumps({"error": f"Column '{column_name}' not found in '{sheet_name}'. Available: {info.get('columns', [])}"})

    cols_info = info.get("columns_info", {})
    col_detail = cols_info.get(column_name, {})
    top_vals = col_detail.get("top_values", {})
    sample_list = list(top_vals.keys())[:5]

    result = {
        "sheet": sheet_name,
        "column": column_name,
        "dtype": info.get("dtypes", {}).get(column_name, "?"),
        "nulls": info.get("null_counts", {}).get(column_name, 0),
        "unique": info.get("unique_counts", {}).get(column_name, 0),
        "pattern_hint": col_detail.get("pattern_hint", ""),
        "sample_values": sample_list,
    }
    if "min" in col_detail:
        result["min"] = col_detail["min"]
    if "max" in col_detail:
        result["max"] = col_detail["max"]
    if "mean" in col_detail:
        result["mean"] = col_detail["mean"]
    if "negative_count" in col_detail:
        result["negative_count"] = col_detail["negative_count"]
    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# Tool 4: check_value_overlap
# ---------------------------------------------------------------------------
@tool
def check_value_overlap(from_sheet: str, from_column: str, to_sheet: str, to_column: str) -> str:
    """Check if values in from_column exist in to_column (referential integrity).
    Use this to verify relationships between sheets, e.g. foreign key checks."""
    result = workbook_tools.check_referential_integrity(
        _file_path, from_sheet, from_column, to_sheet, to_column
    )
    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# Tool 5: submit_mapping
# ---------------------------------------------------------------------------
@tool
def submit_mapping(mapping_json: str) -> str:
    """Submit your final mapping as a JSON string. Call this ONLY when you have mapped
    ALL required concepts. The JSON must have this shape:
    {
      "mappings": [{"concept": "...", "sheet": "...", "column": "...", "confidence": 0.95, "reasoning": "..."}],
      "unmapped_concepts": ["concept names you could not find"],
      "relationships": [{"name": "...", "from_sheet": "...", "from_col": "...", "to_sheet": "...", "to_col": "...", "overlap_verified": true}]
    }"""
    return mapping_json


# ---------------------------------------------------------------------------
# All tools list (used by agent.bind_tools)
# ---------------------------------------------------------------------------
ALL_TOOLS = [list_sheets, get_sheet_info, get_column_details, check_value_overlap, submit_mapping]
