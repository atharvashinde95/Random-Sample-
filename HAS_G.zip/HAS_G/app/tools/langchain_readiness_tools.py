"""
LangChain tool wrappers for the ReadinessValidationAgent.

Tools use a module-level active file path so the agent doesn't need
to pass the file path in every Action Input.

Call set_active_file(path) before creating the agent executor.
"""
from __future__ import annotations

import json
import re
from typing import Any

from langchain_core.tools import tool

from app.tools import workbook_tools

_active_file_path: str = ""


def set_active_file(path: str) -> None:
    global _active_file_path
    _active_file_path = path


def _dumps(result: Any) -> str:
    return json.dumps(result, indent=2, default=str)


def _parse_input(tool_input: Any) -> dict[str, Any]:
    if isinstance(tool_input, dict):
        return tool_input
    text = str(tool_input).strip()

    # Strip markdown code fences
    if "```" in text:
        text = re.sub(r"```[a-zA-Z0-9]*\n?", "", text)
        text = text.replace("```", "").strip()

    # Strip "JSON " prefix that qwen2.5 prepends to Action Inputs
    if text.upper().startswith("JSON "):
        text = text[5:].strip()

    # Strip wrapping quotes
    if len(text) >= 2 and (
        (text[0] == '"' and text[-1] == '"')
        or (text[0] == "'" and text[-1] == "'")
    ):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, dict):
                return parsed
            text = str(parsed)
        except Exception:
            text = text[1:-1]

    # Parse JSON object
    if text.startswith("{"):
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                return data
        except Exception:
            pass

    return {"raw": text}


@tool
def check_column_exists_tool(tool_input: str) -> str:
    """Check whether a column exists in a sheet.
    Input: JSON {"sheet_name": "Demand", "column_name": "qty_required"}"""
    args = _parse_input(tool_input)
    sheet_name = args.get("sheet_name") or args.get("sheet", "")
    column_name = args.get("column_name") or args.get("column", "")
    return _dumps(workbook_tools.check_column_exists(_active_file_path, str(sheet_name), str(column_name)))


@tool
def check_column_numeric_tool(tool_input: str) -> str:
    """Check whether a column contains numeric values.
    Input: JSON {"sheet_name": "Demand", "column_name": "qty_required"}"""
    args = _parse_input(tool_input)
    sheet_name = args.get("sheet_name") or args.get("sheet", "")
    column_name = args.get("column_name") or args.get("column", "")
    return _dumps(workbook_tools.check_column_numeric(_active_file_path, str(sheet_name), str(column_name)))


@tool
def check_column_no_nulls_tool(tool_input: str) -> str:
    """Check whether a column has any null/missing values.
    Input: JSON {"sheet_name": "Demand", "column_name": "qty_required"}"""
    args = _parse_input(tool_input)
    sheet_name = args.get("sheet_name") or args.get("sheet", "")
    column_name = args.get("column_name") or args.get("column", "")
    return _dumps(workbook_tools.check_column_no_nulls(_active_file_path, str(sheet_name), str(column_name)))


@tool
def check_column_no_negatives_tool(tool_input: str) -> str:
    """Check whether a numeric column has any negative values.
    Input: JSON {"sheet_name": "Demand", "column_name": "qty_required"}"""
    args = _parse_input(tool_input)
    sheet_name = args.get("sheet_name") or args.get("sheet", "")
    column_name = args.get("column_name") or args.get("column", "")
    return _dumps(workbook_tools.check_column_no_negatives(_active_file_path, str(sheet_name), str(column_name)))


@tool
def check_referential_integrity_tool(tool_input: str) -> str:
    """Verify every value in from_col exists in to_col (foreign key / relationship check).
    Input: JSON {"from_sheet": "Demand", "from_col": "prod_code", "to_sheet": "Product_Inventory", "to_col": "pid"}"""
    args = _parse_input(tool_input)
    return _dumps(workbook_tools.check_referential_integrity(
        _active_file_path,
        str(args.get("from_sheet", "")),
        str(args.get("from_col", "")),
        str(args.get("to_sheet", "")),
        str(args.get("to_col", "")),
    ))


@tool
def describe_sheet_tool(tool_input: str) -> str:
    """Describe a sheet: columns, dtypes, row count, sample rows.
    Useful to confirm what columns are available before checking them.
    Input: JSON {"sheet_name": "Demand"} or just the sheet name."""
    args = _parse_input(tool_input)
    sheet_name = args.get("sheet_name") or args.get("sheet") or args.get("raw", "")
    return _dumps(workbook_tools.describe_sheet(_active_file_path, str(sheet_name).strip()))


READINESS_TOOLS = [
    check_column_exists_tool,
    check_column_numeric_tool,
    check_column_no_nulls_tool,
    check_column_no_negatives_tool,
    check_referential_integrity_tool,
    describe_sheet_tool,
]
