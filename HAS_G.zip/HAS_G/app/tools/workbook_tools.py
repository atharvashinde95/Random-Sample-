"""
Schema-agnostic workbook loader and primitive validation tools.

All functions are parameterized — no hardcoded column names, no domain assumptions.
Supports .xlsx, .xls (multi-sheet) and .csv (treated as a single sheet named "Sheet1").
The agents decide what to check; these tools perform the factual checks.

The profiler scans the full file but sends only compact summaries and representative
samples to the LLM. Full validation is performed on the complete dataset.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

# ---------------------------------------------------------------------------
# Internal cache — load each sheet once per file path per agent run
# ---------------------------------------------------------------------------
_cache: dict[str, dict[str, pd.DataFrame]] = {}


def reset_cache() -> None:
    _cache.clear()


def load_virtual_schema(file_path: str, frames: dict[str, pd.DataFrame]) -> None:
    """Pre-load virtual DataFrames (from schema text extraction) into the cache."""
    _cache[file_path] = frames


def _load_workbook(file_path: str) -> dict[str, pd.DataFrame]:
    if file_path in _cache:
        return _cache[file_path]
    p = Path(file_path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    ext = p.suffix.lower()
    if ext in (".xlsx", ".xls"):
        sheets: dict[str, pd.DataFrame] = pd.read_excel(file_path, sheet_name=None)
    elif ext == ".csv":
        sheets = {"Sheet1": pd.read_csv(file_path)}
    else:
        raise ValueError(f"Unsupported file type: {ext!r}. Use .xlsx, .xls, or .csv")
    _cache[file_path] = sheets
    return sheets


# ---------------------------------------------------------------------------
# Profile builder (used by the workbook_profiler_node)
# ---------------------------------------------------------------------------

def _representative_sample(df: pd.DataFrame, n_per_position: int = 2, n_random: int = 3) -> list[dict]:
    """Return first 2, middle 2, last 2, and 3 random rows — deduplicated, compact."""
    if len(df) == 0:
        return []
    rows: list[pd.DataFrame] = []
    rows.append(df.head(n_per_position))
    mid = len(df) // 2
    rows.append(df.iloc[max(0, mid - 1): mid + 1])
    rows.append(df.tail(n_per_position))
    combined = pd.concat(rows).drop_duplicates()
    if len(df) > len(combined):
        rand_n = min(n_random, len(df))
        rnd = df.sample(n=rand_n, random_state=42)
        combined = pd.concat([combined, rnd]).drop_duplicates()
    return combined.fillna("").to_dict(orient="records")


def profile_workbook(file_path: str) -> dict[str, Any]:
    """Build a compact schema profile of every sheet in the workbook.

    Scans the full file but sends only compact summaries and representative
    samples to the LLM. Full validation is performed on the complete dataset.
    """
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

    profile: dict[str, Any] = {
        "ok": True,
        "file_path": file_path,
        "file_type": Path(file_path).suffix.lower(),
        "sheet_count": len(sheets),
        "sheets": {},
    }

    for sheet_name, df in sheets.items():
        row_count = int(len(df))
        null_counts = {k: int(v) for k, v in df.isnull().sum().to_dict().items()}
        unique_counts = {col: int(df[col].nunique()) for col in df.columns}

        columns_info: dict[str, Any] = {}
        for col in df.columns:
            null_c = null_counts.get(col, 0)
            null_pct = round(null_c / row_count * 100, 1) if row_count > 0 else 0.0
            top_values = (
                df[col].dropna().astype(str).value_counts().head(5).to_dict()
            )
            # Detect a simple pattern hint
            sample_vals = df[col].dropna().astype(str)
            if len(sample_vals) == 0:
                pattern_hint = "empty"
            elif pd.to_numeric(df[col], errors="coerce").notna().sum() > len(df[col]) * 0.8:
                pattern_hint = "numeric"
            elif sample_vals.str.match(r"^\d{4}-\d{2}-\d{2}").mean() > 0.5:
                pattern_hint = "date"
            elif sample_vals.str.len().mean() < 20:
                pattern_hint = "short_string"
            else:
                pattern_hint = "text"

            col_info: dict[str, Any] = {
                "dtype": str(df[col].dtype),
                "null_count": null_c,
                "null_pct": null_pct,
                "unique_count": unique_counts.get(col, 0),
                "top_values": top_values,
                "pattern_hint": pattern_hint,
            }

            # Numeric stats on the full column
            coerced = pd.to_numeric(df[col], errors="coerce")
            if coerced.notna().sum() > 0:
                col_info["min"] = float(coerced.min())
                col_info["max"] = float(coerced.max())
                col_info["mean"] = round(float(coerced.mean()), 2)
                col_info["negative_count"] = int((coerced < 0).sum())

            columns_info[col] = col_info

        profile["sheets"][sheet_name] = {
            "columns": list(df.columns),
            "dtypes": df.dtypes.astype(str).to_dict(),
            "row_count": row_count,
            "representative_sample": _representative_sample(df),
            "null_counts": null_counts,
            "unique_counts": unique_counts,
            "columns_info": columns_info,
        }

    return profile


# ---------------------------------------------------------------------------
# Exploration tools (used by SchemaMappingAgent)
# ---------------------------------------------------------------------------

def list_sheets(file_path: str) -> dict[str, Any]:
    try:
        sheets = _load_workbook(file_path)
        return {"ok": True, "sheets": list(sheets.keys()), "count": len(sheets)}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def describe_sheet(file_path: str, sheet_name: str) -> dict[str, Any]:
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if sheet_name not in sheets:
        available = list(sheets.keys())
        return {"ok": False, "error": f"Sheet '{sheet_name}' not found. Available: {available}"}
    df = sheets[sheet_name]
    return {
        "ok": True,
        "sheet": sheet_name,
        "columns": list(df.columns),
        "dtypes": df.dtypes.astype(str).to_dict(),
        "row_count": int(len(df)),
        "sample_rows": df.head(5).fillna("").to_dict(orient="records"),
    }


def sample_column(file_path: str, sheet_name: str, column_name: str, n: int = 10) -> dict[str, Any]:
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if sheet_name not in sheets:
        return {"ok": False, "error": f"Sheet '{sheet_name}' not found"}
    df = sheets[sheet_name]
    if column_name not in df.columns:
        return {
            "ok": False,
            "error": f"Column '{column_name}' not in sheet '{sheet_name}'",
            "available_columns": list(df.columns),
        }
    values = df[column_name].dropna().head(n).tolist()
    return {
        "ok": True,
        "sheet": sheet_name,
        "column": column_name,
        "sample_values": values,
        "dtype": str(df[column_name].dtype),
    }


def column_stats(file_path: str, sheet_name: str, column_name: str) -> dict[str, Any]:
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if sheet_name not in sheets:
        return {"ok": False, "error": f"Sheet '{sheet_name}' not found"}
    df = sheets[sheet_name]
    if column_name not in df.columns:
        return {"ok": False, "error": f"Column '{column_name}' not in sheet '{sheet_name}'"}
    col = df[column_name]
    null_count = int(col.isnull().sum())
    unique_count = int(col.nunique())
    result: dict[str, Any] = {
        "ok": True,
        "sheet": sheet_name,
        "column": column_name,
        "row_count": int(len(col)),
        "null_count": null_count,
        "null_pct": round(null_count / len(col) * 100, 1) if len(col) > 0 else 0,
        "unique_count": unique_count,
        "dtype": str(col.dtype),
    }
    coerced = pd.to_numeric(col, errors="coerce")
    if coerced.notna().sum() > 0:
        result["min"] = float(coerced.min())
        result["max"] = float(coerced.max())
        result["mean"] = round(float(coerced.mean()), 2)
    return result


def find_common_values(
    file_path: str, sheet_a: str, col_a: str, sheet_b: str, col_b: str
) -> dict[str, Any]:
    """Value overlap between two columns — detects join/relationship candidates."""
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    for sheet, col in [(sheet_a, col_a), (sheet_b, col_b)]:
        if sheet not in sheets:
            return {"ok": False, "error": f"Sheet '{sheet}' not found"}
        if col not in sheets[sheet].columns:
            return {"ok": False, "error": f"Column '{col}' not in sheet '{sheet}'"}
    set_a = set(sheets[sheet_a][col_a].dropna().astype(str))
    set_b = set(sheets[sheet_b][col_b].dropna().astype(str))
    common = set_a & set_b
    return {
        "ok": True,
        "overlap_count": len(common),
        "set_a_count": len(set_a),
        "set_b_count": len(set_b),
        "overlap_pct_a": round(len(common) / len(set_a) * 100, 1) if set_a else 0,
        "overlap_pct_b": round(len(common) / len(set_b) * 100, 1) if set_b else 0,
        "sample_common": sorted(common)[:5],
    }


def find_join_candidates(file_path: str, sheet_a: str, sheet_b: str) -> dict[str, Any]:
    """For each column pair between two sheets, compute overlap count and pct.

    Returns top 5 candidates sorted by overlap_pct descending.
    """
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if sheet_a not in sheets:
        return {"ok": False, "error": f"Sheet '{sheet_a}' not found"}
    if sheet_b not in sheets:
        return {"ok": False, "error": f"Sheet '{sheet_b}' not found"}

    df_a = sheets[sheet_a]
    df_b = sheets[sheet_b]
    candidates: list[dict[str, Any]] = []

    for col_a in df_a.columns:
        set_a = set(df_a[col_a].dropna().astype(str))
        if not set_a:
            continue
        for col_b in df_b.columns:
            set_b = set(df_b[col_b].dropna().astype(str))
            if not set_b:
                continue
            common = set_a & set_b
            if not common:
                continue
            overlap_pct = round(len(common) / min(len(set_a), len(set_b)) * 100, 1)
            candidates.append({
                "col_a": col_a,
                "col_b": col_b,
                "overlap_count": len(common),
                "overlap_pct": overlap_pct,
                "sample_common": sorted(common)[:3],
            })

    candidates.sort(key=lambda x: x["overlap_pct"], reverse=True)
    return {
        "ok": True,
        "sheet_a": sheet_a,
        "sheet_b": sheet_b,
        "top_candidates": candidates[:5],
    }


def check_unique_values(file_path: str, sheet_name: str, column_name: str, n: int = 10) -> dict[str, Any]:
    """Return top n unique values and their counts for a column."""
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if sheet_name not in sheets:
        return {"ok": False, "error": f"Sheet '{sheet_name}' not found"}
    df = sheets[sheet_name]
    if column_name not in df.columns:
        return {
            "ok": False,
            "error": f"Column '{column_name}' not in sheet '{sheet_name}'",
            "available_columns": list(df.columns),
        }
    counts = df[column_name].dropna().astype(str).value_counts().head(n).to_dict()
    return {
        "ok": True,
        "sheet": sheet_name,
        "column": column_name,
        "total_unique": int(df[column_name].nunique()),
        "top_values": counts,
    }


# ---------------------------------------------------------------------------
# Primitive validation checks (used by ReadinessValidationAgent)
# ---------------------------------------------------------------------------

def check_column_exists(file_path: str, sheet_name: str, column_name: str) -> dict[str, Any]:
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "exists": False, "error": str(exc)}
    if sheet_name not in sheets:
        return {"ok": False, "exists": False, "reason": f"Sheet '{sheet_name}' not found"}
    exists = column_name in sheets[sheet_name].columns
    return {"ok": exists, "exists": exists, "sheet": sheet_name, "column": column_name}


def check_column_numeric(file_path: str, sheet_name: str, column_name: str) -> dict[str, Any]:
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if sheet_name not in sheets or column_name not in sheets[sheet_name].columns:
        return {"ok": False, "error": "Sheet or column not found"}
    col = sheets[sheet_name][column_name]
    original_null = int(col.isnull().sum())
    coerced = pd.to_numeric(col, errors="coerce")
    coerced_null = int(coerced.isnull().sum())
    non_numeric_count = max(0, coerced_null - original_null)
    is_numeric = non_numeric_count == 0
    return {
        "ok": bool(is_numeric),
        "sheet": sheet_name,
        "column": column_name,
        "is_numeric": bool(is_numeric),
        "non_numeric_count": non_numeric_count,
        "dtype": str(col.dtype),
    }


def check_column_no_nulls(file_path: str, sheet_name: str, column_name: str) -> dict[str, Any]:
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if sheet_name not in sheets or column_name not in sheets[sheet_name].columns:
        return {"ok": False, "error": "Sheet or column not found"}
    col = sheets[sheet_name][column_name]
    null_count = int(col.isnull().sum())
    return {
        "ok": null_count == 0,
        "sheet": sheet_name,
        "column": column_name,
        "null_count": null_count,
        "row_count": int(len(col)),
    }


def check_column_no_negatives(file_path: str, sheet_name: str, column_name: str) -> dict[str, Any]:
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if sheet_name not in sheets or column_name not in sheets[sheet_name].columns:
        return {"ok": False, "error": "Sheet or column not found"}
    col = pd.to_numeric(sheets[sheet_name][column_name], errors="coerce")
    negative_count = int((col < 0).sum())
    return {
        "ok": negative_count == 0,
        "sheet": sheet_name,
        "column": column_name,
        "negative_count": negative_count,
    }


def check_referential_integrity(
    file_path: str, from_sheet: str, from_col: str, to_sheet: str, to_col: str
) -> dict[str, Any]:
    """Verify every value in from_col exists in to_col (foreign key check)."""
    try:
        sheets = _load_workbook(file_path)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    for sheet, col in [(from_sheet, from_col), (to_sheet, to_col)]:
        if sheet not in sheets:
            return {"ok": False, "error": f"Sheet '{sheet}' not found"}
        if col not in sheets[sheet].columns:
            return {"ok": False, "error": f"Column '{col}' not in sheet '{sheet}'"}
    from_vals = set(sheets[from_sheet][from_col].dropna().astype(str))
    to_vals = set(sheets[to_sheet][to_col].dropna().astype(str))
    orphans = from_vals - to_vals
    return {
        "ok": len(orphans) == 0,
        "from_sheet": from_sheet,
        "from_col": from_col,
        "to_sheet": to_sheet,
        "to_col": to_col,
        "total_from": len(from_vals),
        "orphan_count": len(orphans),
        "orphan_examples": sorted(orphans)[:5],
    }
