"""
LangChain tool wrappers for the SchemaMappingAgent.

Tools use a module-level active file path so the agent doesn't need
to pass the file path in every Action Input.

Call set_active_file(path) before creating the agent executor.
"""
from __future__ import annotations

import json
import re
from typing import Any

from langchain_core.tools import tool

from app.tools import workbook_tools

_active_file_path: str = ""


def set_active_file(path: str) -> None:
    global _active_file_path
    _active_file_path = path


def _dumps(result: Any) -> str:
    return json.dumps(result, indent=2, default=str)


def _parse_input(tool_input: Any) -> dict[str, Any]:
    if isinstance(tool_input, dict):
        return tool_input
    text = str(tool_input).strip()

    # Strip markdown code fences (small models sometimes wrap JSON in ```json...```)
    if "```" in text:
        text = re.sub(r"```[a-zA-Z0-9]*\n?", "", text)
        text = text.replace("```", "").strip()

    # Strip "JSON " prefix that qwen2.5 prepends to Action Inputs
    if text.upper().startswith("JSON "):
        text = text[5:].strip()

    # Strip wrapping single or double quotes
    if len(text) >= 2 and (
        (text[0] == '"' and text[-1] == '"')
        or (text[0] == "'" and text[-1] == "'")
    ):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, dict):
                return parsed
            text = str(parsed)
        except Exception:
            text = text[1:-1]

    # Parse JSON object
    if text.startswith("{"):
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                return data
        except Exception:
            pass

    return {"raw": text}


@tool
def list_sheets_tool(tool_input: str = "") -> str:
    """List all sheet names in the workbook. No input required."""
    return _dumps(workbook_tools.list_sheets(_active_file_path))


@tool
def describe_sheet_tool(tool_input: str) -> str:
    """Describe a sheet: columns, dtypes, row count, sample rows.
    Input: JSON {"sheet_name": "Demand"} or just the sheet name as a string."""
    args = _parse_input(tool_input)
    sheet_name = (
        args.get("sheet_name")
        or args.get("sheet")
        or args.get("raw", "")
    )
    sheet_name = str(sheet_name).strip()
    # If raw still looks like JSON, extract sheet_name from it
    if sheet_name.startswith("{"):
        try:
            inner = json.loads(sheet_name)
            sheet_name = inner.get("sheet_name") or inner.get("sheet") or sheet_name
        except Exception:
            pass
    return _dumps(workbook_tools.describe_sheet(_active_file_path, sheet_name))


@tool
def sample_column_tool(tool_input: str) -> str:
    """Sample values from a specific column to understand its contents.
    Input: JSON {"sheet_name": "Demand", "column_name": "qty_required", "n": 10}"""
    args = _parse_input(tool_input)
    sheet_name = args.get("sheet_name") or args.get("sheet", "")
    column_name = args.get("column_name") or args.get("column", "")
    n = int(args.get("n", 10))
    return _dumps(workbook_tools.sample_column(_active_file_path, str(sheet_name), str(column_name), n))


@tool
def column_stats_tool(tool_input: str) -> str:
    """Get statistics for a column: null count, min, max, mean, unique count.
    Input: JSON {"sheet_name": "Demand", "column_name": "qty_required"}"""
    args = _parse_input(tool_input)
    sheet_name = args.get("sheet_name") or args.get("sheet", "")
    column_name = args.get("column_name") or args.get("column", "")
    return _dumps(workbook_tools.column_stats(_active_file_path, str(sheet_name), str(column_name)))


@tool
def find_common_values_tool(tool_input: str) -> str:
    """Check value overlap between two columns to detect join relationships.
    Input: JSON {"sheet_a": "Demand", "col_a": "prod_code", "sheet_b": "Product_Inventory", "col_b": "pid"}"""
    args = _parse_input(tool_input)
    return _dumps(workbook_tools.find_common_values(
        _active_file_path,
        str(args.get("sheet_a", "")),
        str(args.get("col_a", "")),
        str(args.get("sheet_b", "")),
        str(args.get("col_b", "")),
    ))


@tool
def find_join_candidates_tool(tool_input: str) -> str:
    """Find columns between two sheets with high value overlap (join candidates).
    Input: JSON {"sheet_a": "Demand", "sheet_b": "Product_Inventory"}"""
    args = _parse_input(tool_input)
    sheet_a = args.get("sheet_a") or args.get("sheet_name_a", "")
    sheet_b = args.get("sheet_b") or args.get("sheet_name_b", "")
    return _dumps(workbook_tools.find_join_candidates(
        _active_file_path,
        str(sheet_a),
        str(sheet_b),
    ))


SCHEMA_MAPPING_TOOLS = [
    list_sheets_tool,
    describe_sheet_tool,
    sample_column_tool,
    column_stats_tool,
    find_common_values_tool,
    find_join_candidates_tool,
]
