"""
Central configuration.
Groq settings and scheduling ontology live here.
"""
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

# ---------------------------------------------------------------------------
# Groq (llama-3.3-70b-versatile)
# ---------------------------------------------------------------------------
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
GROQ_MODEL = "llama-3.3-70b-versatile"

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUTS_DIR = BASE_DIR / "outputs" / "terminal_runs"
DEFAULT_FILE = DATA_DIR / "production_scheduling_sample.xlsx"

DEFAULT_USER_INPUT = (
    "We are planning tomorrow's production run. We have multiple production machines, "
    "customer orders, product processing times, current stock, earliest start dates, "
    "and delivery deadlines. Check whether this workbook has all the required data to "
    "build a CP-SAT production schedule that completes all jobs as early as possible."
)

# ---------------------------------------------------------------------------
# Canonical scheduling ontology
# These are the concepts the agents validate for — not column names.
# ---------------------------------------------------------------------------
SCHEDULING_CONCEPTS: dict[str, str] = {
    "order_id": "Unique identifier for a customer order or job",
    "product_id": "Identifier linking an order to a product in the product catalog",
    "product_name": "Human-readable label for a product",
    "demand_quantity": "Number of units to produce for an order (positive integer)",
    "current_inventory": "Quantity of a product currently in stock (non-negative integer)",
    "processing_time_per_unit": "Minutes required to produce one unit of a product",
    "machine_id": "Identifier of a specific production machine or production line",
    "machine_capacity_minutes_per_day": "Total available working minutes per machine per day",
    "earliest_start_day": "Earliest calendar day on which production of an order may begin",
    "due_day": "Calendar day by which an order must be completed",
    "due_time_minutes": "Minute of the due day by which the order must finish (e.g. 480 = end of 8h shift)",
    "earliest_start_time_minutes": "Minute of the earliest start day at which production may begin (e.g. 0 = start of shift)",
}

SCHEDULING_RELATIONSHIPS: dict[str, dict] = {
    "demand_to_product": {
        "description": "Every order must reference a product that exists in the product catalog",
        "from_concept": "product_id (in demand/orders sheet)",
        "to_concept": "product_id (in product catalog/inventory sheet)",
    },
    "order_to_timeline": {
        "description": "Every order must have a matching timeline or deadline record",
        "from_concept": "order_id (in demand/orders sheet)",
        "to_concept": "order_id (in timeline/deadline sheet)",
    },
}

# ---------------------------------------------------------------------------
# Data quality check requirements per canonical concept.
# This is part of the scheduling ontology — not file-specific.
# These define what makes each concept's data valid for CP-SAT.
# The ReadinessValidator executes these checks against the
# actual mapped columns (sheet/column chosen by the SchemaMappingAgent).
# ---------------------------------------------------------------------------
CONCEPT_CHECK_REQUIREMENTS: dict[str, list[str]] = {
    "order_id":                         ["exists", "no_nulls"],
    "product_id":                       ["exists", "no_nulls"],
    "product_name":                     ["exists"],
    "demand_quantity":                  ["exists", "no_nulls", "numeric", "non_negative"],
    "current_inventory":                ["exists", "no_nulls", "numeric", "non_negative"],
    "processing_time_per_unit":         ["exists", "no_nulls", "numeric", "non_negative"],
    "machine_id":                       ["exists", "no_nulls"],
    "machine_capacity_minutes_per_day": ["exists", "no_nulls", "numeric", "non_negative"],
    "earliest_start_day":               ["exists", "no_nulls", "numeric"],
    "earliest_start_time_minutes":      ["exists", "no_nulls", "numeric"],
    "due_day":                          ["exists", "no_nulls", "numeric"],
    "due_time_minutes":                 ["exists", "no_nulls", "numeric"],
}
