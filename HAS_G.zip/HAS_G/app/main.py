"""
Orchestrator entry point.
Auto-detects the file in the data folder.
Optionally accepts a schema context (column/table descriptions) to guide mapping.
"""
from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

from app.config import DATA_DIR, DEFAULT_USER_INPUT
from app.graph.workflow import build_workflow
from app.utils import logger
from app.utils.json_writer import create_run_dir

_SUPPORTED = (".xlsx", ".xls", ".csv")


def _find_data_files() -> list[Path]:
    return sorted(p for p in DATA_DIR.iterdir() if p.is_file() and p.suffix.lower() in _SUPPORTED)


def _pick_file() -> Path | None:
    files = _find_data_files()
    if len(files) == 1:
        return files[0]
    if not files:
        return None
    print("\nMultiple files found in the data folder:")
    for i, f in enumerate(files, start=1):
        print(f"  [{i}] {f.name}")
    try:
        choice = input("\nChoose a file (number, or ENTER for [1]):\n> ").strip()
    except (EOFError, KeyboardInterrupt):
        choice = ""
    if not choice:
        return files[0]
    if choice.isdigit() and 1 <= int(choice) <= len(files):
        return files[int(choice) - 1]
    return Path(choice)


def _prompt_multiline(prompt: str) -> str:
    """Read multiple lines until a blank line is entered."""
    print(prompt)
    lines: list[str] = []
    try:
        while True:
            line = input("> ")
            if line.strip() == "" and lines:
                break
            if line.strip() == "" and not lines:
                break
            lines.append(line)
    except (EOFError, KeyboardInterrupt):
        pass
    return " ".join(lines).strip()


def main() -> None:
    logger.banner()

    run_id = f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    output_dir = create_run_dir(run_id)
    logger.info("RUN", f"run_id     = {run_id}")
    logger.info("RUN", f"output dir = {output_dir}")

    # --- CLI mode: python run.py <file_path> "<requirement>" ---
    if len(sys.argv) >= 3:
        file_path = Path(sys.argv[1])
        user_input = " ".join(sys.argv[2:])
        schema_context = ""
        if not file_path.exists():
            logger.error("FILE", f"File not found: {file_path}")
            return
        logger.info("FILE", f"file = {file_path}")
        _run(run_id, str(file_path), user_input, schema_context, str(output_dir))
        return

    # --- Interactive mode ---

    # 1. Scheduling requirement
    try:
        user_input = input(
            "\nEnter your scheduling requirement"
            "\n(ENTER for default):\n> "
        ).strip()
    except (EOFError, KeyboardInterrupt):
        user_input = ""
    if not user_input:
        user_input = DEFAULT_USER_INPUT
        logger.info("INPUT", "Using default requirement")

    # 2. Optional schema context
    print(
        "\nOptionally describe your tables and columns so the agent maps them correctly."
        "\nExample: 'Demand table: order_id is the order number, demand_qty is units needed.'"
        "\n         'Product_Inventory: processing_time_min_per_unit is minutes per unit.'"
        "\n         'Demand.product_id links to Product_Inventory.product_id.'"
        "\n(Press ENTER to skip)"
    )
    try:
        schema_context = input("> ").strip()
    except (EOFError, KeyboardInterrupt):
        schema_context = ""

    if schema_context:
        logger.info("CONTEXT", "Schema context received — will guide column mapping")
    else:
        logger.info("CONTEXT", "No schema context — agent will infer from column names and samples")

    # 3. Auto-detect file
    file_path = _pick_file()
    if not file_path or not file_path.exists():
        logger.error("FILE", f"No supported file found in {DATA_DIR}")
        logger.error("FILE", "Place your .xlsx/.xls/.csv file there and try again.")
        return
    logger.info("FILE", f"file = {file_path}")

    _run(run_id, str(file_path), user_input, schema_context, str(output_dir))


def _run(run_id: str, file_path: str, user_input: str, schema_context: str, output_dir: str) -> None:
    logger.graph("START")
    build_workflow().invoke({
        "run_id": run_id,
        "file_path": file_path,
        "schema_context": schema_context,
        "output_dir": output_dir,
        "user_input": user_input,
        "errors": [],
        "warnings": [],
    })
