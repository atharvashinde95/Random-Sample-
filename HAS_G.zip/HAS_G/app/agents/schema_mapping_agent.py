"""
SchemaMappingAgent — ReAct Tool-Calling Agent

Maps workbook columns to canonical scheduling concepts using a ReAct
tool-calling loop powered by llama-3.3-70b-versatile via Groq.

The agent autonomously explores the workbook using tools:
  1. list_sheets()          → discover available sheets
  2. get_sheet_info()       → inspect columns/dtypes per sheet
  3. get_column_details()   → verify sample values for a column
  4. check_value_overlap()  → verify relationships between sheets
  5. submit_mapping()       → submit the final concept-to-column mapping

After the agent submits, deterministic Python validates every mapping
against the actual workbook profile and builds a confidence report.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_groq import ChatGroq

from app.config import (
    GROQ_API_KEY,
    GROQ_MODEL,
    SCHEDULING_CONCEPTS,
    SCHEDULING_RELATIONSHIPS,
)
from app.tools.agent_tools import ALL_TOOLS, configure as configure_tools
from app.utils import logger


MAX_AGENT_ITERATIONS = 25


@dataclass
class SchemaMappingResult:
    file_path: str
    llm_raw_response: str = ""
    mappings: list[dict[str, Any]] = field(default_factory=list)
    unmapped_concepts: list[str] = field(default_factory=list)
    ambiguities: list[dict[str, Any]] = field(default_factory=list)
    relationships: list[dict[str, Any]] = field(default_factory=list)
    mapping_ok: bool = False
    confidence_report: dict[str, Any] = field(default_factory=dict)
    validation_warnings: list[str] = field(default_factory=list)


class SchemaMappingAgent:
    def __init__(
        self,
        file_path: str,
        workbook_profile: dict[str, Any],
        user_requirement: dict[str, Any],
        schema_context: str = "",
    ):
        self.file_path = file_path
        self.workbook_profile = workbook_profile
        self.user_requirement = user_requirement
        self.schema_context = schema_context.strip()

        self._llm = ChatGroq(
            model=GROQ_MODEL,
            api_key=GROQ_API_KEY,
            temperature=0,
            max_tokens=4096,
        )
        self._llm_with_tools = self._llm.bind_tools(ALL_TOOLS)

    # ------------------------------------------------------------------
    # System prompt — tells the agent what to do (no hardcoding of data)
    # ------------------------------------------------------------------

    def _build_system_prompt(self) -> str:
        concepts_str = "\n".join(f"  {k}: {v}" for k, v in SCHEDULING_CONCEPTS.items())
        relationships_str = "\n".join(
            f"  {name}: {info['description']}" for name, info in SCHEDULING_RELATIONSHIPS.items()
        )
        required = self.user_requirement.get("required_concepts", [])
        required_str = ", ".join(required)

        schema_block = ""
        if self.schema_context:
            schema_block = f"""
The user provided this description of their data:
{self.schema_context}
Use this to guide your exploration, but always verify with the tools.
"""

        return f"""You are a Schema Mapping Agent. Your job is to map canonical scheduling
concepts to actual columns in a workbook.

CANONICAL SCHEDULING CONCEPTS (the concepts you must map):
{concepts_str}

KNOWN RELATIONSHIPS:
{relationships_str}

REQUIRED CONCEPTS TO MAP:
{required_str}

{schema_block}
YOUR TASK:
1. Start by calling list_sheets() to see what sheets are available.
2. For each sheet, call get_sheet_info() to see its columns and data types.
3. For columns that might match a required concept, call get_column_details() to verify.
4. For relationships (e.g. foreign keys between sheets), call check_value_overlap().
5. When you have mapped ALL required concepts, call submit_mapping() with your JSON.

RULES:
- Map ONLY to columns that actually exist in the workbook.
- Set confidence between 0.0 and 1.0 based on how well the column matches.
- Include a brief reasoning for each mapping.
- If you truly cannot find a column for a concept, put it in unmapped_concepts.
- Verify at least the key relationships (e.g. demand_to_product, order_to_timeline).
- Do NOT guess or hallucinate column names — use the tools to verify.
"""

    # ------------------------------------------------------------------
    # ReAct tool-calling loop
    # ------------------------------------------------------------------

    def _run_agent_loop(self) -> tuple[str, list[dict[str, Any]]]:
        """Run the ReAct loop. Returns (final_mapping_json, trace)."""
        system_msg = SystemMessage(content=self._build_system_prompt())
        human_msg = HumanMessage(
            content="Please explore the workbook and map all required concepts to columns. "
            "Start by listing the sheets."
        )
        messages = [system_msg, human_msg]
        trace: list[dict[str, Any]] = []
        final_mapping_json = ""

        # Build a tool lookup
        tool_map = {t.name: t for t in ALL_TOOLS}

        for iteration in range(MAX_AGENT_ITERATIONS):
            response = self._llm_with_tools.invoke(messages)
            messages.append(response)

            # Check if the LLM made tool calls
            tool_calls = response.tool_calls if hasattr(response, "tool_calls") else []

            if not tool_calls:
                # No tool calls — agent is done or stuck
                logger.info("MAPPING AGENT", f"Iteration {iteration + 1}: No tool calls (agent finished reasoning)")
                trace.append({"iteration": iteration + 1, "action": "no_tool_call", "content": response.content[:200] if response.content else ""})
                break

            for tc in tool_calls:
                tool_name = tc["name"]
                tool_args = tc["args"]
                logger.info("MAPPING AGENT", f"Iteration {iteration + 1}: {tool_name}({json.dumps(tool_args)[:100]})")

                # Execute the tool
                tool_fn = tool_map.get(tool_name)
                if tool_fn is None:
                    tool_result = json.dumps({"error": f"Unknown tool: {tool_name}"})
                else:
                    try:
                        tool_result = tool_fn.invoke(tool_args)
                    except Exception as e:
                        tool_result = json.dumps({"error": str(e)})

                trace.append({
                    "iteration": iteration + 1,
                    "tool": tool_name,
                    "args": tool_args,
                    "result_preview": str(tool_result)[:200],
                })

                # If submit_mapping was called, capture the result and stop
                if tool_name == "submit_mapping":
                    final_mapping_json = tool_result
                    logger.info("MAPPING AGENT", f"Agent submitted mapping at iteration {iteration + 1}")
                    # Add tool message and break
                    from langchain_core.messages import ToolMessage
                    messages.append(ToolMessage(content="Mapping submitted successfully.", tool_call_id=tc["id"]))
                    return final_mapping_json, trace

                # Feed observation back to the agent
                from langchain_core.messages import ToolMessage
                messages.append(ToolMessage(content=str(tool_result), tool_call_id=tc["id"]))

        return final_mapping_json, trace

    # ------------------------------------------------------------------
    # JSON parsing
    # ------------------------------------------------------------------

    def _extract_json(self, text: str) -> dict[str, Any] | None:
        text = text.strip()
        if "```" in text:
            text = re.sub(r"```[a-zA-Z0-9]*\n?", "", text).replace("```", "").strip()
        start = text.find("{")
        if start == -1:
            return None
        depth = 0
        for i in range(start, len(text)):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[start: i + 1])
                    except json.JSONDecodeError:
                        break
        return None

    # ------------------------------------------------------------------
    # Validation against actual profile (deterministic — no LLM)
    # ------------------------------------------------------------------

    def _validate_mappings(
        self, mappings: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], list[str]]:
        """Validate that each mapping references a real sheet and column in the profile.

        Returns (valid_mappings, validation_warnings).
        """
        sheets = self.workbook_profile.get("sheets", {})
        valid: list[dict[str, Any]] = []
        warnings: list[str] = []

        for m in mappings:
            if not isinstance(m, dict):
                continue
            sheet = m.get("sheet", "")
            col = m.get("column", "")
            if sheet not in sheets:
                warnings.append(
                    f"Mapping for '{m.get('concept')}' references unknown sheet '{sheet}'"
                )
                continue
            if col not in sheets[sheet].get("columns", []):
                warnings.append(
                    f"Mapping for '{m.get('concept')}' references unknown column '{col}' in sheet '{sheet}'"
                )
                continue
            valid.append(m)

        return valid, warnings

    # ------------------------------------------------------------------
    # Confidence report (deterministic — no LLM)
    # ------------------------------------------------------------------

    def _build_confidence_report(
        self,
        mappings: list[dict[str, Any]],
        required_concepts: list[str],
        unmapped: list[str],
    ) -> dict[str, Any]:
        mapped_concepts = {m.get("concept") for m in mappings}
        total_required = len(required_concepts)
        total_mapped = len([c for c in required_concepts if c in mapped_concepts])
        total_unmapped = total_required - total_mapped

        accepted_count = 0
        warned_count = 0
        low_confidence_count = 0
        per_concept: list[dict[str, Any]] = []

        for concept in required_concepts:
            mapping = next((m for m in mappings if m.get("concept") == concept), None)
            if mapping is None:
                status = "low_confidence"
                confidence = 0.0
                low_confidence_count += 1
            else:
                confidence = float(mapping.get("confidence", 0.0))
                if confidence >= 0.80:
                    status = "accepted"
                    accepted_count += 1
                elif confidence >= 0.60:
                    status = "warned"
                    warned_count += 1
                else:
                    status = "low_confidence"
                    low_confidence_count += 1

            per_concept.append({
                "concept": concept,
                "confidence": confidence,
                "status": status,
            })

        if total_required == 0 or total_mapped == total_required and low_confidence_count == 0:
            mapping_status = "VALID"
        elif total_mapped == 0:
            mapping_status = "FAILED"
        else:
            mapping_status = "PARTIAL"

        return {
            "total_required": total_required,
            "total_mapped": total_mapped,
            "total_unmapped": total_unmapped,
            "accepted_count": accepted_count,
            "warned_count": warned_count,
            "low_confidence_count": low_confidence_count,
            "mapping_status": mapping_status,
            "per_concept": per_concept,
        }

    # ------------------------------------------------------------------
    # Run — main entry point
    # ------------------------------------------------------------------

    def run(self) -> SchemaMappingResult:
        logger.info("MAPPING AGENT", f"Starting ReAct agent with {GROQ_MODEL} via Groq")

        required_concepts: list[str] = self.user_requirement.get("required_concepts", [])

        # Inject workbook context into tools
        configure_tools(self.file_path, self.workbook_profile)

        # Run the ReAct tool-calling loop
        raw_mapping_json, trace = self._run_agent_loop()

        # Parse the submitted mapping
        parsed = self._extract_json(raw_mapping_json) if raw_mapping_json else None

        if parsed is None:
            logger.warn("MAPPING AGENT", "Agent did not submit a valid mapping JSON")
            confidence_report = self._build_confidence_report([], required_concepts, required_concepts)
            return SchemaMappingResult(
                file_path=self.file_path,
                llm_raw_response=raw_mapping_json,
                mapping_ok=False,
                confidence_report=confidence_report,
                validation_warnings=["Agent did not produce valid mapping JSON"],
            )

        mappings = parsed.get("mappings", [])
        unmapped = parsed.get("unmapped_concepts", [])
        relationships = parsed.get("relationships", [])

        # Deterministic validation against actual profile
        mappings, val_warnings = self._validate_mappings(mappings)

        # Build confidence report
        confidence_report = self._build_confidence_report(mappings, required_concepts, unmapped)

        logger.info("MAPPING AGENT", f"Mapped {len(mappings)} concept(s), {len(unmapped)} unmapped")
        logger.info("MAPPING AGENT", f"Schema mapping status: {confidence_report.get('mapping_status')}")
        for m in mappings:
            conf = m.get("confidence", "?")
            logger.info(
                "MAPPING AGENT",
                f"  {m.get('concept')} -> {m.get('sheet')}.{m.get('column')} "
                f"(confidence={conf})",
            )

        if val_warnings:
            for w in val_warnings:
                logger.warn("MAPPING AGENT", w)

        return SchemaMappingResult(
            file_path=self.file_path,
            llm_raw_response=raw_mapping_json,
            mappings=mappings,
            unmapped_concepts=unmapped,
            relationships=relationships,
            mapping_ok=len(mappings) > 0,
            confidence_report=confidence_report,
            validation_warnings=val_warnings,
        )
