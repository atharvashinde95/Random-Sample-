"""
ReadinessValidator

Deterministic data quality checker — not an agent.
No LLM call, no reasoning loop. Takes the mapping produced by
SchemaMappingAgent and runs fixed checks on the actual file data.

Steps:
1. Build check_plan from mapping result + CONCEPT_CHECK_REQUIREMENTS
2. Execute each check deterministically using workbook_tools
3. Run referential integrity checks for mapped relationships
4. Return a grounded ReadinessResult
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from app.config import CONCEPT_CHECK_REQUIREMENTS
from app.tools import workbook_tools
from app.utils import logger


@dataclass
class ReadinessResult:
    file_path: str
    trace: list[dict[str, Any]] = field(default_factory=list)
    agent_final_answer: str = ""
    concept_checks: dict[str, Any] = field(default_factory=dict)
    relationship_checks: dict[str, Any] = field(default_factory=dict)
    overall_ready: bool = False
    blocking_issues: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    readiness_status: str = "UNKNOWN"


class ReadinessValidator:
    def __init__(
        self,
        file_path: str,
        schema_mapping: dict[str, Any],
        user_requirement: dict[str, Any],
        workbook_profile: dict[str, Any] | None = None,
    ):
        self.file_path = file_path
        self.schema_mapping = schema_mapping
        self.user_requirement = user_requirement
        self.workbook_profile = workbook_profile or {}
        self._required_concepts: list[str] = user_requirement.get("required_concepts", [])
        self._mappings: list[dict[str, Any]] = schema_mapping.get("mappings", [])
        self._mapping_lookup: dict[str, dict] = {
            m["concept"]: m for m in self._mappings if "concept" in m
        }

    def _build_check_plan(self) -> dict[str, Any]:
        """
        Build the check plan from the mapping result and canonical check requirements.
        No LLM call — CONCEPT_CHECK_REQUIREMENTS defines what each concept needs.
        """
        check_plan = []
        for concept in self._required_concepts:
            m = self._mapping_lookup.get(concept)
            if not m:
                continue  # unmapped — handled separately
            checks = CONCEPT_CHECK_REQUIREMENTS.get(concept, ["exists", "no_nulls"])
            check_plan.append({
                "concept": concept,
                "sheet": m.get("sheet", ""),
                "column": m.get("column", ""),
                "checks_needed": checks,
            })

        relationship_checks = []
        for rel in self.schema_mapping.get("relationships", []):
            relationship_checks.append({
                "name": rel.get("name", "unknown"),
                "from_sheet": rel.get("from_sheet", ""),
                "from_col": rel.get("from_col", ""),
                "to_sheet": rel.get("to_sheet", ""),
                "to_col": rel.get("to_col", ""),
            })

        return {"check_plan": check_plan, "relationship_checks": relationship_checks}

    def _execute_check_plan(self, plan: dict[str, Any]) -> dict[str, Any]:
        """Run every check in the plan using workbook_tools (deterministic)."""
        concept_checks: dict[str, Any] = {}

        for item in plan.get("check_plan", []):
            concept = item.get("concept", "")
            sheet = str(item.get("sheet", ""))
            col = str(item.get("column", ""))
            checks = item.get("checks_needed", ["exists", "no_nulls"])

            result: dict[str, Any] = {"mapped": True, "sheet": sheet, "column": col}

            if "exists" in checks:
                r = workbook_tools.check_column_exists(self.file_path, sheet, col)
                result["exists"] = r.get("exists", False)
                if not result["exists"]:
                    result["ok"] = False
                    result["reason"] = f"Column '{col}' not found in sheet '{sheet}'"
                    concept_checks[concept] = result
                    continue

            if "no_nulls" in checks:
                r = workbook_tools.check_column_no_nulls(self.file_path, sheet, col)
                result["no_nulls"] = r.get("ok", False)
                result["null_count"] = r.get("null_count", 0)

            if "numeric" in checks:
                r = workbook_tools.check_column_numeric(self.file_path, sheet, col)
                result["is_numeric"] = r.get("is_numeric", False)

            if "non_negative" in checks:
                r = workbook_tools.check_column_no_negatives(self.file_path, sheet, col)
                result["no_negatives"] = r.get("ok", False)
                result["negative_count"] = r.get("negative_count", 0)

            ok = result.get("exists", True)
            if "no_nulls" in result:
                ok = ok and result["no_nulls"]
            if "is_numeric" in result:
                ok = ok and result["is_numeric"]
            if "no_negatives" in result:
                ok = ok and result["no_negatives"]
            result["ok"] = ok
            concept_checks[concept] = result

        # Any required concept not in the plan is unmapped
        for concept in self._required_concepts:
            if concept not in concept_checks:
                m = self._mapping_lookup.get(concept)
                if m:
                    concept_checks[concept] = {
                        "mapped": True,
                        "sheet": m.get("sheet", ""),
                        "column": m.get("column", ""),
                        "ok": True,
                        "note": "no specific checks defined — assumed ok",
                    }
                else:
                    concept_checks[concept] = {
                        "mapped": False,
                        "ok": False,
                        "reason": "Concept not mapped to any column in the workbook",
                    }

        # Relationship checks
        relationship_checks: dict[str, Any] = {}
        for rel in plan.get("relationship_checks", []):
            rel_name = rel.get("name", "unknown")
            ri = workbook_tools.check_referential_integrity(
                self.file_path,
                str(rel.get("from_sheet", "")),
                str(rel.get("from_col", "")),
                str(rel.get("to_sheet", "")),
                str(rel.get("to_col", "")),
            )
            relationship_checks[rel_name] = ri

        blocking: list[str] = []
        for concept, v in concept_checks.items():
            if not v.get("ok", False):
                reason = v.get("reason") or _summarize_failures(v)
                blocking.append(f"{concept}: {reason}")
        for rel_name, v in relationship_checks.items():
            if not v.get("ok", True):
                orphans = v.get("orphan_count", "?")
                blocking.append(
                    f"{rel_name}: referential integrity failed — {orphans} orphan value(s)"
                )

        overall_ready = (
            all(v.get("ok", False) for v in concept_checks.values())
            and all(v.get("ok", True) for v in relationship_checks.values())
        )

        return {
            "concept_checks": concept_checks,
            "relationship_checks": relationship_checks,
            "overall_ready": overall_ready,
            "blocking_issues": blocking,
            "warnings": [],
        }

    def run(self) -> ReadinessResult:
        logger.info("READINESS", "Building check plan from ontology + mapping result")

        plan = self._build_check_plan()
        structured = self._execute_check_plan(plan)

        logger.info(
            "READINESS",
            f"Readiness: {'READY' if structured['overall_ready'] else 'NOT_READY'} "
            f"({len(structured['blocking_issues'])} blocking issue(s))"
        )

        return ReadinessResult(
            file_path=self.file_path,
            concept_checks=structured["concept_checks"],
            relationship_checks=structured["relationship_checks"],
            overall_ready=structured["overall_ready"],
            blocking_issues=structured["blocking_issues"],
            warnings=structured["warnings"],
            readiness_status="READY" if structured["overall_ready"] else "NOT_READY",
        )


def _summarize_failures(check: dict[str, Any]) -> str:
    failures: list[str] = []
    if not check.get("no_nulls", True):
        failures.append(f"{check.get('null_count', '?')} null value(s)")
    if "is_numeric" in check and not check["is_numeric"]:
        failures.append("column is not numeric")
    if "no_negatives" in check and not check["no_negatives"]:
        failures.append(f"{check.get('negative_count', '?')} negative value(s)")
    return "; ".join(failures) if failures else "check failed"
