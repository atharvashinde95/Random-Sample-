"""
Prompt templates for the LLM problem understanding step.
"""
from __future__ import annotations

from typing import Any

from app.config import SCHEDULING_CONCEPTS, SCHEDULING_RELATIONSHIPS


PROBLEM_UNDERSTANDING_SCHEMA = """{
  "problem_type": "<classify the type of scheduling/optimization problem based on the user's requirement>",
  "is_cpsat_compatible": true,
  "cpsat_compatibility_reason": "<one sentence explaining why this problem is or is not solvable with CP-SAT>",
  "objective": {"name": "<snake_case name derived from the user's stated goal>", "description": "<what the objective means in plain language>"},
  "requirement_coverage": [
    {
      "user_phrase": "<exact words or phrase the user used>",
      "mapped_concepts": ["<canonical_concept_name from the ontology>"],
      "required": true,
      "reason": "<one sentence why this is required for the user's stated goal>"
    }
  ],
  "required_concepts": ["<only concept names where required=true in requirement_coverage above>"],
  "optional_concepts": ["<concept names logically useful but NOT explicitly mentioned by user>"],
  "required_relationships": ["<relationship names from canonical relationships that this problem needs>"],
  "constraints": [
    {"name": "<constraint name>", "type": "hard or soft", "description": "<what this constraint means>", "concepts_needed": []}
  ],
  "constraint_validation": {
    "are_constraints_valid": true,
    "has_contradictions": false,
    "contradictions": [],
    "warnings": []
  },
  "missing_inputs": [],
  "assumptions": []
}"""


def _format_workbook_profile(workbook_profile: dict[str, Any]) -> str:
    """Compact — sheet names and column names only. No sample rows."""
    if not workbook_profile or not workbook_profile.get("ok"):
        return "(unavailable)"
    sheets = workbook_profile.get("sheets", {})
    lines: list[str] = []
    for sheet_name, info in sheets.items():
        cols = ", ".join(f'"{c}"' for c in info["columns"])
        lines.append(f"Sheet {sheet_name!r} ({info['row_count']} rows): {cols}")
    return "\n".join(lines)


def _format_ontology() -> str:
    concept_lines = "\n".join(f"  {k}: {v}" for k, v in SCHEDULING_CONCEPTS.items())
    rel_lines = "\n".join(
        f"  {name}: {info['description']}"
        for name, info in SCHEDULING_RELATIONSHIPS.items()
    )
    return (
        "CANONICAL CONCEPTS:\n" + concept_lines
        + "\n\nCANONICAL RELATIONSHIPS:\n" + rel_lines
    )


def build_understanding_prompt(user_input: str, workbook_profile: dict[str, Any]) -> str:
    profile_block = _format_workbook_profile(workbook_profile)
    ontology_block = _format_ontology()
    return f"""You are a scheduling and optimization analyst. Read the user's requirement carefully
and extract a structured JSON description based entirely on what the user actually said.

{ontology_block}

WORKBOOK PROFILE (for context only — do not use column names as concept names):
{profile_block}

USER REQUIREMENT:
\"\"\"{user_input}\"\"\"

INSTRUCTIONS:
1. Identify every data category the user mentioned (e.g. "job orders", "processing time", "deadlines").
2. Map each category to the closest canonical concept(s) from the ontology above.
3. Mark a concept as required=true if the user explicitly mentioned it OR if it is logically
   necessary to solve the stated objective.
4. A concept that is useful but not mentioned by the user goes in optional_concepts.
5. Identify any relationships needed (from canonical relationships above).
6. List all scheduling constraints the user implied (hard = must satisfy, soft = preferred).
7. Assess whether this problem can be solved by CP-SAT and explain why.

RULES:
- Use ONLY concept names from the canonical ontology above.
- Do NOT use actual column names from the workbook.
- required_concepts must match all entries where required=true in requirement_coverage.
- Output ONLY valid JSON. No prose, no markdown, no code fences.

{PROBLEM_UNDERSTANDING_SCHEMA}""".strip()


def build_fallback_understanding_prompt(user_input: str) -> str:
    """Minimal fallback when the full prompt returns empty or incomplete JSON."""
    concepts = ", ".join(SCHEDULING_CONCEPTS.keys())
    relationships = ", ".join(SCHEDULING_RELATIONSHIPS.keys())
    return f"""Return ONLY valid JSON. No prose. No markdown.

Analyze this scheduling requirement and extract required concepts.

USER REQUEST: {user_input}

Available canonical concepts: {concepts}
Available relationships: {relationships}

Read the user's requirement carefully. For each data category the user mentioned, map it
to the closest canonical concept from the list above and mark it required=true.
Derive problem_type, objective name, and cpsat_compatibility_reason from the user's actual words.

Output valid JSON in this shape (replace every <...> with values you derive from the user's requirement):
{{"problem_type":"<type of scheduling/optimization problem>","is_cpsat_compatible":true,"cpsat_compatibility_reason":"<reason based on user's requirement>","objective":{{"name":"<snake_case objective derived from user goal>","description":"<what the user wants to achieve>"}},"requirement_coverage":[{{"user_phrase":"<phrase from user>","mapped_concepts":["<concept>"],"required":true,"reason":"<why required>"}}],"required_concepts":["<concepts where required=true>"],"optional_concepts":[],"required_relationships":["<applicable relationships>"],"constraints":[],"constraint_validation":{{"are_constraints_valid":true,"has_contradictions":false,"contradictions":[],"warnings":[]}},"missing_inputs":[],"assumptions":[]}}""".strip()


def build_json_repair_prompt(broken_text: str) -> str:
    return f"""Fix this broken JSON. Output ONLY valid JSON. No prose, no fences.

BROKEN:
{broken_text}
""".strip()
