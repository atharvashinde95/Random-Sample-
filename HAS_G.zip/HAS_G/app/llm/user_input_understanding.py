"""
LLM problem understanding step — robust 4-attempt retry chain.

Attempt 1: full prompt, JSON mode
Attempt 2: full prompt, free-text mode
Attempt 3: simplified fallback prompt, free-text mode
Attempt 4: JSON repair on last raw response

An empty or structurally incomplete response ({}, missing problem_type,
missing required_concepts) is treated as a failure and triggers the next attempt.
"""
from __future__ import annotations

import copy
import json
import re
from typing import Any

from langchain_groq import ChatGroq

from app.config import GROQ_API_KEY, GROQ_MODEL, SCHEDULING_CONCEPTS
from app.llm.prompts import (
    build_fallback_understanding_prompt,
    build_json_repair_prompt,
    build_understanding_prompt,
)
from app.utils import logger


def _call_groq(prompt: str) -> str:
    """Call Groq and return the text response."""
    llm = ChatGroq(
        model=GROQ_MODEL,
        api_key=GROQ_API_KEY,
        temperature=0,
        max_tokens=4096,
    )
    response = llm.invoke(prompt)
    return response.content if hasattr(response, "content") else str(response)


class LLMUnderstandingError(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# JSON parsing
# ---------------------------------------------------------------------------

def _strip_fences(text: str) -> str:
    text = text.strip()
    if "```" in text:
        text = re.sub(r"```[a-zA-Z0-9]*\n?", "", text).replace("```", "").strip()
    return text


def _parse_json(text: str) -> dict[str, Any] | None:
    text = _strip_fences(text)
    try:
        result = json.loads(text)
        if isinstance(result, dict):
            return result
    except json.JSONDecodeError:
        pass
    start = text.find("{")
    while start != -1:
        depth = 0
        for i in range(start, len(text)):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    try:
                        result = json.loads(text[start : i + 1])
                        if isinstance(result, dict):
                            return result
                    except json.JSONDecodeError:
                        break
        start = text.find("{", start + 1)
    return None


# ---------------------------------------------------------------------------
# Completeness check — empty JSON ({}) is treated as a failure
# ---------------------------------------------------------------------------

def _is_complete(parsed: dict[str, Any] | None) -> bool:
    """Structural completeness check only — never injects or modifies concepts."""
    if not parsed:
        return False
    if not parsed.get("problem_type"):
        return False
    obj = parsed.get("objective")
    if not isinstance(obj, dict) or not obj.get("name"):
        return False
    if not parsed.get("required_concepts"):
        return False
    # requirement_coverage must be a non-empty list (structural, not semantic)
    rc = parsed.get("requirement_coverage")
    if not isinstance(rc, list) or len(rc) == 0:
        return False
    return True


# ---------------------------------------------------------------------------
# Default shape
# ---------------------------------------------------------------------------

_DEFAULT_SHAPE: dict[str, Any] = {
    "problem_type": "",
    "is_cpsat_compatible": False,
    "cpsat_compatibility_reason": "",
    "objective": {"name": "", "description": ""},
    "requirement_coverage": [],
    "required_concepts": [],
    "optional_concepts": [],
    "required_relationships": [],
    "constraints": [],
    "global_parameters": {},
    "constraint_validation": {
        "are_constraints_valid": True,
        "has_contradictions": False,
        "contradictions": [],
        "warnings": [],
    },
    "missing_inputs": [],
    "assumptions": [],
}


def _ensure_shape(parsed: dict[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(_DEFAULT_SHAPE)
    out.update(parsed or {})
    if not isinstance(out.get("objective"), dict):
        out["objective"] = dict(_DEFAULT_SHAPE["objective"])
    cv = out.get("constraint_validation")
    if not isinstance(cv, dict):
        out["constraint_validation"] = dict(_DEFAULT_SHAPE["constraint_validation"])
    else:
        for k, v in _DEFAULT_SHAPE["constraint_validation"].items():
            cv.setdefault(k, v)
    for k in (
        "requirement_coverage", "required_concepts", "optional_concepts",
        "required_relationships", "constraints", "missing_inputs", "assumptions",
    ):
        if not isinstance(out.get(k), list):
            out[k] = []
    if not isinstance(out.get("global_parameters"), dict):
        out["global_parameters"] = {}

    # --- Anti-hallucination: strip non-canonical concept names ---
    valid_names = set(SCHEDULING_CONCEPTS.keys())
    for key in ("required_concepts", "optional_concepts"):
        original = out.get(key, [])
        filtered = [c for c in original if c in valid_names]
        removed = [c for c in original if c not in valid_names]
        if removed:
            logger.warn("LLM", f"Filtered {len(removed)} hallucinated {key}: {removed}")
        out[key] = filtered

    return out


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def understand(user_input: str, workbook_profile: dict[str, Any]) -> dict[str, Any]:
    """
    4-attempt retry chain to extract scheduling requirements from user text.
    The LLM decides all concept extraction — no post-processing overrides.

    Attempt 1: full prompt, JSON mode
    Attempt 2: full prompt, free-text mode  (retry in case of empty/truncated response)
    Attempt 3: simplified fallback prompt, free-text mode
    Attempt 4: JSON repair on last raw output
    """
    logger.info("INPUT", "User scheduling requirement received")
    logger.info("GROQ", f"Calling model {GROQ_MODEL}")

    full_prompt = build_understanding_prompt(user_input, workbook_profile)
    logger.info("LLM", f"Prompt length: ~{len(full_prompt) // 4} tokens (estimated)")

    parsed: dict[str, Any] | None = None
    last_raw = ""

    # --- Attempt 1: JSON mode ---
    raw = _call_groq(full_prompt)
    logger.info("LLM", f"Attempt 1 (JSON mode): {len(raw)} chars")
    parsed = _parse_json(raw)
    last_raw = raw
    if _is_complete(parsed):
        logger.info("LLM", "Attempt 1 succeeded")
    else:
        logger.warn("LLM", f"Attempt 1 incomplete — raw preview: {raw[:80]!r}")

        # --- Attempt 2: retry in case of empty or incomplete response ---
        raw = _call_groq(full_prompt)
        logger.info("LLM", f"Attempt 2 (free-text mode): {len(raw)} chars")
        parsed = _parse_json(raw)
        last_raw = raw
        if _is_complete(parsed):
            logger.info("LLM", "Attempt 2 succeeded")
        else:
            logger.warn("LLM", "Attempt 2 incomplete — trying simplified fallback prompt")

            # --- Attempt 3: simplified fallback prompt ---
            fallback_prompt = build_fallback_understanding_prompt(user_input)
            logger.info("LLM", f"Fallback prompt length: ~{len(fallback_prompt) // 4} tokens")
            raw = _call_groq(fallback_prompt)
            logger.info("LLM", f"Attempt 3 (fallback prompt): {len(raw)} chars")
            parsed = _parse_json(raw)
            last_raw = raw
            if _is_complete(parsed):
                logger.info("LLM", "Attempt 3 succeeded")
            else:
                logger.warn("LLM", "Attempt 3 incomplete — trying JSON repair")

                # --- Attempt 4: JSON repair ---
                repair_raw = _call_groq(
                    build_json_repair_prompt(last_raw)
                )
                logger.info("LLM", f"Attempt 4 (JSON repair): {len(repair_raw)} chars")
                parsed = _parse_json(repair_raw)
                if _is_complete(parsed):
                    logger.info("LLM", "Attempt 4 succeeded")
                else:
                    raise LLMUnderstandingError(
                        "LLM problem understanding failed after 4 attempts. "
                        "The model returned empty or incomplete JSON. "
                        f"Last raw response ({len(last_raw)} chars): {last_raw[:200]!r}"
                    )

    result = _ensure_shape(parsed)

    logger.info("LLM", f"Problem type:        {result.get('problem_type') or '(empty)'}")
    logger.info("LLM", f"Objective:           {result.get('objective', {}).get('name') or '(empty)'}")
    logger.info("LLM", f"Required concepts:   {result.get('required_concepts', [])}")
    logger.info("LLM", f"Optional concepts:   {result.get('optional_concepts', [])}")
    logger.info("LLM", f"Required relations:  {result.get('required_relationships', [])}")
    logger.info("LLM", f"Constraints:         {len(result.get('constraints', []))}")
    logger.info("LLM", f"CP-SAT compatible:   {result.get('is_cpsat_compatible')}")

    logger.cpsat_reasoning(result)
    return result
