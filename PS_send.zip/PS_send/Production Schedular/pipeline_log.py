"""
pipeline_log.py
---------------
Minimal, coloured terminal logger for the production-scheduler pipeline.

Usage:
    from pipeline_log import log, log_section, log_action, log_warn, log_ok, log_error

Output goes to stdout (visible in the Streamlit terminal) using ANSI
colour codes that work in PowerShell / Windows Terminal.
"""
from __future__ import annotations

import datetime as _dt
import sys


# --------------------------------------------------------------------------
# ANSI colour helpers — degrade gracefully if the terminal doesn't support
# --------------------------------------------------------------------------
_RESET  = "\033[0m"
_BOLD   = "\033[1m"
_DIM    = "\033[2m"
_CYAN   = "\033[36m"
_YELLOW = "\033[33m"
_GREEN  = "\033[32m"
_RED    = "\033[31m"
_MAGENTA= "\033[35m"
_WHITE  = "\033[97m"
_BLUE   = "\033[34m"

# Node colour map
_NODE_COLOURS = {
    "ingest":   _CYAN,
    "analyse":  _BLUE,
    "plan":     _MAGENTA,
    "schedule": _YELLOW,
    "cost":     _GREEN,
    "report":   _WHITE,
    "supervisor": _DIM + _WHITE,
}

_ICONS = {
    "section":  "━━━",
    "action":   "  ▶",
    "ok":       "  ✓",
    "warn":     "  ⚠",
    "error":    "  ✗",
    "info":     "  ·",
    "route":    "  →",
}


def _ts() -> str:
    return _dt.datetime.now().strftime("%H:%M:%S")


def _colour(node: str) -> str:
    return _NODE_COLOURS.get(node.lower(), _WHITE)


def _print(line: str) -> None:
    print(line, flush=True)


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------

def log_section(node: str, message: str = "") -> None:
    """Print a prominent section header when a node starts."""
    c = _colour(node)
    label = node.upper().ljust(10)
    msg = f"  {message}" if message else ""
    _print(
        f"\n{c}{_BOLD}[{_ts()}] {_ICONS['section']}  NODE: {label}{msg}{_RESET}"
    )


def log_action(node: str, message: str) -> None:
    """Print a step/action inside a node."""
    c = _colour(node)
    _print(f"{c}[{_ts()}]{_ICONS['action']}  [{node}] {message}{_RESET}")


def log_ok(node: str, message: str) -> None:
    """Print a success/completion line."""
    _print(f"{_GREEN}[{_ts()}]{_ICONS['ok']}  [{node}] {message}{_RESET}")


def log_warn(node: str, message: str) -> None:
    """Print a warning line."""
    _print(f"{_YELLOW}[{_ts()}]{_ICONS['warn']}  [{node}] {message}{_RESET}")


def log_error(node: str, message: str) -> None:
    """Print an error line."""
    _print(f"{_RED}[{_ts()}]{_ICONS['error']}  [{node}] {message}{_RESET}")


def log_route(from_node: str, to_node: str) -> None:
    """Print a supervisor routing decision."""
    _print(
        f"{_DIM}[{_ts()}]{_ICONS['route']}  [supervisor] {from_node or 'START'} → {to_node}{_RESET}"
    )


def log(node: str, message: str) -> None:
    """Generic info log."""
    c = _colour(node)
    _print(f"{c}[{_ts()}]{_ICONS['info']}  [{node}] {message}{_RESET}")


def log_pipeline_start(file_path: str) -> None:
    _print(
        f"\n{_BOLD}{_CYAN}"
        f"╔══════════════════════════════════════════════════════╗\n"
        f"║  PRODUCTION SCHEDULER PIPELINE  [{_ts()}]          ║\n"
        f"║  File: {file_path[-44:].ljust(44)}  ║\n"
        f"╚══════════════════════════════════════════════════════╝"
        f"{_RESET}\n"
    )


def log_pipeline_end(n_tasks: int, elapsed_ms: int) -> None:
    _print(
        f"\n{_BOLD}{_GREEN}"
        f"╔══════════════════════════════════════════════════════╗\n"
        f"║  PIPELINE COMPLETE  ·  {n_tasks} gantt tasks  ·  {elapsed_ms}ms{' ' * max(0, 12 - len(str(elapsed_ms)) - len(str(n_tasks)))}║\n"
        f"╚══════════════════════════════════════════════════════╝"
        f"{_RESET}\n"
    )
