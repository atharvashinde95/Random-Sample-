"""
streamlit_app.py
----------------
Streamlit UI for the production scheduler.

The app runs the LangGraph pipeline on an uploaded Excel file and
renders the resulting `final_payload` dict. It contains NO business
logic — the pipeline is the single source of truth for every number.

Run:
    streamlit run streamlit_app.py
"""
from __future__ import annotations

import datetime as _dt
import io
import json
import os
import tempfile
from typing import Any, Dict, List

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from main import run_pipeline


# ------------------------------------------------------------------
# Page config + custom CSS (dark, editorial, restrained)
# ------------------------------------------------------------------
st.set_page_config(
    page_title="Production Scheduler",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.markdown(
    """
    <style>
      @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700;800&family=JetBrains+Mono:wght@400;600&display=swap');

      html, body, [class*="css"] {
          font-family: 'DM Sans', sans-serif;
          background: #07101f;
          color: #e2e8f0;
      }
      .block-container { padding-top: 2rem; padding-bottom: 3rem; max-width: 1400px; }
      h1, h2, h3, h4 { color: #f1f5f9; letter-spacing: -0.02em; }

      /* KPI card */
      .kpi-card {
          background: #0f172a;
          border: 1px solid rgba(148, 163, 184, 0.12);
          border-radius: 10px;
          padding: 16px 20px;
          min-height: 96px;
      }
      .kpi-label {
          font-size: 10px;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.07em;
          margin-bottom: 6px;
          font-weight: 600;
      }
      .kpi-value {
          font-size: 22px;
          font-weight: 800;
          font-family: 'JetBrains Mono', monospace;
      }
      .kpi-sub {
          font-size: 10px;
          color: #475569;
          margin-top: 6px;
      }

      /* Insight card */
      .insight-card {
          background: #0b1526;
          border-radius: 8px;
          padding: 14px 16px;
          border-left: 3px solid rgba(245, 158, 11, 0.55);
          height: 100%;
      }
      .insight-title { color: #e2e8f0; font-weight: 700; font-size: 13px; margin-bottom: 6px; }
      .insight-body  { color: #94a3b8; font-size: 12px; line-height: 1.55; }

      /* Warning severity pills */
      .sev {
          display: inline-block;
          padding: 1px 8px;
          border-radius: 3px;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.05em;
          margin-right: 8px;
      }
      .sev-CRITICAL { background: rgba(239,68,68,0.15); color: #fca5a5; }
      .sev-WARNING  { background: rgba(245,158,11,0.15); color: #fcd34d; }
      .sev-INFO     { background: rgba(56,189,248,0.15); color: #7dd3fc; }

      /* Status badges */
      .status-OnTime       { color: #10b981; font-weight: 600; }
      .status-Inventory    { color: #94a3b8; font-weight: 600; }
      .status-LATE         { color: #ef4444; font-weight: 700; }
      .status-NotScheduled { color: #ef4444; font-weight: 700; }

      .stDataFrame { background: #0b1526; }
      hr { border-color: rgba(148, 163, 184, 0.1); }
      .stTabs [data-baseweb="tab-list"] { gap: 2px; }
      .stTabs [data-baseweb="tab"] {
          background: transparent;
          color: #64748b;
          border-radius: 6px 6px 0 0;
          padding: 6px 18px;
      }
      .stTabs [aria-selected="true"] {
          background: #1e293b !important;
          color: #f1f5f9 !important;
          border-bottom: 2px solid #f59e0b !important;
      }
    </style>
    """,
    unsafe_allow_html=True,
)


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _severity(w: str) -> str:
    if "[CRITICAL]" in w:
        return "CRITICAL"
    if "[WARNING]" in w:
        return "WARNING"
    return "INFO"


def _status_class(status: str) -> str:
    s = (status or "").lower()
    if "late" in s:
        return "status-LATE"
    if "not scheduled" in s:
        return "status-NotScheduled"
    if "inventory" in s:
        return "status-Inventory"
    return "status-OnTime"


def _run_pipeline_on_upload(uploaded_file) -> Dict[str, Any]:
    suffix = os.path.splitext(uploaded_file.name)[1] or ".xlsx"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(uploaded_file.getbuffer())
        tmp_path = tmp.name
    try:
        return run_pipeline(tmp_path)
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass


# ------------------------------------------------------------------
# Sidebar / file upload
# ------------------------------------------------------------------
st.markdown(
    "<div style='display:flex; align-items:center; gap:14px; margin-bottom: 0;'>"
    "<div style='width:40px;height:40px;border-radius:9px;"
    "background: linear-gradient(135deg,#f59e0b,#a78bfa);"
    "display:flex;align-items:center;justify-content:center;font-size:20px;'>🏭</div>"
    "<div><div style='font-size:24px;font-weight:800;color:#f1f5f9;'>"
    "Optimal Production Schedule</div>"
    "<div style='font-size:12px;color:#64748b;'>"
    "LangGraph · OR-Tools CP-SAT · OR-Tools GLOP · Ollama qwen2.5:3b</div>"
    "</div></div>",
    unsafe_allow_html=True,
)

st.write("")

uploaded = st.file_uploader(
    "Upload a manufacturing Excel workbook (.xlsx)",
    type=["xlsx", "xlsm", "xls"],
    help=(
        "Any manufacturing dataset. The ingest agent auto-detects sheet "
        "roles and column meanings — no fixed schema required."
    ),
)

if uploaded is None:
    st.info(
        "👆 Upload any manufacturing Excel file to start. "
        "The pipeline will infer the schema, solve the schedule with CP-SAT "
        "and render the result."
    )
    st.stop()

# Run pipeline
with st.spinner("Running LangGraph pipeline (ingest → analyse → plan → schedule → cost → report)…"):
    payload = _run_pipeline_on_upload(uploaded)

if not payload or "error" in payload:
    st.error(f"Pipeline failed: {payload.get('error', 'unknown')}")
    st.stop()


# ------------------------------------------------------------------
# Header subtitle
# ------------------------------------------------------------------
planning_start = payload.get("planning_start", "?")
planning_end = payload.get("planning_end", "?")
line_count = len(payload.get("line_names", []))
sku_count = payload.get("sku_count", 0)

st.markdown(
    f"<div style='margin:4px 0 24px 0; color:#475569; font-size:12px;'>"
    f"Planning Period: <b style='color:#94a3b8;'>{planning_start}</b> → "
    f"<b style='color:#94a3b8;'>{planning_end}</b> &nbsp;·&nbsp; "
    f"{line_count} Production Line{'s' if line_count != 1 else ''} "
    f"&nbsp;·&nbsp; {sku_count} SKU{'s' if sku_count != 1 else ''}"
    f"</div>",
    unsafe_allow_html=True,
)

# ------------------------------------------------------------------
# Section 1 — KPI cards
# ------------------------------------------------------------------
kpi_cards: List[Dict[str, str]] = payload.get("kpi_cards", [])
if kpi_cards:
    cols = st.columns(min(len(kpi_cards), 6))
    for i, card in enumerate(kpi_cards):
        col = cols[i % len(cols)]
        color = card.get("color", "#f59e0b")
        col.markdown(
            f"""
            <div class="kpi-card" style="border-left: 3px solid {color};">
              <div class="kpi-label">{card.get('label','')}</div>
              <div class="kpi-value" style="color:{color};">{card.get('value','')}</div>
              <div class="kpi-sub">{card.get('sub','')}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

st.write("")

# ------------------------------------------------------------------
# Section 2 — Tabs: Gantt + Schedule Table
# ------------------------------------------------------------------
tab_gantt, tab_table = st.tabs(["📊  Gantt Chart", "📋  Schedule Table"])

with tab_gantt:
    gantt_tasks = payload.get("gantt_tasks", [])
    if not gantt_tasks:
        st.info("No production runs scheduled — all orders covered by on-hand inventory.")
    else:
        # Build dataframe for Plotly timeline
        rows = []
        for t in gantt_tasks:
            # Plotly needs an exclusive end > start. Add one day for display.
            try:
                start = _dt.date.fromisoformat(t["start_date"])
                end = _dt.date.fromisoformat(t["end_date"])
            except Exception:
                continue
            if end <= start:
                end = start + _dt.timedelta(days=1)
            rows.append({
                "Line": t.get("line_name", "—"),
                "SKU": t.get("sku_id", ""),
                "Product": t.get("product_name", ""),
                "Start": str(start),
                "End": str(end),
                "Type": t.get("type", "production"),
                "Units": int(t.get("units_to_produce", 0)),
                "Delivery": t.get("delivery_date", ""),
                "Solver": t.get("solver_status", ""),
            })
        df = pd.DataFrame(rows)

        # Colour scheme: production tasks coloured by SKU, changeovers grey
        prod_df = df[df["Type"] == "production"].copy()
        co_df = df[df["Type"] == "changeover"].copy()

        fig = go.Figure()

        # One trace per SKU so legend shows SKU colours
        palette = px.colors.qualitative.Vivid
        sku_colour: Dict[str, str] = {}
        for i, sku in enumerate(sorted(prod_df["SKU"].unique())):
            sku_colour[sku] = palette[i % len(palette)]

        for _, row in prod_df.iterrows():
            start_ts = pd.to_datetime(row["Start"])
            end_ts   = pd.to_datetime(row["End"])
            duration_ms = max(int((end_ts - start_ts).total_seconds() * 1000), 86_400_000)
            fig.add_trace(go.Bar(
                y=[row["Line"]],
                x=[duration_ms],
                base=[start_ts.isoformat()],
                orientation="h",
                name=row["SKU"],
                marker=dict(color=sku_colour[row["SKU"]], line=dict(width=0)),
                hovertemplate=(
                    f"<b>{row['SKU']} — {row['Product']}</b><br>"
                    f"Line: {row['Line']}<br>"
                    f"Start: {row['Start']}<br>"
                    f"End: {row['End']}<br>"
                    f"Units: {row['Units']:,}<br>"
                    f"Delivery: {row['Delivery']}<br>"
                    f"Solver: {row['Solver']}<extra></extra>"
                ),
                showlegend=row["SKU"] not in [tr.name for tr in fig.data],
            ))

        # Changeover bars: grey, hatched
        for _, row in co_df.iterrows():
            start_ts = pd.to_datetime(row["Start"])
            end_ts   = pd.to_datetime(row["End"])
            duration_ms = max(int((end_ts - start_ts).total_seconds() * 1000), 86_400_000)
            fig.add_trace(go.Bar(
                y=[row["Line"]],
                x=[duration_ms],
                base=[start_ts.isoformat()],
                orientation="h",
                name="Changeover",
                marker=dict(
                    color="rgba(100,116,139,0.45)",
                    line=dict(width=1, color="rgba(100,116,139,0.9)"),
                    pattern=dict(shape="/", solidity=0.3),
                ),
                hovertemplate=(
                    f"<b>Changeover</b><br>{row['Product']}<br>"
                    f"Start: {row['Start']}<br>End: {row['End']}<extra></extra>"
                ),
                showlegend=False,
            ))

        # Delivery markers — vertical lines
        delivery_lines: Dict[str, str] = {}
        for t in gantt_tasks:
            if t["type"] == "production" and t.get("delivery_date"):
                delivery_lines[t["sku_id"]] = t["delivery_date"]

        for sku, d in delivery_lines.items():
            try:
                fig.add_vline(
                    x=pd.to_datetime(d),
                    line=dict(color=sku_colour.get(sku, "#94a3b8"),
                              width=1.5, dash="dot"),
                    annotation_text=f"▼ {sku}",
                    annotation_position="top",
                    annotation_font_size=9,
                    annotation_font_color=sku_colour.get(sku, "#94a3b8"),
                )
            except Exception:
                continue

        # Plan start marker
        try:
            fig.add_vline(
                x=pd.to_datetime(planning_start),
                line=dict(color="#ef4444", width=1.5, dash="dash"),
                annotation_text="Plan Start",
                annotation_position="bottom",
                annotation_font_size=9,
                annotation_font_color="#ef4444",
            )
        except Exception:
            pass

        fig.update_layout(
            barmode="overlay",
            height=120 + 50 * max(1, df["Line"].nunique()),
            margin=dict(l=20, r=20, t=40, b=40),
            plot_bgcolor="#0b1526",
            paper_bgcolor="#0b1526",
            font=dict(family="DM Sans", color="#cbd5e1", size=12),
            xaxis=dict(
                type="date",
                showgrid=True,
                gridcolor="rgba(148,163,184,0.08)",
                tickformat="%b %d",
                ticklabelmode="instant",
            ),
            yaxis=dict(
                autorange="reversed",
                showgrid=False,
                tickfont=dict(size=12, color="#e2e8f0"),
            ),
            legend=dict(
                orientation="h",
                yanchor="bottom", y=-0.25,
                xanchor="left", x=0,
                bgcolor="rgba(0,0,0,0)",
                font=dict(size=11),
            ),
            bargap=0.35,
        )

        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

        st.markdown(
            "<div style='font-size:11px; color:#475569; display:flex; "
            "gap:20px; flex-wrap:wrap; margin-top:4px;'>"
            "<span>█ Coloured bars = production runs</span>"
            "<span>░ Grey hatched = changeover / setup</span>"
            "<span>▼ Dotted verticals = delivery dates</span>"
            "<span style='color:#ef4444;'>│ Red dashed = plan start</span>"
            "</div>",
            unsafe_allow_html=True,
        )

with tab_table:
    table = payload.get("schedule_table", [])
    if not table:
        st.info("No schedule rows to display.")
    else:
        df = pd.DataFrame(table)
        # Friendly column renaming
        rename = {
            "sku_id": "SKU",
            "product_name": "Product",
            "line_name": "Line",
            "order_qty": "Order Qty",
            "on_hand_used": "On-Hand Used",
            "to_produce": "To Produce",
            "prod_start": "Start",
            "prod_end": "End",
            "delivery": "Delivery",
            "lead_buffer": "Lead (days)",
            "hold_cost": "Hold Cost",
            "setup_cost": "Setup Cost",
            "penalty_cost": "Penalty",
            "total_cost": "Total Cost",
            "priority": "Priority",
            "status": "Status",
        }
        df = df.rename(columns=rename)

        # Format currency columns
        for c in ("Hold Cost", "Setup Cost", "Penalty", "Total Cost"):
            if c in df.columns:
                df[c] = df[c].apply(
                    lambda v: f"₹{int(round(float(v))):,}" if isinstance(v, (int, float)) else v
                )

        # Normalise mixed-type columns so PyArrow can serialise them.
        # Any column whose dtype is 'object' and still has integers mixed with
        # strings (e.g. Lead (days) = 5 or "—") must be cast to str.
        for col in df.columns:
            if df[col].dtype == object:
                df[col] = df[col].apply(lambda v: str(v) if v is not None else "—")

        # Status styling
        def _style_status(v):
            s = str(v).lower()
            if "late" in s:   return "color: #ef4444; font-weight:700;"
            if "inventory" in s: return "color: #94a3b8;"
            if "not scheduled" in s: return "color:#ef4444;font-weight:700;"
            return "color: #10b981; font-weight:600;"

        def _style_to_prod(v):
            try:
                n = int(v)
                if n > 0: return "color:#f97316; font-weight:700;"
            except Exception:
                pass
            return "color:#94a3b8;"

        # pandas >= 2.1 renamed applymap → map; fall back gracefully
        _map_fn = getattr(df.style, "map", None) or getattr(df.style, "applymap")
        styler = df.style
        if "Status" in df.columns:
            styler = styler.map(_style_status, subset=["Status"]) if hasattr(df.style, "map") else styler.applymap(_style_status, subset=["Status"])
        if "To Produce" in df.columns:
            styler = styler.map(_style_to_prod, subset=["To Produce"]) if hasattr(df.style, "map") else styler.applymap(_style_to_prod, subset=["To Produce"])

        st.dataframe(styler, width='stretch', hide_index=True)

        # Footnotes
        st.markdown(
            "<div style='display:flex; gap:28px; margin-top:8px; flex-wrap:wrap;'>"
            "<div style='font-size:11px; color:#64748b;'>"
            "<span style='color:#f97316;'>●</span> To-Produce > 0 → fresh production required"
            "</div>"
            "<div style='font-size:11px; color:#64748b;'>"
            "<span style='color:#10b981;'>●</span> Status 'Inventory Covered' → no production needed"
            "</div>"
            "<div style='font-size:11px; color:#64748b;'>"
            "<span style='color:#ef4444;'>●</span> Status 'LATE RISK' → ends after delivery"
            "</div>"
            "</div>",
            unsafe_allow_html=True,
        )

# ------------------------------------------------------------------
# Section 3 — Insights
# ------------------------------------------------------------------
insights = payload.get("insights", [])
if insights:
    st.write("")
    st.markdown(
        "<div style='color:#f1f5f9; font-weight:700; font-size:15px; "
        "margin: 18px 0 10px 0;'>⚡ Optimization Insights</div>",
        unsafe_allow_html=True,
    )
    cols = st.columns(min(4, len(insights)))
    for i, ins in enumerate(insights):
        col = cols[i % len(cols)]
        col.markdown(
            f"""
            <div class="insight-card">
              <div class="insight-title">{ins.get('icon','💡')} {ins.get('title','')}</div>
              <div class="insight-body">{ins.get('body','')}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

# ------------------------------------------------------------------
# Section 4 — Warnings (collapsible)
# ------------------------------------------------------------------
warnings_list = payload.get("warnings_summary", [])
st.write("")
n_warn = len(warnings_list)
with st.expander(f"⚠ Data Quality Warnings ({n_warn})", expanded=False):
    if not warnings_list:
        st.success("✅ No data quality issues detected.")
    else:
        for w in warnings_list:
            sev = _severity(w)
            clean = w.replace(f"[{sev}]", "").strip()
            st.markdown(
                f"<div style='margin-bottom:6px;'>"
                f"<span class='sev sev-{sev}'>{sev}</span>"
                f"<span style='color:#cbd5e1; font-size:12px;'>{clean}</span>"
                f"</div>",
                unsafe_allow_html=True,
            )

# ------------------------------------------------------------------
# Section 5 — Raw payload (collapsible)
# ------------------------------------------------------------------
with st.expander("🔍 Raw Final Payload (JSON)", expanded=False):
    st.json(payload, expanded=False)

# Download buttons
st.write("")
col_dl1, col_dl2 = st.columns(2)
with col_dl1:
    st.download_button(
        "⬇ Download full payload (JSON)",
        data=json.dumps(payload, indent=2, default=str),
        file_name="production_schedule.json",
        mime="application/json",
        width='stretch',
    )
with col_dl2:
    if payload.get("schedule_table"):
        csv_buf = io.StringIO()
        pd.DataFrame(payload["schedule_table"]).to_csv(csv_buf, index=False)
        st.download_button(
            "⬇ Download schedule table (CSV)",
            data=csv_buf.getvalue(),
            file_name="schedule_table.csv",
            mime="text/csv",
            width='stretch',
        )

st.caption(
    f"Cost params used — holding: ₹{payload.get('cost_params_used',{}).get('holding_cost_per_unit_per_day','?')}/unit/day "
    f"· setup: ₹{payload.get('cost_params_used',{}).get('setup_cost_per_run','?')}/run "
    f"· stockout: ₹{payload.get('cost_params_used',{}).get('stockout_cost_per_unit','?')}/unit "
    f"· source: {payload.get('cost_params_used',{}).get('source','?')}"
)
