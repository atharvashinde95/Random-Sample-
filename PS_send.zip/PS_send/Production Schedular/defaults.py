"""
defaults.py
-----------
All configurable default values for the production scheduler.
When the dataset is missing a parameter, the agents fall back to
these values AND log a warning. Nothing is silently assumed.
"""

# -------------------- Cost defaults --------------------
DEFAULT_HOLDING_COST_PER_UNIT_PER_DAY = 0.5   # INR
DEFAULT_STOCKOUT_COST_PER_UNIT = 10.0         # INR
DEFAULT_SETUP_COST_PER_RUN = 2000.0           # INR

# -------------------- Capacity / throughput --------------------
DEFAULT_THROUGHPUT_UNITS_PER_DAY = 1000.0     # when machine_master absent
DEFAULT_SHIFT_HOURS_PER_DAY = 8.0             # when missing on a machine

# -------------------- Changeover --------------------
DEFAULT_CHANGEOVER_DAYS = 0.25                # ~2 hours if 8h shift, 4h if 16h

# -------------------- Scheduling --------------------
DEFAULT_LOGISTICS_BUFFER_DAYS = 3
DEFAULT_JIT_WINDOW_DAYS = 5                   # logistics_buffer + 2
JIT_SHELF_LIFE_THRESHOLD_DAYS = 120           # SKUs below this are JIT-eligible
DEFAULT_PRODUCTION_DAYS_IF_UNKNOWN = 3

# -------------------- LLM confidence thresholds --------------------
SHEET_ROLE_CONFIDENCE_MIN = 0.6               # below → "uncertain"
SHEET_ROLE_CONFIDENCE_DISCARD = 0.4           # below → "unknown" and skip

# -------------------- Solver settings --------------------
CP_SAT_MAX_SECONDS = 30
CP_SAT_WORKERS = 4
MAX_AGENT_RETRIES = 2

# -------------------- Priority weights --------------------
PRIORITY_WEIGHT_HIGH = 3
PRIORITY_WEIGHT_NORMAL = 2
PRIORITY_WEIGHT_LOW = 1
PRIORITY_WEIGHT_DEFAULT = 2

# -------------------- LLM config --------------------
LLM_MODEL = "us.anthropic.claude-3-5-sonnet-20240620-v1:0"
LLM_TEMPERATURE = 0.0                         # deterministic for schema inference
LLM_BASE_URL = "https://openai.generative.engine.capgemini.com/v1"

# -------------------- Currency --------------------
CURRENCY_SYMBOL = "\u20B9"                    # ₹
