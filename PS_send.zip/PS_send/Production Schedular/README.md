# 🏭 Autonomous Production Scheduler

An autonomous, dataset-agnostic manufacturing production scheduler.
Feed it **any** Excel workbook with manufacturing data — no matter how
sheets are named or columns are arranged — and it returns a
cost-optimal production schedule as a Gantt chart, a schedule table,
cost KPIs and narrative insights.

---

## What it does

Given a manufacturing Excel workbook:

1. **Discovers the schema** at runtime (role of each sheet, semantic
   meaning of each column) — no hard-coded names.
2. **Computes net production requirements** per SKU, honouring inventory
   expiry rules via an LP solver.
3. **Assigns SKUs to production lines**, identifies bottleneck machines,
   converts capacity between kg/hr ↔ ml/hr ↔ packs/hr via pack size.
4. **Solves the optimal schedule** with OR-Tools CP-SAT, minimising total
   holding cost subject to delivery deadlines, line non-overlap and
   changeover gaps. Falls back to a greedy heuristic if CP-SAT cannot
   find a solution in 30 s.
5. **Computes a full cost breakdown** (holding, setup, changeover,
   penalty) and summary KPIs.
6. **Renders** the result in Streamlit with a Plotly Gantt, a styled
   schedule table, KPI cards, LLM-generated insights and a warnings
   expander.

### Design principles

| Rule | What it means |
|---|---|
| **Never hallucinate a number** | Every number traces to the dataset, Python, or OR-Tools. The LLM is used only for schema inference and narrative text. |
| **Never drop a SKU silently** | Every SKU in the demand sheet appears in the final table. If it can't be scheduled, it's marked `LATE RISK` or `Not Scheduled`. |
| **Degrade gracefully** | Missing sheets / columns / dates trigger documented defaults with warnings — the pipeline never crashes. |
| **Deterministic where it counts** | All scheduling and cost math is deterministic (temperature-0 LLM only for schema labels). |

---

## Stack

| Layer | Tech |
|---|---|
| Orchestration | **LangGraph** supervisor + 6 agents |
| LLM (schema + insights) | **Ollama `qwen2.5:3b`** via **LangChain** |
| Scheduling solver | **OR-Tools CP-SAT** (30 s timeout, 4 workers) |
| Net-requirement LP | **OR-Tools GLOP** |
| Tool server | **FastMCP** |
| UI | **Streamlit** + **Plotly** |
| Data | **pandas** + **openpyxl** |

---

## Project structure

```
production_scheduler/
├── main.py                    # LangGraph wiring + CLI entry point
├── state.py                   # TypedDict for the shared state object
├── supervisor.py              # Routing decision tree
├── defaults.py                # All configurable defaults + thresholds
├── llm_client.py              # Safe Ollama wrapper + JSON extractor
├── streamlit_app.py           # UI — renders final_payload only
├── requirements.txt
│
├── agents/
│   ├── ingest.py              # Agent 1 — schema discovery
│   ├── analyse.py             # Agent 2 — net requirement + GLOP
│   ├── plan.py                # Agent 3 — lines, bottlenecks, changeovers
│   ├── schedule.py            # Agent 4 — CP-SAT + greedy fallback
│   ├── cost.py                # Agent 5 — cost breakdown
│   └── report.py              # Agent 6 — final payload + LLM insights
│
├── mcp_server/
│   ├── server.py              # FastMCP server + plain-Python dispatcher
│   └── tools/
│       ├── excel_reader.py    # read_excel_all_sheets
│       ├── lp_solver.py       # solve_net_requirement (GLOP)
│       └── cp_solver.py       # solve_production_schedule (CP-SAT)
│
└── prompts/
    ├── infer_sheet_role.txt
    ├── infer_column_mapping.txt
    └── generate_insights.txt
```

---

## Installation

```bash
# 1. Clone / unzip the project
cd production_scheduler

# 2. Create a virtualenv (recommended)
python -m venv .venv
source .venv/bin/activate           # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. (Optional) install and run Ollama for the LLM agent
#    The pipeline works without Ollama — it falls back to a deterministic
#    keyword-based schema inferrer and a rule-based insight generator.
curl -fsSL https://ollama.com/install.sh | sh
ollama pull qwen2.5:3b
ollama serve &    # if not already running
```

---

## Running

### Option A — the Streamlit app (recommended)

```bash
streamlit run streamlit_app.py
```

Then upload any manufacturing Excel workbook.

### Option B — the CLI

```bash
python main.py /path/to/your_dataset.xlsx final_payload.json
```

This writes the full `final_payload` as JSON.

### Option C — the FastMCP server

```bash
python -m mcp_server.server
```

The three tools (`read_excel_all_sheets`, `solve_net_requirement`,
`solve_production_schedule`) become available over MCP for external
clients.

---

## How it handles "different datasets"

The pipeline is explicitly designed to survive schema variation:

| Missing / weird input | What happens |
|---|---|
| Sheet names are totally different | LLM classifies each sheet by its columns and sample rows. If the LLM is down, a deterministic keyword scorer does the job. |
| Columns are renamed / re-ordered | Same: LLM + keyword-fallback semantic mapping. |
| `cost_params` sheet absent | Falls back to defaults (₹0.5/unit/day holding, ₹10/unit stockout, ₹2000/run setup) with a logged warning. |
| Machine capacity in `kg/hr` but pack size in `g` | `plan.py` converts via pack size. Same for `ml/hr` + `ml`. |
| `routing` sheet absent | Assumes a single line for all SKUs with a warning. |
| `machine_master` absent | Uses 1000 units/day default with a warning. |
| `changeover` missing for a pair | Uses 0.25-day default with a warning. |
| Delivery dates in the past (historical data) | `ingest.py` back-dates `planning_start_date` to 10 days before the earliest delivery so the solver has room. |
| CP-SAT reports INFEASIBLE | Supervisor re-plans in relaxed mode (no JIT, no buffer). If still infeasible, greedy forward-scheduler kicks in. Never silently drops a SKU. |
| Ollama is down | Keyword-based schema inference + rule-based insight generation. |

---

## Shared state

Every agent reads and writes into a single `SchedulerState` dict.
The schema is defined in `state.py` and is the contract between
agents. Example trace:

```
ingest    → raw_sheets, schema_map, cost_params, planning_start_date
analyse   → requirements          (needs_production, usable_inventory, ...)
plan      → lines, capacity, changeovers, priority_ranking
schedule  → gantt_tasks, schedule_feasible
cost      → cost_breakdown, cost_summary
report    → schedule_table, kpi_cards, insights, warnings_summary,
            final_payload
```

The supervisor inspects the state after each node and routes by
checking which keys are already present.

---

## FAQ

**Q: The numbers from the scheduler don't match what I'd hand-write. Why?**
A: The scheduler uses GLOP and CP-SAT to find the mathematically
cost-optimal answer. For partial-inventory decisions, the LP compares
holding cost of using old stock vs producing fresh (accounting for
expiry risk). If the answer is unexpected, look at the `reason` field
on each requirement and the `warnings_summary` — both explain what
decisions were made.

**Q: What if the LLM is unavailable?**
A: Everything still works. The deterministic keyword fallbacks for
sheet/column inference are surprisingly accurate for typical
manufacturing datasets, and the rule-based insight generator produces
a reasonable four-bullet summary from the raw state.

**Q: Can I tune the defaults?**
A: Yes — every threshold and default is in `defaults.py`.

**Q: Is CP-SAT guaranteed to finish?**
A: It runs with a 30 s timeout. If it doesn't find a solution, the
greedy forward-scheduler produces a feasible (if sub-optimal) schedule
and all tasks are tagged `HEURISTIC` in the `solver_status` field.

---

## License

Provided as-is for the requested project. Adapt freely.
