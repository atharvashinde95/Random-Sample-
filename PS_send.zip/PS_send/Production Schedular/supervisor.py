"""
supervisor.py
-------------
The supervisor is called after every agent completes. It reads the
state and decides the next step. It implements the exact decision
tree from the spec. No LLM calls here — pure Python routing.
"""
from typing import Literal
from state import SchedulerState
from defaults import MAX_AGENT_RETRIES


NodeName = Literal[
    "ingest", "analyse", "plan", "schedule", "cost", "report", "__end__"
]


def _has_critical(warnings) -> bool:
    if not warnings:
        return False
    return any("CRITICAL" in str(w).upper() for w in warnings)


def _retry_count(state: SchedulerState, node: str) -> int:
    return state.get("agent_retry_counts", {}).get(node, 0)


def supervisor(state: SchedulerState) -> NodeName:
    """
    Return the name of the next node to execute, or '__end__'.
    Must not mutate the state.
    """

    # 1. No raw sheets yet → ingest
    if "raw_sheets" not in state:
        return "ingest"

    # 2. Ingested but not analysed
    if "requirements" not in state:
        if _has_critical(state.get("ingest_warnings", [])):
            # Ingest said the file is unusable.  End with a graceful report.
            return "report"
        return "analyse"

    # 3. Analysed but not planned
    if "lines" not in state:
        reqs = state.get("requirements", [])
        if reqs and all(not r.get("needs_production", False) for r in reqs):
            # All orders covered by inventory — skip plan/schedule/cost
            return "report"
        return "plan"

    # 4. Planned but not scheduled
    if "gantt_tasks" not in state:
        return "schedule"

    # 5. Scheduled but costs not computed
    if "cost_breakdown" not in state:
        if state.get("schedule_feasible", True) is False:
            retry = _retry_count(state, "plan")
            if retry >= MAX_AGENT_RETRIES:
                # Exhausted retries — force schedule to run in relaxed mode
                # so we always have some gantt_tasks for cost to operate on.
                return "schedule"
            # Retry plan with relaxed constraints
            return "plan"
        return "cost"

    # 6. Costs computed but report not built
    if "final_payload" not in state:
        return "report"

    # 7. Done
    return "__end__"
