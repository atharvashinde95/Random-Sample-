"""
llm_client.py
-------------
Thin wrapper around langchain-ollama that:
  1) Returns a singleton LLM instance
  2) Provides a safe `chat()` helper that always returns a string
     (empty string on failure — callers must have a fallback path)

The LLM is used in only three places:
  - Agent 1 (ingest):  sheet-role classification + column mapping
  - Agent 6 (report):  generating narrative insights

All numeric outputs in the final payload come from Python / OR-Tools.
"""
from __future__ import annotations

import json
import re
from typing import Any, Optional

from defaults import LLM_MODEL, LLM_TEMPERATURE, LLM_BASE_URL


_llm_instance: Optional[Any] = None


def _get_llm():
    """Lazily build and cache a ChatOpenAI instance connected to Capgemini Generative Engine."""
    global _llm_instance
    if _llm_instance is not None:
        return _llm_instance
    try:
        from langchain_openai import ChatOpenAI
        from dotenv import load_dotenv
        import os

        # Load environment variables
        load_dotenv()

        _llm_instance = ChatOpenAI(
            model=LLM_MODEL,
            temperature=LLM_TEMPERATURE,
            base_url=LLM_BASE_URL,
            api_key=os.getenv("GENERATIVE_ENGINE_API_KEY")
        )
        return _llm_instance
    except Exception as e:
        print(f"Error initializing LLM: {e}")
        _llm_instance = None
        return None


def chat(prompt: str, timeout: float = 30.0) -> str:
    """
    Send a single-turn prompt to the LLM. Return the text content,
    or "" if the LLM is unreachable / fails. Callers MUST be able to
    continue without the LLM.
    """
    llm = _get_llm()
    if llm is None:
        return ""
    try:
        from langchain_core.messages import HumanMessage
        resp = llm.invoke([HumanMessage(content=prompt)])
        text = getattr(resp, "content", None) or str(resp)
        return str(text).strip()
    except Exception:
        return ""


def extract_json(text: str) -> Any:
    """
    Try hard to extract JSON from an LLM response. Return the parsed
    object or None. Handles:
      - pure JSON
      - JSON wrapped in ```json ... ``` fences
      - JSON with leading/trailing commentary
    """
    if not text:
        return None
    stripped = text.strip()
    # Remove code fences
    fence = re.match(r"^```(?:json)?\s*(.*?)\s*```$", stripped, re.DOTALL | re.IGNORECASE)
    if fence:
        stripped = fence.group(1).strip()

    # First, try direct parse
    try:
        return json.loads(stripped)
    except Exception:
        pass

    # Then try to find a balanced object or array in the text
    for opener, closer in [("[", "]"), ("{", "}")]:
        start = stripped.find(opener)
        end = stripped.rfind(closer)
        if start != -1 and end != -1 and end > start:
            snippet = stripped[start:end + 1]
            try:
                return json.loads(snippet)
            except Exception:
                continue
    return None
