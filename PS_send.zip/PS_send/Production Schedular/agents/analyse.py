"""
agents/analyse.py
-----------------
Agent 2 — ANALYSE

Pure Python. No LLM calls.

For every SKU in demand_orders we compute:
  usable_inventory   — taking expiry into account
  net_requirement    — max(0, order_qty - usable_inventory)
  needs_production   — bool
  reason             — human-readable explanation
Partial-inventory cases are optimised with OR-Tools GLOP via the
`solve_net_requirement` MCP tool.
"""
from __future__ import annotations

import datetime as _dt
import re
from typing import Any, Dict, List, Optional, Tuple

from dateutil import parser as dateparser

from defaults import (
    DEFAULT_HOLDING_COST_PER_UNIT_PER_DAY,
    DEFAULT_SETUP_COST_PER_RUN,
    DEFAULT_STOCKOUT_COST_PER_UNIT,
)
from mcp_server import call_tool
from pipeline_log import log_action, log_ok, log_section, log_warn, log_error
from state import SchedulerState

_NODE = "analyse"


# ------------------------------------------------------------------
# Date parsing
# ------------------------------------------------------------------
def _parse_date(value: Any) -> Optional[_dt.date]:
    """Try every format we support. Returns None on failure."""
    if value is None:
        return None
    if isinstance(value, _dt.date) and not isinstance(value, _dt.datetime):
        return value
    if isinstance(value, _dt.datetime):
        return value.date()
    if isinstance(value, (int, float)):
        # Excel serial date
        try:
            return (_dt.datetime(1899, 12, 30) + _dt.timedelta(days=float(value))).date()
        except Exception:
            return None
    s = str(value).strip()
    if not s or s.lower() in ("nan", "none", "null"):
        return None

    # Try dayfirst=True (for DD-MM-YYYY) and dayfirst=False
    for dayfirst in (True, False):
        try:
            return dateparser.parse(s, dayfirst=dayfirst).date()
        except Exception:
            continue
    return None


def _parse_int(value: Any, default: int = 0) -> int:
    if value is None:
        return default
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def _parse_float(value: Any, default: float = 0.0) -> float:
    if value is None:
        return default
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return default


def _get(row: Dict[str, Any], col_map: Dict[str, str], semantic: str,
         default: Any = None) -> Any:
    """Read a semantic field from a row using the schema's column map."""
    actual = col_map.get(semantic)
    if actual is None:
        return default
    return row.get(actual, default)


def _build_index(rows: List[Dict[str, Any]], col_map: Dict[str, str],
                 key_semantic: str) -> Dict[str, Dict[str, Any]]:
    """Index a list of rows by a semantic key column (e.g. sku_id)."""
    idx: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        key = _get(row, col_map, key_semantic)
        if key is None:
            continue
        idx[str(key).strip()] = row
    return idx


# ------------------------------------------------------------------
# Pack-size & shelf-life parsing (used by other agents too)
# ------------------------------------------------------------------
def parse_pack_size(value: Any) -> Tuple[Optional[float], Optional[str]]:
    """Return (numeric_size, unit_lower) or (None, None)."""
    if value is None:
        return None, None
    s = str(value).strip().lower()
    m = re.match(r"([0-9]+\.?[0-9]*)\s*([a-z]+)", s)
    if not m:
        return None, None
    return float(m.group(1)), m.group(2)


def _priority_str(raw: Any) -> str:
    if raw is None:
        return "Normal"
    s = str(raw).strip()
    if not s or s.lower() in ("nan", "none"):
        return "Normal"
    return s


# ------------------------------------------------------------------
# Main node
# ------------------------------------------------------------------
def analyse_node(state: SchedulerState) -> SchedulerState:
    log_section(_NODE, "Computing net requirements per SKU")
    warnings: List[str] = []

    schema_map = state.get("schema_map", {})
    raw_sheets = state.get("raw_sheets", {})
    cost_params = state.get("cost_params", {})
    holding_rate = float(cost_params.get(
        "holding_cost_per_unit_per_day",
        DEFAULT_HOLDING_COST_PER_UNIT_PER_DAY,
    ))
    setup_cost = float(cost_params.get("setup_cost_per_run", DEFAULT_SETUP_COST_PER_RUN))
    default_penalty = float(cost_params.get(
        "stockout_cost_per_unit", DEFAULT_STOCKOUT_COST_PER_UNIT
    ))
    planning_start = _parse_date(state.get("planning_start_date")) or _dt.date.today()

    # ---------- Fetch the relevant sheets ----------
    demand_info = schema_map.get("demand_orders")
    forecast_info = schema_map.get("demand_forecast")

    if demand_info is None and forecast_info is None:
        log_error(_NODE, "No demand data found — cannot compute requirements")
        warnings.append("[CRITICAL] No demand data found. Cannot compute requirements.")
        return {**state, "requirements": [], "analyse_warnings": warnings}

    # Prefer real orders over forecast
    if demand_info is not None:
        demand_rows = raw_sheets.get(demand_info["sheet_name"], [])
        demand_cols = demand_info["columns"]
        using_forecast = False
        log_action(_NODE, f"Using demand_orders sheet '{demand_info['sheet_name']}' ({len(demand_rows)} rows)")
    else:
        demand_rows = raw_sheets.get(forecast_info["sheet_name"], [])
        demand_cols = forecast_info["columns"]
        using_forecast = True
        log_warn(_NODE, f"No demand_orders — falling back to demand_forecast ({len(demand_rows)} rows)")
        warnings.append(
            "[INFO] No demand_orders sheet. Using demand_forecast as order source."
        )

    # Inventory
    inventory_index: Dict[str, Dict[str, Any]] = {}
    inv_cols: Dict[str, str] = {}
    if "inventory" in schema_map:
        inv_info = schema_map["inventory"]
        inv_cols = inv_info["columns"]
        inv_rows = raw_sheets.get(inv_info["sheet_name"], [])
        inventory_index = _build_index(inv_rows, inv_cols, "sku_id")

    # SKU master (for product name, pack size, shelf life)
    sku_index: Dict[str, Dict[str, Any]] = {}
    sku_cols: Dict[str, str] = {}
    if "sku_master" in schema_map:
        sku_info = schema_map["sku_master"]
        sku_cols = sku_info["columns"]
        sku_rows = raw_sheets.get(sku_info["sheet_name"], [])
        sku_index = _build_index(sku_rows, sku_cols, "sku_id")

    # Forecast index (for priority_flag / service_level when orders lack them)
    fc_index: Dict[str, Dict[str, Any]] = {}
    fc_cols: Dict[str, str] = {}
    if (forecast_info is not None) and (not using_forecast):
        fc_cols = forecast_info["columns"]
        fc_index = _build_index(
            raw_sheets.get(forecast_info["sheet_name"], []),
            fc_cols, "sku_id",
        )

    # ---------- Build requirements ----------
    requirements: List[Dict[str, Any]] = []

    for row in demand_rows:
        flags: List[str] = []
        sku_id = _get(row, demand_cols, "sku_id")
        if sku_id is None:
            continue
        sku_id = str(sku_id).strip()
        if not sku_id:
            continue

        order_qty = _parse_int(_get(row, demand_cols, "order_qty"), 0)

        # delivery date
        raw_delivery = _get(row, demand_cols, "delivery_date")
        delivery = _parse_date(raw_delivery)
        if delivery is None:
            warnings.append(
                f"[CRITICAL] Unparseable delivery date for {sku_id} "
                f"(value={raw_delivery!r}). Skipping this SKU."
            )
            continue

        penalty = _parse_float(_get(row, demand_cols, "penalty_per_unit"), default_penalty)
        priority = _priority_str(_get(row, demand_cols, "priority_flag"))

        service_level_raw = _get(row, demand_cols, "service_level")
        service_level = _parse_int(service_level_raw, 0) if service_level_raw is not None else None

        # Back-fill priority/SL from demand_forecast if missing
        if sku_id in fc_index and priority == "Normal":
            fc_row = fc_index[sku_id]
            fc_priority = _priority_str(_get(fc_row, fc_cols, "priority_flag"))
            if fc_priority:
                priority = fc_priority
            if service_level is None:
                sl_raw = _get(fc_row, fc_cols, "service_level")
                if sl_raw is not None:
                    service_level = _parse_int(sl_raw, 0)

        # Product name — from sku_master, then demand sheet
        product_name = None
        if sku_id in sku_index:
            product_name = _get(sku_index[sku_id], sku_cols, "product_name")
        if not product_name:
            product_name = _get(row, demand_cols, "product_name")
        if not product_name and sku_id in inventory_index:
            product_name = _get(inventory_index[sku_id], inv_cols, "product_name")
        product_name = str(product_name) if product_name else sku_id

        # Inventory
        if sku_id in inventory_index:
            inv_row = inventory_index[sku_id]
            on_hand = _parse_int(_get(inv_row, inv_cols, "on_hand_qty"), 0)
            expiry = _parse_date(_get(inv_row, inv_cols, "expiry_date"))
        else:
            on_hand = 0
            expiry = None
            flags.append(
                f"No inventory record found for {sku_id}. Assuming zero on-hand."
            )
            warnings.append(
                f"[INFO] {flags[-1]}"
            )

        # Shelf life
        shelf_life_days = 999
        if sku_id in sku_index:
            sl = _parse_int(_get(sku_index[sku_id], sku_cols, "shelf_life_days"), 0)
            if sl > 0:
                shelf_life_days = sl

        # Expiry rule
        if expiry is None:
            usable_inventory = on_hand
            expiry_iso: Optional[str] = None
            if on_hand > 0:
                flags.append("No expiry date found. Assuming inventory is usable.")
        else:
            expiry_iso = expiry.isoformat()
            if expiry >= delivery:
                usable_inventory = on_hand
            else:
                usable_inventory = 0
                flags.append(
                    f"Inventory expires {expiry.isoformat()} before "
                    f"delivery {delivery.isoformat()}. Full fresh run required."
                )

        # --- Partial coverage → GLOP LP ---
        if 0 < usable_inventory < order_qty:
            days_until_delivery = (delivery - planning_start).days
            log_action(_NODE, f"  {sku_id}: partial coverage — calling GLOP LP (on_hand={usable_inventory}, order={order_qty})")
            lp_result = call_tool("solve_net_requirement", {
                "order_qty": order_qty,
                "on_hand_qty": usable_inventory,
                "holding_rate": holding_rate,
                "days_until_delivery": max(0, days_until_delivery),
                "shelf_life_remaining_days": shelf_life_days,
                "setup_cost": setup_cost,
            })
            if lp_result.get("solver_status") in ("OPTIMAL", "FEASIBLE", "TRIVIAL"):
                net_requirement = int(lp_result["recommended_production_qty"])
                usable_inventory = int(lp_result["recommended_inventory_use"])
                reason = lp_result.get("decision_reason", "LP decision applied.")
            else:
                net_requirement = max(0, order_qty - usable_inventory)
                reason = (
                    f"On-hand deficit: {order_qty} ordered, "
                    f"{usable_inventory} available. Produce {net_requirement}."
                )
                warnings.append(
                    f"[INFO] GLOP fallback used for {sku_id} "
                    f"(status={lp_result.get('solver_status')})."
                )
        else:
            net_requirement = max(0, order_qty - usable_inventory)
            if net_requirement == 0:
                reason = (
                    f"On-hand stock ({usable_inventory:,}) meets order "
                    f"({order_qty:,}). No production needed."
                )
            elif usable_inventory == 0:
                if expiry is not None and expiry < delivery:
                    reason = (
                        f"Inventory expires {expiry.isoformat()} before "
                        f"delivery {delivery.isoformat()}. Fresh production of "
                        f"{net_requirement:,} units."
                    )
                else:
                    reason = (
                        f"No on-hand stock. Produce all {net_requirement:,} units."
                    )
            else:
                reason = (
                    f"On-hand deficit: {order_qty:,} ordered, "
                    f"{usable_inventory:,} available. "
                    f"Produce {net_requirement:,} units."
                )

        needs_production = net_requirement > 0
        if needs_production:
            log_action(_NODE, f"  {sku_id}: produce {net_requirement:,} units (delivery {delivery.isoformat()})")
        else:
            log_ok(_NODE, f"  {sku_id}: inventory covered — no production needed")

        requirements.append({
            "sku_id": sku_id,
            "product_name": product_name,
            "order_qty": order_qty,
            "on_hand_qty": on_hand,
            "expiry_date": expiry_iso,
            "delivery_date": delivery.isoformat(),
            "penalty_per_unit": penalty,
            "priority": priority,
            "service_level": service_level,
            "usable_inventory": int(usable_inventory),
            "net_requirement": int(net_requirement),
            "needs_production": needs_production,
            "reason": reason,
            "data_quality_flags": flags,
        })

    if not requirements:
        log_error(_NODE, "No usable requirements built from demand sheet")
        warnings.append(
            "[CRITICAL] No usable requirements could be built from the demand sheet."
        )
    else:
        need_prod = sum(1 for r in requirements if r["needs_production"])
        log_ok(_NODE, f"Analyse complete — {len(requirements)} SKU(s), {need_prod} need production, {len(requirements)-need_prod} inventory-covered")

    return {
        **state,
        "requirements": requirements,
        "analyse_warnings": warnings,
    }
