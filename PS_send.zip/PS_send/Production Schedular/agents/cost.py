"""
agents/cost.py
--------------
Agent 5 — COST

Pure Python, no LLM, no solver.

For each production task:
    hold_days       = (delivery - end_date).days clamped at >= 0
    holding_cost    = units * hold_days * holding_rate
    setup_cost      = setup_cost_per_run
    changeover_cost = setup_cost_per_run per adjacent changeover task
    penalty_cost    = late-days * units * penalty_per_unit (0 if on time)
    total_cost      = sum of above
    avoided_penalty = units * penalty_per_unit

Summary KPIs: totals + lines_idle list.
"""
from __future__ import annotations

import datetime as _dt
from collections import defaultdict
from typing import Any, Dict, List

from defaults import (
    DEFAULT_HOLDING_COST_PER_UNIT_PER_DAY,
    DEFAULT_SETUP_COST_PER_RUN,
)
from pipeline_log import log_action, log_ok, log_section
from state import SchedulerState

_NODE = "cost"


def _dt_or_none(s: str):
    try:
        return _dt.date.fromisoformat(s)
    except Exception:
        return None


def cost_node(state: SchedulerState) -> SchedulerState:
    log_section(_NODE, "Computing hold / setup / penalty costs")
    cost_params = state.get("cost_params", {})
    holding_rate = float(cost_params.get(
        "holding_cost_per_unit_per_day",
        DEFAULT_HOLDING_COST_PER_UNIT_PER_DAY,
    ))
    setup_cost = float(cost_params.get("setup_cost_per_run", DEFAULT_SETUP_COST_PER_RUN))
    params_source = cost_params.get("source", "default")
    log_action(_NODE, f"Cost source: {params_source}  |  holding={holding_rate}/unit/day  |  setup={setup_cost}/run")

    gantt_tasks = state.get("gantt_tasks", [])
    reqs = state.get("requirements", [])
    lines_info = state.get("lines", {})

    # Index requirements by SKU
    req_by_sku = {r["sku_id"]: r for r in reqs}

    # Count changeovers adjacent to each production SKU (left and right)
    adjacent_co_by_sku: Dict[str, int] = defaultdict(int)
    for t in gantt_tasks:
        if t["type"] != "changeover":
            continue
        # ids encoded as "CO_{from}__{to}" (via sku_id)
        sid = str(t.get("sku_id", ""))
        if sid.startswith("CO_") and "__" in sid:
            rest = sid[3:]
            from_sku, _, to_sku = rest.partition("__")
            adjacent_co_by_sku[from_sku] += 1
            adjacent_co_by_sku[to_sku] += 1

    # Per-SKU cost rows
    cost_breakdown: List[Dict[str, Any]] = []
    total_setup = 0.0
    total_changeover = 0.0
    total_holding = 0.0
    total_penalty = 0.0
    total_avoided = 0.0
    production_runs = 0

    for t in gantt_tasks:
        if t["type"] != "production":
            continue
        sku = t["sku_id"]
        req = req_by_sku.get(sku, {})
        units = int(t.get("units_to_produce", 0))
        penalty_per_unit = float(req.get("penalty_per_unit", 0))

        end_date = _dt_or_none(t.get("end_date", ""))
        delivery_date = _dt_or_none(t.get("delivery_date", ""))

        if end_date and delivery_date:
            hold_days = max(0, (delivery_date - end_date).days)
            late_days = max(0, (end_date - delivery_date).days)
        else:
            hold_days = 0
            late_days = 0

        holding_cost = units * hold_days * holding_rate
        penalty_cost = late_days * units * penalty_per_unit
        sku_changeover_cost = adjacent_co_by_sku.get(sku, 0) * setup_cost
        # To avoid double counting: we allocate each changeover to only the
        # earlier SKU. Divide by 2 — one from each adjacent SKU counted once.
        # Here both sides see it, so halve.
        sku_changeover_cost = sku_changeover_cost / 2.0

        sku_setup_cost = setup_cost
        avoided = units * penalty_per_unit

        total_cost = holding_cost + sku_setup_cost + sku_changeover_cost + penalty_cost

        flags: List[str] = []
        if params_source == "default":
            flags.append(
                "ESTIMATED — cost_params not found in dataset. Using defaults."
            )
        if t.get("late_risk"):
            flags.append("LATE RISK — production ends after delivery date.")

        cost_breakdown.append({
            "sku_id": sku,
            "holding_cost": round(holding_cost, 2),
            "setup_cost": round(sku_setup_cost, 2),
            "changeover_cost": round(sku_changeover_cost, 2),
            "penalty_cost": round(penalty_cost, 2),
            "total_cost": round(total_cost, 2),
            "hold_days": int(hold_days),
            "avoided_penalty": round(avoided, 2),
            "flags": flags,
        })

        total_setup += sku_setup_cost
        total_changeover += sku_changeover_cost
        total_holding += holding_cost
        total_penalty += penalty_cost
        total_avoided += avoided
        production_runs += 1

    # Lines idle = lines that exist in lines_info but had zero production tasks
    busy_lines = {t["line_id"] for t in gantt_tasks if t["type"] == "production"}
    # Also check lines that were never even assigned in plan (because all
    # their SKUs were inventory-covered)
    all_line_ids = set(lines_info.keys()) | {
        # lines that were implicitly busy
        *busy_lines
    }
    # Plus any line implied by an inventory-covered SKU via category
    # (we don't strictly need it — any line_id we know about counts)
    lines_idle = sorted(all_line_ids - busy_lines)

    # Pretty names for idle lines
    lines_idle_pretty = [
        lines_info.get(lid, {}).get("name", lid) for lid in lines_idle
    ]

    cost_summary = {
        "total_setup_cost": round(total_setup, 2),
        "total_changeover_cost": round(total_changeover, 2),
        "total_holding_cost": round(total_holding, 2),
        "total_penalty_cost": round(total_penalty, 2),
        "total_schedule_cost": round(
            total_setup + total_changeover + total_holding + total_penalty, 2
        ),
        "total_avoided_penalty": round(total_avoided, 2),
        "production_runs": production_runs,
        "lines_idle": lines_idle_pretty,
    }

    return {
        **state,
        "cost_breakdown": cost_breakdown,
        "cost_summary": cost_summary,
    }
