"""
agents/ingest.py
----------------
Agent 1 — INGEST

Reads the raw Excel file. Discovers its schema AT RUNTIME.
Never assumes sheet names or column names.

Uses the LLM for:
  - Sheet-role classification (with a deterministic keyword fallback)
  - Column semantic mapping  (with a deterministic keyword fallback)

Everything numeric is still read straight from pandas — no LLM math.
"""
from __future__ import annotations

import datetime as _dt
import os
import re
from collections import Counter
from typing import Any, Dict, List, Tuple

from defaults import (
    DEFAULT_HOLDING_COST_PER_UNIT_PER_DAY,
    DEFAULT_SETUP_COST_PER_RUN,
    DEFAULT_STOCKOUT_COST_PER_UNIT,
    SHEET_ROLE_CONFIDENCE_MIN,
    SHEET_ROLE_CONFIDENCE_DISCARD,
)
from llm_client import chat, extract_json
from mcp_server import call_tool
from pipeline_log import log_action, log_error, log_ok, log_section, log_warn
from state import SchedulerState

_NODE = "ingest"


# ------------------------------------------------------------------
# Role definitions & standard-field lookup tables
# ------------------------------------------------------------------
KNOWN_ROLES = [
    "demand_orders", "inventory", "sku_master", "routing",
    "machine_master", "changeover", "cost_params", "bom",
    "demand_forecast",
]

STANDARD_FIELDS: Dict[str, List[str]] = {
    "demand_orders": [
        "sku_id", "product_name", "order_qty", "delivery_date",
        "retailer", "penalty_per_unit", "priority_flag", "service_level",
        "order_id",
    ],
    "inventory": [
        "sku_id", "product_name", "on_hand_qty", "expiry_date",
        "warehouse_location", "batch_id",
    ],
    "sku_master": [
        "sku_id", "category", "pack_size", "pack_unit",
        "shelf_life_days", "allergen_flag", "product_name",
    ],
    "routing": [
        "sku_id", "operation_sequence", "machine_type",
        "standard_time_sec", "operation_name",
    ],
    "machine_master": [
        "machine_id", "machine_type", "capacity_per_hr",
        "capacity_unit", "shift_hours_per_day",
    ],
    "changeover": [
        "from_sku", "to_sku", "setup_time_min", "cleaning_required",
    ],
    "cost_params": ["cost_type", "value", "unit"],
    "bom": ["sku_id", "raw_material", "qty_per_unit", "unit"],
    "demand_forecast": [
        "sku_id", "product_name", "forecast_qty",
        "service_level", "priority_flag",
    ],
}

# Keyword hints for deterministic fallback role inference
ROLE_HINTS: Dict[str, List[str]] = {
    "demand_orders":   ["order", "delivery", "penalty", "retailer"],
    "inventory":       ["on_hand", "onhand", "on hand", "expiry", "stock", "batch"],
    "sku_master":      ["pack_size", "shelf_life", "allergen", "category"],
    "routing":         ["operation", "standard_time", "routing", "machine_type"],
    "machine_master":  ["capacity", "shift_hour", "machine_id", "max_capacity"],
    "changeover":      ["from_sku", "to_sku", "setup_time", "cleaning", "changeover"],
    "cost_params":     ["cost_type", "holding_cost", "stockout", "setup_cost"],
    "bom":             ["raw_material", "qty_per_unit", "bill of material", "bom"],
    "demand_forecast": ["forecast", "service_level", "priority_flag"],
}

# Keyword hints for deterministic column mapping fallback
COLUMN_HINTS: Dict[str, List[str]] = {
    "sku_id":              ["sku_id", "sku", "item_id", "product_id", "id"],
    "product_name":        ["sku_name", "product_name", "item_type", "item_name", "name", "description"],
    "order_qty":           ["order_qty", "order_quantity", "qty", "quantity", "forecast_qty"],
    "delivery_date":       ["delivery_date", "due_date", "ship_date", "required_date"],
    "retailer":            ["retailer", "customer", "buyer"],
    "penalty_per_unit":    ["penalty_cost", "penalty", "stockout_cost"],
    "priority_flag":       ["priority", "priority_flag"],
    "service_level":       ["service_level", "svc_level", "sl"],
    "order_id":            ["order_id", "po_number", "po"],
    "on_hand_qty":         ["on_hand_qty", "on_hand", "stock_qty", "inventory_qty", "onhand"],
    "expiry_date":         ["expiry_date", "expiration_date", "use_by", "best_before"],
    "warehouse_location":  ["warehouse", "location", "wh_loc"],
    "batch_id":            ["batch_id", "batch", "lot_id"],
    "category":            ["category", "product_category", "family"],
    "pack_size":           ["pack_size", "size", "unit_size"],
    "pack_unit":           ["pack_unit", "uom"],
    "shelf_life_days":     ["shelf_life_days", "shelf_life"],
    "allergen_flag":       ["allergen_flag", "allergen"],
    "operation_sequence":  ["operation_seq", "op_seq", "sequence", "seq"],
    "machine_type":        ["machine_type", "machine"],
    "standard_time_sec":   ["standard_time_sec", "std_time_sec", "std_time"],
    "operation_name":      ["operation_name", "operation_type", "operations_type"],
    "machine_id":          ["machine_id", "m_id"],
    "capacity_per_hr":     ["capacity_per_hr", "max_capacity_units_hr", "max_capacity_units_per_hr", "capacity"],
    "capacity_unit":       ["capacity_unit"],
    "shift_hours_per_day": ["shift_hours", "shift_hrs", "shift"],
    "from_sku":            ["from_sku", "from"],
    "to_sku":              ["to_sku", "to"],
    "setup_time_min":      ["setup_time_min", "setup_time", "changeover_min"],
    "cleaning_required":   ["cleaning_required", "cleaning", "sanitation"],
    "cost_type":           ["cost_type", "parameter", "type"],
    "value":               ["value", "amount", "rate"],
    "unit":                ["unit", "uom"],
    "raw_material":        ["raw_material", "material", "ingredient"],
    "qty_per_unit":        ["qty_per_unit", "quantity_per_unit"],
    "forecast_qty":        ["forecast_qty", "forecast"],
}


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _normalise(s: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(s).lower()).strip("_")


def _try_parse_date(value: Any):
    """Best-effort date parser, returns a date or None."""
    if value is None:
        return None
    if isinstance(value, _dt.date) and not isinstance(value, _dt.datetime):
        return value
    if isinstance(value, _dt.datetime):
        return value.date()
    s = str(value).strip()
    if not s or s.lower() in ("nan", "none", "null"):
        return None
    try:
        from dateutil import parser as _dp
        for dayfirst in (True, False):
            try:
                return _dp.parse(s, dayfirst=dayfirst).date()
            except Exception:
                continue
    except Exception:
        pass
    return None


def _first_n_rows(rows: List[Dict[str, Any]], n: int = 3) -> List[Dict[str, Any]]:
    return rows[:n] if rows else []


def _fallback_role(sheet_name: str, columns: List[str], sample_rows: List[Dict[str, Any]]) -> Tuple[str, float]:
    """Deterministic keyword-based role inference."""
    haystack = " ".join([_normalise(sheet_name)] + [_normalise(c) for c in columns])
    for row in sample_rows:
        haystack += " " + " ".join(_normalise(v) for v in row.values() if v is not None)

    scores: Dict[str, int] = {}
    for role, kws in ROLE_HINTS.items():
        score = 0
        for kw in kws:
            if _normalise(kw) in haystack:
                score += 1
        scores[role] = score

    best_role, best_score = max(scores.items(), key=lambda kv: kv[1])
    if best_score == 0:
        return "unknown", 0.0
    # Confidence: fraction of hints matched, floor at 0.5, cap at 0.95
    conf = min(0.95, 0.5 + 0.1 * best_score)
    return best_role, conf


def _llm_classify_sheet(sheet_name: str, columns: List[str],
                        sample_rows: List[Dict[str, Any]]) -> Tuple[str, float]:
    """LLM-first, falls back to _fallback_role."""
    try:
        prompt_path = os.path.join(
            os.path.dirname(__file__), "..", "prompts", "infer_sheet_role.txt"
        )
        with open(prompt_path, "r", encoding="utf-8") as f:
            template = f.read()
        prompt = template.format(
            sheet_name=sheet_name,
            column_names=", ".join(columns),
            sample_rows=str(sample_rows),
        )
        resp = chat(prompt)
        if resp:
            # Parse "role: X\nconfidence: 0.8"
            role_m = re.search(r"role\s*:\s*([a-z_]+)", resp, re.IGNORECASE)
            conf_m = re.search(r"confidence\s*:\s*([0-9.]+)", resp, re.IGNORECASE)
            if role_m:
                role = role_m.group(1).strip().lower()
                conf = float(conf_m.group(1)) if conf_m else 0.6
                if role in KNOWN_ROLES or role == "unknown":
                    return role, max(0.0, min(1.0, conf))
    except Exception:
        pass
    return _fallback_role(sheet_name, columns, sample_rows)


def _fallback_column_mapping(role: str, columns: List[str]) -> Dict[str, str]:
    """Keyword-based deterministic column mapping."""
    std_fields = STANDARD_FIELDS.get(role, [])
    mapping: Dict[str, str] = {}  # semantic -> actual
    used_actual = set()

    for semantic in std_fields:
        hints = COLUMN_HINTS.get(semantic, [semantic])
        # Try exact normalised match first
        for actual in columns:
            if actual in used_actual:
                continue
            norm_actual = _normalise(actual)
            if any(_normalise(h) == norm_actual for h in hints):
                mapping[semantic] = actual
                used_actual.add(actual)
                break
        # Then try substring match
        if semantic in mapping:
            continue
        for actual in columns:
            if actual in used_actual:
                continue
            norm_actual = _normalise(actual)
            if any(_normalise(h) in norm_actual for h in hints):
                mapping[semantic] = actual
                used_actual.add(actual)
                break
    return mapping


def _llm_column_mapping(role: str, columns: List[str]) -> Dict[str, str]:
    """LLM-first, fallback to deterministic mapping."""
    std_fields = STANDARD_FIELDS.get(role, [])
    if not std_fields:
        return {}
    try:
        prompt_path = os.path.join(
            os.path.dirname(__file__), "..", "prompts", "infer_column_mapping.txt"
        )
        with open(prompt_path, "r", encoding="utf-8") as f:
            template = f.read()
        prompt = template.format(
            role=role,
            columns=", ".join(columns),
            standard_fields=", ".join(std_fields),
        )
        resp = chat(prompt)
        parsed = extract_json(resp)
        if isinstance(parsed, dict) and parsed:
            # LLM returns {actual: standard}; flip to {standard: actual}
            inverted: Dict[str, str] = {}
            for actual, std in parsed.items():
                if actual in columns and std in std_fields and std not in inverted:
                    inverted[std] = actual
            # Backfill missing mappings with the deterministic fallback
            fallback = _fallback_column_mapping(role, columns)
            for k, v in fallback.items():
                inverted.setdefault(k, v)
            return inverted
    except Exception:
        pass
    return _fallback_column_mapping(role, columns)


# ------------------------------------------------------------------
# Cost-parameter extraction
# ------------------------------------------------------------------
def _extract_cost_params(rows: List[Dict[str, Any]], col_map: Dict[str, str]) -> Tuple[Dict[str, float], List[str]]:
    warnings: List[str] = []
    out: Dict[str, float] = {}

    type_col = col_map.get("cost_type")
    val_col = col_map.get("value")
    if not type_col or not val_col:
        warnings.append(
            "[WARNING] cost_params sheet found but type/value columns unclear. "
            "Using defaults."
        )
        return out, warnings

    for row in rows:
        t = str(row.get(type_col, "")).lower()
        try:
            v = float(row.get(val_col))
        except (TypeError, ValueError):
            continue
        if "hold" in t:
            out["holding_cost_per_unit_per_day"] = v
        elif "stockout" in t or "penalty" in t:
            out["stockout_cost_per_unit"] = v
        elif "setup" in t or "changeover" in t:
            out["setup_cost_per_run"] = v
    return out, warnings


# ------------------------------------------------------------------
# Primary-key detection
# ------------------------------------------------------------------
def _find_primary_key(schema_map: Dict[str, Dict[str, Any]],
                      raw_sheets: Dict[str, List[Dict[str, Any]]]) -> Tuple[str, List[str]]:
    warnings: List[str] = []
    # Count how many sheets have each semantic field
    field_counter: Counter = Counter()
    for role, info in schema_map.items():
        for semantic in info.get("columns", {}).keys():
            field_counter[semantic] += 1

    if field_counter.get("sku_id", 0) >= 3:
        return "sku_id", warnings

    if field_counter.get("product_name", 0) >= 3:
        warnings.append(
            "[WARNING] No reliable SKU ID column found. "
            "Attempting to join on product_name. Results may be less reliable."
        )
        return "product_name", warnings

    warnings.append(
        "[WARNING] No reliable join key found across sheets. "
        "Using 'sku_id' as the nominal key; matches may fail."
    )
    return "sku_id", warnings


# ------------------------------------------------------------------
# Main node
# ------------------------------------------------------------------
def ingest_node(state: SchedulerState) -> SchedulerState:
    log_section(_NODE, f"Reading: {state.get('file_path', '?')}")
    warnings: List[str] = []
    file_path = state.get("file_path")
    if not file_path:
        log_error(_NODE, "No file_path in state — aborting ingest.")
        warnings.append("[CRITICAL] No file_path in state.")
        return {
            **state,
            "raw_sheets": {},
            "schema_map": {},
            "primary_key": "sku_id",
            "planning_start_date": _dt.date.today().isoformat(),
            "ingest_warnings": warnings,
            "cost_params": {
                "holding_cost_per_unit_per_day": DEFAULT_HOLDING_COST_PER_UNIT_PER_DAY,
                "stockout_cost_per_unit": DEFAULT_STOCKOUT_COST_PER_UNIT,
                "setup_cost_per_run": DEFAULT_SETUP_COST_PER_RUN,
            },
        }

    # ---- Step 1: read --------------------------------------------------
    log_action(_NODE, "Calling MCP tool: read_excel_all_sheets")
    result = call_tool("read_excel_all_sheets", {"file_path": file_path})
    if "error" in result:
        log_error(_NODE, f"Cannot read Excel file: {result['error']}")
        warnings.append(f"[CRITICAL] Cannot read Excel file: {result['error']}")
        return {
            **state,
            "raw_sheets": {},
            "schema_map": {},
            "primary_key": "sku_id",
            "planning_start_date": _dt.date.today().isoformat(),
            "ingest_warnings": warnings,
            "cost_params": {
                "holding_cost_per_unit_per_day": DEFAULT_HOLDING_COST_PER_UNIT_PER_DAY,
                "stockout_cost_per_unit": DEFAULT_STOCKOUT_COST_PER_UNIT,
                "setup_cost_per_run": DEFAULT_SETUP_COST_PER_RUN,
            },
        }

    raw_sheets: Dict[str, List[Dict[str, Any]]] = result.get("sheets", {})
    log_ok(_NODE, f"Read {len(raw_sheets)} sheet(s): {', '.join(raw_sheets.keys())}")
    if not raw_sheets:
        warnings.append("[CRITICAL] File has no readable sheets.")

    # ---- Step 2 & 3: classify + map -----------------------------------
    schema_map: Dict[str, Dict[str, Any]] = {}

    for sheet_name, rows in raw_sheets.items():
        if not rows:
            warnings.append(f"[INFO] Sheet '{sheet_name}' is empty. Skipping.")
            continue
        columns = list(rows[0].keys())
        sample = _first_n_rows(rows, 3)

        log_action(_NODE, f"Classifying sheet '{sheet_name}' ({len(rows)} rows, {len(columns)} cols)")
        role, confidence = _llm_classify_sheet(sheet_name, columns, sample)
        log_ok(_NODE, f"  → role='{role}' confidence={confidence:.2f}")

        if confidence < SHEET_ROLE_CONFIDENCE_DISCARD or role == "unknown":
            log_warn(_NODE, f"Sheet '{sheet_name}' unclassifiable — skipping")
            warnings.append(
                f"[WARNING] Sheet '{sheet_name}' could not be classified "
                f"(confidence={confidence:.2f}). Skipping."
            )
            continue

        if confidence < SHEET_ROLE_CONFIDENCE_MIN:
            warnings.append(
                f"[INFO] Sheet '{sheet_name}' classified as '{role}' with low "
                f"confidence ({confidence:.2f}). Using with caution."
            )

        col_map = _llm_column_mapping(role, columns)
        log_action(_NODE, f"  Column mapping for '{role}': {list(col_map.keys())}")
        mapped_fields = set(col_map.keys())
        expected = set(STANDARD_FIELDS.get(role, []))
        missing = sorted(expected - mapped_fields)
        extra = sorted([c for c in columns if c not in col_map.values()])
        if missing:
            log_warn(_NODE, f"  Missing fields in '{sheet_name}': {missing}")

        # If this role already exists (duplicate sheet), keep the higher-confidence one
        if role in schema_map and schema_map[role]["confidence"] >= confidence:
            warnings.append(
                f"[INFO] Sheet '{sheet_name}' duplicates role '{role}' "
                f"(lower confidence). Skipping."
            )
            continue

        schema_map[role] = {
            "sheet_name": sheet_name,
            "columns": col_map,
            "confidence": confidence,
            "missing_fields": missing,
            "extra_fields": extra,
        }

    log_ok(_NODE, f"Schema map built: {list(schema_map.keys())}")

    # ---- Step 4: cost params ------------------------------------------
    cost_params = {
        "holding_cost_per_unit_per_day": DEFAULT_HOLDING_COST_PER_UNIT_PER_DAY,
        "stockout_cost_per_unit": DEFAULT_STOCKOUT_COST_PER_UNIT,
        "setup_cost_per_run": DEFAULT_SETUP_COST_PER_RUN,
        "source": "default",
    }

    if "cost_params" in schema_map:
        log_action(_NODE, "Extracting cost parameters from dataset")
        cp_sheet = schema_map["cost_params"]["sheet_name"]
        cp_cols = schema_map["cost_params"]["columns"]
        extracted, cp_warn = _extract_cost_params(raw_sheets[cp_sheet], cp_cols)
        warnings.extend(cp_warn)
        cost_params.update(extracted)
        if extracted:
            cost_params["source"] = "dataset"
            log_ok(_NODE, f"Cost params from dataset: {extracted}")
    else:
        log_warn(_NODE, "No cost_params sheet — using defaults")
        warnings.append(
            f"[WARNING] No cost_params sheet found. Using defaults: "
            f"holding={DEFAULT_HOLDING_COST_PER_UNIT_PER_DAY}, "
            f"stockout={DEFAULT_STOCKOUT_COST_PER_UNIT}, "
            f"setup={DEFAULT_SETUP_COST_PER_RUN}."
        )

    # ---- Step 5: primary key ------------------------------------------
    primary_key, pk_warn = _find_primary_key(schema_map, raw_sheets)
    warnings.extend(pk_warn)
    log_action(_NODE, f"Primary key detected: '{primary_key}'")

    # ---- Step 6: planning start date ----------------------------------
    # Default is today. But if the dataset's earliest delivery is in the
    # past (historical / demo data), back-date the plan to a reasonable
    # point before the earliest delivery so the solver has space to work.
    planning_start = _dt.date.today()
    if "demand_orders" in schema_map:
        do_info = schema_map["demand_orders"]
        do_cols = do_info["columns"]
        date_col = do_cols.get("delivery_date")
        if date_col:
            earliest = None
            for row in raw_sheets.get(do_info["sheet_name"], []):
                d_raw = row.get(date_col)
                d = _try_parse_date(d_raw)
                if d and (earliest is None or d < earliest):
                    earliest = d
            if earliest and earliest <= planning_start:
                # Back-date to 10 days before the earliest delivery
                planning_start = earliest - _dt.timedelta(days=10)
                warnings.append(
                    f"[INFO] Dataset deliveries start {earliest.isoformat()}, "
                    f"which is on or before today. Planning horizon back-dated "
                    f"to {planning_start.isoformat()} so the schedule has lead time."
                )
    planning_start = planning_start.isoformat()
    log_action(_NODE, f"Planning start date: {planning_start}")

    # ---- Sanity check: do we have the minimum to proceed? -------------
    if "demand_orders" not in schema_map and "demand_forecast" not in schema_map:
        log_error(_NODE, "No demand_orders or demand_forecast sheet — cannot build requirements")
        warnings.append(
            "[CRITICAL] No demand_orders or demand_forecast sheet found. "
            "Cannot build requirements."
        )
    else:
        log_ok(_NODE, f"Ingest complete — {len(warnings)} warning(s)")

    return {
        **state,
        "raw_sheets": raw_sheets,
        "schema_map": schema_map,
        "primary_key": primary_key,
        "planning_start_date": planning_start,
        "ingest_warnings": warnings,
        "cost_params": cost_params,
    }
