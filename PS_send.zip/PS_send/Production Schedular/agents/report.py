"""
agents/report.py
----------------
Agent 6 — REPORT

Builds the final payload that Streamlit will render.

LLM is used ONLY to generate narrative insight text. All numbers
come from the state, never from the LLM. If the LLM fails or
returns invalid JSON we use a deterministic, rule-based fallback.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
from typing import Any, Dict, List

from defaults import CURRENCY_SYMBOL
from llm_client import chat, extract_json
from pipeline_log import log_action, log_ok, log_section, log_warn
from state import SchedulerState

_NODE = "report"


def _fmt_money(v: float) -> str:
    try:
        # Indian-style grouping
        s = f"{int(round(float(v))):,}"
    except Exception:
        s = str(v)
    return f"{CURRENCY_SYMBOL}{s}"


def _fmt_int(v: Any) -> str:
    try:
        return f"{int(v):,}"
    except Exception:
        return str(v)


def _status_for(req: Dict[str, Any],
                gantt_by_sku: Dict[str, Dict[str, Any]]) -> str:
    if not req.get("needs_production"):
        return "Inventory Covered"
    task = gantt_by_sku.get(req["sku_id"])
    if task is None:
        return "Not Scheduled"
    try:
        end = _dt.date.fromisoformat(task["end_date"])
        delivery = _dt.date.fromisoformat(task["delivery_date"])
        if end > delivery:
            return "LATE RISK"
    except Exception:
        pass
    return "On Time"


def _build_schedule_table(state: SchedulerState) -> List[Dict[str, Any]]:
    reqs = state.get("requirements", [])
    gantt = state.get("gantt_tasks", [])
    lines = state.get("lines", {})
    costs = state.get("cost_breakdown", [])

    gantt_by_sku = {g["sku_id"]: g for g in gantt if g["type"] == "production"}
    cost_by_sku = {c["sku_id"]: c for c in costs}

    # Reverse index: sku -> line_name
    sku_to_line_name: Dict[str, str] = {}
    for lid, info in lines.items():
        for s in info.get("sku_ids", []):
            sku_to_line_name[s] = info.get("name", lid)

    rows: List[Dict[str, Any]] = []
    for req in reqs:
        sku = req["sku_id"]
        task = gantt_by_sku.get(sku)
        cost = cost_by_sku.get(sku)

        prod_start = task["start_date"] if task else "—"
        prod_end = task["end_date"] if task else "—"

        lead_buffer: Any = "—"
        if task:
            try:
                lead_buffer = (
                    _dt.date.fromisoformat(task["delivery_date"])
                    - _dt.date.fromisoformat(task["end_date"])
                ).days
            except Exception:
                lead_buffer = "—"

        rows.append({
            "sku_id": sku,
            "product_name": req.get("product_name", sku),
            "line_name": sku_to_line_name.get(sku, "—"),
            "order_qty": int(req.get("order_qty", 0)),
            "on_hand_used": int(req.get("usable_inventory", 0)),
            "to_produce": int(req.get("net_requirement", 0)),
            "prod_start": prod_start,
            "prod_end": prod_end,
            "delivery": req.get("delivery_date", "—"),
            "lead_buffer": lead_buffer,
            "hold_cost": round(cost["holding_cost"], 2) if cost else "—",
            "setup_cost": round(cost["setup_cost"], 2) if cost else "—",
            "penalty_cost": round(cost["penalty_cost"], 2) if cost else "—",
            "total_cost": round(cost["total_cost"], 2) if cost else "—",
            "priority": req.get("priority", "Normal"),
            "status": _status_for(req, gantt_by_sku),
        })
    return rows


def _build_kpi_cards(state: SchedulerState) -> List[Dict[str, str]]:
    summary = state.get("cost_summary", {}) or {}
    gantt = state.get("gantt_tasks", [])
    cost_params = state.get("cost_params", {})
    setup_rate = float(cost_params.get("setup_cost_per_run", 2000))

    produced_skus = sorted({
        t["sku_id"] for t in gantt if t["type"] == "production"
    })
    n_changeover = sum(1 for t in gantt if t["type"] == "changeover")
    n_runs = int(summary.get("production_runs", 0))

    total_setup_co = summary.get("total_setup_cost", 0) + summary.get("total_changeover_cost", 0)
    total_holding = summary.get("total_holding_cost", 0)
    total_cost = summary.get("total_schedule_cost", 0)
    avoided = summary.get("total_avoided_penalty", 0)
    lines_idle = summary.get("lines_idle", [])

    # Count at-risk orders
    reqs = state.get("requirements", [])
    at_risk = 0
    on_time = 0
    for req in reqs:
        if not req.get("needs_production"):
            on_time += 1
            continue
        task = next((g for g in gantt if g["sku_id"] == req["sku_id"] and g["type"] == "production"), None)
        if task is None:
            at_risk += 1
            continue
        try:
            if _dt.date.fromisoformat(task["end_date"]) > _dt.date.fromisoformat(task["delivery_date"]):
                at_risk += 1
            else:
                on_time += 1
        except Exception:
            at_risk += 1

    if at_risk == 0:
        penalty_sub = f"All {len(reqs)} orders fulfilled on time"
    else:
        penalty_sub = f"{on_time} orders on time, {at_risk} at risk"

    cards: List[Dict[str, str]] = [
        {
            "label": "Production Runs",
            "value": str(n_runs),
            "sub": ", ".join(produced_skus) if produced_skus else "—",
            "color": "#f59e0b",
        },
        {
            "label": "Setup + Changeover",
            "value": _fmt_money(total_setup_co),
            "sub": f"{n_runs} setups × {_fmt_money(setup_rate)} + {n_changeover} C/O",
            "color": "#a78bfa",
        },
        {
            "label": "Total Holding Cost",
            "value": _fmt_money(total_holding),
            "sub": "Produced goods until delivery",
            "color": "#38bdf8",
        },
        {
            "label": "Total Schedule Cost",
            "value": _fmt_money(total_cost),
            "sub": "Setup + Holding + Penalty",
            "color": "#f97316",
        },
        {
            "label": "Penalty Avoided",
            "value": _fmt_money(avoided),
            "sub": penalty_sub,
            "color": "#10b981",
        },
        {
            "label": "Lines Idle",
            "value": ", ".join(lines_idle) if lines_idle else "None",
            "sub": "Inventory covered their SKUs" if lines_idle else "All lines in use",
            "color": "#64748b",
        },
    ]
    return cards


def _fallback_insights(state: SchedulerState) -> List[Dict[str, str]]:
    gantt = state.get("gantt_tasks", [])
    reqs = state.get("requirements", [])
    summary = state.get("cost_summary", {}) or {}
    req_by_sku = {r["sku_id"]: r for r in reqs}

    # 1. Most urgent production
    prod_tasks = [t for t in gantt if t["type"] == "production"]
    if prod_tasks:
        most_urgent = min(prod_tasks, key=lambda t: t.get("delivery_date", "9999"))
        u_sku = most_urgent["sku_id"]
        u_name = most_urgent.get("product_name", u_sku)
        u_units = int(most_urgent.get("units_to_produce", 0))
        u_start = most_urgent.get("start_date", "")
        u_end = most_urgent.get("end_date", "")
        u_delivery = most_urgent.get("delivery_date", "")
        u_penalty = float(req_by_sku.get(u_sku, {}).get("penalty_per_unit", 0))
        u_risk = u_units * u_penalty
        insight_1 = {
            "icon": "🔴",
            "title": f"Urgent: {u_sku} ({u_start} → {u_end})",
            "body": (
                f"Start {u_name} immediately. {u_units:,} units must ship by "
                f"{u_delivery}. Penalty risk if delayed: {_fmt_money(u_risk)}."
            ),
        }
    else:
        insight_1 = {
            "icon": "✅",
            "title": "No production required",
            "body": "All customer orders are covered by on-hand inventory.",
        }

    # 2. JIT SKUs — those with short shelf life who were scheduled late
    jit_candidates = []
    schema_map = state.get("schema_map", {})
    raw_sheets = state.get("raw_sheets", {})
    sku_shelf: Dict[str, int] = {}
    if "sku_master" in schema_map:
        sku_info = schema_map["sku_master"]
        cols = sku_info["columns"]
        for row in raw_sheets.get(sku_info["sheet_name"], []):
            sku = row.get(cols.get("sku_id", ""), "")
            try:
                sl = int(float(row.get(cols.get("shelf_life_days", ""), 0)))
            except Exception:
                sl = 0
            if sku and sl > 0:
                sku_shelf[str(sku).strip()] = sl
    for t in prod_tasks:
        sl = sku_shelf.get(t["sku_id"], 999)
        if sl < 120:
            jit_candidates.append((t, sl))
    if jit_candidates:
        names = ", ".join(t["sku_id"] for t, _ in jit_candidates)
        insight_2 = {
            "icon": "🧊",
            "title": "JIT scheduling in effect",
            "body": (
                f"{names} have short shelf life. They are scheduled as close to "
                f"delivery as possible to minimise holding cost."
            ),
        }
    else:
        insight_2 = {
            "icon": "📦",
            "title": "No JIT-sensitive SKUs",
            "body": "All produced SKUs have long shelf life; holding cost is modest.",
        }

    # 3. Idle lines
    idle = summary.get("lines_idle", [])
    if idle:
        insight_3 = {
            "icon": "🛠️",
            "title": f"Idle line(s): {', '.join(idle)}",
            "body": (
                "These lines have no scheduled production because their SKUs "
                "are fully covered by inventory. Use the window for "
                "preventive maintenance or campaign pre-runs."
            ),
        }
    else:
        insight_3 = {
            "icon": "🏭",
            "title": "All lines active",
            "body": "Every production line has a scheduled run — no idle capacity.",
        }

    # 4. Cost savings vs worst case
    avoided = summary.get("total_avoided_penalty", 0)
    total = summary.get("total_schedule_cost", 0)
    insight_4 = {
        "icon": "💰",
        "title": "Penalty avoided vs total cost",
        "body": (
            f"Scheduling cost: {_fmt_money(total)}. Penalty avoided by producing "
            f"on time: {_fmt_money(avoided)}. Net benefit vs. not producing: "
            f"{_fmt_money(max(0, avoided - total))}."
        ),
    }

    return [insight_1, insight_2, insight_3, insight_4]


def _llm_insights(state: SchedulerState) -> List[Dict[str, str]]:
    """Try LLM; fall back to _fallback_insights on any failure."""
    try:
        prompt_path = os.path.join(
            os.path.dirname(__file__), "..", "prompts", "generate_insights.txt"
        )
        with open(prompt_path, "r", encoding="utf-8") as f:
            template = f.read()

        # Build a compact schedule summary for the LLM (no numbers to invent)
        compact_schedule = [
            {
                "sku_id": t["sku_id"],
                "product_name": t["product_name"],
                "line": t["line_name"],
                "type": t["type"],
                "start": t["start_date"],
                "end": t["end_date"],
                "delivery": t.get("delivery_date", ""),
                "units": t["units_to_produce"],
            }
            for t in state.get("gantt_tasks", [])
        ]
        compact_warnings = (
            state.get("ingest_warnings", [])
            + state.get("analyse_warnings", [])
            + state.get("plan_warnings", [])
            + state.get("schedule_warnings", [])
        )[:15]

        prompt = template.format(
            schedule_summary=json.dumps(compact_schedule, indent=2),
            cost_summary=json.dumps(state.get("cost_summary", {}), indent=2),
            warnings=json.dumps(compact_warnings, indent=2),
        )
        resp = chat(prompt)
        parsed = extract_json(resp)

        if isinstance(parsed, list) and len(parsed) >= 1:
            out: List[Dict[str, str]] = []
            for item in parsed[:4]:
                if not isinstance(item, dict):
                    continue
                title = str(item.get("title", "")).strip()
                body = str(item.get("body", "")).strip()
                if not (title and body):
                    continue
                out.append({
                    "icon": str(item.get("icon", "💡")).strip() or "💡",
                    "title": title,
                    "body": body,
                })
            if len(out) >= 2:
                # pad with fallback if fewer than 4
                while len(out) < 4:
                    fb = _fallback_insights(state)
                    for f_i in fb:
                        if len(out) >= 4:
                            break
                        if not any(o["title"] == f_i["title"] for o in out):
                            out.append(f_i)
                return out[:4]
    except Exception:
        pass
    return _fallback_insights(state)


def _warnings_summary(state: SchedulerState) -> List[str]:
    combined: List[str] = []
    for key in ("ingest_warnings", "analyse_warnings",
                "plan_warnings", "schedule_warnings"):
        for w in state.get(key, []) or []:
            w_s = str(w)
            # Ensure severity prefix
            if not w_s.lstrip().startswith("["):
                w_s = f"[INFO] {w_s}"
            combined.append(w_s)
    return combined


def report_node(state: SchedulerState) -> SchedulerState:
    log_section(_NODE, "Building final payload & LLM insights")

    # Build schedule_table
    schedule_table = _build_schedule_table(state)
    log_action(_NODE, f"Schedule table: {len(schedule_table)} row(s)")

    # KPI cards
    kpi_cards = _build_kpi_cards(state)

    # Insights (LLM with fallback)
    log_action(_NODE, "Generating insights (LLM → fallback if LLM fails)")
    insights = _llm_insights(state)
    log_ok(_NODE, f"{len(insights)} insight(s) generated")

    # Warnings summary
    warnings_summary = _warnings_summary(state)
    log_action(_NODE, f"Total pipeline warnings: {len(warnings_summary)}")

    # Planning end = max delivery date in requirements
    reqs = state.get("requirements", [])
    planning_end = None
    for r in reqs:
        try:
            d = _dt.date.fromisoformat(r["delivery_date"])
            if planning_end is None or d > planning_end:
                planning_end = d
        except Exception:
            continue
    planning_end_iso = planning_end.isoformat() if planning_end else state.get("planning_start_date", "")

    line_names = [info.get("name", lid) for lid, info in state.get("lines", {}).items()]

    final_payload = {
        "gantt_tasks":       state.get("gantt_tasks", []),
        "schedule_table":    schedule_table,
        "kpi_cards":         kpi_cards,
        "insights":          insights,
        "warnings_summary":  warnings_summary,
        "planning_start":    state.get("planning_start_date", ""),
        "planning_end":      planning_end_iso,
        "line_names":        line_names,
        "sku_count":         len(reqs),
        "requirements":      reqs,
        "cost_summary":      state.get("cost_summary", {}),
        "cost_breakdown":    state.get("cost_breakdown", []),
        "cost_params_used":  {
            "holding_cost_per_unit_per_day": state.get("cost_params", {}).get("holding_cost_per_unit_per_day"),
            "setup_cost_per_run":            state.get("cost_params", {}).get("setup_cost_per_run"),
            "stockout_cost_per_unit":        state.get("cost_params", {}).get("stockout_cost_per_unit"),
            "source":                        state.get("cost_params", {}).get("source", "default"),
        },
        "schedule_feasible": state.get("schedule_feasible", True),
    }

    return {
        **state,
        "schedule_table": schedule_table,
        "kpi_cards": kpi_cards,
        "insights": insights,
        "warnings_summary": warnings_summary,
        "final_payload": final_payload,
    }
