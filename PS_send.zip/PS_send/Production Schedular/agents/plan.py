"""
agents/plan.py
--------------
Agent 3 — PLAN

Pure Python. No LLM calls.

Responsibilities:
  - Filter to SKUs that need production
  - Group SKUs into production lines by shared machine sets
  - For each line, identify the bottleneck machine (lowest daily capacity)
  - Compute days_needed per SKU
  - Build the changeover matrix
  - Score and rank SKUs by urgency
"""
from __future__ import annotations

import datetime as _dt
import math
import re
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

from defaults import (
    DEFAULT_CHANGEOVER_DAYS,
    DEFAULT_SHIFT_HOURS_PER_DAY,
    DEFAULT_THROUGHPUT_UNITS_PER_DAY,
    PRIORITY_WEIGHT_DEFAULT,
    PRIORITY_WEIGHT_HIGH,
    PRIORITY_WEIGHT_LOW,
    PRIORITY_WEIGHT_NORMAL,
)
from pipeline_log import log_action, log_ok, log_section, log_warn
from state import SchedulerState

_NODE = "plan"


# ------------------------------------------------------------------
# Parsing helpers
# ------------------------------------------------------------------
def _parse_capacity(value: Any) -> Tuple[Optional[float], Optional[str]]:
    """Parse "150 kg/hr", "720 packs/hr" → (150.0, "kg/hr")."""
    if value is None:
        return None, None
    s = str(value).strip().lower()
    m = re.match(r"([0-9]+\.?[0-9]*)\s*([a-z0-9/]+)?", s)
    if not m:
        return None, None
    num = float(m.group(1))
    unit = (m.group(2) or "").strip() or None
    return num, unit


def _parse_pack(value: Any) -> Tuple[Optional[float], Optional[str]]:
    """Parse "300 g" → (300, "g")."""
    if value is None:
        return None, None
    s = str(value).strip().lower()
    m = re.match(r"([0-9]+\.?[0-9]*)\s*([a-z]+)?", s)
    if not m:
        return None, None
    num = float(m.group(1))
    unit = m.group(2) if m.group(2) else None
    return num, unit


def _to_int(v: Any, default: int = 0) -> int:
    try:
        return int(float(str(v).strip()))
    except (TypeError, ValueError):
        return default


def _to_float(v: Any, default: float = 0.0) -> float:
    try:
        return float(str(v).strip())
    except (TypeError, ValueError):
        return default


def _get(row: Dict[str, Any], col_map: Dict[str, str], semantic: str,
         default: Any = None) -> Any:
    actual = col_map.get(semantic)
    if actual is None:
        return default
    return row.get(actual, default)


def _priority_weight(priority: str) -> int:
    if not priority:
        return PRIORITY_WEIGHT_DEFAULT
    p = priority.lower()
    if "high" in p:
        return PRIORITY_WEIGHT_HIGH
    if "low" in p:
        return PRIORITY_WEIGHT_LOW
    if "norm" in p or "med" in p:
        return PRIORITY_WEIGHT_NORMAL
    return PRIORITY_WEIGHT_DEFAULT


# ------------------------------------------------------------------
# Capacity conversion
# ------------------------------------------------------------------
def _capacity_to_units_per_hour(cap_value: float, cap_unit: Optional[str],
                                pack_size: Optional[float],
                                pack_unit: Optional[str]) -> Optional[float]:
    """
    Convert a machine's throughput to units-per-hour using pack size.
    Supports kg/hr, g/hr, lt/hr (or l/hr), ml/hr, plus packs/units/bottles/trays/hr.
    """
    if cap_value is None:
        return None
    if cap_unit is None:
        # Assume already in units/hr
        return cap_value

    cu = cap_unit.lower()

    # Unit-count throughput — no pack-size conversion needed
    if any(tok in cu for tok in ("pack", "unit", "bottle", "tray", "piece", "can")):
        return cap_value

    if pack_size is None or pack_unit is None:
        return None  # can't convert kg/hr to units/hr without pack size

    pu = pack_unit.lower()

    # Mass
    if "kg/hr" in cu and pu in ("g", "gram", "grams"):
        return (cap_value * 1000.0) / pack_size
    if "g/hr" in cu and pu in ("g", "gram", "grams"):
        return cap_value / pack_size
    if "kg/hr" in cu and pu in ("kg",):
        return cap_value / pack_size

    # Volume
    if ("lt/hr" in cu or "l/hr" in cu or "litre/hr" in cu) and pu in ("ml",):
        return (cap_value * 1000.0) / pack_size
    if "ml/hr" in cu and pu in ("ml",):
        return cap_value / pack_size
    if ("lt/hr" in cu or "l/hr" in cu) and pu in ("l", "lt", "litre"):
        return cap_value / pack_size

    # Fallback — assume units/hr directly
    return cap_value


# ------------------------------------------------------------------
# Main node
# ------------------------------------------------------------------
def plan_node(state: SchedulerState) -> SchedulerState:
    log_section(_NODE, "Building line assignments & capacity estimates")
    warnings: List[str] = []

    requirements = state.get("requirements", [])
    schema_map = state.get("schema_map", {})
    raw_sheets = state.get("raw_sheets", {})

    # Track retry count (supervisor increments this implicitly by re-routing)
    retry_counts = dict(state.get("agent_retry_counts", {}))
    retry_counts["plan"] = retry_counts.get("plan", 0) + 1
    relaxed = state.get("relaxed_mode", False)
    if retry_counts["plan"] > 1:
        log_warn(_NODE, f"Retry #{retry_counts['plan']} — relaxed_mode={relaxed}")

    # Filter to production-needed SKUs
    to_produce = [r for r in requirements if r.get("needs_production")]
    log_action(_NODE, f"{len(to_produce)} SKU(s) require production: {[r['sku_id'] for r in to_produce]}")
    if not to_produce:
        warnings.append(
            "[INFO] No SKUs require production. All orders covered by inventory."
        )
        return {
            **state,
            "lines": {},
            "capacity": {},
            "changeovers": {},
            "priority_ranking": [],
            "plan_warnings": warnings,
            "agent_retry_counts": retry_counts,
        }

    # ---------- Routing → SKU → [machine_type, ...] ----------
    routing_index: Dict[str, List[str]] = defaultdict(list)
    if "routing" in schema_map:
        rt_info = schema_map["routing"]
        rt_cols = rt_info["columns"]
        rt_rows = raw_sheets.get(rt_info["sheet_name"], [])
        for row in rt_rows:
            sku = _get(row, rt_cols, "sku_id")
            mt = _get(row, rt_cols, "machine_type")
            if sku is None or mt is None:
                continue
            sku_key = str(sku).strip()
            mt_key = str(mt).strip()
            if mt_key and mt_key not in routing_index[sku_key]:
                routing_index[sku_key].append(mt_key)
    else:
        warnings.append(
            "[WARNING] No routing sheet found. Assuming single production line. "
            "Schedule may be suboptimal."
        )

    # ---------- SKU master → category (for line naming) ----------
    sku_category: Dict[str, str] = {}
    if "sku_master" in schema_map:
        sku_info = schema_map["sku_master"]
        sku_cols = sku_info["columns"]
        for row in raw_sheets.get(sku_info["sheet_name"], []):
            sku = _get(row, sku_cols, "sku_id")
            cat = _get(row, sku_cols, "category")
            if sku is not None and cat is not None:
                sku_category[str(sku).strip()] = str(cat).strip()

    # ---------- SKU master → pack size / shelf life ----------
    sku_pack: Dict[str, Tuple[Optional[float], Optional[str]]] = {}
    sku_shelf: Dict[str, int] = {}
    if "sku_master" in schema_map:
        sku_info = schema_map["sku_master"]
        sku_cols = sku_info["columns"]
        for row in raw_sheets.get(sku_info["sheet_name"], []):
            sku = _get(row, sku_cols, "sku_id")
            if sku is None:
                continue
            sku_key = str(sku).strip()
            ps, pu = _parse_pack(_get(row, sku_cols, "pack_size"))
            sku_pack[sku_key] = (ps, pu)
            sl = _to_int(_get(row, sku_cols, "shelf_life_days"), 0)
            if sl > 0:
                sku_shelf[sku_key] = sl

    # ---------- Step 2: group SKUs into lines ----------
    # Two SKUs share a line if they share the same set of machine types
    # OR (fallback) the same category.
    sku_ids = [r["sku_id"] for r in to_produce]
    line_groups: Dict[str, List[str]] = defaultdict(list)

    if routing_index:
        sig_to_line: Dict[Tuple[str, ...], str] = {}
        for sku in sku_ids:
            machines = tuple(sorted(routing_index.get(sku, [])))
            if not machines:
                # Fallback — group by category
                cat = sku_category.get(sku, "Unassigned")
                line_id = f"line_{_slug(cat)}"
                warnings.append(
                    f"[WARNING] No routing for {sku}. "
                    f"Assigning to line '{line_id}' based on category."
                )
            else:
                if machines not in sig_to_line:
                    # Derive a line name from category if all SKUs with this
                    # signature share one; else auto-name
                    sig_to_line[machines] = f"line_sig_{len(sig_to_line)}"
                line_id = sig_to_line[machines]
            line_groups[line_id].append(sku)
    else:
        # No routing sheet — one line for everyone
        for sku in sku_ids:
            line_groups["line_all"].append(sku)

    # ---------- Rename lines using category when consistent ----------
    renamed: Dict[str, str] = {}
    for lid, skus in line_groups.items():
        cats = {sku_category.get(s, "").strip() for s in skus if sku_category.get(s)}
        if len(cats) == 1 and next(iter(cats)):
            cat = next(iter(cats))
            new_id = f"line_{_slug(cat)}"
            # Ensure uniqueness
            base = new_id
            i = 1
            while new_id in renamed.values() and renamed.get(lid) != new_id:
                i += 1
                new_id = f"{base}_{i}"
            renamed[lid] = new_id
        else:
            renamed[lid] = lid

    # Apply rename
    lines_raw: Dict[str, List[str]] = defaultdict(list)
    for lid, skus in line_groups.items():
        lines_raw[renamed[lid]].extend(skus)

    # ---------- Step 3: bottleneck per line ----------
    # Parse machine_master into {machine_type: (cap_value, cap_unit, shift)}
    machines_master: Dict[str, Tuple[float, str, float]] = {}
    if "machine_master" in schema_map:
        mm_info = schema_map["machine_master"]
        mm_cols = mm_info["columns"]
        for row in raw_sheets.get(mm_info["sheet_name"], []):
            mt = _get(row, mm_cols, "machine_type")
            if mt is None:
                continue
            mt_key = str(mt).strip()
            cap_raw = _get(row, mm_cols, "capacity_per_hr")
            cap_val, cap_unit = _parse_capacity(cap_raw)
            if cap_val is None:
                continue
            shift = _to_float(_get(row, mm_cols, "shift_hours_per_day"), 0.0)
            if shift <= 0:
                shift = DEFAULT_SHIFT_HOURS_PER_DAY
                warnings.append(
                    f"[WARNING] shift_hours missing for {mt_key}. "
                    f"Defaulting to {DEFAULT_SHIFT_HOURS_PER_DAY} hrs/day."
                )
            machines_master[mt_key] = (cap_val, cap_unit or "", shift)
    else:
        warnings.append(
            "[WARNING] No machine_master found. Using default throughput of "
            f"{DEFAULT_THROUGHPUT_UNITS_PER_DAY:.0f} units/day. "
            "Production durations are estimates only."
        )

    lines: Dict[str, Dict[str, Any]] = {}
    capacity: Dict[str, Dict[str, Any]] = {}

    for line_id, skus in lines_raw.items():
        # Bottleneck = machine on this line with lowest daily-units for any
        # of the SKUs on it.  We compute per-SKU throughput and keep the
        # minimum across machines as the daily rate for that SKU.
        bottleneck_machine = "unknown"
        line_daily_min = float("inf")
        line_shift = DEFAULT_SHIFT_HOURS_PER_DAY

        # Pretty line name
        pretty = _prettify_line_id(line_id, skus, sku_category)

        for sku in skus:
            machine_types = routing_index.get(sku, [])
            ps, pu = sku_pack.get(sku, (None, None))
            sku_min_daily = float("inf")
            sku_bottleneck = "unknown"

            if not machine_types or not machines_master:
                daily = DEFAULT_THROUGHPUT_UNITS_PER_DAY
                sku_min_daily = daily
                sku_bottleneck = "default"
            else:
                for mt in machine_types:
                    entry = machines_master.get(mt)
                    if entry is None:
                        continue
                    cap_val, cap_unit, shift = entry
                    units_per_hr = _capacity_to_units_per_hour(
                        cap_val, cap_unit, ps, pu
                    )
                    if units_per_hr is None or units_per_hr <= 0:
                        continue
                    daily = units_per_hr * shift
                    if daily < sku_min_daily:
                        sku_min_daily = daily
                        sku_bottleneck = mt
                        line_shift = shift
                if sku_min_daily == float("inf"):
                    sku_min_daily = DEFAULT_THROUGHPUT_UNITS_PER_DAY
                    sku_bottleneck = "default"
                    warnings.append(
                        f"[WARNING] Could not compute capacity for {sku}. "
                        f"Using default {DEFAULT_THROUGHPUT_UNITS_PER_DAY:.0f} units/day."
                    )

            # Use this SKU's days_needed
            req = next((r for r in to_produce if r["sku_id"] == sku), None)
            net_req = req["net_requirement"] if req else 0
            days_needed = net_req / sku_min_daily if sku_min_daily > 0 else 1
            days_ceil = max(1, int(math.ceil(days_needed)))

            capacity[sku] = {
                "line_id": line_id,
                "daily_units": round(sku_min_daily, 2),
                "days_needed": round(days_needed, 3),
                "days_needed_ceil": days_ceil,
                "bottleneck_machine": sku_bottleneck,
            }

            if sku_min_daily < line_daily_min:
                line_daily_min = sku_min_daily
                bottleneck_machine = sku_bottleneck

        if line_daily_min == float("inf"):
            line_daily_min = DEFAULT_THROUGHPUT_UNITS_PER_DAY

        lines[line_id] = {
            "name": pretty,
            "sku_ids": skus,
            "shift_hours_per_day": line_shift,
            "bottleneck_machine": bottleneck_machine,
            "bottleneck_capacity_units_per_day": round(line_daily_min, 2),
        }
        log_action(_NODE, f"Line '{pretty}': SKUs={skus}, bottleneck='{bottleneck_machine}', capacity={round(line_daily_min, 2):.0f} units/day")

    # ---------- Step 5: changeover matrix ----------
    changeovers: Dict[str, Dict[str, Any]] = {}
    co_index: Dict[Tuple[str, str], Tuple[float, bool]] = {}

    if "changeover" in schema_map:
        co_info = schema_map["changeover"]
        co_cols = co_info["columns"]
        for row in raw_sheets.get(co_info["sheet_name"], []):
            a = _get(row, co_cols, "from_sku")
            b = _get(row, co_cols, "to_sku")
            mins = _to_float(_get(row, co_cols, "setup_time_min"), 0.0)
            cleaning = str(_get(row, co_cols, "cleaning_required", "")).strip().lower() in ("yes", "true", "1", "y")
            if a is None or b is None:
                continue
            a_key = str(a).strip()
            b_key = str(b).strip()
            if mins <= 0:
                continue
            co_index[(a_key, b_key)] = (mins, cleaning)
    else:
        warnings.append(
            f"[WARNING] No changeover sheet found. Using {DEFAULT_CHANGEOVER_DAYS}-day "
            "default for all same-line transitions."
        )

    # Build a changeover entry for every ordered pair that shares a line
    for line_id, info in lines.items():
        skus = info["sku_ids"]
        shift = info["shift_hours_per_day"] or DEFAULT_SHIFT_HOURS_PER_DAY
        for a in skus:
            for b in skus:
                if a == b:
                    continue
                key = f"{a}__{b}"

                # Try exact SKU-level match first
                found = co_index.get((a, b))
                if found is None:
                    # Try category/product-level fuzzy match
                    cat_a = sku_category.get(a, "").lower()
                    cat_b = sku_category.get(b, "").lower()
                    for (fa, fb), val in co_index.items():
                        fa_l, fb_l = fa.lower(), fb.lower()
                        # Loose match: if both sides mention the same category words
                        if (cat_a and cat_a in fa_l) and (cat_b and cat_b in fb_l):
                            found = val
                            break

                if found is not None:
                    mins, cleaning = found
                    days = mins / (60.0 * shift)
                    changeovers[key] = {
                        "days": round(days, 3),
                        "cleaning_required": cleaning,
                        "source": "dataset",
                    }
                else:
                    changeovers[key] = {
                        "days": DEFAULT_CHANGEOVER_DAYS,
                        "cleaning_required": False,
                        "source": "default",
                    }

    # ---------- Step 6: priority ranking ----------
    planning_start = _dt.date.fromisoformat(state["planning_start_date"])
    scored: List[Tuple[float, str]] = []
    for req in to_produce:
        delivery = _dt.date.fromisoformat(req["delivery_date"])
        days_until = max(1, (delivery - planning_start).days)
        priority = req.get("priority", "Normal")
        weight = _priority_weight(priority)
        if not priority or str(priority).lower() in ("nan", "none", ""):
            warnings.append(
                f"[WARNING] priority_flag missing for {req['sku_id']}. "
                "Using weight=2."
            )
        urgency = (1.0 / days_until) * max(1.0, req.get("penalty_per_unit", 1.0)) * weight
        scored.append((urgency, req["sku_id"]))

    scored.sort(key=lambda x: x[0], reverse=True)
    priority_ranking = [sku for _, sku in scored]
    log_ok(_NODE, f"Priority ranking: {priority_ranking}")
    log_ok(_NODE, f"Plan complete — {len(lines)} line(s), {len(changeovers)} changeover pair(s)")

    return {
        **state,
        "lines": lines,
        "capacity": capacity,
        "changeovers": changeovers,
        "priority_ranking": priority_ranking,
        "plan_warnings": warnings,
        "agent_retry_counts": retry_counts,
    }


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", (text or "line").lower()).strip("_") or "line"


def _prettify_line_id(line_id: str, skus: List[str], sku_category: Dict[str, str]) -> str:
    cats = {sku_category.get(s, "").strip() for s in skus if sku_category.get(s)}
    if len(cats) == 1 and next(iter(cats)):
        return f"{next(iter(cats))} Line"
    # fallback to capitalised id
    pretty = line_id.replace("line_", "").replace("_", " ").strip().title()
    return f"{pretty} Line" if pretty else line_id
