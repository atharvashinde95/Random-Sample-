"""
agents/schedule.py
------------------
Agent 4 — SCHEDULE

Deterministic. No LLM calls.

Turns the plan into a concrete timeline by calling OR-Tools CP-SAT
via the MCP tool. Produces gantt_tasks covering every production
run, every changeover and — if the solver fails — a greedy
forward-scheduled fallback so that NO SKU is silently dropped.
"""
from __future__ import annotations

import datetime as _dt
from typing import Any, Dict, List

from defaults import (
    CP_SAT_MAX_SECONDS,
    CP_SAT_WORKERS,
    DEFAULT_LOGISTICS_BUFFER_DAYS,
    DEFAULT_PRODUCTION_DAYS_IF_UNKNOWN,
    JIT_SHELF_LIFE_THRESHOLD_DAYS,
    MAX_AGENT_RETRIES,
)
from mcp_server import call_tool
from pipeline_log import log_action, log_ok, log_section, log_warn, log_error
from state import SchedulerState

_NODE = "schedule"


def _date_from_offset(start: _dt.date, offset: int) -> str:
    return (start + _dt.timedelta(days=int(offset))).isoformat()


def _shelf_life_for(sku_id: str, state: SchedulerState) -> int:
    """Read shelf life from sku_master via the schema map."""
    schema_map = state.get("schema_map", {})
    raw_sheets = state.get("raw_sheets", {})
    if "sku_master" not in schema_map:
        return 999
    info = schema_map["sku_master"]
    cols = info["columns"]
    sku_col = cols.get("sku_id")
    sl_col = cols.get("shelf_life_days")
    if not sku_col or not sl_col:
        return 999
    for row in raw_sheets.get(info["sheet_name"], []):
        if str(row.get(sku_col, "")).strip() == sku_id:
            try:
                return int(float(row.get(sl_col)))
            except (TypeError, ValueError):
                return 999
    return 999


def _build_solver_inputs(state: SchedulerState) -> Dict[str, Any]:
    reqs = state.get("requirements", [])
    lines_info = state.get("lines", {})
    capacity = state.get("capacity", {})
    changeovers = state.get("changeovers", {})
    cost_params = state.get("cost_params", {})
    planning_start = _dt.date.fromisoformat(state["planning_start_date"])
    holding_rate = float(cost_params.get("holding_cost_per_unit_per_day", 0.5))

    to_produce = [r for r in reqs if r.get("needs_production")]
    tasks: List[Dict[str, Any]] = []
    max_delivery_offset = 0

    for req in to_produce:
        sku = req["sku_id"]
        delivery = _dt.date.fromisoformat(req["delivery_date"])
        delivery_offset = (delivery - planning_start).days

        cap = capacity.get(sku, {})
        days_needed = cap.get("days_needed_ceil", DEFAULT_PRODUCTION_DAYS_IF_UNKNOWN)
        if days_needed < 1:
            days_needed = 1

        line_id = cap.get("line_id")
        if line_id is None:
            # Find the first line that contains this SKU
            for lid, info in lines_info.items():
                if sku in info.get("sku_ids", []):
                    line_id = lid
                    break
        if line_id is None:
            line_id = next(iter(lines_info.keys()), "line_all")

        shelf_life = _shelf_life_for(sku, state)
        jit_eligible = shelf_life < JIT_SHELF_LIFE_THRESHOLD_DAYS

        tasks.append({
            "sku_id": sku,
            "line_id": line_id,
            "days_needed": int(days_needed),
            "delivery_offset": int(delivery_offset),
            "logistics_buffer_days": DEFAULT_LOGISTICS_BUFFER_DAYS,
            "net_requirement": int(req.get("net_requirement", 0)),
            "holding_rate": holding_rate,
            "penalty_per_unit": float(req.get("penalty_per_unit", 0)),
            "jit_eligible": jit_eligible,
        })
        if delivery_offset > max_delivery_offset:
            max_delivery_offset = delivery_offset

    # Lines payload: {line_id: [sku_ids...]}
    lines_payload: Dict[str, List[str]] = {}
    for lid, info in lines_info.items():
        line_skus = [t["sku_id"] for t in tasks if t["line_id"] == lid]
        if line_skus:
            lines_payload[lid] = line_skus

    # Changeover days-only payload
    co_days: Dict[str, float] = {
        key: float(info.get("days", 0.25))
        for key, info in changeovers.items()
    }

    horizon = max(30, max_delivery_offset + 10)

    return {
        "tasks": tasks,
        "lines": lines_payload,
        "changeovers": co_days,
        "horizon": horizon,
        "holding_rate": holding_rate,
        "setup_cost": float(cost_params.get("setup_cost_per_run", 2000)),
        "relaxed_mode": bool(state.get("relaxed_mode", False)),
        "max_time_in_seconds": CP_SAT_MAX_SECONDS,
        "num_search_workers": CP_SAT_WORKERS,
    }


def _greedy_schedule(solver_inputs: Dict[str, Any],
                     priority_ranking: List[str]) -> Dict[str, Any]:
    """Sorted forward-fill per line. Used when CP-SAT fails."""
    tasks = solver_inputs.get("tasks", [])
    lines = solver_inputs.get("lines", {})
    changeovers = solver_inputs.get("changeovers", {})
    horizon = solver_inputs.get("horizon", 60)

    # Sort each line's SKUs by priority_ranking, then by delivery
    rank_idx = {s: i for i, s in enumerate(priority_ranking)}
    task_by_sku = {t["sku_id"]: t for t in tasks}

    offsets: List[Dict[str, Any]] = []
    co_records: List[Dict[str, Any]] = []

    for line_id, sku_list in lines.items():
        sorted_skus = sorted(
            sku_list,
            key=lambda s: (rank_idx.get(s, 9999),
                           task_by_sku[s].get("delivery_offset", 9999)),
        )
        cursor = 0
        prev = None
        for sku in sorted_skus:
            t = task_by_sku[sku]
            # Insert changeover from prev if applicable
            if prev is not None:
                co_days = int(round(changeovers.get(f"{prev}__{sku}", 0.25)))
                if co_days > 0:
                    co_records.append({
                        "line_id": line_id,
                        "from_sku": prev,
                        "to_sku": sku,
                        "start_offset": cursor,
                        "end_offset": cursor + co_days,
                        "duration": co_days,
                    })
                    cursor += co_days
            start = cursor
            end = start + int(t.get("days_needed", 1))
            cursor = end
            offsets.append({
                "sku_id": sku,
                "start_offset": start,
                "end_offset": end,
            })
            prev = sku

    return {
        "status": "HEURISTIC",
        "tasks_with_offsets": offsets,
        "changeover_intervals": co_records,
        "solver_wall_time": 0.0,
    }


def schedule_node(state: SchedulerState) -> SchedulerState:
    log_section(_NODE, "Running CP-SAT / greedy scheduler")
    warnings: List[str] = []

    # Track retries
    retry_counts = dict(state.get("agent_retry_counts", {}))
    retry_counts["schedule"] = retry_counts.get("schedule", 0) + 1
    forced_greedy = retry_counts["schedule"] > 1

    reqs = state.get("requirements", [])
    to_produce = [r for r in reqs if r.get("needs_production")]
    if not to_produce:
        log_ok(_NODE, "No production needed — all orders inventory-covered")
        return {
            **state,
            "gantt_tasks": [],
            "schedule_feasible": True,
            "infeasibility_reason": None,
            "schedule_warnings": warnings,
            "agent_retry_counts": retry_counts,
        }

    planning_start = _dt.date.fromisoformat(state["planning_start_date"])
    lines_info = state.get("lines", {})

    solver_inputs = _build_solver_inputs(state)
    log_action(_NODE, f"Solver inputs: {len(solver_inputs['tasks'])} task(s), horizon={solver_inputs['horizon']} days, relaxed={solver_inputs['relaxed_mode']}")

    # If we've already been through here once (plan retries exhausted),
    # go straight to greedy rather than re-invoking CP-SAT.
    if forced_greedy:
        log_warn(_NODE, "Forced greedy — skipping CP-SAT (retries exhausted)")
        warnings.append(
            "[WARNING] Schedule retried — skipping CP-SAT and using greedy "
            "forward-schedule directly."
        )
        result = _greedy_schedule(
            solver_inputs, state.get("priority_ranking", [])
        )
        status = "HEURISTIC"
    else:
        log_action(_NODE, "Calling MCP tool: solve_production_schedule (CP-SAT)")
        result = call_tool("solve_production_schedule", solver_inputs)
        status = result.get("status", "UNKNOWN")
    wall_time = result.get("solver_wall_time", 0.0)
    log_ok(_NODE, f"Solver status: {status} (wall={wall_time:.2f}s)")
    warnings.append(f"[INFO] Scheduler status: {status} (wall={wall_time:.2f}s).")

    feasible = status in ("OPTIMAL", "FEASIBLE", "HEURISTIC")
    infeasibility_reason = None

    if status not in ("OPTIMAL", "FEASIBLE", "HEURISTIC"):
        retry = state.get("agent_retry_counts", {}).get("plan", 0)
        if status == "INFEASIBLE" and retry < MAX_AGENT_RETRIES:
            log_warn(_NODE, f"CP-SAT INFEASIBLE — will retry plan (attempt {retry+1}/{MAX_AGENT_RETRIES})")
            # Tell the supervisor to retry plan with relaxed mode
            warnings.append(
                "[WARNING] CP-SAT returned INFEASIBLE. "
                "Supervisor will retry plan with relaxed constraints."
            )
            new_state = {
                **state,
                "schedule_feasible": False,
                "infeasibility_reason": (
                    "CP-SAT could not find a valid schedule. Likely cause: "
                    "delivery dates too tight for available capacity. "
                    "Supervisor will retry with relaxed constraints."
                ),
                "relaxed_mode": True,
                "schedule_warnings": warnings,
                "agent_retry_counts": retry_counts,
            }
            # Remove gantt_tasks so supervisor re-routes to plan
            new_state.pop("gantt_tasks", None)
            return new_state
        # Fall back to greedy
        log_warn(_NODE, f"Solver {status} — falling back to greedy schedule")
        warnings.append(
            f"[WARNING] Solver {status}. Falling back to greedy forward-schedule. "
            "Tasks marked HEURISTIC."
        )
        result = _greedy_schedule(
            solver_inputs, state.get("priority_ranking", []),
        )
        status = "HEURISTIC"
        feasible = True  # we produced *some* schedule

    offsets = result.get("tasks_with_offsets", [])
    co_intervals = result.get("changeover_intervals", [])

    # Build gantt_tasks
    gantt_tasks: List[Dict[str, Any]] = []
    offset_by_sku = {o["sku_id"]: o for o in offsets}

    # Helper lookups
    req_by_sku = {r["sku_id"]: r for r in reqs}
    line_name_by_id = {lid: info.get("name", lid) for lid, info in lines_info.items()}

    for t in solver_inputs["tasks"]:
        sku = t["sku_id"]
        req = req_by_sku.get(sku, {})
        line_id = t["line_id"]
        line_name = line_name_by_id.get(line_id, line_id)

        offs = offset_by_sku.get(sku)
        if offs is None:
            # Solver didn't place this SKU — use last-resort start=0
            start_off = 0
            end_off = t.get("days_needed", 1)
            warnings.append(
                f"[WARNING] Solver did not place {sku}. "
                "Scheduling from day 0 (LATE RISK)."
            )
        else:
            start_off = int(offs["start_offset"])
            end_off = int(offs["end_offset"])

        start_date = _date_from_offset(planning_start, start_off)
        end_date = _date_from_offset(planning_start, end_off)
        delivery = req.get("delivery_date", end_date)

        # Flag late risk
        late_risk = False
        try:
            if _dt.date.fromisoformat(end_date) > _dt.date.fromisoformat(delivery):
                late_risk = True
                warnings.append(
                    f"[WARNING] {sku} scheduled end {end_date} is AFTER "
                    f"delivery {delivery}. LATE RISK."
                )
        except Exception:
            pass

        gantt_tasks.append({
            "task_id": f"T_{sku}",
            "sku_id": sku,
            "product_name": req.get("product_name", sku),
            "line_id": line_id,
            "line_name": line_name,
            "start_date": start_date,
            "end_date": end_date,
            "units_to_produce": int(req.get("net_requirement", 0)),
            "type": "production",
            "delivery_date": delivery,
            "solver_status": status,
            "late_risk": late_risk,
        })

    # Changeover tasks
    for co in co_intervals:
        start_date = _date_from_offset(planning_start, co["start_offset"])
        end_date = _date_from_offset(planning_start, co["end_offset"])
        from_sku = co["from_sku"]
        to_sku = co["to_sku"]
        line_id = co.get("line_id", "")
        gantt_tasks.append({
            "task_id": f"CO_{from_sku}_{to_sku}",
            "sku_id": f"CO_{from_sku}__{to_sku}",
            "product_name": f"Changeover {from_sku} → {to_sku}",
            "line_id": line_id,
            "line_name": line_name_by_id.get(line_id, line_id),
            "start_date": start_date,
            "end_date": end_date,
            "units_to_produce": 0,
            "type": "changeover",
            "delivery_date": "",
            "solver_status": status,
            "late_risk": False,
        })

    # Sort by start_date
    gantt_tasks.sort(key=lambda g: g["start_date"])

    late_count = sum(1 for g in gantt_tasks if g.get("late_risk"))
    log_ok(_NODE, f"Schedule complete — {len(gantt_tasks)} gantt entries, {late_count} late-risk SKU(s)")

    return {
        **state,
        "gantt_tasks": gantt_tasks,
        "schedule_feasible": feasible,
        "infeasibility_reason": infeasibility_reason,
        "schedule_warnings": warnings,
        "relaxed_mode": state.get("relaxed_mode", False),
        "agent_retry_counts": retry_counts,
    }
