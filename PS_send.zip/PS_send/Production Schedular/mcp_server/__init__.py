"""FastMCP tool server for the production scheduler."""
from .server import call_tool

__all__ = ["call_tool"]
