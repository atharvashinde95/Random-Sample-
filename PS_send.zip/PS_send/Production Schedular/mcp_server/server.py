"""
mcp_server/server.py
--------------------
FastMCP server that exposes the three deterministic tools to any MCP
client. The tools are also importable directly from
mcp_server.tools so the LangGraph agents can call them without
needing the server to be running — which is useful for batch runs,
tests and Streamlit.

Run as a standalone MCP server:
    python -m mcp_server.server
"""
from __future__ import annotations

from typing import Any, Dict

from mcp_server.tools.excel_reader import read_excel_all_sheets as _read_excel
from mcp_server.tools.lp_solver import solve_net_requirement as _solve_net
from mcp_server.tools.cp_solver import solve_production_schedule as _solve_sched


# ------------------------------------------------------------------
# Plain Python façade — used by agents when MCP isn't running.
# ------------------------------------------------------------------
def call_tool(name: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """Dispatch to a tool by name. Agents use this helper."""
    if name == "read_excel_all_sheets":
        return _read_excel(params.get("file_path", ""))
    if name == "solve_net_requirement":
        return _solve_net(params)
    if name == "solve_production_schedule":
        return _solve_sched(params)
    return {"error": f"unknown tool: {name}"}


# ------------------------------------------------------------------
# FastMCP server definition (only activated when fastmcp is present
# AND this module is run as the entry point).
# ------------------------------------------------------------------
def _build_mcp_app():
    try:
        from fastmcp import FastMCP
    except ImportError:
        return None

    app = FastMCP("production-scheduler-tools")

    @app.tool()
    def read_excel_all_sheets(file_path: str) -> Dict[str, Any]:
        """Read every sheet of an Excel workbook."""
        return _read_excel(file_path)

    @app.tool()
    def solve_net_requirement(
        order_qty: int = 0,
        on_hand_qty: int = 0,
        holding_rate: float = 0.5,
        days_until_delivery: int = 0,
        shelf_life_remaining_days: int = 999,
        setup_cost: float = 2000.0,
    ) -> Dict[str, Any]:
        """OR-Tools GLOP net requirement LP."""
        return _solve_net({
            "order_qty": order_qty,
            "on_hand_qty": on_hand_qty,
            "holding_rate": holding_rate,
            "days_until_delivery": days_until_delivery,
            "shelf_life_remaining_days": shelf_life_remaining_days,
            "setup_cost": setup_cost,
        })

    @app.tool()
    def solve_production_schedule(params: Dict[str, Any]) -> Dict[str, Any]:
        """OR-Tools CP-SAT production schedule."""
        return _solve_sched(params)

    return app


if __name__ == "__main__":
    app = _build_mcp_app()
    if app is None:
        print("fastmcp not installed — exiting.")
    else:
        app.run()
