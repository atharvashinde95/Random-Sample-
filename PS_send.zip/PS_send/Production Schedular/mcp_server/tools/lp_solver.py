"""
tools/lp_solver.py
------------------
MCP tool: solve_net_requirement
OR-Tools GLOP LP that decides, for a partial-inventory case,
whether to use the existing stock + produce the deficit, or
discard the inventory and do a full fresh run.

Objective: minimise holding cost of inventory kept + amortised
setup cost of production.

Inputs  (all optional except order_qty / on_hand_qty):
    order_qty                int  — customer order size
    on_hand_qty              int  — usable on-hand (already expiry-checked)
    holding_rate             float— ₹/unit/day
    days_until_delivery      int
    shelf_life_remaining_days int (0 = already expired; caller handles)
    setup_cost               float

Outputs:
    recommended_production_qty   int
    recommended_inventory_use    int
    decision_reason              str
    solver_status                str
"""
from __future__ import annotations

from typing import Any, Dict


def solve_net_requirement(params: Dict[str, Any]) -> Dict[str, Any]:
    order_qty = int(params.get("order_qty", 0))
    on_hand = int(params.get("on_hand_qty", 0))
    holding_rate = float(params.get("holding_rate", 0.5))
    days = int(params.get("days_until_delivery", 0))
    shelf_life = int(params.get("shelf_life_remaining_days", 999))
    setup_cost = float(params.get("setup_cost", 2000.0))

    # ---- Trivial cases handled without the solver --------------------
    if order_qty <= 0:
        return {
            "recommended_production_qty": 0,
            "recommended_inventory_use": 0,
            "decision_reason": "Order quantity is zero.",
            "solver_status": "TRIVIAL",
        }
    if on_hand <= 0:
        return {
            "recommended_production_qty": order_qty,
            "recommended_inventory_use": 0,
            "decision_reason": "No usable on-hand stock; full fresh run.",
            "solver_status": "TRIVIAL",
        }
    if on_hand >= order_qty:
        return {
            "recommended_production_qty": 0,
            "recommended_inventory_use": order_qty,
            "decision_reason": "On-hand stock fully covers the order.",
            "solver_status": "TRIVIAL",
        }

    # ---- Partial coverage — use GLOP ---------------------------------
    # Key insight: we're producing the deficit anyway, so the setup cost is
    # already paid. The ONLY question is whether to use the existing
    # inventory (saving holding days × holding rate per unit used) or
    # discard it (only worthwhile if its shelf life makes it risky).
    try:
        from ortools.linear_solver import pywraplp
    except ImportError:
        # Fallback: just use the partial stock and produce the deficit
        deficit = order_qty - on_hand
        return {
            "recommended_production_qty": deficit,
            "recommended_inventory_use": on_hand,
            "decision_reason": "GLOP unavailable; rule-based partial fill.",
            "solver_status": "FALLBACK",
        }

    solver = pywraplp.Solver.CreateSolver("GLOP")
    if solver is None:
        deficit = order_qty - on_hand
        return {
            "recommended_production_qty": deficit,
            "recommended_inventory_use": on_hand,
            "decision_reason": "GLOP solver not available; rule-based partial fill.",
            "solver_status": "FALLBACK",
        }

    inf = solver.infinity()
    inv_use = solver.NumVar(0.0, float(on_hand), "inv_use")
    prod_qty = solver.NumVar(0.0, inf, "prod_qty")

    # Meet the order exactly
    solver.Add(inv_use + prod_qty == order_qty)

    # Per-unit cost of USING inventory: holding_rate × days_held.
    # Per-unit cost of PRODUCING: holding_rate × 0 (produced just-in-time)
    # PLUS a setup-risk penalty that kicks in when we produce MORE than the
    # deficit — i.e. when we're discarding still-usable inventory.
    # To capture this without binary vars we add a linear premium per
    # unit produced beyond the deficit.
    inv_hold_cost = float(holding_rate) * max(0, int(days))

    # If remaining shelf life is shorter than days-to-delivery, holding
    # the inventory is a bad idea — the inventory will expire en route.
    if shelf_life < days:
        inv_hold_cost = inv_hold_cost + 1_000.0

    # Produced units cost: effectively 0 (we're producing the deficit anyway),
    # but we add a very small production preference multiplier on units
    # beyond the strict deficit so the LP doesn't pointlessly over-produce.
    prod_unit_cost = inv_hold_cost + 0.01  # slightly > inv use when inv is healthy

    solver.Minimize(inv_hold_cost * inv_use + prod_unit_cost * prod_qty)

    status = solver.Solve()
    status_map = {
        pywraplp.Solver.OPTIMAL: "OPTIMAL",
        pywraplp.Solver.FEASIBLE: "FEASIBLE",
        pywraplp.Solver.INFEASIBLE: "INFEASIBLE",
        pywraplp.Solver.UNBOUNDED: "UNBOUNDED",
        pywraplp.Solver.ABNORMAL: "ABNORMAL",
        pywraplp.Solver.NOT_SOLVED: "NOT_SOLVED",
    }
    status_name = status_map.get(status, "UNKNOWN")

    if status in (pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE):
        used = int(round(inv_use.solution_value()))
        produced = int(round(prod_qty.solution_value()))
        # Safety: make sure they still sum to the order
        if used + produced != order_qty:
            produced = order_qty - used
        reason = (
            f"LP decision: use {used} on-hand + produce {produced}. "
            f"(shelf_life={shelf_life}d, delivery={days}d, "
            f"hold={holding_rate} ₹/unit/day)"
        )
        return {
            "recommended_production_qty": produced,
            "recommended_inventory_use": used,
            "decision_reason": reason,
            "solver_status": status_name,
        }

    # Fallback for infeasible / abnormal
    deficit = order_qty - on_hand
    return {
        "recommended_production_qty": deficit,
        "recommended_inventory_use": on_hand,
        "decision_reason": f"GLOP {status_name}; rule-based partial fill.",
        "solver_status": status_name,
    }
