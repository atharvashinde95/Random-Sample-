"""
tools/cp_solver.py
------------------
MCP tool: solve_production_schedule
OR-Tools CP-SAT model that assigns a start/end day offset to every
production task. Objective: minimise total holding cost while
respecting line capacity, delivery deadlines, changeover gaps and
(optionally) a JIT window.

Inputs
    tasks: list of {
        sku_id, line_id, days_needed (int), delivery_offset (int),
        logistics_buffer_days (int), net_requirement (int),
        holding_rate (float), penalty_per_unit (float),
        jit_eligible (bool)
    }
    lines:        {line_id: [sku_id, ...]}
    changeovers:  {"from__to": days (float)}
    holding_rate: float (global default)
    setup_cost:   float
    horizon:      int (days)
    relaxed_mode: bool

Outputs
    status                  "OPTIMAL" | "FEASIBLE" | "INFEASIBLE" |
                            "TIMEOUT" | "ERROR"
    tasks_with_offsets      list of {sku_id, start_offset, end_offset}
    solver_wall_time        float seconds
    changeover_intervals    list of {from_sku, to_sku, start, end, line_id}
"""
from __future__ import annotations

import math
from typing import Any, Dict, List


def solve_production_schedule(params: Dict[str, Any]) -> Dict[str, Any]:
    tasks: List[Dict[str, Any]] = params.get("tasks", []) or []
    lines: Dict[str, List[str]] = params.get("lines", {}) or {}
    changeovers: Dict[str, float] = params.get("changeovers", {}) or {}
    horizon: int = int(params.get("horizon", 60))
    relaxed_mode: bool = bool(params.get("relaxed_mode", False))
    max_seconds: float = float(params.get("max_time_in_seconds", 30.0))
    workers: int = int(params.get("num_search_workers", 4))

    if not tasks:
        return {
            "status": "OPTIMAL",
            "tasks_with_offsets": [],
            "changeover_intervals": [],
            "solver_wall_time": 0.0,
        }

    try:
        from ortools.sat.python import cp_model
    except ImportError:
        return {
            "status": "ERROR",
            "error": "ortools not installed",
            "tasks_with_offsets": [],
            "changeover_intervals": [],
            "solver_wall_time": 0.0,
        }

    model = cp_model.CpModel()

    # --- ceil helper for floating-point changeover days ---
    def _ceil_int(x: float) -> int:
        return int(math.ceil(max(0.0, float(x))))

    # Build all variables and production intervals
    starts: Dict[str, Any] = {}
    ends: Dict[str, Any] = {}
    durations: Dict[str, int] = {}
    intervals: Dict[str, Any] = {}

    task_index = {t["sku_id"]: t for t in tasks}

    for t in tasks:
        sku = t["sku_id"]
        dur = max(1, int(t.get("days_needed", 1)))
        durations[sku] = dur

        start = model.NewIntVar(0, horizon, f"start_{sku}")
        end = model.NewIntVar(0, horizon, f"end_{sku}")
        starts[sku] = start
        ends[sku] = end

        # C1 duration
        model.Add(end == start + dur)

        # C2 finish before delivery (with buffer unless relaxed)
        delivery_offset = int(t.get("delivery_offset", horizon))
        buffer = 0 if relaxed_mode else int(t.get("logistics_buffer_days", 3))
        deadline = delivery_offset - buffer
        # If deadline is impossible, allow end <= delivery_offset and we'll
        # flag LATE RISK afterwards — never drop the SKU.
        if deadline < dur:
            model.Add(end <= max(delivery_offset, dur))
        else:
            model.Add(end <= deadline)

        # C3 cannot start before today is implicit (var lb=0).

        # C5 JIT constraint
        if (not relaxed_mode) and t.get("jit_eligible", False):
            jit_window = int(t.get("logistics_buffer_days", 3)) + 2
            lower = delivery_offset - dur - jit_window
            if lower > 0:
                model.Add(start >= lower)

        interval = model.NewIntervalVar(start, dur, end, f"iv_{sku}")
        intervals[sku] = interval

    # C4 No-overlap per line + changeover intervals between consecutive pairs
    changeover_interval_records: List[Dict[str, Any]] = []
    co_counter = 0

    for line_id, sku_list in lines.items():
        line_intervals = [intervals[s] for s in sku_list if s in intervals]
        # Add changeover intervals between every unordered pair on this line.
        # Only one of (a→b) or (b→a) materialises depending on which SKU
        # actually precedes the other — we create a boolean for that.
        sku_list = [s for s in sku_list if s in intervals]
        pair_co_intervals = []

        for i, a in enumerate(sku_list):
            for b in sku_list[i + 1:]:
                co_days_ab = _ceil_int(
                    changeovers.get(f"{a}__{b}", changeovers.get("__default__", 0))
                )
                co_days_ba = _ceil_int(
                    changeovers.get(f"{b}__{a}", changeovers.get("__default__", 0))
                )
                # We'll create an optional interval right after whichever
                # task ends first.
                a_first = model.NewBoolVar(f"order_{a}_before_{b}")

                # a before b
                if co_days_ab > 0:
                    co_start_ab = model.NewIntVar(0, horizon, f"co_s_{a}_{b}")
                    co_end_ab = model.NewIntVar(0, horizon, f"co_e_{a}_{b}")
                    model.Add(co_start_ab == ends[a]).OnlyEnforceIf(a_first)
                    model.Add(co_end_ab == co_start_ab + co_days_ab).OnlyEnforceIf(a_first)
                    co_iv_ab = model.NewOptionalIntervalVar(
                        co_start_ab, co_days_ab, co_end_ab,
                        a_first, f"co_iv_{a}_{b}"
                    )
                    pair_co_intervals.append(co_iv_ab)
                    # Record (we'll only keep those actually activated)
                    changeover_interval_records.append({
                        "line_id": line_id,
                        "from_sku": a,
                        "to_sku": b,
                        "start_var": co_start_ab,
                        "end_var": co_end_ab,
                        "active_var": a_first,
                        "duration": co_days_ab,
                    })
                    co_counter += 1

                # b before a
                if co_days_ba > 0:
                    b_first = a_first.Not()
                    co_start_ba = model.NewIntVar(0, horizon, f"co_s_{b}_{a}")
                    co_end_ba = model.NewIntVar(0, horizon, f"co_e_{b}_{a}")
                    model.Add(co_start_ba == ends[b]).OnlyEnforceIf(b_first)
                    model.Add(co_end_ba == co_start_ba + co_days_ba).OnlyEnforceIf(b_first)
                    co_iv_ba = model.NewOptionalIntervalVar(
                        co_start_ba, co_days_ba, co_end_ba,
                        b_first, f"co_iv_{b}_{a}"
                    )
                    pair_co_intervals.append(co_iv_ba)
                    changeover_interval_records.append({
                        "line_id": line_id,
                        "from_sku": b,
                        "to_sku": a,
                        "start_var": co_start_ba,
                        "end_var": co_end_ba,
                        "active_var": b_first,
                        "duration": co_days_ba,
                    })
                    co_counter += 1

                # Tie ordering to the boolean — production intervals
                # can't overlap anyway (NoOverlap) but we must ensure
                # the correct changeover is the one active.
                model.Add(ends[a] <= starts[b]).OnlyEnforceIf(a_first)
                model.Add(ends[b] <= starts[a]).OnlyEnforceIf(a_first.Not())

        if line_intervals or pair_co_intervals:
            model.AddNoOverlap(line_intervals + pair_co_intervals)

    # Objective: minimise total holding-cost across SKUs
    # holding_cost_i = (delivery_offset_i - end_i) * net_requirement_i * holding_rate
    # Scale the rate to an integer (×100) so CP-SAT stays integer.
    SCALE = 100
    obj_terms = []
    for t in tasks:
        sku = t["sku_id"]
        net_req = int(t.get("net_requirement", 0))
        rate = float(t.get("holding_rate", 0.5))
        delivery_offset = int(t.get("delivery_offset", horizon))
        coef = int(round(net_req * rate * SCALE))
        if coef <= 0:
            continue
        # (delivery_offset - end_i) must be >= 0; model.NewIntVar to capture
        hold_days = model.NewIntVar(0, horizon, f"hold_{sku}")
        model.Add(hold_days >= delivery_offset - ends[sku])
        model.Add(hold_days >= 0)
        obj_terms.append(coef * hold_days)

    if obj_terms:
        model.Minimize(sum(obj_terms))

    # Solve
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = max_seconds
    solver.parameters.num_search_workers = workers

    result = solver.Solve(model)

    status_name = {
        cp_model.OPTIMAL: "OPTIMAL",
        cp_model.FEASIBLE: "FEASIBLE",
        cp_model.INFEASIBLE: "INFEASIBLE",
        cp_model.MODEL_INVALID: "ERROR",
        cp_model.UNKNOWN: "TIMEOUT",
    }.get(result, "UNKNOWN")

    if result not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return {
            "status": status_name,
            "tasks_with_offsets": [],
            "changeover_intervals": [],
            "solver_wall_time": solver.WallTime(),
        }

    offsets = []
    for t in tasks:
        sku = t["sku_id"]
        offsets.append({
            "sku_id": sku,
            "start_offset": int(solver.Value(starts[sku])),
            "end_offset": int(solver.Value(ends[sku])),
        })

    # Extract only the active changeover intervals
    active_cos = []
    for rec in changeover_interval_records:
        if solver.Value(rec["active_var"]) == 1:
            active_cos.append({
                "line_id": rec["line_id"],
                "from_sku": rec["from_sku"],
                "to_sku": rec["to_sku"],
                "start_offset": int(solver.Value(rec["start_var"])),
                "end_offset": int(solver.Value(rec["end_var"])),
                "duration": rec["duration"],
            })

    return {
        "status": status_name,
        "tasks_with_offsets": offsets,
        "changeover_intervals": active_cos,
        "solver_wall_time": solver.WallTime(),
    }
