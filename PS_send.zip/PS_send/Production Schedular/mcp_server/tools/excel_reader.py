"""
tools/excel_reader.py
---------------------
MCP tool: read_excel_all_sheets
Reads every sheet in an Excel workbook and returns a dict of
{sheet_name: [row_dict, ...]}. Every cell is serialised to JSON-safe
types (str / int / float / None) so it can be piped straight to any
downstream agent.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List

import pandas as pd


def _jsonable(v: Any) -> Any:
    """Convert pandas/numpy values to plain JSON-safe Python types."""
    if v is None:
        return None
    # pandas NaN check
    try:
        if pd.isna(v):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(v, (pd.Timestamp,)):
        return v.isoformat()
    if hasattr(v, "item"):  # numpy scalars
        try:
            return v.item()
        except Exception:
            return str(v)
    if isinstance(v, (int, float, str, bool)):
        return v
    return str(v)


def read_excel_all_sheets(file_path: str) -> Dict[str, Any]:
    """
    Read every sheet from the given Excel file.
    Returns:
        On success: {"sheets": {sheet_name: [row_dict, ...]}}
        On failure: {"error": "file_not_found | unreadable | empty"}
    """
    if not file_path or not os.path.exists(file_path):
        return {"error": "file_not_found"}

    try:
        xls = pd.ExcelFile(file_path)
    except Exception as e:
        return {"error": f"unreadable: {e}"}

    if not xls.sheet_names:
        return {"error": "empty"}

    sheets: Dict[str, List[Dict[str, Any]]] = {}
    for name in xls.sheet_names:
        try:
            df = pd.read_excel(xls, sheet_name=name, dtype=object)
        except Exception as e:
            # Skip unreadable sheet but keep going
            sheets[name] = []
            continue

        # Drop completely empty rows and columns
        df = df.dropna(how="all").dropna(axis=1, how="all")

        # Normalise column headers: strip whitespace, coerce to str
        df.columns = [str(c).strip() for c in df.columns]

        rows = [
            {col: _jsonable(row[col]) for col in df.columns}
            for _, row in df.iterrows()
        ]
        sheets[name] = rows

    return {"sheets": sheets}
