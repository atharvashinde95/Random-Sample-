"""
main.py
-------
Assembles the LangGraph StateGraph. Every agent writes into the
SchedulerState; between agents the supervisor() function is called
to decide the next hop.

Usage:
    python main.py /path/to/Manufacturing_Dataset.xlsx [out.json]
"""
from __future__ import annotations

import json
import sys
from typing import Any, Dict

from agents import (
    analyse_node, cost_node, ingest_node, plan_node, report_node, schedule_node,
)
from pipeline_log import log_pipeline_end, log_pipeline_start, log_route
from state import SchedulerState
from supervisor import supervisor


# ------------------------------------------------------------------
# LangGraph wiring (graceful fallback when langgraph isn't installed)
# ------------------------------------------------------------------
def build_graph():
    """Return a compiled LangGraph app, or None if langgraph is unavailable.

    Topology — hub-and-spoke via an explicit supervisor node:

        __start__ → supervisor
        supervisor -.→ ingest | analyse | plan | schedule | cost | report | __end__
        ingest  → supervisor
        analyse → supervisor
        ...

    The supervisor() function in supervisor.py is unchanged.
    Making it an explicit graph node (pass-through lambda) gives a clean
    Mermaid diagram instead of the N×N conditional-edge explosion.
    Execution behaviour is identical.
    """
    try:
        from langgraph.graph import END, StateGraph
    except ImportError:
        return None

    g = StateGraph(SchedulerState)

    # ── Agent nodes ──────────────────────────────────────────────────
    g.add_node("ingest",    ingest_node)
    g.add_node("analyse",   analyse_node)
    g.add_node("plan",      plan_node)
    g.add_node("schedule",  schedule_node)
    g.add_node("cost",      cost_node)
    g.add_node("report",    report_node)

    # ── Supervisor as an explicit pass-through node ───────────────────
    # Does NOT modify state; exists so LangGraph draws one central hub.
    g.add_node("supervisor", lambda state: state)

    # ── Entry: pipeline always starts at supervisor ───────────────────
    g.set_entry_point("supervisor")

    # ── Conditional edges: supervisor → next agent (or END) ───────────
    route_map = {
        "ingest":   "ingest",
        "analyse":  "analyse",
        "plan":     "plan",
        "schedule": "schedule",
        "cost":     "cost",
        "report":   "report",
        "__end__":  END,
    }
    g.add_conditional_edges("supervisor", supervisor, route_map)

    # ── Every agent feeds back to the supervisor ──────────────────────
    for node in ("ingest", "analyse", "plan", "schedule", "cost", "report"):
        g.add_edge(node, "supervisor")

    return g.compile()



# ------------------------------------------------------------------
# Manual sequential runner — used when LangGraph is unavailable or
# for deterministic debugging. Mirrors the supervisor routing.
# ------------------------------------------------------------------
NODE_FUNCS = {
    "ingest":   ingest_node,
    "analyse":  analyse_node,
    "plan":     plan_node,
    "schedule": schedule_node,
    "cost":     cost_node,
    "report":   report_node,
}


def run_manual(initial_state: SchedulerState,
               max_steps: int = 30) -> SchedulerState:
    state: SchedulerState = dict(initial_state)
    prev = "START"
    for _ in range(max_steps):
        nxt = supervisor(state)
        log_route(prev, nxt)
        if nxt == "__end__":
            return state
        fn = NODE_FUNCS.get(nxt)
        if fn is None:
            return state
        state = fn(state)
        prev = nxt
    return state


def run_pipeline(file_path: str) -> Dict[str, Any]:
    """Public entry. Returns the final_payload dict."""
    import time
    t0 = time.monotonic()
    log_pipeline_start(file_path)

    initial: SchedulerState = {"file_path": file_path, "agent_retry_counts": {}}

    app = build_graph()
    if app is None:
        # Fallback: deterministic supervised loop (langgraph not installed)
        final_state = run_manual(initial)
    else:
        final_state = app.invoke(initial)

    payload = final_state.get("final_payload", {"error": "no final_payload produced"})
    elapsed_ms = int((time.monotonic() - t0) * 1000)
    n_tasks = len(payload.get("gantt_tasks", []))
    log_pipeline_end(n_tasks, elapsed_ms)
    return payload


# ------------------------------------------------------------------
# CLI
# ------------------------------------------------------------------
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python main.py <excel_file> [out.json]")
        sys.exit(1)
    file_path = sys.argv[1]
    out_path = sys.argv[2] if len(sys.argv) > 2 else "final_payload.json"

    payload = run_pipeline(file_path)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, default=str)
    print(f"Wrote {out_path} ({len(payload.get('schedule_table', []))} rows).")
