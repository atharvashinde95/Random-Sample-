"""
state.py
--------
TypedDict definition of the shared state object that flows
through every LangGraph node. Each agent reads what it needs
and writes its output into new keys — no agent overwrites
another agent's keys.
"""
from typing import TypedDict, List, Dict, Any, Optional


class SchemaMapEntry(TypedDict, total=False):
    sheet_name: str
    columns: Dict[str, str]        # semantic_name -> actual_column_name
    confidence: float
    missing_fields: List[str]
    extra_fields: List[str]


class Requirement(TypedDict, total=False):
    sku_id: str
    product_name: str
    order_qty: int
    on_hand_qty: int
    expiry_date: Optional[str]
    delivery_date: str
    penalty_per_unit: float
    priority: str
    service_level: Optional[int]
    usable_inventory: int
    net_requirement: int
    needs_production: bool
    reason: str
    data_quality_flags: List[str]


class LineInfo(TypedDict, total=False):
    name: str
    sku_ids: List[str]
    shift_hours_per_day: float
    bottleneck_machine: str
    bottleneck_capacity_units_per_day: float


class CapacityInfo(TypedDict, total=False):
    line_id: str
    daily_units: float
    days_needed: float
    days_needed_ceil: int


class ChangeoverInfo(TypedDict, total=False):
    days: float
    cleaning_required: bool
    source: str                    # "dataset" or "default"


class GanttTask(TypedDict, total=False):
    task_id: str
    sku_id: str
    product_name: str
    line_id: str
    line_name: str
    start_date: str
    end_date: str
    units_to_produce: int
    type: str                      # "production" | "changeover" | "idle"
    delivery_date: str
    solver_status: str


class CostRow(TypedDict, total=False):
    sku_id: str
    holding_cost: float
    setup_cost: float
    changeover_cost: float
    penalty_cost: float
    total_cost: float
    hold_days: int
    avoided_penalty: float
    flags: List[str]


class CostSummary(TypedDict, total=False):
    total_setup_cost: float
    total_changeover_cost: float
    total_holding_cost: float
    total_penalty_cost: float
    total_schedule_cost: float
    total_avoided_penalty: float
    production_runs: int
    lines_idle: List[str]


class KpiCard(TypedDict, total=False):
    label: str
    value: str
    sub: str
    color: str


class Insight(TypedDict, total=False):
    icon: str
    title: str
    body: str


class SchedulerState(TypedDict, total=False):
    # -------- ingest --------
    file_path: str
    raw_sheets: Dict[str, List[Dict[str, Any]]]
    schema_map: Dict[str, SchemaMapEntry]
    primary_key: str
    planning_start_date: str
    ingest_warnings: List[str]
    cost_params: Dict[str, float]

    # -------- analyse --------
    requirements: List[Requirement]
    analyse_warnings: List[str]

    # -------- plan --------
    lines: Dict[str, LineInfo]
    capacity: Dict[str, CapacityInfo]
    changeovers: Dict[str, ChangeoverInfo]
    priority_ranking: List[str]
    plan_warnings: List[str]
    plan_retry_count: int

    # -------- schedule --------
    gantt_tasks: List[GanttTask]
    schedule_feasible: bool
    infeasibility_reason: Optional[str]
    schedule_warnings: List[str]
    relaxed_mode: bool

    # -------- cost --------
    cost_breakdown: List[CostRow]
    cost_summary: CostSummary

    # -------- report --------
    schedule_table: List[Dict[str, Any]]
    kpi_cards: List[KpiCard]
    insights: List[Insight]
    warnings_summary: List[str]
    final_payload: Dict[str, Any]

    # -------- control --------
    agent_retry_counts: Dict[str, int]
    next_node: Optional[str]
