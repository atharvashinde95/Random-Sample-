# agents/planning_agent.py
"""
Planning Agent — Feasibility check (via MCP tools) + LLM strategic reasoning.

Pipeline position: ingest → analyse → plan → schedule → report

AGENTIC UPGRADE:
  BEFORE: All feasibility logic lived as raw Python functions directly inside
          this module.  The agent had zero tools, making it structurally
          identical to a helper called by the supervisor — not a real agent.

  AFTER:  The agent calls planning_server MCP tools for ALL computation:
            1. run_feasibility_check  — simulates priority-ordered schedule,
                                        computes horizon, flags late/tight tasks
            2. summarise_at_risk_tasks — focused at-risk list for the LLM
          The LLM then reasons from those tool outputs, not from raw task dicts.

  This matches the tool-use pattern of every other agent:
    ingest_agent    → file_processing_server  (read_file, infer_schema, …)
    analysis_agent  → data_analysis_server    (compute_demand_summary, …)
    planning_agent  → planning_server          (run_feasibility_check, …)  ← NEW
    scheduling_agent → scheduling_server       (build_cp_sat_model, …)
    report_agent    → (direct Plotly — no MCP needed for local file I/O)
"""
import json
import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from config.llm import get_llm
from langchain_core.messages import HumanMessage
from graph.state import PlanningState
from config.settings import PLANNING_MCP_CMD, DAILY_CAPACITY_UNITS

llm = get_llm()


# ── MCP helper ────────────────────────────────────────────────────────────────

async def _call_mcp_tool(server_cmd: list, tool_name: str, args: dict) -> str:
    params = StdioServerParameters(command=server_cmd[0], args=server_cmd[1:])
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(tool_name, args)
            return result.content[0].text


# ── Node entry point ───────────────────────────────────────────────────────────

def planning_node(state: PlanningState) -> PlanningState:
    return asyncio.run(_planning_async(state))


async def _planning_async(state: PlanningState) -> PlanningState:
    tasks = state.get("tasks") or []
    if not tasks:
        return {
            **state,
            "error":      "Planning failed: no tasks found. Run analysis first.",
            "next_agent": "supervisor",
        }

    start_date    = state.get("schedule_start_date") or ""
    capacity_gaps = state.get("capacity_gaps") or []

    print(f"[PLANNING] Feasibility check: {len(tasks)} tasks, "
          f"capacity={DAILY_CAPACITY_UNITS:,}/day, start={start_date!r}")

    try:
        # ── Tool 1: run_feasibility_check ─────────────────────────────────────
        # Simulates the priority-ordered schedule and checks deadline compliance.
        feasibility_json = await _call_mcp_tool(
            PLANNING_MCP_CMD,
            "run_feasibility_check",
            {
                "tasks":          json.dumps(tasks),
                "daily_capacity": DAILY_CAPACITY_UNITS,
                "start_date":     start_date,
            },
        )
        feasibility = json.loads(feasibility_json)

        if feasibility.get("error"):
            return {
                **state,
                "error":      f"Feasibility check failed: {feasibility['error']}",
                "next_agent": "supervisor",
            }

        print(f"[PLANNING] utilisation={feasibility['utilisation_pct']}%, "
              f"at_risk={len(feasibility['tasks_at_risk'])}, "
              f"feasible={feasibility['overall_feasible']}")

        # ── Tool 2: summarise_at_risk_tasks ───────────────────────────────────
        # Produces a trimmed payload for the LLM — avoids passing the full
        # task_detail list (which can be large) into the LLM prompt.
        at_risk_json = await _call_mcp_tool(
            PLANNING_MCP_CMD,
            "summarise_at_risk_tasks",
            {"feasibility_result": feasibility_json},
        )
        # (at_risk_json is passed to the LLM implicitly via feasibility dict)

        # ── LLM: generate human-readable planning rationale ───────────────────
        rationale = _llm_planning_reasoning(feasibility, capacity_gaps)
        print(f"[PLANNING] Rationale: {len(rationale)} chars")

        return {
            **state,
            "feasibility_report": feasibility,
            "planning_rationale": rationale,
            "next_agent":         "supervisor",
        }

    except Exception as exc:
        import traceback
        traceback.print_exc()
        return {
            **state,
            "error":      f"Planning failed: {exc}",
            "next_agent": "supervisor",
        }


# ── LLM reasoning ─────────────────────────────────────────────────────────────

def _llm_planning_reasoning(feasibility: dict, capacity_gaps: list) -> str:
    """
    Produce a concise planning rationale from the MCP tool's feasibility output.
    Falls back to a formatted Python summary if the LLM is unavailable.
    """
    at_risk    = feasibility.get("tasks_at_risk", [])
    task_lines = []

    for t in feasibility.get("task_detail", []):
        slack_str = (
            f"slack={t['slack_days']} days"
            if t["slack_days"] is not None else "no deadline set"
        )
        task_lines.append(
            f"  • {t['name']}: qty={t['quantity']:,}, needs {t['duration']} day(s), "
            f"Day {t['start_day']}→{t['finish_day']}, {slack_str} [{t['status'].upper()}]"
        )

    prompt = f"""You are a senior production planner reviewing a scheduling feasibility report.

FEASIBILITY SUMMARY
  Start date       : {feasibility['start_date']}
  Planning horizon : {feasibility['horizon_days']} days
  Total demand     : {feasibility['total_demand_units']:,} units
  Production needed: {feasibility['total_prod_days']} days
  Line utilisation : {feasibility['utilisation_pct']}%
  Overall feasible : {'YES' if feasibility['overall_feasible'] else 'NO — demand exceeds available horizon'}
  Tasks at risk    : {len(at_risk)} of {len(feasibility['task_detail'])}

SIMULATED SCHEDULE (priority order, {DAILY_CAPACITY_UNITS:,} units/day):
{chr(10).join(task_lines) if task_lines else '  (no tasks)'}

CAPACITY GAPS: {json.dumps(capacity_gaps) if capacity_gaps else 'none flagged'}

Write a planning rationale of 3-5 sentences that:
1. States clearly whether the overall plan is feasible
2. Names any specific tasks that are late or tight (use exact task names from the list above)
3. Identifies the single biggest constraint
4. Gives ONE concrete, actionable recommendation (be specific — name tasks, days, quantities)

Use plain, direct language. No bullet points. No vague generalities."""

    try:
        resp = llm.invoke([HumanMessage(content=prompt)])
        text = resp.content.strip()
        if text and len(text) > 40:
            return text
    except Exception as exc:
        print(f"[PLANNING] LLM reasoning failed: {exc} — using Python fallback")

    # ── Python fallback (LLM unreachable) ─────────────────────────────────────
    lines = []
    if feasibility["overall_feasible"]:
        lines.append(
            f"✅ Feasible — {feasibility['total_prod_days']} production days fit within "
            f"the {feasibility['horizon_days']}-day horizon "
            f"({feasibility['utilisation_pct']}% utilisation)."
        )
    else:
        lines.append(
            f"❌ Not feasible — {feasibility['total_prod_days']} production days needed "
            f"but only {feasibility['horizon_days']} days available "
            f"({feasibility['utilisation_pct']}% utilisation)."
        )
    if at_risk:
        names = ", ".join(t["name"] for t in at_risk)
        lines.append(f"⚠️ Tasks at risk of missing their deadline: {names}.")
        lines.append(
            "Recommendation: consider splitting the largest order, "
            "negotiating the tightest deadline, or adding a production shift."
        )
    else:
        lines.append("All tasks are projected to meet their delivery deadlines in priority order.")

    return " ".join(lines)
