# agents/analysis_agent.py
"""
Agentic enhancement:
  BEFORE: Always ran all 3 MCP analyses blindly regardless of data or query.
  AFTER:  LLM reviews the ingested data first, flags quality issues,
          and explains which analyses are relevant to the user's query.
          The analysis summary is stored in insights for the report agent.
"""
import json
import math
import asyncio
import pandas as pd
import numpy as np
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from config.llm import get_llm
from langchain_core.messages import HumanMessage, SystemMessage
from graph.state import PlanningState
from config.settings import DATA_ANALYSIS_MCP_CMD, DAILY_CAPACITY_UNITS

llm = get_llm()


async def call_mcp_tool(server_cmd, tool_name, args):
    params = StdioServerParameters(command=server_cmd[0], args=server_cmd[1:])
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(tool_name, args)
            return result.content[0].text


def analysis_node(state: PlanningState) -> PlanningState:
    return asyncio.run(_analysis_async(state))


async def _analysis_async(state: PlanningState) -> PlanningState:
    raw_sheets = state.get("raw_sheets") or {}
    schema     = state.get("data_schema") or {}
    query      = state.get("user_query", "")

    if not raw_sheets:
        return {**state, "error": "Analysis failed: no ingested data. Run ingestion first.",
                "next_agent": "supervisor"}

    primary_sheet = _find_primary_sheet(raw_sheets, schema)
    print(f"[ANALYSIS] Primary sheet: {primary_sheet!r}")

    df        = raw_sheets[primary_sheet]
    s         = schema[primary_sheet]
    data_json = df.to_json(orient="records")

    def _safe_parse(val, label="", default=None):
        if isinstance(val, (dict, list)):
            return val
        if isinstance(val, str):
            try:
                return json.loads(val)
            except json.JSONDecodeError:
                print(f"[ANALYSIS] WARNING: Could not parse {label}: {val[:200]!r}")
                return ({} if default is None else default)
        return ({} if default is None else default)

    try:
        # ── LLM data quality review ────────────────────────────────────────────
        quality_note = _llm_data_quality_review(df, s, query)
        print(f"[ANALYSIS] Data quality note: {quality_note}")

        # ── MCP analyses ───────────────────────────────────────────────────────
        print("[ANALYSIS] Computing demand summary...")
        demand_raw = await call_mcp_tool(DATA_ANALYSIS_MCP_CMD, "compute_demand_summary", {
            "data":         data_json,
            "product_col":  s.get("product_col", ""),
            "quantity_col": s.get("quantity_col", ""),
            "period_col":   s.get("date_col", ""),
        })
        demand_summary = _safe_parse(demand_raw, "demand_summary", default={})
        print(f"[ANALYSIS] Demand summary: {len(demand_summary)} products")

        print("[ANALYSIS] Computing capacity utilisation...")
        capacity_raw = await call_mcp_tool(DATA_ANALYSIS_MCP_CMD, "compute_capacity_utilisation", {
            "data":         data_json,
            "resource_col": s.get("resource_col", ""),
            "period_col":   s.get("date_col", ""),
        })
        capacity_summary = _safe_parse(capacity_raw, "capacity_summary", default={})
        print(f"[ANALYSIS] Capacity summary: {len(capacity_summary)} resources")

        print("[ANALYSIS] Flagging capacity gaps...")
        gaps_raw = await call_mcp_tool(DATA_ANALYSIS_MCP_CMD, "flag_capacity_gaps", {
            "demand_data":   json.dumps(demand_summary) if isinstance(demand_summary, dict) else demand_raw,
            "capacity_data": json.dumps(capacity_summary) if isinstance(capacity_summary, dict) else capacity_raw,
        })
        capacity_gaps = _safe_parse(gaps_raw, "gaps", default=[])
        print(f"[ANALYSIS] Capacity gaps: {len(capacity_gaps)} entries")

        tasks = _build_tasks(df, s)
        print(f"[ANALYSIS] Built {len(tasks)} tasks")

        # Extract schedule_start_date from the data:
        # min(earliest delivery date in dataset, today) so the planning horizon
        # starts from whichever comes first — avoids hardcoding today's date.
        extracted_start = _extract_start_date(df, s)
        print(f"[ANALYSIS] Extracted schedule_start_date: {extracted_start}")

        # Surface the quality note as an insight if it flags something real
        existing_insights = state.get("insights") or ""
        if quality_note and "no issues" not in quality_note.lower():
            existing_insights = f"**📋 Data Quality Note:** {quality_note}\n\n" + existing_insights

        return {
            **state,
            "demand_summary":      demand_summary,
            "capacity_summary":    capacity_summary,
            "capacity_gaps":       capacity_gaps,
            "tasks":               tasks,
            "schedule_start_date": extracted_start,   # derived from data, not hardcoded
            "insights":            existing_insights or None,
            "next_agent":          "supervisor",
        }

    except Exception as e:
        import traceback
        traceback.print_exc()
        return {**state, "error": f"Analysis failed: {str(e)}"}


# ── LLM data quality review ────────────────────────────────────────────────────

def _llm_data_quality_review(df: pd.DataFrame, schema: dict, query: str) -> str:
    """
    LLM reviews the data and schema to flag quality issues relevant to the query.
    Returns a short plain-text note (1-2 sentences). Returns "" on failure.
    """
    missing_roles = [r for r in ["product_col", "quantity_col"] if not schema.get(r)]
    null_counts   = df.isnull().sum()
    null_cols     = null_counts[null_counts > 0].to_dict()
    row_count     = len(df)

    prompt = f"""You are a data quality analyst reviewing production planning data.

Schema inferred: {json.dumps(schema)}
Row count: {row_count}
Missing critical roles: {missing_roles if missing_roles else "none"}
Columns with nulls: {null_cols if null_cols else "none"}
User query: "{query}"

In ONE sentence, flag the most important data quality issue (if any) that could affect scheduling accuracy. If no issues, say "No issues detected." Be specific and concise."""

    try:
        resp = llm.invoke([HumanMessage(content=prompt)])
        return resp.content.strip()
    except Exception as e:
        print(f"[ANALYSIS] LLM quality review failed: {e}")
        return ""


# ── Schedule start date extraction ────────────────────────────────────────────

_DATE_FORMATS_ANALYSIS = ["%Y-%m-%d", "%d-%m-%Y", "%m-%d-%Y",
                          "%d/%m/%Y", "%m/%d/%Y", "%d %b %Y", "%b %d %Y"]


def _extract_start_date(df: pd.DataFrame, schema: dict) -> str:
    """
    Derive the schedule start date from the data rather than hardcoding today.

    Logic:
      1. Parse all values from deadline / date columns in the primary sheet.
      2. Take the earliest delivery date found.
      3. Return min(earliest_delivery_date, today) so the planning horizon
         begins from whichever comes first (handles both future and past-due scenarios).
      4. Falls back to today if no parseable dates are found.
    """
    from datetime import datetime  # fix: was `date as _date` — caused NameError
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)

    date_cols = [c for c in [schema.get("deadline_col"), schema.get("date_col")]
                 if c and c in df.columns]

    candidate_dates = []
    for col in date_cols:
        for raw in df[col].dropna().astype(str):
            raw = raw.strip()
            if raw.lower() in ("", "none", "nan", "nat"):
                continue
            for fmt in _DATE_FORMATS_ANALYSIS:
                try:
                    candidate_dates.append(datetime.strptime(raw, fmt))
                    break
                except (ValueError, TypeError):
                    continue

    if candidate_dates:
        earliest = min(candidate_dates)
        result   = min(earliest, today)   # start from whichever is earlier
    else:
        result = today

    return result.strftime("%Y-%m-%d")


# ── Sheet selection ────────────────────────────────────────────────────────────

def _find_primary_sheet(raw_sheets: dict, schema: dict) -> str:
    SCORE_MAP = {
        "quantity": (["qty", "quantity", "demand", "forecast", "amount", "order", "volume", "units"], 3),
        "product":  (["sku", "product", "item", "part", "material", "name"],                          2),
        "priority": (["priority", "urgency", "flag", "importance", "rank"],                           2),
        "date":     (["date", "week", "period", "delivery", "due", "target", "deadline"],              1),
        "service":  (["service", "sla", "level"],                                                      1),
        "resource": (["machine", "resource", "line", "station"],                                       1),
    }
    best_sheet, best_score = None, -1
    for name, df in raw_sheets.items():
        if df.empty:
            continue
        cols_lower = [c.lower().replace("_", " ") for c in df.columns]
        score, has_qty = 0, False
        for role, (keywords, weight) in SCORE_MAP.items():
            for kw in keywords:
                if any(kw in col for col in cols_lower):
                    score += weight
                    if role == "quantity":
                        has_qty = True
                    break
        if has_qty and score > best_score:
            best_score, best_sheet = score, name
    return best_sheet or list(raw_sheets.keys())[0]


# ── Task builder ───────────────────────────────────────────────────────────────

def _find_col(df: pd.DataFrame, keywords: list) -> str:
    for col in df.columns:
        if any(kw in col.lower().replace("_", " ") for kw in keywords):
            return col
    return ""


def _build_tasks(df: pd.DataFrame, schema: dict) -> list:
    product_col       = schema.get("product_col")   or _find_col(df, ["sku", "product", "item", "part", "material"])
    quantity_col      = schema.get("quantity_col")   or _find_col(df, ["qty", "quantity", "demand", "forecast", "amount", "order"])
    resource_col      = schema.get("resource_col")   or _find_col(df, ["machine", "resource", "line", "station"])
    duration_col      = schema.get("duration_col")   or _find_col(df, ["duration", "hours", "minutes", "cycle", "time", "setup"])
    deadline_col      = schema.get("deadline_col")   or _find_col(df, ["deadline", "due", "delivery", "target"])
    priority_col      = schema.get("priority_col")   or _find_col(df, ["priority", "urgency", "flag", "importance"])
    service_level_col = _find_col(df, ["service level", "service", "sla"])
    date_col          = schema.get("date_col", "")

    if not deadline_col and date_col and date_col in df.columns:
        deadline_col = date_col

    PRIORITY_MAP = {"high": 1, "urgent": 1, "critical": 1, "normal": 2, "medium": 2, "low": 3}
    tasks = []

    for i, row in df.iterrows():
        name     = str(row[product_col]) if product_col and product_col in df.columns else f"Task_{i}"
        resource = str(row[resource_col]) if resource_col and resource_col in df.columns else "Production Line"

        quantity = 1.0
        if quantity_col and quantity_col in df.columns:
            try:   quantity = max(0.0, float(row[quantity_col]))
            except: quantity = 1.0

        duration = 1
        if duration_col and duration_col in df.columns:
            try:   duration = max(1, int(float(row[duration_col])))
            except: duration = 1
        else:
            # No explicit duration column — compute from quantity and capacity
            duration = max(1, math.ceil(quantity / DAILY_CAPACITY_UNITS))

        delivery_date = ""
        if deadline_col and deadline_col in df.columns:
            delivery_date = str(row.get(deadline_col, ""))

        priority_flag = ""
        if priority_col and priority_col in df.columns:
            priority_flag = str(row.get(priority_col, "")).strip()

        priority_int  = PRIORITY_MAP.get(priority_flag.lower(), 2)

        service_level = 0.0
        if service_level_col and service_level_col in df.columns:
            try:   service_level = float(row[service_level_col])
            except: service_level = 0.0

        tasks.append({
            "name": name, "resource": resource, "duration": duration,
            "quantity": quantity, "deadline": delivery_date,
            "delivery_date": delivery_date, "priority": priority_int,
            "priority_flag": priority_flag, "service_level": service_level,
        })

    return tasks
