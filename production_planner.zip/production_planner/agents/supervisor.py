# agents/supervisor.py
"""
Truly Agentic Supervisor — ReAct (Reason + Act) Pattern
=========================================================

HOW IT WORKS:
  Every time the supervisor is called it:
    1. Builds a concise summary of the current pipeline state
    2. Sends that summary + the user query + its reasoning history to the LLM
    3. The LLM replies with THOUGHT (reasoning) + ACTION (next step)
    4. The supervisor executes that action by setting next_agent
    5. On the next turn the cycle repeats with the updated state

  This replaces the old hardcoded if/else routing with genuine LLM reasoning.
  The LLM can:
    - Skip steps it doesn't need (e.g. answer without re-running report)
    - Recover from errors by replanning
    - Explain its decisions in the scratchpad
    - Choose different paths for different query types

SAFEGUARDS:
  - Max 8 reasoning steps per user turn (prevents infinite loops)
  - If LLM output is unparseable, falls back to deterministic safe routing
  - All numerical answers are computed by Python — LLM only formats them
"""
import math
from datetime import datetime, timedelta
import pandas as pd
from config.llm import get_llm
from langchain_core.messages import HumanMessage, SystemMessage
from graph.state import PlanningState
from config.settings import DAILY_CAPACITY_UNITS

llm = get_llm()

MAX_ITERATIONS = 8

VALID_ACTIONS = {"ingest", "analyse", "plan", "schedule", "report", "answer", "chat", "end"}

# Actions in pipeline order for progression logic
_PIPELINE_ORDER = ["ingest", "analyse", "plan", "schedule", "report"]

# Production-related keywords used ONLY as a last-resort fallback when the LLM
# is completely unreachable.  The LLM is the primary intent classifier.
_PRODUCTION_KEYWORDS = [
    "schedule", "production", "gantt", "capacity", "demand", "forecast",
    "generate", "chart", "bottleneck", "priority", "makespan", "utilisation",
    "utilization", "inventory", "order", "sku", "machine", "setup", "plan",
    "report", "table", "show", "optimise", "optimize", "delay", "delivery",
]

REACT_SYSTEM = """You are an autonomous production planning agent.
Your job is to decide the SINGLE next action in a production scheduling pipeline.

AVAILABLE ACTIONS:
- chat     : Respond to greetings, chitchat, off-topic, or non-production queries directly
- ingest   : Parse the uploaded Excel/CSV file into structured data
- analyse  : Compute demand summary, capacity utilisation, build task list, extract start date
- plan     : Run feasibility check and generate LLM planning rationale (BEFORE scheduling)
- schedule : Run the production scheduler (priority-based or CP-SAT)
- report   : Generate the schedule Markdown table and Gantt chart
- answer   : Answer the user's question from the existing schedule data
- end      : Task is complete, stop

CRITICAL RULES (follow strictly):
1. If the user's message is a greeting (hi, hello, etc.), general chitchat,
   or anything NOT related to production/scheduling → use 'chat'
2. Pipeline order: ingest → analyse → plan → schedule → report
3. NEVER repeat a step that is already marked as complete in the state below
4. If DATA shows "ingested" → ingest is DONE, move forward
5. If ANALYSIS shows "complete" → analysis is DONE, move forward
6. If PLANNING shows "complete" → planning is DONE, move forward
7. If SCHEDULE shows tasks → scheduling is DONE, move forward
8. If the user asks a factual question and the schedule exists → use 'answer'
9. If the user asks to show/generate the chart or schedule and no schedule exists → run the pipeline from the next incomplete step
10. If the user asks to show/generate the chart and schedule exists → use 'report'
11. Choose the NEXT INCOMPLETE step in the pipeline, never go backwards

CRITICAL — REASONING ACCURACY:
- Your THOUGHT must be 100% consistent with the CURRENT PIPELINE STATE shown below.
- Do NOT claim a step is incomplete or not done if the state says it IS done.
- Do NOT say "file not ingested" if DATA shows "ingested".
- Do NOT say "analysis not done" if ANALYSIS shows "complete".
- Do NOT say "planning not done" if PLANNING shows "complete".
- Read the state CAREFULLY before reasoning. Contradicting the state is a critical error.

REPLY FORMAT (strictly follow this — put ACTION on its own line):
THOUGHT: <your step-by-step reasoning>
ACTION: <exactly one action from the list above>"""


# ── Entry point ────────────────────────────────────────────────────────────────

def supervisor_node(state: PlanningState) -> PlanningState:
    query = (state.get("user_query") or "").strip()

    scratchpad = list(state.get("agent_scratchpad") or [])

    # Guard: prevent infinite loops
    if len(scratchpad) >= MAX_ITERATIONS:
        return {**state, "next_agent": "end",
                "error": f"Agent reached maximum {MAX_ITERATIONS} reasoning steps."}

    state_summary = _build_state_summary(state)
    query         = state.get("user_query", "")
    error         = state.get("error")

    _llm_thought, action = _llm_react(state_summary, query, scratchpad, error)

    # ── Loop detection: if the LLM picks an action that already completed,
    #    override it with the next incomplete pipeline step ──
    action = _enforce_progression(action, state, scratchpad)

    # Build a DETERMINISTIC trace thought from actual state.
    # The LLM's raw thought is unreliable (it hallucinates stale state),
    # so we replace it with a ground-truth description.
    trace_thought = _build_trace_thought(action, state)

    print(f"[SUPERVISOR] LLM_THOUGHT: {_llm_thought}")
    print(f"[SUPERVISOR] TRACE:       {trace_thought}")
    print(f"[SUPERVISOR] ACTION:      {action}")

    scratchpad.append({"thought": trace_thought, "action": action})

    # Clear the previous turn's error now that the LLM has seen it
    new_state = {**state, "agent_scratchpad": scratchpad, "error": None}

    if action == "chat":
        reply = _generate_chat_response(query)
        return {**new_state, "next_agent": "end", "llm_answer": reply}

    if action == "answer":
        answer = _compute_and_format_answer(state)
        return {**new_state, "next_agent": "end", "llm_answer": answer}

    # For pipeline actions, require a file
    if not state.get("file_path"):
        return {**state, "next_agent": "end",
                "llm_answer": "⚠️ Please upload a file first using the sidebar."}

    return {**new_state, "next_agent": action}


def _build_trace_thought(action: str, state: PlanningState) -> str:
    """
    Build a deterministic, ground-truth reasoning trace from actual pipeline state.
    This replaces the LLM's raw THOUGHT, which often hallucinates stale information
    (e.g. 'file not ingested' when ingestion is complete).
    """
    rs    = state.get("raw_sheets")
    tasks = state.get("tasks")
    sdf   = state.get("schedule_df")
    tbl   = state.get("table_str")
    err   = state.get("error")
    feas  = state.get("feasibility_report")

    # Current state description
    parts = []
    if rs:
        sheet_info = ", ".join(f"{n} ({len(d)} rows)" for n, d in rs.items())
        parts.append(f"Data ingested: {sheet_info}")
    if tasks:
        ssd = state.get("schedule_start_date", "")
        parts.append(f"Analysis complete: {len(tasks)} tasks built"
                     + (f", start_date={ssd}" if ssd else ""))
    if feas:
        util = feas.get("utilisation_pct", "?")
        risk = len(feas.get("tasks_at_risk", []))
        parts.append(f"Planning complete: utilisation={util}%, {risk} task(s) at risk")
    if sdf is not None and not sdf.empty:
        mk = state.get('makespan', '?')
        parts.append(f"Schedule generated: {len(sdf)} tasks, {mk}-day makespan")
    if tbl:
        parts.append("Report and Gantt chart ready")
    if err:
        parts.append(f"Previous error: {err}")

    state_desc = ". ".join(parts) + "." if parts else "Pipeline not started."

    # Action rationale
    rationale_map = {
        "ingest":   "File loaded but not yet parsed → running ingestion.",
        "analyse":  "Data ingested → running demand analysis, task builder, and start date extraction.",
        "plan":     "Analysis complete → running feasibility check and planning reasoning.",
        "schedule": "Planning complete → running production scheduler.",
        "report":   "Schedule ready → generating report table and Gantt chart.",
        "answer":   "All pipeline stages complete → answering user question from schedule data.",
        "end":      "Pipeline complete. No further action needed.",
    }
    rationale = rationale_map.get(action, f"Executing: {action}")

    return f"{state_desc} {rationale}"


# ── State summary for the LLM ──────────────────────────────────────────────────

def _build_state_summary(state: PlanningState) -> str:
    lines = []

    # File
    fp = state.get("file_path")
    lines.append(f"FILE      : {'loaded (' + fp.split('/')[-1] + ')' if fp else 'NOT loaded'}")

    # Ingestion
    rs = state.get("raw_sheets")
    if rs:
        sheet_info = ", ".join(
            f"{name} ({len(df)} rows)" for name, df in rs.items()
        )
        lines.append(f"DATA      : ingested — {sheet_info}")
    else:
        lines.append("DATA      : NOT ingested")

    # Analysis — use tasks as the ground-truth signal (demand_summary can be
    # empty {} when the MCP tool errors, but tasks still get built)
    tasks = state.get("tasks")
    ds    = state.get("demand_summary")
    ssd   = state.get("schedule_start_date")
    if tasks:
        n_products = len(ds) if ds else 0
        start_info = f", start_date={ssd}" if ssd else ""
        lines.append(f"ANALYSIS  : complete — {len(tasks)} tasks built, {n_products} products in demand summary{start_info}")
    else:
        lines.append("ANALYSIS  : NOT done")

    # Planning (feasibility check + LLM rationale)
    feasibility = state.get("feasibility_report")
    if feasibility:
        util  = feasibility.get("utilisation_pct", "?")
        risk  = len(feasibility.get("tasks_at_risk", []))
        ok    = "YES" if feasibility.get("overall_feasible") else "NO"
        lines.append(f"PLANNING  : complete — feasible={ok}, utilisation={util}%, tasks_at_risk={risk}")
    else:
        lines.append("PLANNING  : NOT done")

    # Schedule
    sdf = state.get("schedule_df")
    if sdf is not None and not sdf.empty:
        lines.append(
            f"SCHEDULE  : {len(sdf)} tasks, makespan {state.get('makespan')} days, "
            f"status {state.get('solver_status')}"
        )
    else:
        lines.append("SCHEDULE  : NOT generated")

    # Report
    if state.get("table_str"):
        lines.append("REPORT    : table and Gantt chart generated")
    else:
        lines.append("REPORT    : NOT generated")

    # Calendar mapping — now derived from data by analysis_agent, not hardcoded
    ssd = state.get("schedule_start_date")
    if ssd:
        lines.append(f"START_DATE: {ssd} (derived from data — Day 1 = {ssd})")
    else:
        lines.append("START_DATE: NOT set (will be extracted during analysis)")

    # Error
    err = state.get("error")
    lines.append(f"LAST_ERROR: {err if err else 'none'}")

    return "\n".join(lines)


# ── ReAct LLM call ─────────────────────────────────────────────────────────────

def _llm_react(state_summary: str, query: str,
               scratchpad: list, error: str | None) -> tuple[str, str]:
    """
    Ask the LLM to reason about the current state and pick the next action.
    Returns (thought, action). Falls back to deterministic routing on failure.
    """
    history = ""
    if scratchpad:
        history = "\n\nPREVIOUS STEPS THIS TURN:\n" + "\n".join(
            f"Step {i+1}: THOUGHT: {s['thought']} | ACTION: {s['action']}"
            for i, s in enumerate(scratchpad)
        )

    error_block = f"\n\nERROR FROM LAST ACTION: {error}" if error else ""

    user_prompt = (
        f"CURRENT PIPELINE STATE:\n{state_summary}"
        f"{error_block}"
        f"{history}"
        f"\n\nUSER QUERY: \"{query}\""
        f"\n\nWhat is the next action?"
    )

    try:
        resp = llm.invoke([
            SystemMessage(content=REACT_SYSTEM),
            HumanMessage(content=user_prompt),
        ])
        return _parse_react_response(resp.content.strip())
    except Exception as e:
        print(f"[SUPERVISOR] LLM ReAct call failed: {e} — using deterministic fallback")
        return _deterministic_fallback(state_summary, query, error)


def _parse_react_response(text: str) -> tuple[str, str]:
    """Parse THOUGHT/ACTION from LLM output. Returns (thought, action)."""
    thought = ""
    action  = ""

    for line in text.splitlines():
        line = line.strip()
        if line.upper().startswith("THOUGHT:"):
            thought = line.split(":", 1)[1].strip()
        elif line.upper().startswith("ACTION:"):
            raw = line.split(":", 1)[1].strip().lower().split()[0].rstrip(".,:")
            if raw in VALID_ACTIONS:
                action = raw

    if not action:
        # Only search AFTER the last ACTION-like line for a valid word,
        # to avoid picking up actions mentioned in reasoning text
        action_idx = text.upper().rfind("ACTION")
        search_text = text[action_idx:].lower() if action_idx != -1 else ""
        # Prefer pipeline actions in order
        for word in ["chat", "schedule", "report", "analyse", "ingest", "answer", "end"]:
            if word in search_text:
                action = word
                break

    if not action:
        action = "end"

    if not thought:
        thought = f"LLM chose action: {action}"

    return thought, action


# ── Pipeline progression enforcement ──────────────────────────────────────────

def _step_is_complete(step: str, state: PlanningState) -> bool:
    """Check whether a pipeline step has already completed successfully."""
    if step == "ingest":
        return bool(state.get("raw_sheets"))
    elif step == "analyse":
        # Analysis is complete if tasks were built (demand_summary may be
        # empty {} when the MCP tool errors, but tasks still get created).
        return bool(state.get("tasks"))
    elif step == "plan":
        return bool(state.get("feasibility_report"))
    elif step == "schedule":
        sdf = state.get("schedule_df")
        return sdf is not None and not sdf.empty
    elif step == "report":
        return bool(state.get("table_str"))
    return False


def _next_incomplete_step(state: PlanningState) -> str:
    """Return the next pipeline step that hasn't completed, or 'end'."""
    for step in _PIPELINE_ORDER:
        if not _step_is_complete(step, state):
            return step
    return "end"


def _enforce_progression(action: str, state: PlanningState,
                         scratchpad: list) -> str:
    """
    Enforce strict pipeline ordering and prevent loops.
    Rules:
      1. 'answer'/'end' always pass through
      2. If a pipeline step already completed, skip to the next incomplete one
      3. If the LLM tries to skip ahead (e.g. report before schedule),
         redirect to the first incomplete prerequisite
      4. Detect same-action loops from the scratchpad
    """
    # If the action is 'answer', 'chat', or 'end', let it through
    if action in ("answer", "chat", "end"):
        return action

    # For pipeline actions, enforce strict ordering
    if action in _PIPELINE_ORDER:
        # If the chosen step already completed, skip ahead
        if _step_is_complete(action, state):
            corrected = _next_incomplete_step(state)
            print(f"[SUPERVISOR] OVERRIDE: '{action}' already complete → '{corrected}'")
            return corrected

        # Enforce ordering: don't allow skipping ahead past incomplete steps
        # e.g. can't run 'report' if 'analyse' or 'schedule' haven't completed
        action_idx = _PIPELINE_ORDER.index(action)
        for i in range(action_idx):
            earlier_step = _PIPELINE_ORDER[i]
            if not _step_is_complete(earlier_step, state):
                print(f"[SUPERVISOR] ORDER ENFORCED: '{action}' blocked — "
                      f"prerequisite '{earlier_step}' not complete")
                return earlier_step

    # Detect same-action loop from the last scratchpad entry
    if scratchpad:
        last_action = scratchpad[-1].get("action")
        if last_action == action and action in _PIPELINE_ORDER:
            corrected = _next_incomplete_step(state)
            print(f"[SUPERVISOR] LOOP DETECTED: '{action}' repeated → '{corrected}'")
            return corrected

    return action


def _deterministic_fallback(state_summary: str, query: str,
                            error: str | None) -> tuple[str, str]:
    """
    Safe deterministic routing used when the LLM is unavailable.
    Mirrors the minimal pipeline logic but expressed as (thought, action).
    Uses keyword heuristics ONLY as a last-resort when LLM is unreachable.
    """
    # Check if the query is production-related using keyword heuristics
    q = query.lower()
    is_production = any(kw in q for kw in _PRODUCTION_KEYWORDS)

    if not is_production and not error:
        return "Query does not appear production-related. Responding conversationally.", "chat"

    if error:
        return "An error occurred. Stopping to avoid further failures.", "end"
    if "NOT ingested" in state_summary:
        return "Data has not been ingested yet. Must ingest first.", "ingest"
    if "ANALYSIS  : NOT" in state_summary:
        return "Data ingested but analysis not done. Running analysis.", "analyse"
    if "PLANNING  : NOT" in state_summary:
        return "Analysis done but feasibility check not run. Running planning.", "plan"
    if "SCHEDULE  : NOT" in state_summary:
        return "Planning done but no schedule yet. Running scheduler.", "schedule"
    if "REPORT    : NOT" in state_summary:
        if any(w in q for w in ["gantt", "chart", "schedule", "generate", "show", "table"]):
            return "User wants to see the schedule/chart. Generating report.", "report"
        return "Schedule exists. Answering user question.", "answer"
    if "REPORT    : table" in state_summary:
        return "Report exists. Answering user question from schedule data.", "answer"
    return "Nothing more to do.", "end"


# ── Chat response (LLM-generated conversational reply) ───────────────────────

def _generate_chat_response(query: str) -> str:
    """
    Use the LLM to generate a conversational response for non-pipeline queries
    (greetings, chitchat, off-topic). Falls back to a generic message only if
    the LLM is completely unreachable.
    """
    try:
        resp = llm.invoke([
            SystemMessage(content=(
                "You are a Production Planning & Scheduling Assistant embedded in a factory tool. "
                "Respond briefly and helpfully (2-3 sentences max). "
                "For greetings, greet the user warmly and explain what you can do "
                "(production scheduling, capacity analysis, Gantt charts, demand forecasting). "
                "For off-topic or non-production questions, politely explain that you "
                "specialise in production planning and redirect the user."
            )),
            HumanMessage(content=query),
        ])
        return resp.content.strip()
    except Exception as e:
        print(f"[SUPERVISOR] Chat LLM call failed: {e} — using fallback response")
        return (
            "🏭 I'm your **Production Planning Assistant**. "
            "I can help with production scheduling, capacity analysis, and Gantt charts. "
            "Upload a file and ask me a production planning question to get started!"
        )


# ── Answer generation (Python facts → LLM formatting) ────────────────────────

def _compute_and_format_answer(state: PlanningState) -> str:
    """
    Dispatch to the correct data-computation function based on query,
    then ask the LLM to format a natural answer from the computed facts.
    The LLM receives ONLY pre-computed Python facts — it cannot hallucinate numbers.
    """
    df         = state.get("schedule_df", pd.DataFrame())
    makespan   = state.get("makespan", int(df["Finish"].max()) if not df.empty else "?")
    query      = state.get("user_query", "")
    start_date = state.get("schedule_start_date")  # may be None

    if df is None or df.empty:
        return "No schedule data found. Please generate the schedule first."

    intent = _classify_intent(query)
    print(f"[SUPERVISOR] Answer intent: {intent!r}")

    if intent == "first_product":
        facts = _facts_first_product(df, start_date)
    elif intent == "bottleneck":
        facts = _facts_bottleneck(df, makespan)
    elif intent == "capacity_gap":
        return _capacity_gap_analysis(df, makespan)
    elif intent == "risk":
        return _risk_analysis(df, makespan)
    elif intent == "makespan":
        facts = _facts_makespan(df, makespan, start_date)
    elif intent == "high_priority":
        facts = _facts_priority(df, makespan, "high")
    elif intent == "low_priority":
        facts = _facts_priority(df, makespan, "low")
    elif intent == "summary":
        facts = _facts_summary(df, makespan, start_date)
    else:
        return (
            "👋 I'm your **Production Planning Assistant**.\n\n"
            "Try asking:\n"
            "- *Which product should be produced first?*\n"
            "- *Which product is the bottleneck?*\n"
            "- *Flag any capacity gaps*\n"
            "- *How many days does the schedule take?*\n"
            "- *Show me the Gantt chart*"
        )

    return _llm_format_answer(query, facts)


def _classify_intent(query: str) -> str:
    """LLM classifies the question into an answer category."""
    if not query.strip():
        return "off_topic"

    prompt = (
        "Classify this production planning question into exactly one category.\n"
        f'Question: "{query}"\n\n'
        "Categories: first_product, bottleneck, capacity_gap, risk, "
        "makespan, high_priority, low_priority, summary, off_topic\n\n"
        "Reply with ONLY the category name."
    )
    try:
        resp = llm.invoke([HumanMessage(content=prompt)])
        cat  = resp.content.strip().lower().split()[0].rstrip(".,:") 
        if cat in {"first_product", "bottleneck", "capacity_gap", "risk",
                   "makespan", "high_priority", "low_priority", "summary", "off_topic"}:
            return cat
    except Exception as e:
        print(f"[SUPERVISOR] Intent LLM failed: {e}")

    return _keyword_intent(query)


def _keyword_intent(query: str) -> str:
    q = query.lower()
    if any(w in q for w in ["first", "start with", "begin", "produce first"]):
        return "first_product"
    if any(w in q for w in ["bottleneck", "slowest", "longest", "constraint"]):
        return "bottleneck"
    if any(w in q for w in ["capacity", "gap", "overload", "flag", "utilisation"]):
        return "capacity_gap"
    if any(w in q for w in ["risk", "risky", "danger", "critical path"]):
        return "risk"
    if any(w in q for w in ["how many days", "makespan", "how long", "total days"]):
        return "makespan"
    if any(w in q for w in ["high priority", "urgent"]):
        return "high_priority"
    if any(w in q for w in ["low priority", "last product"]):
        return "low_priority"
    if any(w in q for w in ["summary", "overview", "tell me"]):
        return "summary"
    return "off_topic"


def _llm_format_answer(query: str, facts: dict) -> str:
    """LLM formats pre-computed facts into a natural answer. Cannot invent numbers."""
    facts_text = "\n".join(f"  {k}: {v}" for k, v in facts.items())
    system = (
        "You are a production planning assistant. "
        "Answer using ONLY the facts provided. "
        "Do NOT invent or estimate any numbers, dates, or SKU names not in the facts."
    )
    prompt = (
        f"User question: {query}\n\n"
        f"Computed facts (use ONLY these):\n{facts_text}\n\n"
        "Write a clear, concise answer in 2-4 sentences."
    )
    try:
        resp = llm.invoke([SystemMessage(content=system), HumanMessage(content=prompt)])
        ans  = resp.content.strip()
        if ans and len(ans) > 10:
            return ans
    except Exception as e:
        print(f"[SUPERVISOR] Format LLM failed: {e}")

    return "\n\n".join(f"**{k}:** {v}" for k, v in facts.items())


# ── Date helper ───────────────────────────────────────────────────────────────

def _day_to_date_str(day_num: int, start_date_str: str) -> str:
    """Convert a schedule Day number to a calendar date string (dd-Mon-YYYY)."""
    try:
        base = datetime.strptime(start_date_str, "%Y-%m-%d")
        actual = base + timedelta(days=day_num - 1)
        return actual.strftime("%d-%b-%Y")
    except (ValueError, TypeError):
        return f"Day {day_num}"


# ── Facts computation (pure Python — zero hallucination) ──────────────────────

def _facts_first_product(df: pd.DataFrame, start_date: str = None) -> dict:
    row = df.iloc[0]
    scheduled = f"Day {row['Start']} → Day {row['Finish']}"
    if start_date:
        scheduled += f" ({_day_to_date_str(int(row['Start']), start_date)} → {_day_to_date_str(int(row['Finish']), start_date)})"
    return {
        "First SKU":      row["Task"],
        "Priority":       row.get("Priority", "N/A"),
        "Service Level":  f"{row.get('Service_Level', '')}%",
        "Delivery Date":  row.get("Delivery_Date", "N/A"),
        "Quantity":       f"{int(row.get('Quantity', 0)):,} units",
        "Scheduled":      scheduled,
        "Reason":         "Highest priority, then highest service level, then earliest delivery date",
    }


def _facts_bottleneck(df: pd.DataFrame, makespan) -> dict:
    """
    Multi-factor bottleneck scoring:
      1. Line utilisation  = (units/day) / daily_capacity  → saturation
      2. Cascade factor    = downstream_jobs × duration    → ripple effect
      3. Critical path     = +30 if Finish == makespan
    """
    daily_cap = DAILY_CAPACITY_UNITS
    n         = len(df)
    mk        = int(makespan) if str(makespan).isdigit() else int(df["Finish"].max())

    scored = []
    for _, row in df.iterrows():
        qty       = max(1.0, float(row.get("Quantity", 1)))
        dur       = max(1,   int(row.get("Duration", 1)))
        finish    = int(row.get("Finish", 0))
        seq       = int(row.get("Sequence", 1))

        util_rate  = (qty / dur) / daily_cap
        cascade    = (n - seq) * dur * 2
        cp_bonus   = 30 if finish == mk else 0
        score      = util_rate * 100 + cascade + cp_bonus

        scored.append({
            "row": row, "score": score,
            "util_pct": round(util_rate * 100, 1),
            "daily_out": round(qty / dur, 1),
            "downstream": n - seq,
            "on_cp": finish == mk,
        })

    best = max(scored, key=lambda x: x["score"])
    row  = best["row"]

    return {
        "Bottleneck SKU":     row["Task"],
        "Why":               (
            f"Highest composite bottleneck score — "
            f"line utilisation {best['util_pct']}% of {daily_cap:,} units/day, "
            f"{best['downstream']} downstream jobs at risk"
        ),
        "Daily throughput":   f"{best['daily_out']:,} units/day",
        "Duration":           f"{int(row['Duration'])} days",
        "Quantity":           f"{int(row.get('Quantity', 0)):,} units",
        "Scheduled":          f"Day {int(row['Start'])} → Day {int(row['Finish'])}",
        "On critical path":   "Yes — sets the schedule end date" if best["on_cp"] else "No",
        "Downstream at risk": best["downstream"],
        "Recommendation":     "Add buffer capacity, split the order, or negotiate delivery date.",
    }


def _facts_makespan(df: pd.DataFrame, makespan, start_date: str = None) -> dict:
    first_start = int(df.iloc[0]['Start'])
    last_finish = int(df.iloc[-1]['Finish'])
    first_job = f"{df.iloc[0]['Task']} starts Day {first_start}"
    last_job  = f"{df.iloc[-1]['Task']} finishes Day {last_finish}"
    if start_date:
        first_job += f" ({_day_to_date_str(first_start, start_date)})"
        last_job  += f" ({_day_to_date_str(last_finish, start_date)})"
    facts = {
        "Total makespan":  f"{makespan} days",
        "First job":       first_job,
        "Last job":        last_job,
        "Total SKUs":      len(df),
        "Total units":     f"{int(df['Quantity'].sum()):,}",
    }
    if start_date:
        try:
            base = datetime.strptime(start_date, "%Y-%m-%d")
            end  = base + timedelta(days=int(makespan) - 1)
            facts["Schedule period"] = f"{base.strftime('%d-%b-%Y')} → {end.strftime('%d-%b-%Y')}"
        except (ValueError, TypeError):
            pass
    return facts


def _facts_priority(df: pd.DataFrame, makespan, level: str) -> dict:
    if "Priority" not in df.columns:
        return {"Note": "No priority column in schedule."}
    if level == "high":
        mask  = df["Priority"].str.lower().isin(["high", "urgent", "critical"])
        label = "High-priority SKUs"
    else:
        mask  = df["Priority"].str.lower().isin(["low"])
        label = "Low-priority SKUs"
    subset = df[mask]
    if subset.empty:
        return {label: "None found."}
    items = "; ".join(
        f"{r['Task']} (Day {int(r['Start'])}–{int(r['Finish'])}, "
        f"{int(r.get('Quantity', 0)):,} units)"
        for _, r in subset.iterrows()
    )
    return {label: items, "Count": len(subset), "Makespan": f"{makespan} days"}


def _facts_summary(df: pd.DataFrame, makespan, start_date: str = None) -> dict:
    row_parts = []
    for _, r in df.iterrows():
        s, f = int(r['Start']), int(r['Finish'])
        part = (f"Seq {int(r.get('Sequence','?'))}: {r['Task']} "
                f"Day {s}–{f}")
        if start_date:
            part += f" ({_day_to_date_str(s, start_date)}–{_day_to_date_str(f, start_date)})"
        part += f" ({int(r.get('Quantity',0)):,} units, {r.get('Priority','')})"
        row_parts.append(part)
    facts = {
        "Schedule":    "; ".join(row_parts),
        "Makespan":    f"{makespan} days",
        "Total SKUs":  len(df),
        "Total units": f"{int(df['Quantity'].sum()):,}",
    }
    if start_date:
        try:
            base = datetime.strptime(start_date, "%Y-%m-%d")
            end  = base + timedelta(days=int(makespan) - 1)
            facts["Schedule period"] = f"{base.strftime('%d-%b-%Y')} → {end.strftime('%d-%b-%Y')}"
        except (ValueError, TypeError):
            pass
    return facts


# ── Rich formatted outputs ────────────────────────────────────────────────────

def _risk_analysis(df: pd.DataFrame, makespan) -> str:
    max_dur     = df["Duration"].max()
    last_finish = df["Finish"].max()
    mk          = int(makespan) if str(makespan).isdigit() else int(last_finish)

    lines = [f"### 🚨 Schedule Risk Analysis  _(Makespan: {makespan} days)_\n",
             "_Risk based on duration, position, and cascade impact._\n"]
    high, medium, low = [], [], []

    for _, row in df.iterrows():
        task, dur, start, finish = row["Task"], int(row["Duration"]), int(row["Start"]), int(row["Finish"])
        qty, seq = int(row.get("Quantity", 0)), int(row.get("Sequence", 0))

        if dur == max_dur:
            high.append(f"🔴 **{task}** — Day {start}–{finish} ({dur} days, {qty:,} units)\n"
                        f"   → Longest job. Delay cascades to all downstream SKUs.")
        elif finish == last_finish:
            high.append(f"🔴 **{task}** — Day {start}–{finish} ({dur} days)\n"
                        f"   → Last job. Highest risk of missing delivery deadline.")
        elif seq == 1:
            medium.append(f"🟠 **{task}** — Day {start}–{finish} ({dur} days)\n"
                          f"   → First job. Startup delay ripples across entire plan.")
        elif start > mk * 0.3 and dur > 1:
            medium.append(f"🟠 **{task}** — Day {start}–{finish} ({dur} days)\n"
                          f"   → Mid-schedule. Delay shifts all subsequent jobs.")
        else:
            low.append(f"🟢 **{task}** — Day {start}–{finish} ({dur} days) — Low risk")

    if high:   lines += ["#### 🔴 High Risk",   *high,   ""]
    if medium: lines += ["#### 🟠 Medium Risk", *medium, ""]
    if low:    lines += ["#### 🟢 Low Risk",    *low,    ""]

    bot = df.loc[df["Duration"].idxmax()]
    lines.append(f"**💡 Insight:** Protect **{bot['Task']}** "
                 f"(Day {int(bot['Start'])}–{int(bot['Finish'])}, {int(bot['Duration'])} days) — critical bottleneck.")
    return "\n".join(lines)


def _capacity_gap_analysis(df: pd.DataFrame, makespan) -> str:
    capacity  = DAILY_CAPACITY_UNITS
    daily_load: dict = {}
    daily_skus: dict = {}

    for _, row in df.iterrows():
        start, finish = int(row["Start"]), int(row["Finish"])
        qty   = float(row.get("Quantity", 0))
        days  = max(1, finish - start + 1)
        per_d = qty / days
        for day in range(start, finish + 1):
            daily_load[day] = daily_load.get(day, 0.0) + per_d
            daily_skus.setdefault(day, []).append(row["Task"])

    overloaded, warnings, ok_days = [], [], []
    for day in sorted(daily_load):
        load = daily_load[day]
        util = load / capacity * 100
        skus = ", ".join(daily_skus[day])
        entry = f"Day {day:>2}: {load:>7,.0f} / {capacity:,} units ({util:.0f}%) — {skus}"
        if util > 100:  overloaded.append(f"🔴 {entry}  ← **OVERLOADED**")
        elif util > 80: warnings.append(f"🟡 {entry}  ← HIGH")
        else:           ok_days.append(f"🟢 {entry}")

    lines = ["### 📊 Capacity Gap Analysis",
             f"_Limit: **{capacity:,} units/day** | Makespan: **{makespan} days** | SKUs: **{len(df)}**_\n"]
    if overloaded: lines += ["#### 🔴 Overloaded (>100%)", *overloaded, ""]
    if warnings:   lines += ["#### 🟡 High Load (>80%)",  *warnings,   ""]
    lines += ["#### 🟢 Normal", *(ok_days or ["All days within normal range."]), ""]

    if overloaded:   lines.append(f"**⚠️ {len(overloaded)} overloaded day(s). Consider splitting large orders.**")
    elif warnings:   lines.append(f"**⚠️ {len(warnings)} high-load day(s). Any disruption risks overload.**")
    else:            lines.append(f"**✅ No overloads. All days within {capacity:,} units/day.**")
    return "\n".join(lines)
