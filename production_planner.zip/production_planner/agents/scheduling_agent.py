# agents/scheduling_agent.py
"""
Agentic enhancement:
  BEFORE: Hardcoded rule — "if len(resources) <= 1: use priority else use CP-SAT"
          No reasoning, no explanation, no consideration of data characteristics.
  AFTER:  LLM reasons about the task data and decides which scheduler to use,
          explaining its choice. The reasoning is stored in state["scheduler_reasoning"]
          so the user can understand why a particular approach was taken.

Fix retained:
  solver_status = "PRIORITY-SEQUENCED" for the heuristic path (not "OPTIMAL").
  "OPTIMAL" / "FEASIBLE" are reserved for CP-SAT proven results.
"""
import io
import json
import math
import asyncio
from datetime import datetime, timedelta

import pandas as pd

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from config.llm import get_llm
from langchain_core.messages import HumanMessage
from graph.state import PlanningState
from config.settings import SCHEDULING_MCP_CMD, SOLVER_TIME_LIMIT_SEC, DAILY_CAPACITY_UNITS

llm = get_llm()

_PRIORITY_ORDER = {"high": 1, "urgent": 1, "critical": 1,
                   "normal": 2, "medium": 2, "low": 3}
_DATE_FORMATS   = ["%Y-%m-%d", "%d-%m-%Y", "%m-%d-%Y",
                   "%d/%m/%Y", "%m/%d/%Y", "%d %b %Y", "%b %d %Y"]


def _priority_key(task):
    raw = str(task.get("priority_flag", task.get("priority", ""))).strip().lower()
    return int(raw) if raw.isdigit() else _PRIORITY_ORDER.get(raw, 2)


def _service_level_key(task):
    try:    return -float(task.get("service_level", 0))
    except: return 0.0


def _date_key(task):
    raw = str(task.get("delivery_date", task.get("deadline", ""))).strip()
    if not raw or raw.lower() in ("", "none", "nan", "nat"):
        return "9999-12-31"
    for fmt in _DATE_FORMATS:
        try:    return datetime.strptime(raw, fmt).strftime("%Y-%m-%d")
        except: continue
    return raw


# ── LLM scheduler decision ─────────────────────────────────────────────────────

def _llm_choose_scheduler(tasks: list) -> tuple[str, str]:
    """
    Ask the LLM to reason about the task data and decide which scheduler is most
    appropriate. Returns (choice, reasoning) where choice is 'priority' or 'cpsat'.
    Falls back to the hardcoded rule if LLM fails.
    """
    resources    = list({t.get("resource", "Production Line") for t in tasks})
    n_tasks      = len(tasks)
    has_deadlines = any(t.get("deadline", "").strip() not in ("", "none", "nan", "nat")
                        for t in tasks)
    priorities   = list({t.get("priority_flag", "").lower() for t in tasks if t.get("priority_flag")})

    prompt = f"""You are a production scheduling expert. Choose the best scheduling algorithm for this dataset.

Dataset characteristics:
- Number of tasks: {n_tasks}
- Distinct resources: {resources}
- Has delivery deadlines: {has_deadlines}
- Priority levels present: {priorities}

Algorithm options:
- priority : Fast greedy heuristic. Best for single-resource, priority-driven schedules.
             Sorts by priority → service level → delivery date. Result: "PRIORITY-SEQUENCED".
- cpsat    : OR-Tools CP-SAT exact solver. Best for multi-resource problems where
             minimising makespan mathematically matters. Slower but proves optimality.

Reason briefly (2-3 sentences), then state your choice.

Reply format:
REASONING: <your reasoning>
CHOICE: <priority or cpsat>"""

    try:
        resp = llm.invoke([HumanMessage(content=prompt)])
        text = resp.content.strip()

        reasoning = ""
        choice    = ""
        for line in text.splitlines():
            line = line.strip()
            if line.upper().startswith("REASONING:"):
                reasoning = line.split(":", 1)[1].strip()
            elif line.upper().startswith("CHOICE:"):
                raw = line.split(":", 1)[1].strip().lower()
                if "cpsat" in raw or "cp-sat" in raw or "cp_sat" in raw:
                    choice = "cpsat"
                elif "priority" in raw:
                    choice = "priority"

        if choice in ("priority", "cpsat"):
            return choice, reasoning or f"LLM chose {choice} scheduler."

    except Exception as e:
        print(f"[SCHEDULING] LLM scheduler decision failed: {e} — using rule fallback")

    # Rule fallback
    if len(resources) <= 1 or all(r in ("Production Line", "Machine_1", "") for r in resources):
        return "priority", "Single production line detected — priority-based scheduler is appropriate."
    return "cpsat", "Multiple distinct resources detected — CP-SAT solver required for conflict-free scheduling."


# ── Priority scheduler ────────────────────────────────────────────────────────

def _priority_finite_capacity_schedule(tasks: list, daily_capacity: int) -> list:
    sorted_tasks = sorted(
        tasks,
        key=lambda t: (_priority_key(t), _service_level_key(t), _date_key(t))
    )
    schedule, current_day = [], 1
    for seq, task in enumerate(sorted_tasks, start=1):
        qty        = max(1.0, float(task.get("quantity", 1)))
        days_needed = max(1, math.ceil(qty / daily_capacity))
        start_day  = current_day
        end_day    = start_day + days_needed - 1
        schedule.append({
            "Sequence":      seq,
            "Task":          task["name"],
            "Resource":      task.get("resource", "Production Line"),
            "Start":         start_day,
            "Finish":        end_day,
            "Duration":      days_needed,
            "Quantity":      int(qty),
            "Priority":      task.get("priority_flag") or str(task.get("priority", "")),
            "Service_Level": task.get("service_level", ""),
            "Delivery_Date": task.get("delivery_date", task.get("deadline", "")),
        })
        current_day = end_day + 1
    return schedule


# ── Delivery slack analysis (JIT awareness without idle gaps) ──────────────────

def _compute_delivery_slack(schedule: list, schedule_start_date: str | None) -> list:
    """
    Compute delivery slack (buffer days) for each task WITHOUT moving anything.

    For a single production line, tasks MUST stay packed from Day 1 with zero
    idle gaps. Shifting tasks right creates an idle factory — economically worse
    than producing early.

    Instead, we compute:
      slack = due_date_as_day - finish_day

    Positive slack  → task finishes BEFORE due date (buffer available)
    Zero slack      → on time (exact match)
    Negative slack  → task finishes AFTER due date (LATE — risk!)

    This gives the planner visibility without breaking utilization.
    """
    if not schedule or not schedule_start_date:
        return schedule

    try:
        base_date = datetime.strptime(schedule_start_date, "%Y-%m-%d")
    except (ValueError, TypeError):
        return schedule

    def _due_date_to_day(raw_date: str) -> int | None:
        """Convert a delivery date string to a day number (1-based)."""
        raw = str(raw_date).strip()
        if not raw or raw.lower() in ("", "none", "nan", "nat"):
            return None
        for fmt in _DATE_FORMATS:
            try:
                dt = datetime.strptime(raw, fmt)
                delta = (dt - base_date).days + 1  # Day 1 = base_date
                return delta if delta > 0 else None
            except (ValueError, TypeError):
                continue
        return None

    enriched = []
    for row in schedule:
        row = row.copy()
        due_day = _due_date_to_day(row.get("Delivery_Date", ""))
        if due_day is not None:
            finish = int(row["Finish"])
            row["Slack_Days"] = due_day - finish   # positive = early, negative = late
        else:
            row["Slack_Days"] = ""  # no due date → can't compute
        enriched.append(row)

    return enriched


# ── CP-SAT via MCP ────────────────────────────────────────────────────────────

async def _call_mcp_tool(server_cmd, tool_name, args):
    params = StdioServerParameters(command=server_cmd[0], args=server_cmd[1:])
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(tool_name, args)
            return result.content[0].text


def _safe_parse(val, default=None):
    if isinstance(val, (dict, list)): return val
    if isinstance(val, str):
        try:    return json.loads(val)
        except: return default if default is not None else {}
    return default if default is not None else {}


async def _cp_sat_schedule(tasks: list):
    print(f"[SCHEDULING] Building CP-SAT model with {len(tasks)} tasks...")
    model_json    = await _call_mcp_tool(SCHEDULING_MCP_CMD, "build_cp_sat_model", {"tasks": json.dumps(tasks)})
    solution_json = await _call_mcp_tool(SCHEDULING_MCP_CMD, "solve_schedule",
                                         {"model_state": model_json, "time_limit_sec": SOLVER_TIME_LIMIT_SEC})
    solution      = _safe_parse(solution_json)

    if solution.get("status") == "INFEASIBLE":
        diag   = _safe_parse(await _call_mcp_tool(SCHEDULING_MCP_CMD, "check_feasibility", {"model_state": model_json}))
        issues = "; ".join(diag.get("issues", ["Infeasible — unknown reason."]))
        raise RuntimeError(f"INFEASIBLE: {issues}")

    results_json = await _call_mcp_tool(SCHEDULING_MCP_CMD, "extract_schedule_results",
                                        {"solution": solution_json, "tasks": json.dumps(tasks)})
    df = pd.read_json(io.StringIO(results_json), orient="records") if isinstance(results_json, str) else pd.DataFrame(results_json)
    return df, solution.get("status"), solution.get("makespan")


# ── Node entry point ───────────────────────────────────────────────────────────

def scheduling_node(state: PlanningState) -> PlanningState:
    return asyncio.run(_scheduling_async(state))


async def _scheduling_async(state: PlanningState) -> PlanningState:
    tasks = state.get("tasks", [])
    if not tasks:
        return {**state, "error": "No tasks available to schedule."}

    daily_capacity = DAILY_CAPACITY_UNITS

    # LLM decides which scheduler to use
    choice, reasoning = _llm_choose_scheduler(tasks)
    print(f"[SCHEDULING] LLM initial choice: {choice} — {reasoning}")

    # Hard guard: single resource → always use priority scheduler
    resources = list({t.get("resource", "Production Line") for t in tasks})
    if len(resources) <= 1:
        if choice != "priority":
            print(f"[SCHEDULING] OVERRIDE: Single resource '{resources[0]}' detected → forcing priority scheduler")
        choice = "priority"
        reasoning = (f"Single resource detected ({resources[0]}). "
                     "Priority-based finite-capacity scheduler is the efficient heuristic for single-line scheduling.")

    try:
        if choice == "priority":
            print(f"[SCHEDULING] Running priority scheduler (capacity: {daily_capacity} units/day)...")
            rows          = _priority_finite_capacity_schedule(tasks, daily_capacity)

            # Compute delivery slack (buffer days) — tasks stay packed, no idle gaps
            start_date = state.get("schedule_start_date")
            rows = _compute_delivery_slack(rows, start_date)

            schedule_df   = pd.DataFrame(rows)
            solver_status = "PRIORITY-SEQUENCED"   # heuristic — not mathematically optimal
            makespan      = int(schedule_df["Finish"].max()) if not schedule_df.empty else 0
            print(f"[SCHEDULING] Done — {len(schedule_df)} tasks, makespan: {makespan} days")
        else:
            # Ensure CP-SAT tasks have capacity-aware durations
            for t in tasks:
                qty = max(1.0, float(t.get("quantity", 1)))
                t["duration"] = max(t.get("duration", 1), math.ceil(qty / daily_capacity))
            print(f"[SCHEDULING] Running CP-SAT solver (capacity-adjusted durations)...")
            schedule_df, solver_status, makespan = await _cp_sat_schedule(tasks)

        # Sanity check: reject mathematically impossible schedules
        _validate_schedule(schedule_df, tasks, daily_capacity)

        return {
            **state,
            "schedule_df":        schedule_df,
            "makespan":           makespan,
            "solver_status":      solver_status,
            "scheduler_reasoning": reasoning,
            "next_agent":         "supervisor",
        }

    except Exception as e:
        import traceback
        traceback.print_exc()
        return {**state, "error": f"Scheduling failed: {str(e)}"}


def _validate_schedule(schedule_df: pd.DataFrame, tasks: list, daily_capacity: int):
    """Reject schedules that violate basic capacity physics."""
    if schedule_df is None or schedule_df.empty:
        return
    total_qty = sum(max(0, float(t.get("quantity", 0))) for t in tasks)
    makespan  = int(schedule_df["Finish"].max())
    # For single-resource (sequential) scheduling, minimum makespan = ceil(total/capacity)
    resources = list({t.get("resource", "Production Line") for t in tasks})
    if len(resources) <= 1:
        min_makespan = math.ceil(total_qty / daily_capacity) if daily_capacity > 0 else 1
        if makespan < min_makespan:
            raise ValueError(
                f"Schedule makespan ({makespan} days) violates capacity constraint. "
                f"Total demand={total_qty:,.0f}, capacity={daily_capacity:,}/day, "
                f"minimum feasible={min_makespan} days."
            )
