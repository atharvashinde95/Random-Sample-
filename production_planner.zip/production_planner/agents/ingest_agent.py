# agents/ingest_agent.py
"""
Agentic enhancement:
  BEFORE: Pure heuristic keyword matching for schema inference.
          Silently wrong if column names are unusual (e.g. "fcst_vol", "deliv_dt").
  AFTER:  Two-pass schema inference:
          1. Heuristic keyword scan (fast, always runs)
          2. LLM validation pass — LLM sees actual column names + sample rows
             and can correct or fill gaps the heuristic missed.
          The two results are merged: LLM wins on any key it is confident about.
"""
import io
import json
import asyncio
import pandas as pd
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from config.llm import get_llm
from langchain_core.messages import HumanMessage
from graph.state import PlanningState
from config.settings import FILE_PROCESSING_MCP_CMD

llm = get_llm()


async def call_mcp_tool(server_cmd: list, tool_name: str, args: dict):
    params = StdioServerParameters(command=server_cmd[0], args=server_cmd[1:])
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(tool_name, args)
            return result.content[0].text


def ingest_node(state: PlanningState) -> PlanningState:
    return asyncio.run(_ingest_node_async(state))


async def _ingest_node_async(state: PlanningState) -> PlanningState:
    file_path = state.get("file_path")
    if not file_path:
        return {**state, "error": "No file path provided."}

    try:
        # Step 1: Read file via MCP
        print(f"[INGEST] Reading file: {file_path}")
        raw_json = await call_mcp_tool(
            FILE_PROCESSING_MCP_CMD, "read_file", {"file_path": file_path}
        )
        raw_data = json.loads(raw_json)
        print(f"[INGEST] Read {len(raw_data)} sheet(s): {list(raw_data.keys())}")

        raw_sheets = {name: pd.DataFrame(rows) for name, rows in raw_data.items()}

        # Step 2: Two-pass schema inference per sheet
        schema = {}
        for sheet_name, df in raw_sheets.items():
            cols = list(df.columns)
            print(f"[INGEST] Schema inference for {sheet_name!r} ({len(df)} rows)")

            # Pass 1: fast heuristic
            heuristic = _infer_schema_heuristic(cols)
            print(f"[INGEST] Heuristic schema: {heuristic}")

            # Pass 2: LLM validation with sample data
            sample = df.head(3).to_dict(orient="records")
            llm_schema = _llm_validate_schema(cols, sample, heuristic)
            print(f"[INGEST] LLM-validated schema: {llm_schema}")

            # Merge: LLM overrides heuristic where it has a confident answer
            merged = {**heuristic, **llm_schema}
            # Remove any LLM keys that point to non-existent columns
            merged = {k: v for k, v in merged.items() if v in cols}
            schema[sheet_name] = merged
            print(f"[INGEST] Final merged schema: {schema[sheet_name]}")

        # Step 3: Clean data via MCP
        cleaned_sheets = {}
        for sheet_name, df in raw_sheets.items():
            clean_json = await call_mcp_tool(
                FILE_PROCESSING_MCP_CMD,
                "validate_and_clean_data",
                {
                    "data":          df.to_json(orient="records"),
                    "column_schema": json.dumps(schema[sheet_name]),
                }
            )
            cleaned_sheets[sheet_name] = pd.read_json(
                io.StringIO(clean_json), orient="records"
            )

        print(f"[INGEST] Complete. Sheets: {list(cleaned_sheets.keys())}")
        return {
            **state,
            "raw_sheets":  cleaned_sheets,
            "data_schema": schema,
            "next_agent":  "supervisor",
        }

    except Exception as e:
        import traceback
        traceback.print_exc()
        return {**state, "error": f"Ingest failed: {type(e).__name__}: {e}"}


# ── Pass 1: heuristic keyword scan ───────────────────────────────────────────

def _infer_schema_heuristic(columns: list) -> dict:
    schema    = {}
    col_lower = {c: c.lower().replace("_", " ") for c in columns}
    role_keywords = {
        "date_col":     ["date", "week", "period", "month", "day", "delivery"],
        "product_col":  ["sku", "product", "item", "part", "material"],
        "quantity_col": ["qty", "quantity", "demand", "forecast qty", "amount",
                         "count", "volume", "order qty", "on hand", "forecast"],
        "resource_col": ["machine", "resource", "station", "line", "work center"],
        "duration_col": ["duration", "hours", "minutes", "cycle", "setup",
                         "processing", "time sec", "time min", "std time"],
        "priority_col": ["priority", "urgent", "flag", "importance"],
        "deadline_col": ["deadline", "due", "target"],
    }
    for role, keywords in role_keywords.items():
        for col, lower in col_lower.items():
            if any(kw in lower for kw in keywords):
                schema[role] = col
                break
    return schema


# ── Pass 2: LLM validation ────────────────────────────────────────────────────

def _llm_validate_schema(columns: list, sample_rows: list, heuristic: dict) -> dict:
    """
    Ask the LLM to verify and improve the heuristic schema using actual column
    names and sample data. Returns only keys the LLM is confident about.
    Falls back silently if the LLM fails.
    """
    prompt = f"""You are a data engineer. Given these column names and sample data from a production planning spreadsheet, identify the semantic role of each relevant column.

Column names: {columns}

Sample data (first 3 rows):
{json.dumps(sample_rows, indent=2)}

Current heuristic guess: {json.dumps(heuristic)}

Identify which column corresponds to each role. Only include roles you are confident about.
Valid roles: date_col, product_col, quantity_col, resource_col, duration_col, priority_col, deadline_col

Return ONLY a JSON object. No explanation. No markdown. Example:
{{"product_col": "sku_id", "quantity_col": "fcst_vol", "date_col": "deliv_dt"}}"""

    try:
        resp = llm.invoke([HumanMessage(content=prompt)])
        text = resp.content.strip()

        # Strip markdown fences if present
        if text.startswith("```"):
            parts = text.split("```")
            if len(parts) >= 2:
                text = parts[1].lstrip("json").strip()

        # Extract JSON object
        start, end = text.find("{"), text.rfind("}")
        if start != -1 and end != -1:
            candidate = text[start:end + 1]
            parsed    = json.loads(candidate)
            # Only keep valid role keys
            valid_roles = {"date_col", "product_col", "quantity_col",
                           "resource_col", "duration_col", "priority_col", "deadline_col"}
            return {k: v for k, v in parsed.items() if k in valid_roles}
    except Exception as e:
        print(f"[INGEST] LLM schema validation failed: {e} — using heuristic only")

    return {}
