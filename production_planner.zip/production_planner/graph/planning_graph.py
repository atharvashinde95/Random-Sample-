# graph/planning_graph.py
from langgraph.graph import StateGraph, END
from graph.state import PlanningState
from agents.supervisor import supervisor_node
from agents.ingest_agent import ingest_node
from agents.analysis_agent import analysis_node
from agents.planning_agent import planning_node
from agents.scheduling_agent import scheduling_node
from agents.report_agent import report_node


def route_from_supervisor(state: PlanningState) -> str:
    """
    Read state['next_agent'] set by supervisor_node and return the
    name of the next graph node to execute.
    Valid values: 'ingest', 'analyse', 'plan', 'schedule', 'report', 'end'
    """
    return state.get("next_agent", "end")


def build_graph():
    graph = StateGraph(PlanningState)

    # Register nodes
    graph.add_node("supervisor", supervisor_node)
    graph.add_node("ingest",     ingest_node)
    graph.add_node("analyse",    analysis_node)
    graph.add_node("plan",       planning_node)       # NEW: feasibility + LLM reasoning
    graph.add_node("schedule",   scheduling_node)
    graph.add_node("report",     report_node)

    # Entry point
    graph.set_entry_point("supervisor")

    # Supervisor routes conditionally
    graph.add_conditional_edges("supervisor", route_from_supervisor, {
        "ingest":   "ingest",
        "analyse":  "analyse",
        "plan":     "plan",
        "schedule": "schedule",
        "report":   "report",
        "end":       END,
    })

    # After each agent, always return to supervisor
    graph.add_edge("ingest",   "supervisor")
    graph.add_edge("analyse",  "supervisor")
    graph.add_edge("plan",     "supervisor")          # NEW
    graph.add_edge("schedule", "supervisor")
    graph.add_edge("report",    END)   # Report is always the last step

    return graph.compile()


# Singleton compiled graph
planning_graph = build_graph()
