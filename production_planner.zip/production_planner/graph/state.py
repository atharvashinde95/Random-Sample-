# graph/state.py
from typing import TypedDict, Optional, Any


class PlanningState(TypedDict):
    # Conversation
    messages:   list          # Full conversation history (HumanMessage / AIMessage)
    user_query: str           # Latest user message text

    # File
    file_path: Optional[str]  # Path to uploaded file (.xlsx / .csv)
    file_type: Optional[str]  # 'excel' or 'csv'

    # Ingestion outputs
    raw_sheets:  Optional[dict]   # { sheet_name: pd.DataFrame }
    data_schema: Optional[dict]   # Inferred column roles per sheet

    # Analysis outputs
    demand_summary:   Optional[dict]  # { product: { period: qty } }
    capacity_summary: Optional[dict]  # { resource: utilisation_fraction }
    capacity_gaps:    Optional[list]  # [{ resource, utilisation, flag }]

    # Scheduling outputs
    tasks:              Optional[list]   # Rich task dicts for the scheduler
    schedule_df:        Optional[Any]    # pd.DataFrame
    makespan:           Optional[int]    # Total schedule length in days
    solver_status:      Optional[str]    # 'PRIORITY-SEQUENCED' / 'OPTIMAL' / 'FEASIBLE'
    scheduler_reasoning: Optional[str]  # LLM's explanation of why it chose this scheduler

    # Planning outputs (feasibility check + LLM rationale — runs before scheduling)
    feasibility_report:  Optional[dict]  # Structured feasibility data from planning_agent
    planning_rationale:  Optional[str]   # LLM's strategic planning reasoning

    # Report outputs
    table_str:  Optional[str]   # Markdown-formatted schedule table
    gantt_path: Optional[str]   # Absolute path to saved Gantt chart HTML
    insights:   Optional[str]   # Planner insight text block (Markdown)
    llm_answer: Optional[str]   # Contextual question answer

    # Calendar mapping
    schedule_start_date: Optional[str]  # User-supplied schedule start date (YYYY-MM-DD)

    # Agentic control
    next_agent:       Optional[str]   # Supervisor routing decision
    error:            Optional[str]   # Error message if any agent fails
    agent_scratchpad: Optional[list]  # ReAct loop history: [{thought, action}]
