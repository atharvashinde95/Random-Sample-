#!/usr/bin/env python3
# chatbot/cli.py
"""
CLI fallback interface for the Production Planning System.
Usage:
    python chatbot/cli.py
    python chatbot/cli.py --file path/to/data.xlsx
"""
import argparse
import os
import sys

# Allow running from any directory
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from langchain_core.messages import HumanMessage
from graph.planning_graph import planning_graph
from graph.state import PlanningState


def make_initial_state(file_path: str | None = None) -> PlanningState:
    return PlanningState(
        messages=[], user_query="", file_path=file_path,
        file_type=("csv" if file_path and file_path.endswith(".csv") else "excel") if file_path else None,
        raw_sheets=None, schema=None, demand_summary=None,
        capacity_summary=None, capacity_gaps=None, tasks=None,
        schedule_df=None, makespan=None, solver_status=None,
        table_str=None, gantt_path=None, next_agent=None, error=None,
    )


def format_result(result: dict) -> str:
    lines = []
    if result.get("error"):
        lines.append(f"\n⚠  Error: {result['error']}")
    if result.get("capacity_gaps"):
        alerts = [g for g in result["capacity_gaps"] if g["flag"] != "OK"]
        if alerts:
            lines.append("\nCapacity Alerts:")
            for g in alerts:
                lines.append(f"  [{g['flag']}] {g['resource']}: {g['utilisation']}%")
    if result.get("solver_status"):
        lines.append(f"\nSolver: {result['solver_status']} | Makespan: {result.get('makespan')} time units")
    if result.get("table_str"):
        lines.append("\nProduction Schedule:")
        lines.append(result["table_str"])
    if result.get("gantt_path"):
        lines.append(f"\nGantt chart saved: {result['gantt_path']}")
    if not lines:
        lines.append("Done. Ask me to generate a schedule or Gantt chart.")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Production Planning CLI")
    parser.add_argument("--file", help="Path to Excel/CSV file to load on startup")
    args = parser.parse_args()

    state = make_initial_state(args.file)

    print("=" * 60)
    print("  Production Planning & Scheduling Assistant (CLI)")
    print("  Type 'quit' or 'exit' to stop.")
    print("  Type 'load <path>' to load a file.")
    print("=" * 60)
    if args.file:
        print(f"  File loaded: {args.file}")
    print()

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit"):
            print("Goodbye.")
            break
        if user_input.lower().startswith("load "):
            path = user_input[5:].strip()
            if os.path.exists(path):
                state = make_initial_state(path)
                print(f"  ✓ Loaded: {path}\n")
            else:
                print(f"  ✗ File not found: {path}\n")
            continue

        state["user_query"] = user_input
        state["messages"].append(HumanMessage(content=user_input))

        try:
            result = planning_graph.invoke(state)
            state = result
            print(format_result(result))
            print()
        except Exception as e:
            print(f"\n⚠  Exception: {e}\n")


if __name__ == "__main__":
    main()
