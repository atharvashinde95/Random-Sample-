# mcp_servers/planning_server.py
"""
Planning MCP Server
===================
Provides the feasibility-check tools that planning_agent.py calls.

WHY THIS EXISTS:
  The old planning_agent embedded the feasibility simulation directly as raw
  Python functions inside the agent module.  That made it the only agent with
  no tools — a pattern inconsistency that also made the logic untestable in
  isolation.  Moving the computation here gives planning_agent the same
  tool-based structure as every other agent in the pipeline.

TOOLS:
  run_feasibility_check    — simulate priority-ordered schedule, flag late tasks
  summarise_at_risk_tasks  — extract a focused at-risk list for LLM reasoning
"""
import json
import math
import sys
import os
from datetime import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastmcp import FastMCP

mcp = FastMCP("planning")

_DATE_FORMATS = [
    "%Y-%m-%d", "%d-%m-%Y", "%m-%d-%Y",
    "%d/%m/%Y", "%m/%d/%Y", "%d %b %Y", "%b %d %Y",
]

_PRIORITY_ORDER = {
    "high": 1, "urgent": 1, "critical": 1,
    "normal": 2, "medium": 2,
    "low": 3,
}


# ── Internal helpers ──────────────────────────────────────────────────────────

def _parse_json_or_obj(val):
    if isinstance(val, (dict, list)):
        return val
    if isinstance(val, str):
        try:
            return json.loads(val)
        except json.JSONDecodeError:
            return []
    return []


def _parse_date(raw: str) -> datetime | None:
    if not raw or str(raw).strip().lower() in ("", "none", "nan", "nat"):
        return None
    raw = str(raw).strip()
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(raw, fmt)
        except (ValueError, TypeError):
            continue
    return None


def _priority_sort_key(task: dict) -> tuple:
    """Sort key: priority (1=high) → service_level (desc) → due_date (asc)."""
    raw  = str(task.get("priority_flag", task.get("priority", ""))).strip().lower()
    prio = int(raw) if raw.isdigit() else _PRIORITY_ORDER.get(raw, 2)
    try:
        svc = -float(task.get("service_level", 0))
    except (ValueError, TypeError):
        svc = 0.0
    due_raw = str(task.get("deadline", task.get("delivery_date", ""))).strip()
    due_dt  = _parse_date(due_raw)
    due_str = due_dt.strftime("%Y-%m-%d") if due_dt else "9999-12-31"
    return (prio, svc, due_str)


# ── MCP Tools ─────────────────────────────────────────────────────────────────

@mcp.tool()
def run_feasibility_check(tasks, daily_capacity: int = 2000,
                           start_date: str = "") -> str:
    """
    Simulate a priority-ordered sequential schedule and check whether each
    task can meet its delivery deadline.

    Args:
        tasks          : JSON list of task dicts (name, quantity, deadline/
                         delivery_date, priority_flag, service_level).
        daily_capacity : Units produced per day (default 2000).
        start_date     : Schedule start date in YYYY-MM-DD format.
                         If empty, horizon = total_prod_days (no calendar check).

    Returns JSON dict:
        horizon_days        — days from start_date to the latest deadline
        total_demand_units  — sum of all task quantities
        total_prod_days     — sum of ceil(qty/capacity) for each task
        utilisation_pct     — total_prod_days / horizon_days × 100
        overall_feasible    — True if demand fits inside the horizon
        start_date          — echoed back (or 'not set')
        tasks_at_risk       — list of tasks where status is 'late' or 'tight'
        task_detail         — per-task breakdown list (all tasks, sorted by priority)

    Each task_detail entry:
        name, quantity, duration, start_day, finish_day,
        due_day, slack_days, status, priority, service_level

    Status values: 'ok' | 'tight' (≤2 days buffer) | 'on_time_exact' |
                   'late' (negative slack) | 'no_deadline'
    """
    task_list = _parse_json_or_obj(tasks)
    if not task_list:
        return json.dumps({"error": "No tasks provided"})

    # Parse schedule start date
    base_date = None
    if start_date and start_date.strip():
        try:
            base_date = datetime.strptime(start_date.strip(), "%Y-%m-%d")
        except (ValueError, TypeError):
            pass

    sorted_tasks    = sorted(task_list, key=_priority_sort_key)
    total_demand    = sum(max(0.0, float(t.get("quantity", 1))) for t in task_list)
    total_prod_days = sum(
        max(1, math.ceil(max(0.0, float(t.get("quantity", 1))) / daily_capacity))
        for t in task_list
    )

    # Horizon = distance from start_date to the latest deadline
    # (but at minimum equal to total_prod_days so utilisation ≤ 100% is possible)
    deadline_dates = []
    for t in task_list:
        dt = _parse_date(str(t.get("deadline", t.get("delivery_date", ""))))
        if dt and base_date:
            deadline_dates.append(dt)

    if deadline_dates and base_date:
        horizon_days = max((max(deadline_dates) - base_date).days + 1, total_prod_days)
    else:
        horizon_days = total_prod_days   # no calendar — horizon = production demand

    utilisation_pct  = round(total_prod_days / horizon_days * 100, 1) if horizon_days > 0 else 100.0
    overall_feasible = total_prod_days <= horizon_days

    # Simulate sequential schedule (packed from Day 1, no idle gaps)
    task_detail   = []
    tasks_at_risk = []
    current_day   = 1

    for t in sorted_tasks:
        qty      = max(1.0, float(t.get("quantity", 1)))
        dur      = max(1, math.ceil(qty / daily_capacity))
        start_d  = current_day
        finish_d = current_day + dur - 1

        due_dt  = _parse_date(str(t.get("deadline", t.get("delivery_date", ""))))
        due_day = None
        slack   = None
        status  = "no_deadline"

        if due_dt and base_date:
            due_day = (due_dt - base_date).days + 1
            slack   = due_day - finish_d
            if slack < 0:
                status = "late"
            elif slack == 0:
                status = "on_time_exact"
            elif slack <= 2:
                status = "tight"
            else:
                status = "ok"

        detail = {
            "name":          t["name"],
            "quantity":      int(qty),
            "duration":      dur,
            "start_day":     start_d,
            "finish_day":    finish_d,
            "due_day":       due_day,
            "slack_days":    slack,
            "status":        status,
            "priority":      str(t.get("priority_flag", t.get("priority", ""))),
            "service_level": t.get("service_level", ""),
        }
        task_detail.append(detail)

        if status in ("late", "tight"):
            tasks_at_risk.append(detail)

        current_day = finish_d + 1

    return json.dumps({
        "horizon_days":       horizon_days,
        "total_demand_units": int(total_demand),
        "total_prod_days":    total_prod_days,
        "utilisation_pct":    utilisation_pct,
        "overall_feasible":   overall_feasible,
        "tasks_at_risk":      tasks_at_risk,
        "task_detail":        task_detail,
        "start_date":         start_date.strip() if start_date else "not set",
    })


@mcp.tool()
def summarise_at_risk_tasks(feasibility_result) -> str:
    """
    Extract a concise at-risk summary from a run_feasibility_check result.

    Returns JSON list of dicts:
        { name, slack_days, status, due_day, finish_day }

    Designed to be fed directly into the LLM reasoning step — smaller payload,
    lower token cost than passing the full feasibility result.
    """
    result = _parse_json_or_obj(feasibility_result)
    if isinstance(result, dict) and result.get("error"):
        return json.dumps([])

    at_risk = result.get("tasks_at_risk", [])
    return json.dumps([
        {
            "name":       t["name"],
            "slack_days": t["slack_days"],
            "status":     t["status"],
            "due_day":    t["due_day"],
            "finish_day": t["finish_day"],
        }
        for t in at_risk
    ])


if __name__ == "__main__":
    mcp.run(transport="stdio")
