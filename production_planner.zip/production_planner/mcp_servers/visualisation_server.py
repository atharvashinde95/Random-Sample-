import io
# mcp_servers/visualisation_server.py
import json
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pandas as pd
import plotly.express as px
from fastmcp import FastMCP

mcp = FastMCP("visualisation")


def _to_dataframe(data) -> pd.DataFrame:
    """Convert data to DataFrame, handling both JSON strings and pre-parsed lists."""
    if isinstance(data, str):
        return pd.read_json(io.StringIO(data), orient="records")
    elif isinstance(data, list):
        return pd.DataFrame(data)
    elif isinstance(data, pd.DataFrame):
        return data
    return pd.DataFrame()


@mcp.tool()
def format_schedule_table(data) -> str:
    """
    Convert schedule JSON (orient='records') to a Markdown table string.
    Returns the table as a plain string ready to paste in chat.
    Columns shown: Task, Resource, Start, Finish, Duration, Quantity
    """
    df = _to_dataframe(data)
    preferred = ["Task", "Resource", "Start", "Finish", "Duration", "Quantity"]
    cols = [c for c in preferred if c in df.columns]
    if not cols:
        cols = list(df.columns)
    df = df[cols].sort_values("Start") if "Start" in df.columns else df[cols]

    # Build Markdown table
    header    = "| " + " | ".join(cols) + " |"
    separator = "|" + "|".join([" --- "] * len(cols)) + "|"
    rows = []
    for _, row in df.iterrows():
        rows.append("| " + " | ".join(str(row[c]) for c in cols) + " |")
    return "\n".join([header, separator] + rows)


@mcp.tool()
def generate_gantt_chart(data, output_dir: str = "./outputs",
                         filename: str = "production_gantt") -> str:
    """
    Generate a Plotly Gantt chart from schedule data.
    Uses px.timeline — converts integer Start/Finish to relative dates from Day 0.
    Saves as HTML (interactive).
    Returns the absolute path to the saved HTML file.
    """
    print(f"[GANTT] Generating chart, output_dir={output_dir}")
    os.makedirs(output_dir, exist_ok=True)
    df = _to_dataframe(data)

    # Convert integer time units to datetime for px.timeline
    if "Start" in df.columns and pd.api.types.is_integer_dtype(df["Start"]):
        base = pd.Timestamp("2024-01-01")
        df["Start"]  = df["Start"].apply(lambda x: base + pd.Timedelta(days=int(x)))
        df["Finish"] = df["Finish"].apply(lambda x: base + pd.Timedelta(days=int(x)))

    color_col = "Resource" if "Resource" in df.columns else df.columns[0]
    y_col     = "Resource" if "Resource" in df.columns else df.columns[0]

    fig = px.timeline(
        df,
        x_start="Start",
        x_end="Finish",
        y=y_col,
        color=color_col,
        text="Task" if "Task" in df.columns else None,
        title="Production Schedule — Gantt Chart",
        labels={"Resource": "Machine / Resource", "Task": "Production Task"},
        color_discrete_sequence=px.colors.qualitative.Set2,
    )
    fig.update_yaxes(autorange="reversed")
    fig.update_layout(
        xaxis_title="Timeline (Days)",
        yaxis_title="Resource",
        font=dict(family="Arial", size=12),
        plot_bgcolor="#f8f9fa",
        paper_bgcolor="white",
        height=max(400, len(df[y_col].unique()) * 60 + 200),
        showlegend=True,
    )

    html_path = os.path.abspath(os.path.join(output_dir, filename + ".html"))
    fig.write_html(html_path)
    print(f"[GANTT] Saved HTML to {html_path}")
    return html_path


@mcp.tool()
def get_critical_path(data) -> str:
    """
    Identify the critical path: the chain of tasks with the latest finish time
    on each resource, which collectively determines the makespan.
    Returns JSON list of task names on the critical path.
    """
    df = _to_dataframe(data)
    if df.empty or "Finish" not in df.columns:
        return json.dumps([])

    max_finish = df["Finish"].max()
    # Tasks that finish at or near the makespan are on the critical path
    critical = df[df["Finish"] == max_finish]["Task"].tolist()
    return json.dumps(critical)


if __name__ == "__main__":
    mcp.run(transport="stdio")
