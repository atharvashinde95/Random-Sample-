import io
# mcp_servers/scheduling_server.py
import json
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastmcp import FastMCP
from ortools.sat.python import cp_model
import pandas as pd

mcp = FastMCP("scheduling")


def _parse_json_or_obj(val):
    """Parse a JSON string or return the object as-is if already parsed by MCP."""
    if isinstance(val, str):
        return json.loads(val)
    return val


@mcp.tool()
def build_cp_sat_model(tasks, daily_capacity: int = 2000) -> str:
    """
    Build a CP-SAT model from a JSON list of task dicts.
    Each task dict: { name, resource, duration, quantity, deadline, priority }
    duration must be a positive integer (time units).
    Returns a JSON model_state dict containing all variable assignments.

    Note: OR-Tools objects cannot be serialised — we store the task list and
    resource mapping; solve_schedule rebuilds the model from this state.
    """
    task_list = _parse_json_or_obj(tasks)

    # Ensure durations are positive ints and reflect capacity constraints
    for t in task_list:
        raw_dur = max(1, int(t.get("duration", 1)))
        qty     = max(1, int(t.get("quantity", 1)))
        # If duration looks wrong (1 day for large quantity), recompute
        capacity_dur = max(1, -(-qty // daily_capacity))  # ceiling division
        t["duration"] = max(raw_dur, capacity_dur)

    # Compute horizon = sum of all durations (worst case upper bound)
    horizon = sum(t["duration"] for t in task_list) + 1

    # Group tasks by resource
    resource_to_tasks: dict = {}
    for i, t in enumerate(task_list):
        res = t.get("resource", "default")
        resource_to_tasks.setdefault(res, []).append(i)

    model_state = {
        "tasks":              task_list,
        "resource_to_tasks":  resource_to_tasks,
        "horizon":            horizon,
    }
    return json.dumps(model_state)


@mcp.tool()
def solve_schedule(model_state, time_limit_sec: int = 30) -> str:
    """
    Rebuild CP-SAT model from model_state and solve.
    Returns JSON: { status, makespan, assignments: [{task_idx, start, end}] }
    Status: 'OPTIMAL' | 'FEASIBLE' | 'INFEASIBLE' | 'UNKNOWN'
    """
    state     = _parse_json_or_obj(model_state)
    task_list = state["tasks"]
    resource_to_tasks = state["resource_to_tasks"]
    horizon   = state["horizon"]

    model = cp_model.CpModel()
    all_starts, all_ends, all_intervals = [], [], []

    for i, t in enumerate(task_list):
        s  = model.NewIntVar(0, horizon, f"s{i}")
        e  = model.NewIntVar(0, horizon, f"e{i}")
        iv = model.NewIntervalVar(s, t["duration"], e, f"iv{i}")
        all_starts.append(s)
        all_ends.append(e)
        all_intervals.append(iv)

    # No-overlap constraint per resource
    for res, indices in resource_to_tasks.items():
        model.AddNoOverlap([all_intervals[i] for i in indices])

    # Makespan variable and minimisation objective
    makespan_var = model.NewIntVar(0, horizon, "makespan")
    model.AddMaxEquality(makespan_var, all_ends)
    model.Minimize(makespan_var)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit_sec
    status = solver.Solve(model)

    status_map = {
        cp_model.OPTIMAL:    "OPTIMAL",
        cp_model.FEASIBLE:   "FEASIBLE",
        cp_model.INFEASIBLE: "INFEASIBLE",
        cp_model.UNKNOWN:    "UNKNOWN",
    }
    result = {
        "status":    status_map.get(status, "UNKNOWN"),
        "makespan":  int(solver.ObjectiveValue()) if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None,
        "assignments": [],
    }
    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        for i in range(len(task_list)):
            result["assignments"].append({
                "task_idx": i,
                "start":    int(solver.Value(all_starts[i])),
                "end":      int(solver.Value(all_ends[i])),
            })
    return json.dumps(result)


@mcp.tool()
def extract_schedule_results(solution, tasks) -> str:
    """
    Convert CP-SAT solver output into a clean schedule DataFrame.
    Returns JSON (orient='records') with columns:
      Sequence, Task, Resource, Start, Finish, Duration, Quantity,
      Priority, Service_Level, Delivery_Date
    """
    sol       = _parse_json_or_obj(solution)
    task_list = _parse_json_or_obj(tasks)
    rows = []
    for seq, a in enumerate(sol.get("assignments", []), start=1):
        i = a["task_idx"]
        t = task_list[i]
        rows.append({
            "Sequence":      seq,
            "Task":          t["name"],
            "Resource":      t.get("resource", "Machine_1"),
            "Start":         a["start"],
            "Finish":        a["end"],
            "Duration":      t["duration"],
            "Quantity":      t.get("quantity", 1),
            "Priority":      t.get("priority_flag", t.get("priority", "")),
            "Service_Level": t.get("service_level", ""),
            "Delivery_Date": t.get("delivery_date", t.get("deadline", "")),
        })
    df = pd.DataFrame(rows).sort_values("Start").reset_index(drop=True)
    # Re-sequence after sorting
    df["Sequence"] = range(1, len(df) + 1)
    return df.to_json(orient="records")


@mcp.tool()
def check_feasibility(model_state) -> str:
    """
    Simple feasibility diagnosis: returns a human-readable explanation
    of why the model might be infeasible (e.g., total demand > horizon).
    Returns JSON: { 'issues': ['...'] }
    """
    state     = _parse_json_or_obj(model_state)
    task_list = state["tasks"]
    resource_to_tasks = state["resource_to_tasks"]
    horizon   = state["horizon"]
    issues    = []

    total_duration = sum(t["duration"] for t in task_list)
    if total_duration > horizon:
        issues.append(
            f"Total duration {total_duration} exceeds horizon {horizon}"
        )
    for res, idxs in resource_to_tasks.items():
        res_duration = sum(task_list[i]["duration"] for i in idxs)
        if res_duration > horizon:
            issues.append(
                f"Resource '{res}' has total work {res_duration} > horizon {horizon}"
            )
    if not issues:
        issues.append("No obvious infeasibility detected — check data quality.")
    return json.dumps({"issues": issues})


if __name__ == "__main__":
    mcp.run(transport="stdio")
