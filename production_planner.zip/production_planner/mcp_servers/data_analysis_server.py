import io
# mcp_servers/data_analysis_server.py
import json
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pandas as pd
import numpy as np
from fastmcp import FastMCP

mcp = FastMCP("data-analysis")


def _to_dataframe(data) -> pd.DataFrame:
    """Convert data to DataFrame, handling both JSON strings and pre-parsed lists."""
    if isinstance(data, str):
        return pd.read_json(io.StringIO(data), orient="records")
    elif isinstance(data, list):
        return pd.DataFrame(data)
    elif isinstance(data, pd.DataFrame):
        return data
    return pd.DataFrame()


def _parse_json_or_obj(val):
    """Parse a JSON string or return the object as-is if already parsed."""
    if isinstance(val, str):
        return json.loads(val)
    return val


@mcp.tool()
def compute_demand_summary(data, product_col: str,
                           quantity_col: str, period_col: str) -> str:
    """
    Aggregate demand by product and period.
    Returns JSON: { 'Product_A': { 'Week1': 100, 'Week2': 80 }, ... }
    If period_col is empty string, groups by product only.
    """
    df = _to_dataframe(data)

    if not product_col or product_col not in df.columns:
        product_col = df.columns[0]
    if not quantity_col or quantity_col not in df.columns:
        num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        quantity_col = num_cols[0] if num_cols else df.columns[1]

    if period_col and period_col in df.columns:
        grouped = df.groupby([product_col, period_col])[quantity_col].sum().reset_index()
        result = {}
        for prod, grp in grouped.groupby(product_col):
            result[str(prod)] = dict(zip(grp[period_col].astype(str), grp[quantity_col]))
    else:
        grouped = df.groupby(product_col)[quantity_col].sum()
        result = {str(k): float(v) for k, v in grouped.items()}

    return json.dumps(result)


@mcp.tool()
def compute_capacity_utilisation(data, resource_col: str, period_col: str) -> str:
    """
    Calculate what fraction of time each resource is busy.
    Returns JSON: { 'Machine_A': 0.87, 'Machine_B': 0.62 }
    If resource_col is missing, returns empty dict.
    """
    df = _to_dataframe(data)
    if not resource_col or resource_col not in df.columns:
        # No resource column — treat as single production line
        return json.dumps({"Production Line": 1.0})
    counts = df[resource_col].value_counts(normalize=True)
    return json.dumps({str(k): round(float(v), 4) for k, v in counts.items()})


@mcp.tool()
def detect_demand_peaks(data, product_col: str,
                        quantity_col: str, period_col: str) -> str:
    """
    Identify time periods where demand spikes above the mean + 1 std deviation.
    Returns JSON list: [{ 'period': ..., 'product': ..., 'demand': ..., 'threshold': ... }]
    """
    df = _to_dataframe(data)
    if not quantity_col or quantity_col not in df.columns:
        return json.dumps([])

    peaks = []
    mean_val = df[quantity_col].mean()
    std_val  = df[quantity_col].std()
    threshold = mean_val + std_val

    for _, row in df.iterrows():
        val = row.get(quantity_col, 0)
        if val > threshold:
            peaks.append({
                "period":    str(row.get(period_col, "")) if period_col and period_col in df.columns else "",
                "product":   str(row.get(product_col, "")) if product_col and product_col in df.columns else "",
                "demand":    float(val),
                "threshold": round(float(threshold), 2),
            })
    return json.dumps(peaks)


@mcp.tool()
def flag_capacity_gaps(demand_data, capacity_data) -> str:
    """
    Compare demand totals against capacity utilisation.
    Returns JSON list: [{ 'resource': ..., 'utilisation': ..., 'flag': ... }]
    Flags: OVERLOADED (>100%), AT_CAPACITY (85-100%), HIGH (70-85%), OK (<70%)
    """
    capacity = _parse_json_or_obj(capacity_data)
    if not isinstance(capacity, dict):
        return json.dumps([])
    gaps = []
    for resource, util in capacity.items():
        if util > 1.0:
            flag = "OVERLOADED"
        elif util >= 0.85:
            flag = "AT_CAPACITY"
        elif util >= 0.70:
            flag = "HIGH"
        else:
            flag = "OK"
        gaps.append({
            "resource":    resource,
            "utilisation": round(util * 100, 1),
            "flag":        flag,
        })
    return json.dumps(gaps)


if __name__ == "__main__":
    mcp.run(transport="stdio")
